-- Generic initial preferences. Copy only if this radio has no RF2 settings.lua.
return { useLvgl = 1, uiTheme = "light", useAdjustmentTeller = 0, autoSetName = 0 }
