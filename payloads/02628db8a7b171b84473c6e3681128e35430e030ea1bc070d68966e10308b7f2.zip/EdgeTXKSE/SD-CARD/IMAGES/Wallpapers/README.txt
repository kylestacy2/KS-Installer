KSE wallpaper and startup images

SYS > Appearance > Wallpaper & Startup lists PNG, JPG and BMP files
from /IMAGES/Wallpapers. Add your own images here.

KSE Dark.png and KSE Light.png are sample dashboard wallpapers.
Set Dashboard > Options > Dashboard theme to Transparent and turn
theme matching Off to see wallpaper through the dashboard tiles.

splash.png: orange startup artwork
splash2.png: American flag startup artwork
splash-canada.png: Canadian flag startup artwork

Select an image, preview it, then apply. Both settings are radio-wide.
Use theme default restores the theme wallpaper. Use splash.png restores
the original /IMAGES/splash.png. Previously saved image paths still work.
The installer keeps existing images and adds missing files.
