The firmware writes Lua fault reports and exported performance captures here. Keep this folder on the SD card. Do not erase a report before sending it to Kyle.
