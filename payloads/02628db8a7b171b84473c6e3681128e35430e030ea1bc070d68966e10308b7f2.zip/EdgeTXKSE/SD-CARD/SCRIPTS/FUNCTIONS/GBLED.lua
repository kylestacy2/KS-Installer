-- Gimbal LEDs - model-based color mapping for EdgeTX 2.12
-- Screen-independent special function (no UI)

local CONFIG_PATH = "/SCRIPTS/RGBLED/model_leds_config.lua"

-- Slots 13-16 are reserved by Custom Colors (see README). This RAM-only
-- handoff preserves the latch across the separate editor/function Lua states.
local SHM_BASE = 13
local SHM_TAG = 4408064
local function readHandoff(enable, disable, editorOnly)
    if type(getShmVar) ~= "function" then return nil end
    local ok, tag, en, dis, stamp = pcall(function()
        return getShmVar(SHM_BASE), getShmVar(SHM_BASE + 1),
            getShmVar(SHM_BASE + 2), getShmVar(SHM_BASE + 3)
    end)
    if not ok or type(tag) ~= "number" or type(stamp) ~= "number" then return nil end
    local flags = tag - SHM_TAG
    local age = getTime() - stamp
    if flags < 0 or flags > 3 or flags ~= math.floor(flags) or age < 0 or age > 200
        or (enable ~= nil and (en ~= enable or dis ~= disable)) or (editorOnly and flags < 2) then return nil end
    return flags % 2 == 1, en, dis
end
local function publishHandoff(enable, disable, enabled, editor)
    if type(setShmVar) ~= "function" then return end
    pcall(function()
        setShmVar(SHM_BASE + 1, enable)
        setShmVar(SHM_BASE + 2, disable)
        setShmVar(SHM_BASE + 3, getTime())
        setShmVar(SHM_BASE, SHM_TAG + (enabled and 1 or 0) + (editor and 2 or 0))
    end)
end

local function normalizeSwitch(value)
    value = tonumber(value)
    if not value or value ~= math.floor(value) or math.abs(value) > 32767 then return 0 end
    return value
end

-- Keep the same switch behavior as the Custom Colors editor preview.
local function switchControlEnabled(enable, disable, previous)
    if enable == 0 and disable == 0 then return true end
    if type(getSwitchValue) ~= "function" then return false end
    local function active(index)
        if index == 0 then return false end
        local ok, value = pcall(getSwitchValue, index)
        return ok and value == true
    end
    if active(disable) then return false end
    if active(enable) then return true end
    if enable == 0 then return true end
    if disable == 0 then return false end
    return previous == true
end

local COLORS = {
    OFF    = { r = 0,   g = 0,   b = 0   },
    WHITE  = { r = 255, g = 255, b = 255 },
    PURPLE = { r = 255, g = 0,   b = 255 },
    ORANGE = { r = 255, g = 100, b = 0   },
    YELLOW = { r = 255, g = 255, b = 0   },
    BLUE   = { r = 0,   g = 0,   b = 128 },
    GREEN  = { r = 0,   g = 255, b = 0   },
    RED    = { r = 50,  g = 0,   b = 0   },
}

local effects = {}

local function rainbowColor(phase, length)
    local position = (phase % length) / length
    local r, g, b = 0, 0, 0
    local maxBrightness = 255
    if position < 1/3 then
        r = maxBrightness * (1 - 3 * position)
        g = maxBrightness * (3 * position)
    elseif position < 2/3 then
        position = position - 1/3
        g = maxBrightness * (1 - 3 * position)
        b = maxBrightness * (3 * position)
    else
        position = position - 2/3
        b = maxBrightness * (1 - 3 * position)
        r = maxBrightness * (3 * position)
    end
    return r, g, b
end

local function rainbowColorSkip(phase, length, bg_r, bg_g, bg_b, threshold)
    local r, g, b = rainbowColor(phase, length)
    if math.abs(r - bg_r) < threshold and math.abs(g - bg_g) < threshold and math.abs(b - bg_b) < threshold then
        return rainbowColorSkip((phase + 1) % length, length, bg_r, bg_g, bg_b, threshold)
    end
    return r, g, b
end

effects.POLICE = {
    continuous = true,
    state = { oldtime = 0, cycle = 0 },
    init = function(s)
        s.oldtime = getTime()
        s.cycle = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        for i = 0, total - 1, 1 do
            if (i % 2 == s.cycle) then
                setRGBLedColor(i, 0, 0, 50)
            else
                setRGBLedColor(i, 50, 0, 0)
            end
        end
        if ((getTime() - s.oldtime) > 8) then
            s.oldtime = getTime()
            s.cycle = 1 - s.cycle
        end
        applyRGBLedColors()
    end
}

effects.SCR = {
    continuous = true,
    state = { oldtime = 0, cycle = 0 },
    init = function(s)
        s.oldtime = getTime()
        s.cycle = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        for i = 0, total - 1, 1 do
            if (i == s.cycle) then
                setRGBLedColor(i, 0, 50, 0)
            else
                setRGBLedColor(i, 0, 0, 50)
            end
        end
        if ((getTime() - s.oldtime) > 8) then
            s.oldtime = getTime()
            s.cycle = s.cycle + 1
            if s.cycle >= total then
                s.cycle = 0
            end
        end
        applyRGBLedColors()
    end
}

effects.SCL = {
    continuous = true,
    state = { oldtime = 0, cycle = 0 },
    init = function(s)
        local total = LED_STRIP_LENGTH or 0
        s.oldtime = getTime()
        s.cycle = math.max(0, total - 1)
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        for i = 0, total - 1, 1 do
            if (i == s.cycle) then
                setRGBLedColor(i, 0, 50, 0)
            else
                setRGBLedColor(i, 0, 0, 50)
            end
        end
        if ((getTime() - s.oldtime) > 8) then
            s.oldtime = getTime()
            s.cycle = s.cycle - 1
            if s.cycle < 0 then
                s.cycle = total - 1
            end
        end
        applyRGBLedColors()
    end
}

effects.SAPP = {
    continuous = false,
    state = {},
    init = function(s)
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        for i = 0, total - 1, 1 do
            setRGBLedColor(i, 0, 255, 255)
        end
        applyRGBLedColors()
    end
}

effects.RUNNER = {
    continuous = true,
    state = { colorTime = 0, phase = 0, currentLed = 0 },
    init = function(s)
        s.colorTime = getTime()
        s.phase = 0
        s.currentLed = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        if ((getTime() - s.colorTime) > 2) then
            s.colorTime = getTime()
            s.phase = s.phase + 1
            s.currentLed = (s.currentLed + 1) % total
        end
        for i = 0, total - 1, 1 do
            local r, g, b = rainbowColor(s.phase, 255)
            if i <= s.currentLed then
                setRGBLedColor(i, r, g, b)
            else
                local bg_r = (r + 128) % 256
                local bg_g = (g + 128) % 256
                local bg_b = (b + 128) % 256
                local maxBackgroundBrightness = 255
                bg_r = math.min(bg_r, maxBackgroundBrightness)
                bg_g = math.min(bg_g, maxBackgroundBrightness)
                bg_b = math.min(bg_b, maxBackgroundBrightness)
                if bg_r > bg_g and bg_r > bg_b then
                    bg_r = 0
                elseif bg_g > bg_r and bg_g > bg_b then
                    bg_g = 0
                else
                    bg_b = 0
                end
                setRGBLedColor(i, bg_r, bg_g, bg_b)
            end
        end
        applyRGBLedColors()
    end
}

effects.RGBLOP = {
    continuous = true,
    state = { cycleTime = 0, phase = 0 },
    init = function(s)
        s.cycleTime = getTime()
        s.phase = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        if ((getTime() - s.cycleTime) > 2) then
            s.cycleTime = getTime()
            s.phase = s.phase + 1
        end
        for i = 0, total - 1, 1 do
            local r, g, b = rainbowColor(s.phase, 255)
            setRGBLedColor(i, r, g, b)
        end
        applyRGBLedColors()
    end
}

effects.RAINBW = {
    continuous = true,
    state = { colorTime = 0, phase = 0 },
    init = function(s)
        s.colorTime = getTime()
        s.phase = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        if ((getTime() - s.colorTime) > 2) then
            s.colorTime = getTime()
            s.phase = (s.phase + 1) % 255
            for i = 0, total - 1, 1 do
                local r, g, b = rainbowColor(s.phase + i * 64, 255)
                setRGBLedColor(i, r, g, b)
            end
            applyRGBLedColors()
        end
    end
}

effects.PFWRD = {
    continuous = true,
    state = { oldtime = 0, cycle = 0, phase = 0 },
    init = function(s)
        s.oldtime = getTime()
        s.cycle = 0
        s.phase = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        for i = 0, total - 1, 1 do
            if (i == s.cycle) then
                local r, g, b = rainbowColorSkip(s.phase, 255, 72, 0, 72, 30)
                setRGBLedColor(i, r, g, b)
            else
                setRGBLedColor(i, 72, 0, 72)
            end
        end
        if ((getTime() - s.oldtime) > 8) then
            s.oldtime = getTime()
            s.cycle = s.cycle + 1
            if s.cycle >= total then
                s.cycle = 0
            end
        end
        s.phase = (s.phase + 1) % 255
        applyRGBLedColors()
    end
}

effects.PBACK = {
    continuous = true,
    state = { oldtime = 0, cycle = 0, phase = 0 },
    init = function(s)
        s.oldtime = getTime()
        s.cycle = 0
        s.phase = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        for i = total - 1, 0, -1 do
            if (i == s.cycle) then
                local r, g, b = rainbowColorSkip(s.phase, 255, 72, 0, 72, 30)
                setRGBLedColor(i, r, g, b)
            else
                setRGBLedColor(i, 72, 0, 72)
            end
        end
        if ((getTime() - s.oldtime) > 8) then
            s.oldtime = getTime()
            s.cycle = s.cycle - 1
            if s.cycle < 0 then
                s.cycle = total - 1
            end
        end
        s.phase = (s.phase + 1) % 255
        applyRGBLedColors()
    end
}

effects.FLOW = {
    continuous = true,
    state = { colorTime = 0, phase = 0 },
    init = function(s)
        s.colorTime = getTime()
        s.phase = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        if ((getTime() - s.colorTime) > 1) then
            s.colorTime = getTime()
            s.phase = (s.phase + 1) % 255
            for i = 0, total - 1, 1 do
                local r, g, b = rainbowColor(s.phase + i * 64, 255)
                setRGBLedColor(i, math.floor(r), math.floor(g), math.floor(b))
            end
            applyRGBLedColors()
        end
    end
}

effects.BFWRD = {
    continuous = true,
    state = { oldtime = 0, cycle = 0, phase = 0 },
    init = function(s)
        s.oldtime = getTime()
        s.cycle = 0
        s.phase = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        for i = 0, total - 1, 1 do
            if (i == s.cycle) then
                local r, g, b = rainbowColorSkip(s.phase, 255, 0, 0, 72, 30)
                setRGBLedColor(i, r, g, b)
            else
                setRGBLedColor(i, 0, 0, 72)
            end
        end
        if ((getTime() - s.oldtime) > 8) then
            s.oldtime = getTime()
            s.cycle = s.cycle + 1
            if s.cycle >= total then
                s.cycle = 0
            end
        end
        s.phase = (s.phase + 1) % 255
        applyRGBLedColors()
    end
}

-- Missing presets from Workspaces/Flying/RGBLED. Keep these implementations
-- identical in Custom Colors.lua and FUNCTIONS/GBLED.lua.
effects.BBACK = {
    continuous = true,
    state = { oldtime = 0, cycle = 0, phase = 0 },
    init = function(s)
        s.oldtime = getTime()
        s.cycle = 0
        s.phase = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then return end
        for i = total - 1, 0, -1 do
            if i == s.cycle then
                local r, g, b = rainbowColorSkip(s.phase, 255, 0, 0, 72, 30)
                setRGBLedColor(i, r, g, b)
            else
                setRGBLedColor(i, 0, 0, 72)
            end
        end
        if getTime() - s.oldtime > 8 then
            s.oldtime = getTime()
            s.cycle = s.cycle - 1
            if s.cycle < 0 then s.cycle = total - 1 end
        end
        s.phase = (s.phase + 1) % 255
        applyRGBLedColors()
    end,
}

local function gimbalEffect(red, green, blue)
    return {
        continuous = true,
        state = {},
        init = function(s)
            s.ail, s.ele, s.rud, s.thr = 0, 0, 0, 0
            -- Paint even without movement, including when re-enabled.
            s.firstFrame = true
        end,
        run = function(s)
            local total = LED_STRIP_LENGTH or 0
            if total <= 0 then return end
            local ail = tonumber(getValue("ail")) or 0
            local ele = tonumber(getValue("ele")) or 0
            local rud = tonumber(getValue("rud")) or 0
            local thr = tonumber(getValue("thr")) or 0
            local da, de = math.abs(ail - s.ail), math.abs(ele - s.ele)
            local dr, dt = math.abs(rud - s.rud), math.abs(thr - s.thr)
            if not s.firstFrame and math.max(da, de, dr, dt) < 3 then return end

            for i = 0, total - 1 do setRGBLedColor(i, red, green, blue) end
            local function ringHighlight(ring, h, v, delta)
                local magnitude = math.sqrt(h * h + v * v)
                if magnitude < 0.1 then return end
                local angle = math.atan2 and math.atan2(v, h) or math.atan(v, h)
                angle = (math.deg(angle) + 360) % 360
                local center = math.floor(angle / 36 + 0.5) % 10
                local intensity = math.min(255, 250 * magnitude * math.min(1 + delta / 200, 2))
                for offset = -2, 2 do
                    local index = (center + offset) % 10 + ring * 10
                    if index < total then
                        local value = math.floor(intensity * math.exp(-0.5 * offset * offset))
                        setRGBLedColor(index, value, value, value)
                    end
                end
            end
            -- Preserve the supplied presets' ring mapping and movement boost.
            -- Older firmware without stick-mode reporting keeps the base color.
            local mode = type(getStickMode) == "function" and getStickMode() or 0
            if mode == 1 then
                ringHighlight(0, -ail / 1024, thr / 1024, da + dt)
                ringHighlight(1, rud / 1024, -ele / 1024, dr + de)
            elseif mode == 2 then
                ringHighlight(0, -ail / 1024, ele / 1024, da + dt)
                ringHighlight(1, rud / 1024, -thr / 1024, dr + de)
            end
            s.ail, s.ele, s.rud, s.thr = ail, ele, rud, thr
            s.firstFrame = false
            applyRGBLedColors()
        end,
    }
end

effects.GBLBLU = gimbalEffect(0, 0, 255)
effects.GBLCYN = gimbalEffect(0, 255, 255)
effects.GBLGRE = gimbalEffect(0, 255, 0)
effects.GBLLIM = gimbalEffect(191, 255, 0)
effects.GBLMAG = gimbalEffect(255, 0, 255)
effects.GBLORG = gimbalEffect(255, 165, 0)
effects.GBLPNK = gimbalEffect(255, 20, 147)
effects.GBLPUR = gimbalEffect(128, 0, 128)
effects.GBLRED = gimbalEffect(255, 0, 0)
effects.GBLTRQ = gimbalEffect(64, 224, 208)
effects.GBLYEL = gimbalEffect(255, 255, 0)

local function trim(s)
    return string.gsub(s, "^%s*(.-)%s*$", "%1")
end

local function getModelName()
    local info = model and model.getInfo and model.getInfo() or nil
    local name = (info and info.name) or ""
    return trim(name)
end

-- Read source explicitly: FAT timestamps can tie after consecutive saves,
-- so a cached .luac must never override a newly saved configuration.
local PREVIOUS_PATH = "/SCRIPTS/RGBLED/model_leds_previous.lua"
local CONFIG_DIR = "/SCRIPTS/RGBLED"
local function fileInfo(path)
    if type(fstat) ~= "function" then return nil, false end
    local ok, info = pcall(fstat, path)
    return info, ok
end
local function validConfig(cfg)
    if type(cfg) ~= "table" then return false end
    local models = cfg
    if cfg.version == 2 then
        if type(cfg.models) ~= "table" or (cfg.global ~= nil and type(cfg.global) ~= "table") then return false end
        models = cfg.models
    end
    for name, entry in pairs(models) do
        if type(name) ~= "string" or type(entry) ~= "table" then return false end
        for _, key in ipairs({"mode", "left", "right", "sw1", "sw2", "sw3", "sw4", "sw5", "sw6"}) do
            if entry[key] ~= nil and type(entry[key]) ~= "string" then return false end
        end
    end
    return true
end
local function readConfigFile(path)
    local ok, chunk = pcall(loadScript, path, "tx")
    if not ok or type(chunk) ~= "function" then return nil end
    local loaded, cfg = pcall(chunk)
    if loaded and validConfig(cfg) then return cfg end
    return nil
end
local configSeen = false
local function loadConfig()
    local info, known = fileInfo(CONFIG_PATH)
    if not known then return nil, "Cannot inspect the configuration file." end
    if info then
        local cfg = readConfigFile(CONFIG_PATH)
        if cfg then configSeen = true; return cfg end
        return nil, "Cannot read the existing configuration. It has not been replaced."
    end
    -- A power interruption between the two renames leaves the last good
    -- configuration here. Never consume an uncommitted pending file.
    local previous, previousKnown = fileInfo(PREVIOUS_PATH)
    if not previousKnown then return nil, "Cannot inspect the recovery file." end
    if previous then
        local cfg = readConfigFile(PREVIOUS_PATH)
        if cfg then configSeen = true; return cfg, "Recovered previous settings" end
        return nil, "Cannot read the recovery configuration."
    end
    local directory, directoryKnown = fileInfo(CONFIG_DIR)
    local binary, binaryKnown = fileInfo(string.gsub(CONFIG_PATH, "%.lua$", ".luac"))
    if configSeen or not directoryKnown or not directory or not binaryKnown or binary then
        return nil, "Configuration unavailable. Check the SD card and RGBLED folder."
    end
    return {}, "New configuration"
end

local function resolveEntry(cfg, modelName)
    if cfg[modelName] then
        return cfg[modelName]
    end
    if cfg["*"] then
        return cfg["*"]
    end
    if cfg["_default"] then
        return cfg["_default"]
    end
    return nil
end

-- Keep this format handling in sync with the Custom Colors editor.
local function configSections(cfg)
    if cfg.version == 2 and type(cfg.models) == "table" then
        return cfg.models, type(cfg.global) == "table" and cfg.global or {}
    end
    return cfg, {}
end

local function normalizeMode(mode)
    if string.upper(tostring(mode or "OFF")) == "ON" then
        return "ON"
    end
    return "OFF"
end

local function applyStatic(leftName, rightName)
    local left = COLORS[leftName] or COLORS.OFF
    local right = COLORS[rightName] or COLORS.OFF
    local total = LED_STRIP_LENGTH or 0
    if total <= 0 then
        return
    end
    for i = 0, total - 1, 1 do
        local c = ((i % 2) == 0) and left or right
        setRGBLedColor(i, c.r, c.g, c.b)
    end
    applyRGBLedColors()
end

local function applySwitchColors(sw)
    if not setCFSLedColor then
        return
    end
    for i = 1, 6 do
        local name = sw[i] or "OFF"
        if name ~= "NONE" then
            local c = COLORS[name] or COLORS.OFF
            setCFSLedColor("SW"..i, c.r, c.g, c.b)
        end
    end
end

local function applyPerGimbal(leftName, rightName)
    local left = COLORS[leftName] or COLORS.OFF
    local right = COLORS[rightName] or COLORS.OFF
    local total = LED_STRIP_LENGTH or 0

    if total > 0 then
        local rightEnd = math.floor(total / 2)
        if rightEnd > (total - 1) then
            rightEnd = total - 1
        end
        local leftStart = rightEnd - 3
        if leftStart < 0 then
            leftStart = 0
        end

        for i = 0, rightEnd, 1 do
            setRGBLedColor(i, right.r, right.g, right.b)
        end
        for j = leftStart, total - 1, 1 do
            setRGBLedColor(j, left.r, left.g, left.b)
        end
    end

    applyRGBLedColors()
end

-- State
local lastModel = ""
local lastLeft = nil
local lastRight = nil
local lastSwitch = {"","","","","",""}
local lastEffect = nil
local lastMode = "OFF"
local lastConfigCheck = -1
local cachedConfig = nil
local lastEnableSwitch = nil
local lastDisableSwitch = nil
local ledsEnabled = nil

local function refreshConfig(force)
    local now = getTime()
    if force or lastConfigCheck < 0 or (now - lastConfigCheck) > 50 then
        local cfg = loadConfig()
        if cfg then cachedConfig = cfg end
        lastConfigCheck = now
        return cfg ~= nil
    end
    return true
end

local lastRun = nil
local function applyIfNeeded(force)
    local now = getTime()
    -- Repaint after any standalone tool pauses this script, even if the
    -- saved colors have not changed. No continuous SD writes are needed.
    force = force or (lastRun ~= nil and (now < lastRun or now - lastRun > 100))
    lastRun = now
    local modelName = getModelName()
    local handoff, handoffEnable, handoffDisable = readHandoff(nil, nil, true)
    local refreshed = refreshConfig(force or modelName ~= lastModel or handoff ~= nil)
    if not cachedConfig or (handoff ~= nil and not refreshed) then return end
    local models, global = configSections(cachedConfig)
    local entry = resolveEntry(models, modelName)
    local enable = normalizeSwitch(global.enableSwitch)
    local disable = normalizeSwitch(global.disableSwitch)
    if enable ~= lastEnableSwitch or disable ~= lastDisableSwitch then
        ledsEnabled = nil
    end
    if handoff ~= nil and handoffEnable == enable and handoffDisable == disable then
        ledsEnabled = handoff
        force = true
    end
    local enabled = switchControlEnabled(enable, disable, ledsEnabled)
    force = force or enabled ~= ledsEnabled
    ledsEnabled = enabled
    lastEnableSwitch = enable
    lastDisableSwitch = disable
    publishHandoff(enable, disable, ledsEnabled, false)
    local modeName = normalizeMode(entry and entry.mode)
    local perGimbal = (modeName == "ON")
    local leftName = (entry and entry.left) or "OFF"
    local rightName = (entry and entry.right) or "OFF"
    local sw = {
        (entry and entry.sw1) or "NONE",
        (entry and entry.sw2) or "NONE",
        (entry and entry.sw3) or "NONE",
        (entry and entry.sw4) or "NONE",
        (entry and entry.sw5) or "NONE",
        (entry and entry.sw6) or "NONE",
    }
    if not ledsEnabled then
        leftName, rightName = "OFF", "OFF"
        for i = 1, 6 do
            -- None is intentionally unmanaged, even while disabled.
            if sw[i] ~= "NONE" then sw[i] = "OFF" end
        end
    end
    local effectName = nil
    if (not perGimbal) and leftName == rightName and effects[leftName] then
        effectName = leftName
    end
    local switchesChanged = force or (modelName ~= lastModel)
    if not switchesChanged then
        for i = 1, 6 do
            if sw[i] ~= lastSwitch[i] then
                switchesChanged = true
                break
            end
        end
    end

    local baseChanged = force or (modelName ~= lastModel) or (leftName ~= lastLeft) or (rightName ~= lastRight) or (modeName ~= lastMode)

    if perGimbal then
        if baseChanged then
            applyPerGimbal(leftName, rightName)
        end
        if switchesChanged then
            applySwitchColors(sw)
        end
        lastModel = modelName
        lastLeft = leftName
        lastRight = rightName
        lastEffect = nil
        lastMode = modeName
        lastSwitch = { sw[1], sw[2], sw[3], sw[4], sw[5], sw[6] }
        return
    end

    if effectName then
        local effect = effects[effectName]
        local changed = baseChanged or (lastEffect ~= effectName)
        if changed and effect.init then
            effect.init(effect.state)
        end
        if effect.continuous or changed then
            effect.run(effect.state)
        end
        if switchesChanged then
            applySwitchColors(sw)
        end
        lastModel = modelName
        lastLeft = leftName
        lastRight = rightName
        lastEffect = effectName
        lastMode = modeName
        lastSwitch = { sw[1], sw[2], sw[3], sw[4], sw[5], sw[6] }
        return
    end

    if baseChanged or switchesChanged or lastEffect then
        applyStatic(leftName, rightName)
        if switchesChanged then
            applySwitchColors(sw)
        end
        lastModel = modelName
        lastLeft = leftName
        lastRight = rightName
        lastEffect = nil
        lastMode = modeName
        lastSwitch = { sw[1], sw[2], sw[3], sw[4], sw[5], sw[6] }
    end
end

local function init()
    lastModel = ""
    lastLeft = nil
    lastRight = nil
    lastEffect = nil
    lastMode = "OFF"
    lastSwitch = {"","", "", "", "", ""}
    lastConfigCheck = -1
    cachedConfig = nil
    configSeen = false
    lastRun = nil
    lastEnableSwitch = nil
    lastDisableSwitch = nil
    ledsEnabled = nil
    -- A newly enabled function is loaded after the editor closes. Preserve
    -- its fresh editor handoff, including an enabled latch in the middle
    -- switch position; ordinary boot/stale runtime state still starts fresh.
    if readHandoff(nil, nil, true) == nil then
        publishHandoff(0, 0, false, false)
    end
    applyIfNeeded(true)
end

local function run()
    applyIfNeeded(false)
end

local function background()
    -- No-op
end

return { run = run, background = background, init = init }
