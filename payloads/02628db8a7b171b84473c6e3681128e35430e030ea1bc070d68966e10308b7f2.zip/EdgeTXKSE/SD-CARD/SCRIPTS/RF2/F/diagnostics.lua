-- Bounded diagnostic records shared by background service and foreground UI.
-- rf2.lua preserves these records when the standalone tool reloads the core.
local d = {}
rf2.runtimeErrors = rf2.runtimeErrors or {}

function d.report(source, message, stage)
    local now = rf2.clock()
    message = string.sub(tostring(message), 1, 320)
    local previous = rf2.runtimeErrors[source]
    local changed = not previous or previous.message ~= message or previous.stage ~= stage or not previous.active
    local record = previous or {count = 0}
    record.message, record.stage = message, stage
    record.count, record.time, record.active = math.min(record.count + 1, 999999), now, true
    rf2.runtimeErrors[source] = record
    if changed then rf2.pendingNotice = {source = source, message = message} end
    -- One bounded file/console entry per minute, not a write on every frame.
    if source == "background" and (not record.loggedAt or now - record.loggedAt >= 60 or now < record.loggedAt) then
        record.loggedAt = now
        local text = string.format("RF2 background error at %.1fs (%s): %s", now, stage or "unknown", message)
        pcall(print, text)
        local file
        local ok = pcall(function()
            file = assert(io.open(rf2.baseDir .. "background_error.log", "w"))
            io.write(file, text .. "\n")
            io.close(file)
            file = nil
        end)
        if file then pcall(io.close, file) end
        record.logAttemptOk = ok
    end
    return record
end

function d.recover(source, dismissNotice)
    local record = rf2.runtimeErrors[source]
    if record then record.active = false end
    if dismissNotice and rf2.pendingNotice and rf2.pendingNotice.source == source then rf2.pendingNotice = nil end
end

function d.takeNotice()
    local message = rf2.pendingNotice
    rf2.pendingNotice = nil
    return message and (message.source .. ": " .. message.message)
end

function d.lines()
    local lines = {}
    for _, source in ipairs({"background", "settings"}) do
        local record = rf2.runtimeErrors[source]
        if record then
            lines[#lines + 1] = string.format("%s: %s (%d failures; last at %.1fs, %s)",
                source, record.active and "error" or "recovered", record.count, record.time, record.stage or "unknown")
            lines[#lines + 1] = record.message
        end
    end
    if #lines == 0 then lines[1] = "No background or settings errors this session." end
    return lines
end

return d
