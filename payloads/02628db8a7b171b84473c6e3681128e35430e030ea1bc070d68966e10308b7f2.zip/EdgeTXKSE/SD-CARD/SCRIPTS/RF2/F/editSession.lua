-- Value snapshots for configuration pages with deferred Save semantics.
-- Servo overrides and other immediate actions stay on their
-- existing workflows; a local discard must never imply it undid an FC action.
local supported = {
    profile_pids = true, rates = true, collective_pitch = true, rate_dynamics = true,
    profile_pidcon = true, profile_various = true, profile_rescue = true,
    profile_governor = true, battery = true, smartfuel = true,
    filters = true, governor = true, accelerometer = true, experimental = true,
    settings = true, swash_trim = true, esc_hwpl5 = true, mixer = true,
}
local excluded = {
    ["Current PID profile"] = true, ["Current rate profile"] = true,
    ["Current battery"] = true, ["Destination profile"] = true,
}
local s = {}

function s.supports(script) return supported[script] == true end

function s.capture(page)
    local values = {}
    for i, field in ipairs(page.fields or {}) do
        if field.data and not field.readOnly and not excluded[field.t] then
            values[i] = field.data.value
        end
    end
    return values
end

function s.context(page)
    local parts = {}
    if page.uiScript == 'esc_hwpl5' then parts[#parts + 1] = page.escIdentity or 'ESC not ready' end
    for _, field in ipairs(page.fields or {}) do
        if field.t and string.sub(field.t, 1, 8) == "Current " and field.data then
            parts[#parts + 1] = field.t .. ":" .. tostring(field.data.value)
        end
    end
    return table.concat(parts, ";")
end

function s.label(page, i)
    local field = page.fields[i]
    if field.t and field.t ~= "" then return field.t end
    if page.title == "PID Gains" then
        if i <= 15 then
            return ({"Roll", "Pitch", "Yaw"})[(i - 1) % 3 + 1] .. " " .. ({"P", "I", "D", "FF", "B"})[math.floor((i - 1) / 3) + 1]
        elseif i == 19 or i == 20 then
            return (i == 19 and "Roll" or "Pitch") .. " HSI offset"
        end
    elseif page.rateFields and page.rateFieldOrder[i] <= 12 then
        i = page.rateFieldOrder[i]
        local axis = ({"Roll", "Pitch", "Yaw", "Collective"})[(i - 1) % 4 + 1]
        local column = math.floor((i - 1) / 4)
        local a, b = page.rateLabels[7 + column * 2], page.rateLabels[8 + column * 2]
        return axis .. " " .. (a and a.t or "") .. " " .. (b and b.t or "")
    end
    return "Field " .. tostring(i)
end

function s.format(field, value)
    if value == nil then return "--" end
    local data = field.data
    if data.table and data.table[value] then return tostring(data.table[value]) end
    if type(value) == "number" then
        value = value / (data.scale or 1)
        -- Use the same explicit decimal format as the live editor. Native
        -- EdgeTX's general number conversion can misdisplay fractional values.
        value = string.gsub(string.gsub(string.format('%.3f', value), '0+$', ''), '%.$', '')
    end
    return tostring(value) .. (data.unit or "")
end

function s.changes(page, baseline)
    local changes = {}
    for i, value in pairs(baseline or {}) do
        local field = page.fields[i]
        if field and field.data and field.data.value ~= value then
            changes[#changes + 1] = { index = i, label = s.label(page, i),
                before = s.format(field, value), after = s.format(field, field.data.value) }
        end
    end
    table.sort(changes, function(a, b) return a.index < b.index end)
    return changes
end

function s.countChanges(page, baseline)
    local count = 0
    for i, value in pairs(baseline or {}) do
        local field = page.fields[i]
        if field and field.data and field.data.value ~= value then count = count + 1 end
    end
    return count
end

function s.matches(page, expected, context)
    if s.context(page) ~= context then return false end
    local actual = s.capture(page)
    for i, value in pairs(expected or {}) do
        if actual[i] ~= value then return false end
    end
    return true
end

return s
