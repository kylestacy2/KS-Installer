-- Hangar preferences live in the existing verified RF2 settings store.
local c={}
local defaults={'profile_pids','rates','profile_governor','battery','profile_rescue'}
c.pidGainKeys={'p','i','d','ff','boost'}
c.pageIds={'profile_pids','rates','profile_governor','profile_rescue','battery','servos','rate_dynamics','profile_pidcon','profile_various','filters','mixer','swash_trim','governor','accelerometer','smartfuel','model','status','experimental','esc_sensor','esc_hwpl5','esc_xdfly','esc_scorp','esc_am32','esc_blhelis','esc_bluejay','esc_flyrotor','esc_yge'}
c.options={
 {key='theme',title='Theme',default='graphite',values={'graphite','daylight','obsidian','copper','amethyst','radio'},names={'Graphite','Daylight','Obsidian','Copper','Amethyst','Follow radio theme'}},
 {key='openingPage',title='Opening page',values={'hangar','all','last'},names={'Hangar','All pages','Last tuning page'}},
 {key='pidView',title='PID opening view',values={'all','last'},names={'All axes','Last axis view'}},
 {key='buttonRepeat',title='Hold + / -',values={'off','normal','fast'},names={'Off','Normal','Fast'}},
 {key='startingValue',title='Starting value',values={'on','off'},names={'On','Off'}},
 {key='changeMarkers',title='Change markers',values={'on','off'},names={'On','Off'}},
 {key='adjustmentVoice',title='Adjustment Teller',values={'off','on'},names={'Off','On'}},
 {key='saveSound',title='Save sound',values={'off','on'},names={'Off','On'}},
}
function c.unified() return type(getAppAppearanceMode)=='function' and getAppAppearanceMode()==true end
function c.theme() return c.unified() and 'radio' or c.get().theme end
function c.enabled() return LCD_W==800 and LCD_H==480 and rf2.hangarDisabled~=true end
function c.normalize(settings)
 local saved=type(settings.hangar)=='table' and settings.hangar or {}
 local p={version=1,homePages={},rateSliderMax={},pidGainMax={},lastPage=saved.lastPage}
 for _,o in ipairs(c.options) do
  local value=saved[o.key]
  if o.key=='adjustmentVoice' then value=settings.useAdjustmentTeller==1 and 'on' or 'off' end
  p[o.key]=o.default or o.values[1]
  for _,v in ipairs(o.values) do if v==value then p[o.key]=v;break end end
 end
 local known={};for _,id in ipairs(c.pageIds)do known[id]=true end
 local seen={}
 local function add(id) if #p.homePages<5 and known[id] and not seen[id] then p.homePages[#p.homePages+1]=id;seen[id]=true end end
 if type(saved.homePages)=='table' then for _,id in ipairs(saved.homePages)do add(id)end
 elseif type(settings.favoritePages)=='table' then
  -- Legacy favorites have no order; migrate in the stable catalog order.
  for _,id in ipairs(c.pageIds)do if settings.favoritePages[id]==1 then add(id)end end
  if settings.favoritePages.collective_pitch==1 then add('rates')end
 end
 for _,id in ipairs(defaults)do add(id)end
 for _,id in ipairs(c.pageIds)do add(id)end
 for _,axis in ipairs({'roll','pitch','yaw'})do
  local v=type(saved.rateSliderMax)=='table' and saved.rateSliderMax[axis]
  p.rateSliderMax[axis]=type(v)=='number' and v>=10 and v<=1000 and v%5==0 and v or 1000
 end
 for _,key in ipairs(c.pidGainKeys)do
  local v=type(saved.pidGainMax)=='table' and saved.pidGainMax[key]
  p.pidGainMax[key]=type(v)=='number' and v>=0 and v<=1000 and v%1==0 and v or 1000
 end
 return p
end
function c.get()
 if not rf2.hangarPreferences then rf2.hangarPreferences=c.normalize(rf2.loadSettings()) end
 return rf2.hangarPreferences
end
function c.remember(script)
 if script~='settings' then rf2.hangarLastPage=script;c.get().lastPage=script end
end
function c.saveLast()
 if c.get().openingPage~='last' or not rf2.hangarLastPage then return true end
 local settings=rf2.loadSettings()
 local p=c.normalize(settings)
 if p.lastPage==rf2.hangarLastPage then return true end
 p.lastPage=rf2.hangarLastPage;settings.hangar=p
 return rf2.saveSettings(settings)
end
function c.invalidate() rf2.hangarPreferences=nil end
function c.sound() if c.get().saveSound=='on' and playTone then playTone(1800,80,0,0) end end
return c
