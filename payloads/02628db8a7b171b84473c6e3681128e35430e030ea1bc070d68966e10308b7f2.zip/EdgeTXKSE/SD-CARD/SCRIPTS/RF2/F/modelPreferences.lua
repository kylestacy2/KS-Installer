-- Small, per-model local preferences. No executable settings, MSP or globals.
-- Alternate two checksummed slots: a torn write never overwrites the last
-- verified generation. Only explicit Save writes; readers are bounded.
local m={}
local kinds={speeds=4,layout1=8,layout2=8,layout3=8,layout4=8}
local fields={gov=true,rpm=true,bec=true,temp=true,current=true,cell=true,capacity=true,battery=true,tail=true,pack=true,link=true,timer=true,empty=true}
-- Compact, non-executable sensor descriptors keep eight tiles inside the
-- existing 384-byte record bound. No transient EdgeTX source IDs are persisted.
-- type/id/instance/unit/precision/name(4 bytes)/view/unit override/title(8 bytes).
function m.isBinding(value)
 if type(value)~='string' or #value<23 or #value>39 or #value%2~=1 then return false end
 if not string.match(value,'^@[01]%x%x%x%x%x%x%x%x[0-3]%x%x%x%x%x%x%x%x%x%x%x%x%x*$')then return false end
 local view,unit=tonumber(string.sub(value,20,21),16),tonumber(string.sub(value,22,23),16)
 if view>34 or (unit>29 and unit~=255)or string.sub(value,12,19)=='00000000'then return false end
 local title=string.sub(value,24)
 if string.gsub(title,'[2-7]%x','')~='' or string.find(title,'7[fF]')then return false end
 return true
end
local function hex(text)
 return (string.gsub(text,'.',function(c)return string.format('%02x',string.byte(c))end))
end
local function unhex(text)
 return (string.gsub(text,'%x%x',function(pair)return string.char(tonumber(pair,16))end))
end
function m.sensorKey(sensor)
 if type(sensor)~='table' or type(sensor.name)~='string' or #sensor.name==0 or #sensor.name>4 then return end
 local kind=sensor.type;local id=kind==1 and sensor.formula or sensor.id
 local instance=kind==1 and 0 or sensor.instance
 if (kind~=0 and kind~=1) or type(id)~='number' or id<0 or id>65535 or id%1>0
  or type(instance)~='number' or instance<0 or instance>255 or instance%1>0
  or type(sensor.unit)~='number' or sensor.unit<0 or sensor.unit>255 or sensor.unit%1>0
  or type(sensor.prec)~='number' or sensor.prec<0 or sensor.prec>3 or sensor.prec%1>0 then return end
 return '@'..string.format('%x%04x%02x%02x%x',kind,id,instance,sensor.unit,sensor.prec)..hex(sensor.name..string.rep('\0',4-#sensor.name))
end
function m.binding(value)
 if not m.isBinding(value) then return end
 return {key=string.sub(value,1,19),name=string.gsub(unhex(string.sub(value,12,19)),'%z+$',''),
  unit=tonumber(string.sub(value,9,10),16),prec=tonumber(string.sub(value,11,11),16),
  view=tonumber(string.sub(value,20,21),16),override=tonumber(string.sub(value,22,23),16),
  title=unhex(string.sub(value,24))}
end
function m.bind(key,view,unit,title)
 title=title or '';view=view or 0;unit=unit or 255
 if type(key)~='string' or #key~=19 or type(title)~='string' or #title>8 or string.find(title,'[^ -~]')
  or type(view)~='number' or view~=view or view<0 or view>255 or view%1>0
  or type(unit)~='number' or unit~=unit or unit<0 or unit>255 or unit%1>0 then return end
 local value=key..string.format('%02x%02x',view,unit)..hex(title)
 if m.isBinding(value) then return value end
end
function m.fieldKey(value)
 return type(value)=='string' and string.sub(value,1,1)=='@' and string.sub(value,1,21) or value
end
function m.identity()
 local ok,info=pcall(model.getInfo)
 local key=ok and type(info)=='table' and info.filename
 if type(key)=='string' and #key>0 and #key<=64 then return key end
end
function m.valid(kind,values)
 if not kinds[kind] or type(values)~='table' or #values~=kinds[kind] then return false end
 local seen={}
 for i=1,kinds[kind] do
  local v=values[i]
  if kind=='speeds' then
   if type(v)~='number' or v~=v or v<0 or v>5500 or v%10>0 or v>0 and v<900 then return false end
   if v>0 then if seen[v] then return false end;seen[v]=true end
  else
   if not fields[v] and not m.isBinding(v) then return false end
   -- OMP's unchanged dashboard contains Governor/BEC placeholders and a real
   -- cell-voltage tile. Preserve those on the first edit of any other slot.
   if kind=='layout3' and v=='tail' then return false end
   if v~='empty' then local key=m.fieldKey(v);if seen[key] then return false end;seen[key]=true end
  end
 end
 return true
end
local function prefix(key,kind)
 if type(key)~='string' or #key==0 or #key>64 or not kinds[kind] then return end
 return '/SCRIPTS/RF2/PREFS/'..string.gsub(key,'.',function(c)return string.format('%02x',string.byte(c))end)..'_'..kind
end
local function checksum(text)
 local a,b=1,0
 for i=1,#text do a=(a+string.byte(text,i))%65521;b=(b+a)%65521 end
 return string.format('%04x%04x',b,a)
end
local function read(path)
 local f,found
 local ok,text=pcall(function()
  f=io.open(path,'r');if not f then return end
  found=true
  local value,readError=io.read(f,385);local closed,closeError=io.close(f);f=nil
  if closed==false or closeError or readError then error('read/close')end
  return value
 end)
 if f then pcall(io.close,f)end
 if not ok then return nil,true end
 return text,found==true
end
local function decode(text,kind)
 if type(text)~='string' or #text>384 then return end
 local body,hash=string.match(text,'^(KSEP1|%d+|[^\n]+)\n(%x%x%x%x%x%x%x%x)\n$')
 if not body or checksum(body)~=hash then return end
 local sequence,values=string.match(body,'^KSEP1|(%d+)|(.+)$')
 sequence=tonumber(sequence)
 if not sequence or sequence<1 or sequence>1000000 then return end
 local list={}
 for token in string.gmatch(values,'[^,]+')do list[#list+1]=kind=='speeds' and tonumber(token) or token end
 if not m.valid(kind,list) or table.concat(list,',')~=values then return end
 return {values=list,sequence=sequence}
end
function m.load(key,kind)
 local path=prefix(key,kind);if not path then return nil,0,'Model file unavailable' end
 local selected,damaged
 for _,slot in ipairs({'a','b'})do
  local text,present=read(path..'.'..slot)
  local record=decode(text,kind)
  if record and (not selected or record.sequence>selected.sequence)then record.slot=slot;selected=record end
  if present and not record then damaged=true end
 end
 if selected then return selected.values,selected.sequence,nil,selected.slot end
 return nil,0,damaged and 'Preferences damaged; previous choices unavailable' or nil
end
function m.prepare(key,kind,values,expected,guard)
 if key~=m.identity() then return nil,'Model changed' end
 if not m.valid(kind,values) then return nil,'Invalid preferences' end
 local _,sequence,err,slot=m.load(key,kind)
 if sequence~=expected then return nil,'Preferences changed; reopen this page' end
 if err then return nil,err end
 if sequence>=1000000 then return nil,'Preference revision limit' end
 local body='KSEP1|'..(sequence+1)..'|'..table.concat(values,',')
 local text=body..'\n'..checksum(body)..'\n'
 local path=prefix(key,kind)..(slot=='a' and '.b' or '.a')
 local consumed=false
 return function()
 if consumed then return false,'Save already attempted' end
 consumed=true
 local f
 local ok,failure=pcall(function()
  local _,latest,readError=m.load(key,kind)
  if latest~=sequence or readError then error('Preferences changed; reopen this page')end
  if key~=m.identity() or guard and not guard() then error('Context changed; save cancelled')end
  f=assert(io.open(path,'w'),'Cannot open preferences')
  local result,reason=io.write(f,text);if result==false or reason then error('Preference write failed')end
  result,reason=io.close(f);f=nil;if result==false or reason then error('Preference close failed')end
  if read(path)~=text then error('Preference save was not confirmed')end
 end)
 if f then pcall(io.close,f)end
 if not ok then return false,tostring(failure) end
 return true,sequence+1
 end
end
function m.save(...)
 local commit,reason=m.prepare(...)
 if not commit then return false,reason end
 return commit()
end
return m
