-- Local navigation preferences; never contains FC values or sends MSP.
local n = {}
n.groups = {{key="all", title="All"}, {key="favorites", title="Fav"},
    {key="tuning", title="Tuning"}, {key="setup", title="Setup"}, {key="esc", title="ESC"}}
n.info = {
    status={group="setup", title="Status", detail="FC overview"},
    rates={group="tuning", title="Rates", detail="Cyclic + collective"},
    rate_dynamics={group="tuning", title="Rate Dynamics", detail="Response shaping"},
    profile_pids={group="tuning", title="PID Gains", detail="Axis + tail gains"},
    profile_pidcon={group="tuning", title="PID Controller", detail="Controller setup"},
    profile_various={group="tuning", title="Flight Profile", detail="Profile options"},
    profile_rescue={group="tuning", title="Rescue", detail="Rescue profile"},
    profile_governor={group="tuning", title="Governor", detail="Head speed + gains"},
    battery={group="setup", title="Battery", detail="Pack capacities"},
    smartfuel={group="setup", title="Smart Fuel", detail="Fuel settings"},
    servos={group="setup", title="Servos", detail="Centers + limits"},
    mixer={group="setup", title="Mixer", detail="Swash + tail"},
    swash_trim={group="setup", title="Swash Trim", detail="Roll + elevator + collective"},
    filters={group="tuning", title="Gyro Filters", detail="Filter setup"},
    governor={group="setup", title="Governor Setup", detail="Governor setup"},
    accelerometer={group="setup", title="Accel. Trim", detail="Sensor trim"},
    esc_sensor={group="esc", title="ESC Sensor", detail="Telemetry setup"},
    model={group="setup", title="Model", detail="Identity + stats"},
    experimental={group="setup", title="Experimental", detail="Advanced values"},
    esc_am32={group="esc", title="AM32", detail="ESC parameters"},
    esc_blhelis={group="esc", title="BLHeli_S", detail="ESC parameters"},
    esc_bluejay={group="esc", title="Bluejay", detail="ESC parameters"},
    esc_flyrotor={group="esc", title="FLYROTOR", detail="ESC parameters"},
    esc_hwpl5={group="esc", title="HW Platinum V5", detail="ESC parameters"},
    esc_scorp={group="esc", title="Scorpion", detail="ESC parameters"},
    esc_xdfly={group="esc", title="XDFly / OMP", detail="ESC parameters"},
    esc_yge={group="esc", title="YGE", detail="ESC parameters"},
}
function n.favorites()
    local saved = rf2.loadSettings().favoritePages
    if type(saved) ~= "table" then return {profile_pids=1, rates=1, profile_governor=1, battery=1} end
    if saved.collective_pitch == nil then return saved end
    -- Fold the old shortcut into Rates without writing settings during startup.
    local favorites = {}
    for key,value in pairs(saved) do if key ~= "collective_pitch" then favorites[key] = value end end
    if saved.collective_pitch == 1 then favorites.rates = 1 end
    return favorites
end
function n.toggle(script)
    if not n.info[script] then return end
    local settings, favorites = rf2.loadSettings(), {}
    for key, value in pairs(n.favorites()) do favorites[key] = value end
    if favorites[script] == 1 then favorites[script] = nil
    else favorites[script] = 1 end
    settings.favoritePages = favorites -- replace the table to trigger dirty tracking
    if not rf2.saveSettings(settings) then return n.favorites() end
    return favorites
end
function n.items(menu, group, favorites)
    local result = {}
    for _, item in ipairs(menu.items) do
        local info = n.info[item.script]
        if info and (group == "all" or info.group == group or (group == "favorites" and favorites[item.script] == 1)) then
            result[#result + 1] = item
        end
    end
    return result
end
return n
