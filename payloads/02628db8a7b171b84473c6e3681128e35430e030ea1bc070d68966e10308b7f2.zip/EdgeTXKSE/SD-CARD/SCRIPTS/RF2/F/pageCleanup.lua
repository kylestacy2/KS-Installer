-- Cleanup has its own queue ownership and survives page cancellation/reload.
-- Frontends must keep servicing it before returning from a normal tool exit.
local queue = rf2.mspQueue
local cleanup = { owners = {} }

function cleanup.release(page)
    if not page or not page.unload or page._rf2Unloaded then return end
    page._rf2Unloaded = true
    local owner = {timeout = 12}
    owner.onError = function()
        cleanup.error = (page.title or "Setup") .. " cleanup was not confirmed.\nReconnect and reopen this page to clear setup controls."
    end
    cleanup.owners[#cleanup.owners + 1] = owner
    local ok = pcall(queue.withOwner, queue, owner, page.unload, page)
    if not ok then
        queue:cancelOwner(owner)
        owner.onError()
    end
end

function cleanup.pending()
    for i = #cleanup.owners, 1, -1 do
        if queue:isOwnerProcessed(cleanup.owners[i]) then table.remove(cleanup.owners, i) end
    end
    return #cleanup.owners > 0
end

function cleanup.takeError()
    local message = cleanup.error
    cleanup.error = nil
    return message
end

return cleanup
