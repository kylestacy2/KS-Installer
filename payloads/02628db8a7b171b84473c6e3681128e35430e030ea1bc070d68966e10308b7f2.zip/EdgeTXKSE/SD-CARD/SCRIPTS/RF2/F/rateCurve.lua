-- Static rate response, adapted from Rotorflight (GPL-3.0-or-later):
-- https://github.com/rotorflight/rotorflight-firmware/blob/release/4.6.0/src/main/fc/rc_rates.c
-- Uses raw MSP values. Rotational output is deg/s; collective is nominal pitch
-- in degrees (firmware convention: 480 deg/s maps to 12 degrees). This excludes
-- response dynamics, mixer limits/calibration and measured blade pitch.
return function(kind,rcRate,sRate,expo,input,collective)
    local x=math.min(1,math.abs(input))
    local e=expo/100
    local r,s,value=rcRate,sRate,0
    local function divisor(v)return math.max(0.01,math.min(1,v))end
    if kind==1 then
        r=r*2;if r>400 then r=r+14.54*(r-400) end
        value=r*(x*(1-e)+x^4*e)/divisor(1-x*s/100)
    elseif kind==2 then
        value=r*10*(x*(1-e)+x^3*e)*(1+x*s/100)
    elseif kind==3 then
        value=r*2*(x*(1-e)+x^3*e)/divisor(1-x*s/100)
    elseif kind==4 then
        r,s=r*10,s*10
        value=x*(r+math.max(0,s-r)*(x*(1-e)+x^5*e))
    elseif kind==5 then
        r,s=r*2,s*10
        local maximum=math.max(r,s)
        if maximum>0 then value=r*x/divisor(1-(x*(1-e)+x^3*e)*(1-r/maximum)) end
    elseif kind==6 then
        value=r*5*(x*(1-e)+x^(2+s/16)*e)
    else value=500*x end
    value=math.min(2000,value)
    if collective then value=value/40 end
    return input<0 and -value or value
end
