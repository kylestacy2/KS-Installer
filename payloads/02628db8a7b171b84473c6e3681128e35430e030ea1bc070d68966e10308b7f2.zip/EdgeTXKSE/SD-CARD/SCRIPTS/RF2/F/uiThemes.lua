-- Stable saved keys; display order is independent of the persisted setting.
local keys = { "light", "dark", "titanium_ember", "radio" }
local names = { [0] = "Light", "Dark", "Titanium Ember", "Follow radio theme" }
local palettes = {
    light = {
        background = 0xEDF3FA, surface = 0xFFFFFF, ink = 0x18314F,
        muted = 0x526984, line = 0xCCDAEB, accent = 0x2463DC, accentInk = 0xFFFFFF,
    },
    dark = {
        background = 0x000000, surface = 0x121416, ink = 0xF4F6F8,
        muted = 0xBAC3CC, line = 0x343C45, accent = 0x83B4FF, accentInk = 0x08111F,
    },
    -- KSE5 Titanium Ember colors with lighter panels for the RF tool.
    titanium_ember = {
        background = 0x0B0E12, surface = 0x3B444E, ink = 0xF5F5F5,
        muted = 0xAEB8C1, line = 0x64717D, accent = 0xFF8A3D, accentInk = 0x0B0E12,
        header = 0x303840,
    },
}

return {
    keys = keys, names = names, palettes = palettes,
    index = function(key)
        for i, name in ipairs(keys) do if name == key then return i - 1 end end
        return 0
    end,
}
