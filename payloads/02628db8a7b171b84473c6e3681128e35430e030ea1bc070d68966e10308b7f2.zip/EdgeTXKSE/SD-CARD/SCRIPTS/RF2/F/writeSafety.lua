-- Safety proof comes from fresh FC replies, not getValue()'s zero for a missing
-- sensor. Radio telemetry may stop updating while a standalone tool is open.
local safety = {}
local function bytes(buf, count)
    if type(buf) ~= "table" or #buf < count then return false end
    for i=1,count do
        local v=buf[i]
        if type(v) ~= "number" or v ~= math.floor(v) or v < 0 or v > 255 then return false end
    end
    return true
end

function safety.armed(buf)
    if not bytes(buf,28) then return nil end
    return buf[7] % 2 == 1
end

function safety.status(buf, proof)
    -- MSP_STATUS: flight-mode flags start at byte 7; motor count is byte 28.
    if not bytes(buf,28) or buf[28] < 1 or buf[28] > 8 then
        return false, "Invalid FC status. Write cancelled."
    end
    if buf[7] % 2 == 1 then return false, "Disarm before writing to the FC." end
    proof.motorCount = buf[28]
    proof.statusAt = rf2.clock()
    return true
end

function safety.motors(buf, proof)
    -- MSP_MOTOR_TELEMETRY: count, then 16 bytes per motor (U32 RPM first).
    if not bytes(buf,1) or buf[1] ~= proof.motorCount or not bytes(buf,1+16*buf[1]) then
        return false, "Invalid FC RPM reply. Write cancelled."
    end
    for i=0,buf[1]-1 do
        local offset=2+i*16
        for j=offset,offset+3 do
            if buf[j] ~= 0 then return false, "Stop the rotor before writing to the FC." end
        end
    end
    proof.checkedAt = proof.statusAt
    return true
end

local function current(name)
    if type(getSourceValue) ~= "function" then return nil end
    local ok, value, live, fresh = pcall(getSourceValue,name)
    if ok and live == true and fresh == true and type(value) == "number" then return value end
end

function safety.check(proof)
    if rf2.offlineSimulator then return true end
    local ok, rssi = pcall(getRSSI)
    if not ok or type(rssi) ~= "number" or not (rssi > 0) then
        return false, "Connection lost. Reload before saving."
    end
    -- Fresh telemetry may veto a proof between MSP replies. Missing telemetry
    -- never supplies proof; the mandatory status/RPM reads below supply it.
    local arm, rpm, gov = current("ARM"), current("Hspd"), current("Gov")
    if arm and (arm < 0 or arm > 255 or arm ~= math.floor(arm) or arm % 2 == 1) then
        return false, "Disarm before writing to the FC."
    end
    if rpm and rpm ~= 0 then return false, "Stop the rotor before writing to the FC." end
    if gov and (gov < 0 or gov > 9 or gov ~= math.floor(gov)
        or gov == 2 or gov == 3 or gov == 4 or gov == 8 or gov == 9) then
        return false, "Stop the governor before writing to the FC."
    end
    local age = proof and proof.checkedAt and rf2.clock() - proof.checkedAt
    if not age or age < 0 or age > 2 then return false, "Checking FC safety state...", true end
    return true
end

return safety
