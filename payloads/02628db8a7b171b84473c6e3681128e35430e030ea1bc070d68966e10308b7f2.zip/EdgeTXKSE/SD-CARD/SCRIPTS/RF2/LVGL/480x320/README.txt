480 x 320 presentation

These renderers are selected only when LCD_W == 480 and LCD_H == 320.
The main menu, page composition and header entry points dispatch here. Other
resolutions continue to use their existing renderers.

Keep native editor objects, field indexes and callbacks intact. This directory
contains presentation only; MSP, page data and preview behavior remain shared.
Settings stays one continuous form. PID Gains keeps the paired Roll/Pitch and
Yaw/Governor tabs. Native controls can be 32 pixels high on TX15; do not assume
the 28-pixel default from older color radios.

The approved 800 x 480 snapshot is saved under:
/Users/kyle/Desktop/RMCode/RF-Lua-snapshots/800x480-approved-20261003-085017
Its rounded-rates-update folder contains the later user-approved corner change.
The *-rounded-rates-layout.txt files are the protected 800 x 480 layout baseline.

Host validation:
RF2_TEST_CONTROL_HEIGHT=32 lua tests/rf2_studio.lua "$PWD" source 480 320
RF2_TEST_CONTROL_HEIGHT=32 lua tests/rf2_navigation.lua "$PWD" source 480 320
RF2_TEST_CONTROL_HEIGHT=32 lua tests/rf2_pages.lua "$PWD" source 480 320
Repeat with bytecode after rebuilding with Lua 5.3.6.

tests/rf2_layout_snapshot.lua emits deterministic layout properties for an
800 x 480 comparison, including all menu groups and all page tabs/sections.
