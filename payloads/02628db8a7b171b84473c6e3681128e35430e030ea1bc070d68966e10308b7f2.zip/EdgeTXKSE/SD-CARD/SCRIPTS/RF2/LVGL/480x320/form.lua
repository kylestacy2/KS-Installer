-- Keep complete sections together in a compact, scrollable form. Section
-- navigation changes presentation only; native editors own the field values.
local page,editors,theme,hidden,redraw=...
local s=rf2.executeScript('LVGL/studio',theme,page,editors)
local m,g,w=s.margin,4,s.w
local template=rf2.executeScript(rf2.radio.template)
local entries,groups={},{}
for i,field in ipairs(page.fields) do
    if not hidden[field] and editors[field] then entries[#entries+1]={item=field,index=i,y=field.y} end
end
for i,label in ipairs(page.labels) do
    if label.t~='' then entries[#entries+1]={item=label,y=label.y,order=i} end
end
table.sort(entries,function(a,b)
    if a.y~=b.y then return a.y<b.y end
    if not a.index~=not b.index then return not a.index end
    return (a.index or a.order)<(b.index or b.order)
end)
local current
for _,entry in ipairs(entries) do
    if not entry.index and entry.item.bold~=false and entry.item.x==template.margin then
        current={title=entry.item.t,items={}}
        groups[#groups+1]=current
    else
        if not current then current={title='Overview',items={}};groups[#groups+1]=current end
        current.items[#current.items+1]=entry
    end
end
if #groups==0 then groups[1]={title='Overview',items={}} end
page.uiPanel=math.max(1,math.min(page.uiPanel or 1,#groups))
local values={}
for i,group in ipairs(groups) do values[i]=page.lvglSectionTabs and page.lvglSectionTabs[i] or group.title end
local y
if page.lvglSectionTabs then
    y=s.tabs(values,page.uiPanel,function(value)page.uiPanel=value;redraw()end)+g
else
    local choiceW=w-m*2-(s.control+g)*2
    s.children[#s.children+1]={type='choice',name='Sections',x=m,y=m,w=choiceW,h=s.control,values=values,
        get=function() return page.uiPanel end,
        set=function(value) page.uiPanel=value;redraw() end}
    local prev=s.button(m+choiceW+g,m,s.control,s.control,'<<',function()page.uiPanel=page.uiPanel-1;redraw()end,false,'Previous section')
    local next=s.button(w-m-s.control,m,s.control,s.control,'>>',function()page.uiPanel=page.uiPanel+1;redraw()end,false,'Next section')
    prev.active=function()return page.uiPanel>1 end
    next.active=function()return page.uiPanel<#groups end
    y=m+s.control+g*2
end
local innerW=w-m*2-12
for _,entry in ipairs(groups[page.uiPanel].items) do
    local field=entry.item
    local editor=entry.index and editors[field]
    if editor then
        if editor.type=='button' then
            local _,lines=theme.wrap(field.t,innerW,SMLSIZE,s.scale)
            s.editor(entry.index,m,y,w-m*2,math.max(s.control,lines*s.textH+8))
            y=y+math.max(s.control,lines*s.textH+8)+g
        else
            local valueW=104
            if editor.values then
                for _,value in pairs(editor.values) do valueW=math.max(valueW,theme.textSize(value,SMLSIZE,s.scale)+28) end
            elseif editor.type=='textEdit' or editor.type=='label' then valueW=180 end
            valueW=math.min(valueW,224)
            local caption=field.t or ('Value '..entry.index)
            local captionW=innerW-valueW-10
            local _,lines=theme.wrap(caption,captionW,SMLSIZE,s.scale)
            local rowH=math.max(s.control,lines*s.textH)+8
            s.panel(m,y,w-m*2,rowH)
            s.label(m+6,y+(rowH-lines*s.textH)/2,captionW,caption,theme.ink,SMLSIZE,lines)
            local node=s.editor(entry.index,w-m-6-valueW,y+(rowH-s.control)/2,valueW)
            if node.type=='label' then
                local original=node.text
                node.text=function()return theme.fit(type(original)=='function' and original() or original,valueW,SMLSIZE,s.scale)end
                node.font=SMLSIZE
            end
            y=y+rowH+g
        end
    else
        local _,lines=theme.wrap(field.t,innerW,SMLSIZE,s.scale)
        s.label(m+6,y,innerW,function()return field.t end,theme.muted,SMLSIZE,lines)
        y=y+lines*s.textH+g*2
    end
end
return s.children
