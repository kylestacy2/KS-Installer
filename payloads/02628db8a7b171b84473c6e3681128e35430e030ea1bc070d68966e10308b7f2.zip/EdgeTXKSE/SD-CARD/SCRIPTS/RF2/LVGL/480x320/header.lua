-- Compact header for this resolution only. Keep status in the fixed top bar
-- and measure both lines so text never touches the page content.
local theme,title,subtitle,children,back,action,profileStatus,pageStatus,menuAction=...
local w,h,scale,control=theme.metrics()
local headerH=LCD_H-h
local m=6
local background=theme.panel(0,0,w,h,theme.background)
background.floating=true
table.insert(children,1,background)
local layout={{type='page',title=title,subtitle=subtitle,back=back,
    backButton=false,scrollBar=true,children=children}}
layout[#layout+1]=theme.panel(0,0,w,headerH,theme.background)
local buttonY=theme.round((headerH-control)/2)
layout[#layout+1]=theme.button({type='button',text='<',x=m,y=buttonY,w=control,h=control,press=back})
local right=w-m
if action then
    local actionText=type(action.text)=='function' and action.text() or action.text
    local width=math.max(70,theme.textSize(actionText,SMLSIZE,scale)+20)
    action.type,action.x,action.y='button',right-width,buttonY
    action.w,action.h=width,control
    layout[#layout+1]=theme.button(action,actionText=='Save' or actionText=='Saved' or actionText=='Applied')
    right=action.x-m
end
if menuAction then
    right=right-control
    layout[#layout+1]=theme.button({type='button',name='Page menu',text='...',
        x=right,y=buttonY,w=control,h=control,press=menuAction})
    right=right-m
end
local left=m*2+control
local titleRight=right
local titleH=select(2,theme.textSize('Ag',BOLD,scale))
local statusH=select(2,theme.textSize('Ag',SMLSIZE,scale))
local titleY=math.max(1,math.floor((headerH-titleH-statusH-4)/2))
if profileStatus then
    local width=theme.textSize(profileStatus(),SMLSIZE,scale)
    titleRight=right-width-m
    layout[#layout+1]={type='label',x=right-width,y=titleY,w=width,h=titleH,
        text=profileStatus,font=SMLSIZE,color=theme.muted}
end
local function getTitle()
    local value=type(subtitle)=='function' and subtitle() or subtitle
    return theme.fit(string.gsub(value~='' and value or title,' %- SIMULATOR',''),titleRight-left,BOLD,scale)
end
local function getStatus()
    local value=pageStatus or (rf2.offlineSimulator and 'PREVIEW / SIMULATOR' or 'ROTORFLIGHT  '..rf2.luaVersion)
    if type(value)=='function' then value=value() end
    return theme.fit(value,right-left,SMLSIZE,scale)
end
layout[#layout+1]={type='label',x=left,y=titleY,w=titleRight-left,h=titleH,text=getTitle,font=BOLD,color=theme.ink}
layout[#layout+1]={type='label',x=left,y=titleY+titleH,w=right-left,h=statusH,text=getStatus,font=SMLSIZE,
    color=pageStatus and theme.accent or theme.muted}
return layout
