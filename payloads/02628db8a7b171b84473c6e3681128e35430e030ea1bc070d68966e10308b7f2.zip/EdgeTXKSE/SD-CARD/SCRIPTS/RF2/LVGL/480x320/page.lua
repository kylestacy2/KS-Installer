-- Resolution-specific composition; all editors retain their original data
-- objects and callbacks from LVGL/page.lua.
local page,editors,theme,hidden,redraw=...
local children
if page.title=='PID Gains' then
    children=rf2.executeScript('LVGL/480x320/pids',page,editors,theme,redraw)
elseif page.rateFields then
    children=rf2.executeScript('LVGL/480x320/rates',page,editors,theme,redraw)
elseif page.title=='Swash Trim' then
    children=rf2.executeScript('LVGL/swashTrim',page,editors,theme)
elseif page.title=='Battery' then
    children=rf2.executeScript('LVGL/battery',page,editors,theme)
elseif page.title=='Settings' then
    for i,field in ipairs(page.fields) do
        if editors[field] then editors[field].name='Field '..i end
    end
    children=rf2.executeScript('LVGL/settings',page,editors,theme)
else
    children=rf2.executeScript('LVGL/480x320/form',page,editors,theme,hidden,redraw)
end
-- Rounded content cards match the native controls. Divider and dirty-marker
-- rectangles retain their sharp edges.
for _,child in ipairs(children) do
    if child.type=='rectangle' and child.h>lvgl.UI_ELEMENT_HEIGHT then
        child.rounded=theme.round(4*(lvgl.LCD_SCALE or 1))
    end
end
return children
