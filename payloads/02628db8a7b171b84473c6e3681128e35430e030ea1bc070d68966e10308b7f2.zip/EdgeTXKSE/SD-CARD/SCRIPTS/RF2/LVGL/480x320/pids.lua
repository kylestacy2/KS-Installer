-- Use the same three-axis cards and native control sizing at this resolution.
return rf2.executeScript('LVGL/precisionPids',...)
