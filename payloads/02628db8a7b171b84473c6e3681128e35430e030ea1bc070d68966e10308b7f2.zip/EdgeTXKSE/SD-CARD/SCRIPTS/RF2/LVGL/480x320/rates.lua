local page,editors,theme,redraw=...
if not page.collectiveOnly and not page.uiCollectiveCurve then
    return rf2.executeScript('LVGL/compactRates',page,editors,theme,redraw)
end
local s=rf2.executeScript('LVGL/studio',theme,page,editors)
local axis=4
-- Keep the signed collective curve available within Rates.
s.label(s.margin,s.margin+(s.control-s.textH)/2,s.w-s.margin*2,"Collective",theme.ink)
if not page.collectiveOnly then
    s.button(s.w-s.margin-100,s.margin,100,s.control,'All axes',function()
        page.uiCollectiveCurve=false;redraw()
    end)
end
local y=s.margin+s.control+s.gap
local function index(original) return page.rateFieldIndices[original] end
local m,g,w=s.margin,s.gap,s.w
do
    local cardW=math.floor((w-m*2-g*2)/3)
    -- Reserve real caption and editor heights before assigning graph space.
    local cardH=0
    for i=1,3 do
        local a,b=page.rateLabels[5+i*2],page.rateLabels[6+i*2]
        local caption=(a.t~='' and a.t..' ' or '')..b.t
        local _,lines=theme.wrap(caption,cardW-12,SMLSIZE,s.scale)
        cardH=math.max(cardH,12+lines*s.textH+4+s.control)
    end
    local cardY=s.h-m-cardH
    rf2.executeScript('LVGL/ratePlot',page,axis,s,theme,m,y,w-m*2,cardY-y-g)
    for i=1,3 do
        local a,b=page.rateLabels[5+i*2],page.rateLabels[6+i*2]
        local caption=(a.t~='' and a.t..' ' or '')..b.t
        local panelIndex=#s.children+1
        s.card(index((i-1)*4+axis),caption,m+(i-1)*(cardW+g),cardY,cardW,cardH)
        s.children[panelIndex].rounded=theme.round(4*s.scale)
    end
end
return s.children
