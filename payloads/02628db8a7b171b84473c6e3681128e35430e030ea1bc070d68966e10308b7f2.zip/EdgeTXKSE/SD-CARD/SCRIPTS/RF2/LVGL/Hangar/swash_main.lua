-- Full owns this scene: inline trim controls edit the existing page draft.
-- No repeat timer, scene rebuild, controller request or SD write per tap.
local page = ...
local fields = page.fields
local epoch = rf2.nativeSessionEpoch
local nodes = {
    {type='label', x=16, y=91, w=768, h=23,
        text='Adjust each trim below, then press Save.', font='small', color='muted'},
}
local ids = {'swash.roll', 'swash.pitch', 'swash.collective'}
for i, id in ipairs(ids) do
    local field = fields[i]
    local data = field.data
    local y = 132 + (i - 1) * 106
    local function editable(delta)
        if not page.uiCanInteract or not page.uiCanInteract() or not page.isReady
            or page.readOnly or field.readOnly or page.fields ~= fields
            or fields[i] ~= field or field.data ~= data then return false end
        if not rf2.offlineSimulator and epoch and lvgl.appSessionEpoch
            and lvgl.appSessionEpoch() ~= epoch then return false end
        -- Mixer trim is signed tenths of a percent. Never reinterpret a field
        -- with a different scale, or turn an invalid/out-of-range read into zero.
        local value = data.value
        if data.scale ~= 10 or (data.mult or 1) ~= 1 or type(value) ~= 'number'
            or value ~= value or value % 1 ~= 0 or not data.min or not data.max
            or value < data.min or value > data.max then return false end
        return delta < 0 and value > data.min or delta > 0 and value < data.max
    end
    nodes[#nodes+1] = {type='rectangle', x=16, y=y, w=768, h=96,
        filled=true, rounded=6, color='panel'}
    nodes[#nodes+1] = {type='label', x=32, y=y+35, w=164, h=27,
        text=field.t, font='bold', color='ink'}
    nodes[#nodes+1] = {type='label', x=212, y=y+17, w=220, h=27,
        text=field.negativeHint, font='normal', color='muted'}
    nodes[#nodes+1] = {type='label', x=212, y=y+53, w=220, h=27,
        text=field.positiveHint, font='normal', color='muted'}
    nodes[#nodes+1] = {type='label', x=440, y=y+22, w=132, h=55,
        valueField=id, font='large', color='accent', align=CENTER}
    nodes[#nodes+1] = {type='label', x=192, y=y+8, w=16, h=23,
        name='Changed '..i, text=function()return page.uiChanged(i) and '*' or ''end,
        font='small', color='accent'}
    for _, delta in ipairs({-1, 1}) do
        nodes[#nodes+1] = {type='button', x=delta<0 and 584 or 684, y=y+12,
            w=88, h=72, text=delta<0 and '-' or '+', font='large',
            color='raised', textColor='ink', cornerRadius=6,
            name=(delta<0 and 'Decrease ' or 'Increase ')..field.t,
            active=function()return editable(delta)end,
            press=function()
                if not editable(delta) then return end
                page.uiRun(function()
                    if not editable(delta) then return end
                    local value = data.value + delta
                    if field.change then field.change(field,value,page)end
                    data.value = value
                    if field.postEdit then field.postEdit(field,page)end
                end)
            end}
    end
end
nodes[#nodes+1] = {type='label', x=16, y=455, w=768, h=23,
    text='0.1% per tap / Changes stay in the draft until saved.', font='small', color='muted'}
return nodes
