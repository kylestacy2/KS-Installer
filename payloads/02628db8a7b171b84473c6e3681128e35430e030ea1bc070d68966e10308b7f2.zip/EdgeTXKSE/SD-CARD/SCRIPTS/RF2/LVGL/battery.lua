-- All six capacities share one form. Native editors, profile selection and
-- Save keeps the page's existing callbacks and field identities.
local page,editors,theme=...
local s=rf2.executeScript('LVGL/studio',theme,page,editors)
local m,g,w=s.margin,s.gap,s.w
local profiles=page.batSwitcher~=nil
local leftW=s.large and math.floor((w-m*2-g)/2) or w-m*2
local y=m
if profiles then
    local valueW=s.large and 104 or 84
    s.label(m,y+(s.control-s.textH)/2,leftW-valueW-g,'Active battery',theme.muted)
    s.editor(1,m+leftW-valueW,y,valueW)
    y=y+s.control+g
end
s.label(m,y,leftW,'Capacity (mAh)',theme.accent)
y=y+s.textH+g
local columns=profiles and 2 or 1
local cardW=math.floor((leftW-g*(columns-1))/columns)
local inset=s.large and 8 or 6
local cardH=inset*2+s.textH+4+s.control
local count=profiles and 6 or 1
for slot=1,count do
    local index=profiles and slot+1 or 1
    local x=m+(slot-1)%columns*(cardW+g)
    local yy=y+math.floor((slot-1)/columns)*(cardH+g)
    local card=s.panel(x,yy,cardW,cardH)
    card.rounded=theme.round(4*s.scale)
    s.label(x+inset,yy+inset,cardW-inset*2,profiles and ('Battery '..slot) or 'Capacity',theme.ink)
    s.editor(index,x+inset,yy+inset+s.textH+4,cardW-inset*2)
    local marker=s.panel(x,yy+cardH-2,cardW,2,theme.background)
    if page.uiChanged then
        marker.color=function()return page.uiChanged(index) and theme.accent or (theme.header or theme.surface)end
    end
end
local rows=math.ceil(count/columns)
local bottom=y+rows*cardH+(rows-1)*g
local x=s.large and m+leftW+g or m
local width=s.large and w-m-x or leftW
y=s.large and m or bottom+g*2
local first=profiles and 8 or 2
local function section(title,start)
    s.label(x,y,width,title,theme.accent)
    y=y+s.textH+4
    local valueW=s.large and 124 or 118
    local inset=4
    local captionW=width-valueW-inset*3
    for index=start,start+3 do
        local field=page.fields[index]
        local _,lines=theme.wrap(field.t,captionW,SMLSIZE,s.scale)
        local height=math.max(s.control,lines*s.textH)
        s.label(x+inset,y+(height-lines*s.textH)/2,captionW,field.t,theme.ink,SMLSIZE,lines)
        s.editor(index,x+width-inset-valueW,y+(height-s.control)/2,valueW)
        if page.uiChanged then
            local marker=s.panel(x,y,2,height,theme.background)
            marker.color=function()return page.uiChanged(index) and theme.accent or theme.background end
        end
        y=y+height+2
    end
end
section('Configuration',first)
y=y+g
section('Cell voltages',first+4)
return s.children
