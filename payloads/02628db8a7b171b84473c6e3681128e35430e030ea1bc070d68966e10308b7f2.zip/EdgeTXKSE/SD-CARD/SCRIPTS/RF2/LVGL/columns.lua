-- Wide-screen form layout. Positions are separate from the shared page model:
-- LCD navigation, field indexes, API data and edit callbacks stay untouched.
local function layout(page, hiddenFields)
    if LCD_W < 800 or page.lvglColumns == false then return {} end
    for _, collection in ipairs({ page.labels, page.fields }) do
        for _, item in ipairs(collection) do
            -- Rates/PID and other hand-tuned pages already have their own grid.
            if item.lvglPosition then return {} end
        end
    end

    local template = rf2.executeScript(rf2.radio.template)
    local margin = template.margin
    local spacing = template.lineSpacing
    local scale = (rf2.radio.screenMult or 1) / 1.75
    local columnWidth = (LCD_W / 1.75 - margin * 2) / 2
    local contentWidth = columnWidth - margin * 2
    local positions = {}
    local entries = {}
    local topFields = page.lvglTopFields or (page.profileSwitcher and 1 or 0)
    local rowY = rf2.radio.yMinLimit

    -- Conservative touch-font estimate in unscaled coordinates. Wrapping uses
    -- explicit newlines, so it works in both EdgeTX LVGL and the web preview.
    local function textWidth(text)
        local width = 0
        for char in string.gmatch(tostring(text or ""), ".") do
            if string.match(char, "[ilI1%.,:'!| ]") then width = width + 4
            elseif string.match(char, "[MWmw@%%]") then width = width + 11
            else width = width + 8 end
        end
        return width
    end

    local function wrap(text, width)
        local lines, line = {}, ""
        for paragraph in string.gmatch(tostring(text or "") .. "\n", "(.-)\n") do
            for word in string.gmatch(paragraph, "%S+") do
                if line ~= "" and textWidth(line .. " " .. word) > width then
                    lines[#lines + 1], line = line, ""
                end
                -- Long model names and serial numbers may have no spaces.
                while textWidth(word) > width do
                    local count = 1
                    while count < #word and textWidth(string.sub(word, 1, count + 1)) <= width do
                        count = count + 1
                    end
                    lines[#lines + 1], word = string.sub(word, 1, count), string.sub(word, count + 1)
                end
                line = line == "" and word or line .. " " .. word
            end
            lines[#lines + 1], line = line, ""
        end
        return table.concat(lines, "\n"), #lines
    end

    for i, field in ipairs(page.fields) do
        if hiddenFields and hiddenFields[field] then
            -- Header status consumes no form row.
        elseif i <= topFields then
            rowY = math.max(rowY, field.y + spacing * 1.25)
        elseif field ~= page.lvglHeaderField and (field.t or field.data) then
            entries[#entries + 1] = { item = field, field = true, order = i }
        end
    end
    for i, label in ipairs(page.labels) do
        entries[#entries + 1] = { item = label, order = i }
    end
    table.sort(entries, function(a, b)
        if a.item.y ~= b.item.y then return a.item.y < b.item.y end
        if a.field ~= b.field then return not a.field end
        return a.order < b.order
    end)

    local sections = {}
    for _, entry in ipairs(entries) do
        local item = entry.item
        if #sections == 0 or (not entry.field and item.bold ~= false and item.x == margin) then
            sections[#sections + 1] = {}
        end
        local section = sections[#sections]
        section[#section + 1] = entry
    end

    -- A plain list (e.g. Smart Fuel or Servos) still gets two useful columns.
    -- A single section keeps its heading above both halves.
    if #sections == 1 then
        local section = sections[1]
        if section[1] and not section[1].field then
            local heading = table.remove(section, 1).item
            local _, lines = wrap(heading.t, contentWidth)
            positions[heading] = { x = margin, y = rowY, wrap = function(text) return wrap(text, contentWidth) end }
            rowY = rowY + math.max(spacing, lines * 20 + 5)
        end
        if #section > 1 then
            local second = {}
            local split = math.ceil(#section / 2)
            while #section > split do second[#second + 1] = table.remove(section, split + 1) end
            sections[2] = second
        end
    end

    local function place(section, columnX, startY)
        local y = startY
        for _, entry in ipairs(section) do
            local item = entry.item
            local indent = math.min(math.max(0, item.x - margin), template.indent * 2)
            local x = columnX + indent
            local available = contentWidth - indent
            local position = { x = x, y = y }
            positions[item] = position
            if not entry.field then
                local _, lines = wrap(item.t, available)
                position.wrap = function(text) return wrap(text, available) end
                y = y + math.max(spacing, lines * 20 + 5)
            elseif item.t and string.sub(item.t, 1, 1) == "[" and not item.data then
                position.w = math.min(item.w or 200, contentWidth / scale)
                position.x = columnX + math.min(indent, contentWidth - position.w * scale)
                y = y + spacing
            else
                local data = item.data or {}
                local width = item.w or (type(data.value) == "string" and 125 or 75)
                if data.table and not item.w then
                    local longest = 0
                    for _, option in pairs(data.table) do longest = math.max(longest, textWidth(option)) end
                    width = math.max(60, math.min(150, longest / scale + 24))
                end
                position.w = math.min(width, contentWidth / scale)
                position.sp = columnX + contentWidth - position.w * scale
                local labelWidth = position.sp - x - 8
                if item.t and not item.lvglInline and textWidth(item.t) > labelWidth then
                    local _, lines = wrap(item.t, available)
                    position.wrap = function(text) return wrap(text, available) end
                    position.labelY = y
                    position.y = y + lines * 20 + 3
                end
                y = position.y + spacing
            end
        end
        return y
    end

    if page.lvglIndependentColumns then
        -- Let a short left section continue without waiting for the right one.
        local bottoms = { rowY, rowY }
        for i, section in ipairs(sections) do
            local column = (page.lvglSectionColumns and page.lvglSectionColumns[i]) or (i - 1) % 2 + 1
            bottoms[column] = place(section, margin + (column - 1) * columnWidth, bottoms[column]) + spacing * 0.25
        end
        return positions
    end

    for i = 1, #sections, 2 do
        local bottom = place(sections[i], margin, rowY)
        if sections[i + 1] then
            bottom = math.max(bottom, place(sections[i + 1], margin + columnWidth, rowY))
        end
        rowY = bottom + spacing * 0.25
    end
    return positions
end

return layout
