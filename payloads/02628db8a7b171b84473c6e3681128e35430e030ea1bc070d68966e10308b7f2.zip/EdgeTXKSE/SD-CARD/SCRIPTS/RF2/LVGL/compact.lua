-- Compact native forms. Only widget geometry changes: the page model and the
-- editor objects (including their callbacks) remain owned by LVGL/page.lua.
local page, editors, theme, hiddenFields = ...
hiddenFields = hiddenFields or {}
local width, _, scale, control = theme.metrics()
local round = theme.round
local margin, gap = round(6 * scale), round(3 * scale)
local valueGap = round(8 * scale)
local columns = width >= 480 and 2 or 1
local columnWidth = math.floor((width - margin * 2 - gap * (columns - 1)) / columns)
local children = {}
local _, textHeight = theme.textSize("Ag", SMLSIZE, scale)
local _, bodyHeight = theme.textSize("Ag", 0, scale)
local _, headingHeight = theme.textSize("Ag", BOLD, scale)
textHeight, bodyHeight, headingHeight = math.ceil(textHeight), math.ceil(bodyHeight), math.ceil(headingHeight)

-- Preserve explicit lines and split long identifiers as well as ordinary words.
local function wrap(text, available, font)
    local lines = {}
    for paragraph in string.gmatch(tostring(text or "") .. "\n", "(.-)\n") do
        local line = ""
        for word in string.gmatch(paragraph, "%S+") do
            if line ~= "" and theme.textSize(line .. " " .. word, font, scale) > available then
                lines[#lines + 1], line = line, ""
            end
            while theme.textSize(word, font, scale) > available and #word > 1 do
                local count = 1
                while count < #word and theme.textSize(string.sub(word, 1, count + 1), font, scale) <= available do
                    count = count + 1
                end
                lines[#lines + 1], word = string.sub(word, 1, count), string.sub(word, count + 1)
            end
            line = line == "" and word or line .. " " .. word
        end
        lines[#lines + 1] = line
    end
    return table.concat(lines, "\n"), #lines
end

local function label(item, x, y, w, heading, font, centered)
    font = heading and BOLD or font or SMLSIZE
    local source = item.t
    local text, lines = wrap(source, w, font)
    children[#children + 1] = {type = "label", x = round(x), y = round(y), w = math.floor(w),
        font = font, color = heading and theme.ink or theme.muted, align = centered and CENTER or nil,
        text = function()
            if source ~= item.t then source = item.t; text = wrap(source, w, font) end
            return text
        end}
    return lines * (heading and headingHeight or font == 0 and bodyHeight or textHeight)
end

-- Center the two form columns together, retaining their shared value alignment.
-- Parameter text keeps a common left edge within the centered label column.
-- Titles, full-width notes and independently centered buttons stay in place.
local function centerContent(group, x, available)
    local right = x
    for _, child in ipairs(group) do right = math.max(right, child.x + child.w) end
    local shift = math.max(0, round((available - (right - x)) / 2))
    for _, child in ipairs(group) do child.x = child.x + shift end
end

-- Prefer the native normal font, retaining small text when its larger sibling
-- would add lines/taller rows. This is calculated only when the page is built.
local function captionFont(text, available)
    local _, smallLines = wrap(text, available, SMLSIZE)
    local _, normalLines = wrap(text, available, 0)
    if normalLines * bodyHeight <= math.max(control, smallLines * textHeight) then
        return 0, bodyHeight, normalLines
    end
    return SMLSIZE, textHeight, smallLines
end

local function editorWidth(item, available)
    local child, data = editors[item], item.data or {}
    local w = round(56 * scale)
    if not child then return w end
    if child.type == "choice" then
        for _, value in pairs(child.values) do w = math.max(w, theme.textSize(value, 0, scale) + round(24 * scale)) end
    elseif child.type == "textEdit" or (child.type == "label" and type(data.value) == "string") then
        w = math.max(w, math.min(round(130 * scale), theme.textSize(tostring(data.value), 0, scale) + gap * 2))
    elseif child.display then
        for _, value in ipairs({child.get(), child.min or 0, child.max or 0}) do
            w = math.max(w, theme.textSize(child.display(value), 0, scale) + round(12 * scale))
        end
    end
    local minimum = math.ceil(w)
    w = math.max(round(64 * scale), minimum)
    if item.t then
        -- Reclaim unused editor width on tight rows before reducing the caption
        -- font. Keep room for every value, its unit, and the choice arrow.
        local room = math.floor(available - theme.textSize(item.t, 0, scale) - valueGap)
        if room >= minimum then w = math.min(w, room) end
    end
    return math.min(w, available)
end

local function inlineGap(item, available, editorWidth)
    if not item.t then return valueGap end
    -- Wide ESC choices can already fill a column. Use as much of the new gap
    -- as fits there without shrinking the caption or introducing another line.
    local space = available - editorWidth - gap
    if space < round(65 * scale) then return valueGap end
    local font = captionFont(item.t, space)
    local text = wrap(item.t, space, font)
    local longest = 0
    for line in string.gmatch(text .. "\n", "(.-)\n") do
        longest = math.max(longest, theme.textSize(line, font, scale))
    end
    return math.min(valueGap, math.max(gap, math.floor(available - editorWidth - longest)))
end

local function row(item, x, y, available, offset, group)
    local start = #children + 1
    local child = editors[item]
    local isButton = child and child.type == "button"
    if isButton then
        child.w = math.min(available, math.max(round(110 * scale), theme.textSize(child.text(), SMLSIZE, scale) + gap * 4))
        child.x, child.y, child.h = round(x + (available - child.w) / 2), round(y), control
        children[#children + 1] = child
        return control + gap
    end
    if not item.data or item.data.value == nil or not child then
        return label(item, x, y, available, false, captionFont(item.t, available), false) + gap
    end
    local w = editorWidth(item, available)
    local spacing = inlineGap(item, available, w)
    local captionWidth = math.min(offset and offset - spacing or available - w - spacing, available - w - spacing)
    local hasCaption = item.t and item.t ~= ""
    local captionHeight, rowHeight = 0, control
    local valueX = x + (hasCaption and captionWidth + spacing or 0)
    if hasCaption and captionWidth < math.min(round(65 * scale), math.ceil(theme.textSize(item.t, 0, scale))) then
        captionHeight = label(item, x, y, available, false, captionFont(item.t, available), false)
        y = y + captionHeight + gap
        valueX = x + (available - w) / 2
    elseif hasCaption then
        local font, height, lines = captionFont(item.t, captionWidth)
        captionHeight = lines * height
        rowHeight = math.max(control, captionHeight)
        label(item, x, y + (rowHeight - captionHeight) / 2, captionWidth, false, font)
        captionHeight = 0
    elseif group then
        valueX = x + (available - w) / 2
    end
    child.x, child.y, child.w, child.h = round(valueX), round(y + (rowHeight - control) / 2), math.floor(w), control
    if child.type == "label" then
        local value = child.text
        local function getText() return type(value) == "function" and value() or value end
        local source = getText()
        local font, height = captionFont(source, w)
        child.font, child.align = font, CENTER
        local text, lines = wrap(source, w, font)
        rowHeight = math.max(rowHeight, lines * height)
        child.y, child.h = round(y + (rowHeight - lines * height) / 2), lines * height
        child.text = function()
            local current = getText()
            if source ~= current then source = current; text = wrap(source, w, font) end
            return text
        end
    end
    children[#children + 1] = child
    if group and hasCaption and captionHeight == 0 then
        for i = start, #children do group[#group + 1] = children[i] end
    end
    return captionHeight + (captionHeight > 0 and gap or 0) + rowHeight + gap
end

local template = rf2.executeScript(rf2.radio.template)

-- Experimental is a byte table, not a sequence of unrelated section headings.
if page.title == "Experimental" then
    local rows = math.ceil(#page.fields / columns)
    for column = 1, columns do
        local x = margin + (column - 1) * (columnWidth + gap)
        local valueX = x + round(55 * scale)
        local y = margin + gap
        children[#children + 1] = theme.panel(x, margin, columnWidth,
            headingHeight + gap * 2 + rows * (control + gap), theme.surface, margin)
        label(page.labels[1], x + gap, y, valueX - x - gap, true)
        label(page.labels[#page.labels], valueX, y, columnWidth - (valueX - x) - gap, true)
        y = y + headingHeight + gap
        for r = 1, rows do
            local i = (column - 1) * rows + r
            local item = page.fields[i]
            if item then
                label(page.labels[i + 1], x + gap, y + (control - bodyHeight) / 2, valueX - x - gap, false, 0)
                row(item, valueX, y, columnWidth - (valueX - x) - gap)
                y = y + control + gap
            end
        end
    end
    return children
end

local topCount = page.lvglTopFields or ((page.profileSwitcher or page.rateSwitcher) and 1 or 0)
local topY = margin
local function topRow(item)
    local w = width - margin * 2
    local start = #children + 1
    local group = {}
    local h = row(item, margin + gap, topY + gap, w - gap * 2,
        math.ceil(theme.textSize(item.t or "", 0, scale)) + valueGap, group) + gap
    centerContent(group, margin + gap, w - gap * 2)
    table.insert(children, start, theme.panel(margin, topY, w, h, theme.surface, margin))
    topY = topY + h + gap
end
if page.lvglHeaderField then topRow(page.lvglHeaderField) end
for i = 1, topCount do if not hiddenFields[page.fields[i]] then topRow(page.fields[i]) end end

-- Merge labels and fields in their original reading order, keeping nested
-- headings with their parent. No shared coordinates or indexes are modified.
local entries, sections = {}, {}
for i, item in ipairs(page.fields) do
    if i > topCount and not hiddenFields[item] and item ~= page.lvglHeaderField and (item.t or item.data) then
        entries[#entries + 1] = {item = item, field = true, order = i}
    end
end
for i, item in ipairs(page.labels) do
    if item.t ~= "" then entries[#entries + 1] = {item = item, order = i} end
end
table.sort(entries, function(a, b)
    if a.item.y ~= b.item.y then return a.item.y < b.item.y end
    if a.field ~= b.field then return not a.field end
    return a.order < b.order
end)
for _, entry in ipairs(entries) do
    if #sections == 0 or (not entry.field and entry.item.bold ~= false and entry.item.x == template.margin) then
        sections[#sections + 1] = {}
    end
    local section = sections[#sections]
    section[#section + 1] = entry
end

-- A plain parameter list can flow down the left and continue on the right.
if columns == 2 and #sections == 1 and #sections[1] > 2 then
    local section, second = sections[1], {}
    local heading = not section[1].field and table.remove(section, 1) or nil
    local split = math.ceil(#section / 2)
    while #section > split do second[#second + 1] = table.remove(section, split + 1) end
    if heading then
        table.insert(section, 1, heading)
        table.insert(second, 1, heading)
    end
    sections[2] = second
end

local bottoms = {topY, topY}
for i, section in ipairs(sections) do
    local mapping = page.lvglCompactSectionColumns or page.lvglSectionColumns
    local column = columns == 1 and 1 or (mapping and mapping[i]) or (i - 1) % 2 + 1
    local x = margin + (column - 1) * (columnWidth + gap)
    local startY, start = bottoms[column], #children + 1
    local y, available = startY + gap, columnWidth - gap * 2
    local group = {}
    local offset = round(80 * scale) + valueGap
    for _, entry in ipairs(section) do
        if entry.field and entry.item.t and editors[entry.item] and editors[entry.item].type ~= "button" then
            local w = editorWidth(entry.item, available)
            local spacing = inlineGap(entry.item, available, w)
            offset = math.max(offset, math.min(theme.textSize(entry.item.t, 0, scale) + spacing, available - w))
        end
    end
    for j, entry in ipairs(section) do
        if entry.field then
            y = y + row(entry.item, x + gap, y, available, math.ceil(offset), group)
        else
            local following = section[j + 1]
            local nestedHeading = entry.item.bold == false and following and following.field and following.item.x > entry.item.x
            local heading = entry.item.bold ~= false
            y = y + label(entry.item, x + gap, y, available, heading, nestedHeading and 0 or SMLSIZE, not heading and not nestedHeading)
                + (heading and math.max(1, round(scale)) or gap)
        end
    end
    centerContent(group, x + gap, available)
    table.insert(children, start, theme.panel(x, startY, columnWidth, y - startY, theme.surface, margin))
    bottoms[column] = y + gap
end

return children
