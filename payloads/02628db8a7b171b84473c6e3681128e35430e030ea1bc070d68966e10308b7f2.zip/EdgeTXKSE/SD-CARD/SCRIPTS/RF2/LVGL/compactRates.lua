local page,editors,theme,redraw=...
local s=rf2.executeScript('LVGL/studio',theme,page,editors)
local function index(original) return page.rateFieldIndices[original] end
local m,g,w=s.margin,s.gap,s.w
if not page.collectiveOnly and not page.uiCollectiveCurve then
    -- Keep the rate model beside all four axes. Reuse the native
    -- editors so scales, bounds, dirty tracking and save callbacks are intact.
    local captionW=theme.textSize('Rates type',SMLSIZE,s.scale)
    local optionsW=s.large and 144 or 80
    local choiceX=m+captionW+g
    local choiceW=math.min(s.large and 240 or 160,w-m-optionsW-g-choiceX)
    s.label(m,m+(s.control-s.textH)/2,captionW,'Rates type',theme.muted)
    s.editor(index(13),choiceX,m,choiceW)
    s.button(w-m-optionsW,m,optionsW,s.control,page.uiRatesOptions and 'All axes' or 'Options',
        function() page.uiRatesOptions=not page.uiRatesOptions;redraw() end)
    local y=m+s.control+g
    if page.uiRatesOptions then
        local cardW=math.floor((w-m*2-g)/2)
        local cardH=s.h-y-m-s.control-g*3
        for col,original in ipairs({17,18}) do
            if page.rateFields[original] then
                s.card(index(original),page.rateFields[original].t,m+(col-1)*(cardW+g),y,cardW,cardH)
            end
        end
        s.copy(index(15),index(16),s.h-m-s.control-g)
        return s.children
    end

    local captions={}
    for col=1,3 do
        local a,b=page.rateLabels[5+col*2],page.rateLabels[6+col*2]
        local caption=(a.t~='' and a.t..' ' or '')..b.t
        if caption=='Center Sens' then caption=s.large and 'Center sensitivity' or 'Center sens.' end
        captions[col]=caption
    end
    local function roundedPanel(x,yy,width,height,color,radius)
        local panel=s.panel(x,yy,width,height,color)
        panel.rounded=radius
        return panel
    end

    -- Tall axis cards repeat the parameter labels so every value has a clear
    -- context. Keep matching parameters at the same height for comparison.
    local cardW=math.floor((w-m*2-g*3)/4)
    local cardH=s.h-y-m
    local inset=s.large and 18 or 8
    local innerW=cardW-inset*2
    local titleH=select(2,theme.textSize('Roll',MIDSIZE,s.scale))
    local headingH=titleH+g
    local labelGap=s.large and 6 or 3
    local editorH=math.max(s.control,s.large and 48 or s.control)
    local slotH=math.floor((cardH-inset*2-headingH)/3)
    local labelHeights,requiredH={},0
    for col,caption in ipairs(captions) do
        local _,lines=theme.wrap(caption,innerW,SMLSIZE,s.scale)
        labelHeights[col]=lines*s.textH
        requiredH=math.max(requiredH,labelHeights[col]+labelGap+editorH+4)
    end
    if w>=480 and slotH>=requiredH and theme.textSize('Collective',MIDSIZE,s.scale)<=innerW then
        local radius=theme.round(s.large and 10 or 6)
        for axis,name in ipairs({'Roll','Pitch','Yaw','Collective'}) do
            local x=m+(axis-1)*(cardW+g)
            roundedPanel(x,y,cardW,cardH,theme.line,radius)
            roundedPanel(x+1,y+1,cardW-2,cardH-2,theme.header or theme.surface,radius-1)
            s.label(x+inset,y+inset,innerW,name,theme.accent,MIDSIZE)
            s.panel(x+inset,y+inset+titleH+math.floor(g/2),innerW,1,theme.line)
            for col,caption in ipairs(captions) do
                local yy=y+inset+headingH+(col-1)*slotH
                local fieldIndex=index((col-1)*4+axis)
                s.label(x+inset,yy,innerW,caption,theme.muted,SMLSIZE,labelHeights[col]/s.textH)
                local editorY=yy+labelHeights[col]+labelGap
                s.editor(fieldIndex,x+inset,editorY,innerW,editorH)
            end
        end
        return s.children
    end

    -- Short displays use horizontal cards to keep all twelve native editors in
    -- view without reducing control height or introducing axis navigation.
    inset=s.large and 14 or 6
    local axisW=s.large and 100 or (w<480 and 48 or 100)
    local valueX=m+inset+axisW+g
    local valueW=math.floor((w-m*2-inset*2-axisW-g*3)/3)
    headingH=0
    for col,caption in ipairs(captions) do
        local _,lines=theme.wrap(caption,valueW,SMLSIZE,s.scale)
        labelHeights[col]=lines*s.textH
        headingH=math.max(headingH,lines*s.textH)
    end
    for col,caption in ipairs(captions) do
        s.label(valueX+(col-1)*(valueW+g),y+(headingH-labelHeights[col])/2,
            valueW,caption,theme.muted,SMLSIZE,labelHeights[col]/s.textH)
    end
    y=y+headingH+g
    local rowH=math.max(s.control+4,math.floor((s.h-m-y-g*3)/4))
    for axis,name in ipairs({'Roll','Pitch','Yaw','Collective'}) do
        local rowY=y+(axis-1)*(rowH+g)
        roundedPanel(m,rowY,w-m*2,rowH,theme.header or theme.surface,theme.round(4*s.scale))
        s.panel(m,rowY+6,2,rowH-12,theme.accent)
        local font=s.large and MIDSIZE or BOLD
        local textH=select(2,theme.textSize(name,font,s.scale))
        s.label(m+inset,rowY+(rowH-textH)/2,axisW,name,theme.accent,font)
        for col=1,3 do
            local fieldIndex=index((col-1)*4+axis)
            local x=valueX+(col-1)*(valueW+g)
            s.editor(fieldIndex,x,rowY+(rowH-s.control)/2,valueW)
        end
    end
    return s.children
end

local axis=4
local y
-- The curve is a local view of the same Rates page and draft.
s.label(s.margin,s.margin+(s.control-s.textH)/2,s.w-s.margin*2,"Collective",theme.ink)
if not page.collectiveOnly then
    s.button(s.w-s.margin-100,s.margin,100,s.control,'All axes',function()
        page.uiCollectiveCurve=false;redraw()
    end)
end
y=s.margin+s.control+s.gap
do
    local cardW=math.floor((w-m*2-g*2)/3)
    local cardH=s.large and 108 or 70
    local cardY=s.h-m-cardH
    rf2.executeScript('LVGL/ratePlot',page,axis,s,theme,m,y,w-m*2,cardY-y-g)
    for i=1,3 do
        local a,b=page.rateLabels[5+i*2],page.rateLabels[6+i*2]
        local caption=(a.t~='' and a.t..' ' or '')..b.t
        local panelIndex=#s.children+1
        s.card(index((i-1)*4+axis),caption,m+(i-1)*(cardW+g),cardY,cardW,cardH)
        s.children[panelIndex].rounded=theme.round(4*s.scale)
    end
end
return s.children
