local w=rf2.executeScript('LVGL/hangarWidgets')
local config=rf2.executeScript('F/hangarConfig')
local edits=rf2.executeScript('F/editSession')
return function(page,index,spec,caption,done)
 if spec.headspeedPrefs then
  return rf2.executeScript('LVGL/headspeedFavorites')(spec.current,function()done(false)end)
 end
 local field=page.fields[index];local data=field.data
 local draft,start=data.value,data.value
 local context=edits.context(page)
 local isHeadspeed=spec.id=='governor.headspeed'
 local store=isHeadspeed and rf2.executeScript('F/modelPreferences')
 local modelKey=store and store.identity()
 local favorites=isHeadspeed and store.load(modelKey,'speeds') or nil
 favorites=favorites or {0,0,0,0}
 local function current()return (not spec.current or spec.current()) and (not store or modelKey==store.identity()) and edits.context(page)==context
  and (page.uiScript=='settings' or not rf2.nativeSessionEpoch or rf2.offlineSimulator or not lvgl.appSessionEpoch or lvgl.appSessionEpoch()==rf2.nativeSessionEpoch) end
 local prefs=config.get()
 local low,high,step=data.min or 0,data.max or 100,data.mult or 1
 local gain=spec.id and string.match(spec.id,'^pids%.[^.]+%.([^.]+)$')
 local gainMax=gain and prefs.pidGainMax[gain]
 if gainMax then high=math.min(high,gainMax)end
 local rangeLow,rangeHigh=low,high
 local axis=spec.id and string.match(spec.id,'^rates%.(.-)%.rate$')
 if axis and prefs.rateSliderMax[axis] then rangeHigh=math.max(start,math.min(high,prefs.rateSliderMax[axis]*(data.scale or 1)))end
 -- Keep the controller's full range for exact entry and existing values.
 if spec.id=='governor.headspeed' then rangeLow=math.max(low,900*(data.scale or 1));rangeHigh=math.min(high,5500*(data.scale or 1))end
 local firstStep=math.floor(rangeLow/step)
 local held,nextRepeat,choicePage,exact=nil,nil,1,false
 local choiceKeys
 if data.table then
  choiceKeys={};for key in pairs(data.table)do if type(key)=='number' then choiceKeys[#choiceKeys+1]=key end end
  table.sort(choiceKeys,function(a,b)if spec.favorite then return string.lower(data.table[a])<string.lower(data.table[b])end;return a<b end)
  if spec.favorite then for i,key in ipairs(choiceKeys)do if key==start then choicePage=math.ceil(i/6);break end end end
 end
 local entry,replaceEntry=w.value(data,start),true
 local function clamp(value) return math.max(low,math.min(high,math.floor(value/step+0.5)*step))end
 local function entryValue()
  if not string.match(entry,'^%-?%d+%.?%d*$') then return end
  local v=tonumber(entry)*(data.scale or 1)
  local rounded=math.floor(v/step+.5)*step
  if v>=low-.0001 and v<=high+.0001 and math.abs(v-rounded)<.0001 then return math.max(low,math.min(high,rounded))end
 end
 local function validEntry()return entryValue()~=nil end
 local function keypress(key)
  local nextValue
  if key=='Clear' then nextValue=''
  elseif key=='Del' then nextValue=string.sub(entry,1,-2)
  elseif key=='+/-' then nextValue=string.sub(entry,1,1)=='-' and string.sub(entry,2) or '-'..entry
  elseif key=='.' then
   nextValue=replaceEntry and '0' or entry
   if nextValue=='' or nextValue=='-' then nextValue=nextValue..'0' end
   if not string.find(nextValue,'.',1,true)then nextValue=nextValue..'.' end
  else nextValue=(replaceEntry and '' or entry)..key end
  if #nextValue<=10 then entry=nextValue;replaceEntry=false;local value=entryValue();if value then draft=value end end
 end
 local function change(delta)
  if gainMax and delta>0 and draft>=high then return end
  draft=clamp(draft+delta*step);entry=w.value(data,draft);replaceEntry=true
 end
 local function stop()held,nextRepeat=nil,nil end
 local build,nativeTicket
 local editorTick=function()
  if not current()then
   if nativeTicket and lvgl.cancelAppNumber then lvgl.cancelAppNumber()end
   nativeTicket=nil;stop();done(false);return
  end
  if nativeTicket then
   local state,value=lvgl.takeAppNumber(nativeTicket)
   if state=='pending' then return end
   nativeTicket=nil
   if state=='done' and type(value)=='number' and value>=low and value<=high and value%step==0 then
    draft=value;entry=w.value(data,draft);done(true)
   else done(false)end
   return
  end
  if held and nextRepeat and rf2.clock()>=nextRepeat then change(held);nextRepeat=rf2.clock()+(prefs.buttonRepeat=='fast' and .08 or .18)end
 end
 rf2.hangarTick=editorTick
 local function exactEntry()
  local scale=data.scale or 1
  local precision=scale==1 and 0 or scale==10 and 1 or scale==100 and 2 or nil
  if precision and lvgl and type(lvgl.appServiceProtocol)=='function' and lvgl.appServiceProtocol()==1
   and type(lvgl.openAppNumber)=='function' and type(lvgl.takeAppNumber)=='function' then
   nativeTicket=lvgl.openAppNumber({value=draft,min=low,max=high,precision=precision,step=step,
    title=caption,unit=data.unit or '',live=not rf2.offlineSimulator and page.uiScript~='settings'})
   if nativeTicket then stop();return end
  end
  exact=true;entry=w.value(data,draft);replaceEntry=true;build()
 end
 local generation=0
 build=function()
  generation=generation+1;local token=generation
  stop()
  local palette=page.hangarSettings and index==1 and config.options[1].values[draft+1] or nil
  local p=w.palette(palette)
  local n=w.scene(function()done(false)end,p)
  w.header(n,p,page.title,function()done(false)end)
  w.panel(n,p,72,90,656,380)
  local title,font=w.fit(caption,608,'large');w.label(n,p,96,104,608,title,font)
  local sub=spec.favorite and 'Choosing a page already on Home swaps the two tiles.' or spec.selection and 'Selection is sent separately after confirmation.' or prefs.startingValue=='on' and 'Starting value '..w.value(data,start,true) or ''
  if gainMax then sub='Maximum '..high..(start>high and ' for new edits; current '..start..' is preserved.' or ' for new edits. Starting value '..start)end
  w.label(n,p,96,153,608,sub,'small','muted')
  if data.table then
   local keys=choiceKeys
   choicePage=math.max(1,math.min(choicePage,math.ceil(#keys/6)))
   for slot=1,6 do
    local key=keys[(choicePage-1)*6+slot]
    if key~=nil then
     local caption=data.table[key]
     if spec.favorite then for i=12,16 do if page.fields[i].data.value==key then caption=caption..' / '..(i-11);break end end end
     local text=w.fit(caption,270,'small')
     w.button(n,p,96+(slot-1)%2*310,190+math.floor((slot-1)/2)*66,298,56,text,function()draft=key;build()end,draft==key,'Choice '..key)
    end
   end
   if #keys>6 then
    local b=w.button(n,p,278,418,48,44,'<',function()choicePage=choicePage-1;build()end);b.active=function()return choicePage>1 end
    w.label(n,p,336,430,110,choicePage..' / '..math.ceil(#keys/6),'small','muted')
    b=w.button(n,p,458,418,48,44,'>',function()choicePage=choicePage+1;build()end);b.active=function()return choicePage<math.ceil(#keys/6)end
   end
  elseif exact or spec.input=='keypad' then
   w.label(n,p,96,194,248,function()return entry=='' and '--' or entry end,'large','accent',55).name='Live value'
   w.label(n,p,96,240,248,data.unit or '','small','muted')
   w.label(n,p,96,270,248,function()return validEntry() and ('Step '..w.value(data,step,true)) or 'Enter a valid value' end,'small','muted')
   w.label(n,p,96,300,248,w.value(data,low)..' to '..w.value(data,high),'small','muted')
   if spec.input=='keypad' then
    w.button(n,p,96,334,116,48,'-25',function()change(-1)end,false,'Decrease value')
    w.button(n,p,224,334,116,48,'+25',function()change(1)end,false,'Increase value')
   else
    local sign=w.button(n,p,96,334,72,48,'+/-',function()keypress('+/-')end);sign.active=function()return low<0 end
    -- EdgeTX floors floats in mixed float/integer equality; use ordering here.
    local point=w.button(n,p,180,334,72,48,'.',function()keypress('.')end);point.active=function()return step/(data.scale or 1)%1>0 end
    w.button(n,p,264,334,80,48,'Slider',function()exact=false;build()end,false,'Use slider')
   end
   for i,key in ipairs({'1','2','3','4','5','6','7','8','9','Clear','0','Del'})do
    w.button(n,p,368+(i-1)%3*112,184+math.floor((i-1)/3)*54,104,46,key,function()keypress(key)end)
   end
  else
   local function adjust(x,delta,text,name)
    local b=w.button(n,p,x,192,64,64,text,function()change(delta)end,false,name)
    if prefs.buttonRepeat~='off' then
     b.type='momentaryButton';b.press=function()change(delta);held=delta;nextRepeat=rf2.clock()+.45 end;b.release=stop
    end
    if gainMax then b.active=function()return delta<0 and draft>low or delta>0 and draft<high end end
   end
   adjust(96,-1,'-','Decrease value');adjust(640,1,'+','Increase value')
   w.label(n,p,180,197,440,function()return w.value(data,draft,true)end,'huge','accent',55).name='Live value'
   do
    n[#n+1]={type='slider',name='Touch slider',x=110,y=isHeadspeed and 264 or 286,w=580,min=0,max=math.max(1,math.ceil(rangeHigh/step)-firstStep),color=p.accent,get=function()return math.floor(math.max(rangeLow,math.min(draft,rangeHigh))/step+.5)-firstStep end,set=function(v)draft=clamp(math.max(rangeLow,math.min(rangeHigh,(firstStep+v)*step)))end}
    w.label(n,p,110,isHeadspeed and 298 or 336,280,w.value(data,rangeLow,true),'small','muted')
    w.label(n,p,480,isHeadspeed and 298 or 336,210,w.value(data,rangeHigh,true),'small','muted')
   end
   if isHeadspeed then
    for i=1,4 do local rpm=favorites[i]
     if rpm>0 then w.button(n,p,96+(i-1)*154,325,146,44,tostring(rpm),function()
      if current()then stop();draft=rpm*(data.scale or 1)end
     end,false,'Preset '..i)end
    end
    w.button(n,p,548,374,156,44,'Manage',function()
     if not current()then return end
     stop();rf2.executeScript('LVGL/headspeedFavorites')(current,function(result)
      if result then favorites=result end
      if current()then rf2.hangarTick=editorTick;build()else done(false)end
     end)
    end)
   end
   if spec.id and string.match(spec.id,'^swash%.')then
    w.button(n,p,96,367,160,44,'Center (0)',function()draft=0;stop()end)
    w.label(n,p,96,260,608,(field.negativeHint or '')..' / '..(field.positiveHint or ''),'small','muted')
   end
   w.button(n,p,isHeadspeed and 96 or 270,isHeadspeed and 374 or 367,isHeadspeed and 440 or 260,44,'Type exact value',exactEntry)
  end
  w.button(n,p,96,isHeadspeed and 424 or 418,136,44,'Cancel',function()stop();done(false)end)
  local apply=w.button(n,p,568,isHeadspeed and 424 or 418,136,44,spec.selection and 'Select' or 'Done',function()stop();done(true)end,true,spec.selection and 'Select' or 'Done')
  if exact or spec.input=='keypad' then apply.active=validEntry end
  for _,node in ipairs(n)do
   for _,key in ipairs({'press','release','set','back'})do
    local callback=node[key]
    if type(callback)=='function' then node[key]=function(...)
     if token==generation and current()then return callback(...)end
    end end
   end
  end
  w.draw(n)
 end
 build()
 return function()
  stop();rf2.hangarTick=nil
  if nativeTicket then
   if lvgl.cancelAppNumber then lvgl.cancelAppNumber()end
   nativeTicket=nil;return
  end
  if page.fields[index]~=field or field.data~=data or edits.context(page)~=context then return end
  if (exact or spec.input=='keypad') and not validEntry()then return end
  if draft==start then return end
  if gainMax and draft>high then return end
  if spec.selection then page.uiSelectBattery(draft);return end
  if spec.favorite then
   for i=12,16 do if i~=index and page.fields[i].data.value==draft then page.fields[i].data.value=start end end
  end
  local function apply()
   if field.change then field.change(field,draft,page)end
   data.value=draft
   if field.postEdit then field.postEdit(field,page)end
  end
  if page.uiRun then page.uiRun(apply)else apply()end
 end
end
