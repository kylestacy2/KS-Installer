local w=rf2.executeScript('LVGL/hangarWidgets')
local config=rf2.executeScript('F/hangarConfig')
local catalog=rf2.executeScript('LVGL/Hangar/catalog')
local current
local h={}
function h.show(menu)
 current=menu
 local state=menu.navigation;local prefs=config.get();local p=w.palette()
 local lookup={};for _,item in ipairs(menu.items)do if item.script then lookup[item.script]=item end end
 local function connected()return rf2.offlineSimulator or getRSSI()>0 end
 local function profile(i)
  local f=menu.status.fields[i]
  return connected() and menu.status.isReady and f and f.data.value~=nil and tostring(f.data.value+1) or '--'
 end
 local function select(id)if lookup[id] then lookup[id].click()end end
 local function repaint()h.show(menu)end
 local function home()state.hangarView='home';repaint()end
 local n=w.scene(state.hangarView=='all' and home or menu.back,p)
 w.header(n,p,state.hangarView=='all' and 'All pages' or 'ROTORFLIGHT',state.hangarView=='all' and home or nil,{text='Settings',press=menu.settings.click})
 local modelName=(model.getInfo()or{}).name or 'Model'
 if state.hangarView~='all' then
  w.panel(n,p,16,82,244,382)
  w.label(n,p,36,102,204,'CURRENT MODEL','small','muted')
  local name,font=w.fit(modelName,204,'huge');w.label(n,p,36,138,204,name,font).name='Model name'
  w.panel(n,p,36,204,204,2,'accent',0)
  for i,title in ipairs({'PID','RATE'})do
   local x=36+(i-1)*110;w.panel(n,p,x,224,94,88,'raised',4)
   w.label(n,p,x+12,236,70,title,'small','muted');w.label(n,p,x+12,263,70,function()return profile(i)end,'large')
  end
  w.label(n,p,36,336,204,function()return connected() and 'FC connected' or 'Disconnected'end,'small','good')
  w.button(n,p,36,394,204,48,'Connection',menu.diagnostics or function()select('status')end)
  w.label(n,p,280,89,504,'RotorFlight Setup','large')
  for i=1,6 do
   local id=prefs.homePages[i];local item=id and catalog[id]or {'All pages','Browse all pages'}
   local x,y=280+(i-1)%2*258,144+math.floor((i-1)/2)*110
   local b=w.button(n,p,x,y,246,98,'',function()if id then select(id)else state.hangarView='all';state.group='all';state.page=1;repaint()end end,false,item[1])
   b.active=function()return not id or lookup[id]~=nil end
   w.label(n,p,x+16,y+16,214,item[1],'bold')
   w.label(n,p,x+16,y+48,214,(not id or lookup[id]) and item[2]or 'Unavailable for this FC','small','muted')
  end
 else
  local ids={}
  for _,id in ipairs(config.pageIds)do if lookup[id] then ids[#ids+1]=id end end
  table.sort(ids,function(a,b)
   local aa,bb=string.lower(catalog[a][1]),string.lower(catalog[b][1])
   return aa==bb and a<b or aa<bb
  end)
  local total=math.max(1,math.ceil(#ids/9));state.page=math.max(1,math.min(state.page or 1,total))
  for slot=1,9 do
   local id=ids[(state.page-1)*9+slot]
   if id then
    local item=catalog[id];local x,y=16+(slot-1)%3*260,90+math.floor((slot-1)/3)*108
    w.button(n,p,x,y,248,96,'',function()select(id)end,false,item[1])
    local title,font=w.fit(item[1],216,'bold');w.label(n,p,x+16,y+16,216,title,font)
    local subtitle=w.fit(item[2],216,'small');w.label(n,p,x+16,y+48,216,subtitle,'small','muted')
   end
  end
  if #ids==0 then w.label(n,p,16,90,768,'No pages available for this controller.','normal','muted')end
  w.label(n,p,16,432,420,#ids..' pages','small','muted')
  w.label(n,p,456,432,108,state.page..' / '..total,'small','muted')
  local b=w.button(n,p,580,420,96,44,'<',function()state.page=state.page-1;repaint()end,false,'Previous pages');b.active=function()return state.page>1 end
  b=w.button(n,p,688,420,96,44,'>',function()state.page=state.page+1;repaint()end,false,'Next pages');b.active=function()return state.page<total end
 end
 w.draw(n)
end
function h.update(force) if force and current then h.show(current)end end
function h.clear()current=nil end
return h
