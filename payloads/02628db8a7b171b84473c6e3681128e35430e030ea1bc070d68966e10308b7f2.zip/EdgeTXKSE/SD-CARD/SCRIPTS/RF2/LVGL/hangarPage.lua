local config=rf2.executeScript('F/hangarConfig')
local widgets=rf2.executeScript('LVGL/hangarWidgets')
local bindings=rf2.executeScript('LVGL/Hangar/fields')
local routes={rates='rates',profile_pids='pids',profile_governor='governor',profile_rescue='rescue',profile_various='flight',battery='battery',rate_dynamics='dynamics',profile_pidcon='controller',filters='filters',swash_trim='swash',esc_hwpl5='platinum',settings='settings'}
local h={}
local private={action=true,field=true,valueField=true,optionKey=true,status=true}
local function field(page,id)
 local b=bindings[id];if not b then return end
 if b.dataKey then
  for i,f in ipairs(page.fields)do if f.dataKey==b.dataKey then return f,i,b end end
  return
 end
 local index=page.rateFieldIndices and page.rateFieldIndices[b.index] or b.index
 return page.fields[index],index,b
end
local function supported(page)
 if not config.enabled() or not routes[page.uiScript] or (rf2.apiVersion<12.09 and page.uiScript~='settings') then return false end
 if page.uiHangarLegacy or page.uiRatesOptions or page.uiCollectiveCurve or page.uiAxis==3 then return false end
 if page.rateFields and page.rateFields[13].data.table[page.rateFields[13].data.value]~='ROTORFL' then return false end
 return true
end
function h.supported(page) return supported(page) end
local initial={rates='main',pids='all',governor='overview',rescue='overview',flight='main',battery='packs',dynamics='axes',controller='relax',filters='lowpass',swash='main',platinum='general',settings='general'}
function h.prepare(page)
 if not supported(page) then return end
 local route=routes[page.uiScript]
 if route=='settings' and rf2.hangarSettingsSection then page.hangarSection=rf2.hangarSettingsSection;rf2.hangarSettingsSection=nil end
 if not page.hangarSection then
  page.hangarSection=route=='pids' and config.get().pidView=='last' and rf2.hangarPidAxis or initial[route]
 end
 page.hangarSection=page.hangarSection or initial[route]
 if route=='platinum' then page.hangarScene=rf2.executeScript('LVGL/hangarPlatinum')(page,bindings);return end
 page.hangarScene=rf2.executeScript('LVGL/Hangar/'..route..'_'..page.hangarSection,page)
end
function h.show(page)
 if not supported(page) then return false end
 local route=routes[page.uiScript]
 local section=page.hangarSection or initial[route]
 local paletteKey=page.hangarSettings and config.options[1].values[page.fields[1].data.value+1] or nil
 local p=widgets.palette(paletteKey)
 local function redraw(nextSection)
  if nextSection then page.hangarSection=nextSection;if route=='pids' then rf2.hangarPidAxis=nextSection end end
  page.hangarScene=nil;page.uiRefresh()
 end
 local function edit(id)
  if id=='prefs.theme' and config.unified() then return end
  local f,index,b=field(page,id);if not page.isReady or page.readOnly or not f or not f.data or f.data.value==nil then return end
  page.uiEditField(index,{hangar=true,id=id,input=b.input,favorite=b.favorite},b.title)
 end
 local function action(key)
  if string.sub(key,1,5)=='edit:' then edit(string.sub(key,6))
  elseif string.sub(key,1,8)=='section:' then redraw(string.match(key,'[^:]+$'))
  elseif string.sub(key,1,12)=='gov-section:' then redraw(string.sub(key,13))
  elseif string.sub(key,1,9)=='pid-axis:' then redraw(string.sub(key,10))
  elseif string.sub(key,1,17)=='settings-section:' then redraw(string.sub(key,18))
  elseif string.sub(key,1,10)=='home-move:' then
   local slot,delta=string.match(key,'^home%-move:(%d+):(%-?%d+)$')
   slot,delta=tonumber(slot),tonumber(delta)
   if not page.isReady or page.readOnly or not slot or not delta or slot<0 or slot>4 or math.abs(delta)~=1 or slot+delta<0 or slot+delta>4 then return end
   local a,b=page.fields[12+slot].data,page.fields[12+slot+delta].data
   a.value,b.value=b.value,a.value;redraw()
  elseif key=='rate-limits' then rf2.hangarSettingsSection='limits';page.uiOpenScript('settings')
  elseif key=='page:rates' then page.uiOpenScript('rates')
  elseif key=='page:profile_pids' then page.uiOpenScript('profile_pids')
  elseif key=='test-save-sound' then if playTone then playTone(1800,80,0,0)end
  elseif key=='select-battery' then
   if page.uiHasChanges() then page.uiNotice('Save or discard Battery edits before selecting another active pack.');return end
   page.uiEditField(1,{hangar=true,id='battery.active',selection=true},'Select active battery')
  elseif key=='reset-settings-tab' then
   local ids=section=='pidlimits' and {17,18,19,20,21} or section=='limits' and {9,10,11} or section=='general' and {1,2,3} or section=='editing' and {4,5,6} or {7,8}
   for _,i in ipairs(ids)do
    local value=i>=9 and 1000 or 0
    if i<=8 then for k,v in ipairs(config.options[i].values)do if v==config.options[i].default then value=k-1 end end end
    page.fields[i].data.value=value
   end;redraw()
  end
 end
 local n=widgets.scene(page.back,p)
 widgets.header(n,p,page.title,page.back,{name='Page save',text=function()
  if page.uiSaveText then return page.uiSaveText() end
  return 'Save'
 end,notice=page.uiSaveNotice,press=page.uiSave,active=page.uiCanSave})
 if route=='settings' and section=='general' then
  widgets.button(n,p,406,416,378,44,'Headspeed favorites',function()
   page.uiEditField(1,{hangar=true,headspeedPrefs=true},'Headspeed favorites')
  end)
 end
  if not page.hangarScene then page.hangarSection=section;h.prepare(page)end
  for _,source in ipairs(page.hangarScene)do
   local node={};for k,v in pairs(source)do if not private[k] then node[k]=v end end
   if node.color then node.color=p[node.color]end;if node.textColor then node.textColor=p[node.textColor]end
   local font=source.font or 'small';if node.font then node.font=widgets.fonts[font]end
   if source.action then node.press=function()action(source.action)end end
   local id=source.valueField or source.field or source.action and string.match(source.action,'^edit:(.*)')
   local f,index
   if id then f,index=field(page,id)end
   if source.field or source.action and string.match(source.action,'^edit:') then
    node.name='Field '..tostring(index);node.active=function()return page.isReady and not page.readOnly and f and f.data and f.data.value~=nil end
   end
   if source.action and string.sub(source.action,1,10)=='home-move:' then
    local slot,delta=string.match(source.action,'^home%-move:(%d+):(%-?%d+)$')
    local to=tonumber(slot)+tonumber(delta)
    node.active=function()return page.isReady and not page.readOnly and to>=0 and to<5 end
   end
   if source.valueField then
    node.text=function()return f and widgets.value(f.data,f.data.value,route=='swash') or '--' end
    local sample=f and widgets.value(f.data,f.data.max or f.data.value,route=='swash') or '--'
    local _,fit=widgets.fit(sample,node.w,font);node.font=widgets.fonts[fit];node.h=math.max(node.h,widgets.heights[fit])
   elseif source.status then node.text=page.uiProfileStatus
   elseif source.action=='select-battery' then node.text=function()return 'Active: '..widgets.value(page.fields[1].data,page.fields[1].data.value)end end
   if id=='prefs.theme' and config.unified() then
    if source.valueField then node.text='Radio (shared)'
    else node.active=function()return false end end
   end
   if route=='rates' and node.type=='label' and node.x==16 and node.y==91 then
    node=nil;widgets.button(n,p,16,80,260,44,'Rate type / Options',page.uiNative)
   end
   if node then n[#n+1]=node end
   if (source.field or section=='favorites' and source.action and string.match(source.action,'^edit:')) and f and config.get().changeMarkers=='on' then
    local marker=widgets.label(n,p,source.x+source.w-18,source.y+4,16,function()return page.uiChanged(index) and '*' or ''end,'small','accent');marker.name='Changed '..index
   end
  end
 widgets.draw(n);return true
end
return h
