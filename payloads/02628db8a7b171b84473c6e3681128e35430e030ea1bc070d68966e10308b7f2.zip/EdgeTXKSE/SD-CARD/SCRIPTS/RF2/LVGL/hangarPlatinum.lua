-- Build only the current section from the ESC's actual supported fields.
-- Bounds, choices and write encodings remain owned by mspEscHwPl5.
local sections=rf2.executeScript('LVGL/Hangar/platinumSections')
return function(page,bindings)
 local groups={}
 for _,f in ipairs(page.fields)do
  local id='platinum.'..f.dataKey;local b=bindings[id]
  if b and f.data and f.data.value~=nil then
   groups[b.section]=groups[b.section]or{}
   local g=groups[b.section];g[#g+1]={id=id,binding=b,data=f.data}
  end
 end
 local tabs={}
 for _,s in ipairs(sections)do if groups[s[1]]then tabs[#tabs+1]=s end end
 local n={}
 local function label(x,y,width,text,font,role,height)
  local node={type='label',x=x,y=y,w=width,h=height or 23,text=text,font=font or 'small',color=role or 'ink'}
  n[#n+1]=node;return node
 end
 if #tabs==0 then label(16,139,768,'ESC not ready, waiting...');return n end
 if not groups[page.hangarSection]then page.hangarSection=tabs[1][1]end
 local section=page.hangarSection
 local tabWidth=math.floor((768-12*(#tabs-1))/#tabs)
 for i,s in ipairs(tabs)do
  n[#n+1]={type='button',x=16+(i-1)*(tabWidth+12),y=80,w=tabWidth,h=44,text=s[2],font='small',action='section:platinum:'..s[1],color=s[1]==section and 'accent'or'panel',textColor=s[1]==section and 'accentInk'or'ink',cornerRadius=6}
 end
 local hardware=page.labels[2]and page.labels[2].t or ''
 label(16,139,768,'Platinum V5 / '..hardware,'bold',nil,27)
 label(16,175,768,section=='governor'and'ESC governor gains / separate from Rotorflight Governor'or'Only controls supported by this ESC are shown.','small','muted')
 local entries=groups[section];local columns=#entries==3 and 3 or 2
 local width=columns==3 and 248 or 378;local single=#entries<=3
 for i,e in ipairs(entries)do
  local x,y=16+(i-1)%columns*(width+12),214+math.floor((i-1)/columns)*126
  local height=single and 240 or 114
  n[#n+1]={type='button',x=x,y=y,w=width,h=height,text='',font='small',action='edit:'..e.id,field=e.id,color='panel',textColor='ink',cornerRadius=6}
  label(x+12,y+9,width-24,e.binding.title,'bold',nil,27)
  label(x+12,y+(single and 68 or 40),width-24,'',single and'huge'or'large','accent',single and 55 or 42).valueField=e.id
  if e.data.unit then label(x+12,y+height-30,width-24,e.data.unit,'small','muted')end
 end
 return n
end
