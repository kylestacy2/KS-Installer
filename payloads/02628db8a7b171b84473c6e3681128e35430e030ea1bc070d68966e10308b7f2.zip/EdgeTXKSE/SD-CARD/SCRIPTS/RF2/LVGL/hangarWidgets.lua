local config=rf2.executeScript('F/hangarConfig')
local themes=rf2.executeScript('LVGL/Hangar/themes')
local w={fonts={small=SMLSIZE,normal=0,bold=BOLD,large=MIDSIZE,huge=DBLSIZE}}
w.heights={small=23,normal=27,bold=27,large=42,huge=55}
function w.palette(key)
 key=config.unified() and "radio" or key or config.get().theme
 if key=='radio' and type(getRadioTheme)=='function' then
  local ok,native=pcall(getRadioTheme)
  if ok and type(native)=='table' then
   local p={good=lcd.RGB(28,232,119)}
   local roles={bg='background',panel='surface',raised='surface',ink='ink',muted='muted',line='line',accent='accent',accentInk='accentInk'}
   local valid=true
   for role,name in pairs(roles)do
    local n=native[name]
    if type(n)~='number' or n~=n or n<0 or n>0xffffff then valid=false;break end
    p[role]=lcd.RGB(math.floor(n/65536),math.floor(n/256)%256,n%256)
   end
   if valid then
    local n=native.background
    p.lightBackground=3*math.floor(n/65536)+4*(math.floor(n/256)%256)+n%256>1024
    return p
   end
  end
 end
 local p={};for role,color in pairs(themes[key or config.get().theme] or themes.graphite)do
  local n=tonumber(string.sub(color,2),16);p[role]=lcd.RGB(math.floor(n/65536),math.floor(n/256)%256,n%256)
 end
 local n=tonumber(string.sub((themes[key or config.get().theme] or themes.graphite).bg,2),16)
 p.lightBackground=3*math.floor(n/65536)+4*(math.floor(n/256)%256)+n%256>1024
 return p
end
function w.fit(text,width,font)
 text=tostring(text or '--')
 for _,name in ipairs(font=='huge' and {'huge','large','bold','small'} or font=='large' and {'large','bold','small'} or {font,'small'})do
  if lcd.sizeText(text,w.fonts[name])<=width then return text,name end
 end
 while #text>0 and lcd.sizeText(text..'...',SMLSIZE)>width do
  local i=#text;while i>1 and string.byte(text,i)>=128 and string.byte(text,i)<192 do i=i-1 end;text=string.sub(text,1,i-1)
 end
 return text..'...','small'
end
function w.scene(back,p)
 return {{type='page',title='',back=back,children={}}, {type='rectangle',x=0,y=0,w=800,h=480,filled=true,color=p.bg}}
end
function w.label(n,p,x,y,width,text,font,role,height)
 local node={type='label',x=x,y=y,w=width,h=height or w.heights[font or 'small'],font=w.fonts[font or 'small'],color=p[role or 'ink'],text=text}
 n[#n+1]=node;return node
end
function w.button(n,p,x,y,width,height,text,press,primary,name)
 local node={type='button',x=x,y=y,w=width,h=height,text=text,font=SMLSIZE,cornerRadius=6,color=p[primary and 'accent' or 'panel'],textColor=p[primary and 'accentInk' or 'ink'],press=press,name=name or text}
 n[#n+1]=node;return node
end
function w.panel(n,p,x,y,width,height,role,radius)
 n[#n+1]={type='rectangle',x=x,y=y,w=width,h=height,color=p[role or 'panel'],filled=true,rounded=radius or 6}
end
function w.header(n,p,title,back,action)
 if back then w.button(n,p,16,10,48,52,'<',back,false,'Back to RF home')end
 local x=back and 80 or 16
 local titleText,titleFont=w.fit(title,404-x,'bold');w.label(n,p,x,12,404-x,titleText,titleFont)
 local modelName=(model.getInfo() or {}).name or 'Model'
 local text,font=w.fit(modelName,404-x,'small')
 local subtitle=action and action.notice and function()return action.notice() or text end or text
 w.label(n,p,x,40,404-x,subtitle,font,'muted')
 local home=w.button(n,p,412,10,52,52,'',rf2.requestRFHome,false,'RF Home');home.active=rf2.canExitToDashboard
 -- EdgeTX line points use page coordinates; x/y do not offset the points.
 n[#n+1]={type='line',pts={{426,32},{438,22},{450,32},{450,48},{442,48},{442,38},{434,38},{434,48},{426,48},{426,32}},thickness=2,color=p.ink}
 if action then local b=w.button(n,p,476,10,100,52,action.text,action.press,action.primary,action.name);b.active=action.active end
 local b=w.button(n,p,588,10,196,52,'Back to dashboard',rf2.requestDashboardExit);b.active=rf2.canExitToDashboard
 w.panel(n,p,16,73,768,1,'line',0)
end
function w.draw(nodes) lvgl.clear();lvgl.build(nodes) end
function w.value(data,raw,unit)
 if raw==nil then return '--' end
 if data.table then return tostring(data.table[raw] or ('Unknown '..raw)) end
 local v=raw/(data.scale or 1)
 local text=string.gsub(string.gsub(string.format('%.3f',v),'0+$',''),'%.$','')
 return text..(unit and (data.unit or '') or '')
end
return w
