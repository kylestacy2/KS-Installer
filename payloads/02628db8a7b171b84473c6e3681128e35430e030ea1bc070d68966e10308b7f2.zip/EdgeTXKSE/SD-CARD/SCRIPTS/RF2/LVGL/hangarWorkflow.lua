local w=rf2.executeScript('LVGL/hangarWidgets')
local h={}
local function wrap(text,width)
 local lines,line={},''
 for word in string.gmatch(tostring(text),'%S+')do
  local nextLine=line=='' and word or line..' '..word
  if lcd.sizeText(nextLine,SMLSIZE)>width and line~='' then lines[#lines+1]=line;line=word else line=nextLine end
 end
 lines[#lines+1]=line;return lines
end
function h.show(title,lines,back,action)
 local page=1
 local function build()
  local p=w.palette();local n=w.scene(back,p)
  w.header(n,p,title,back,action)
  local rows={}
  for _,entry in ipairs(lines)do
   local text=type(entry)=='table' and entry.text or entry
   if type(text)=='function' then
    local getter=text
    rows[#rows+1]={text=function()local value=w.fit(getter(),736,'small');return value end,accent=type(entry)=='table' and entry.accent}
   else
    for _,line in ipairs(wrap(text,736))do rows[#rows+1]={text=line,accent=type(entry)=='table' and entry.accent}end
   end
   rows[#rows+1]={text=''}
  end
  local total=math.max(1,math.ceil(#rows/12));page=math.min(page,total)
  for i=1,12 do local row=rows[(page-1)*12+i];if row then w.label(n,p,32,92+(i-1)*26,736,row.text,'small',row.accent and 'accent' or 'ink')end end
  if total>1 then
   local b=w.button(n,p,536,422,116,44,'<',function()page=math.max(1,page-1);build()end);b.active=function()return page>1 end
   b=w.button(n,p,668,422,116,44,'>',function()page=math.min(total,page+1);build()end);b.active=function()return page<total end
  end
  w.draw(n)
 end
 build()
end
function h.leave(count,keep,discard,save)
 local p=w.palette();local n=w.scene(keep,p)
 w.header(n,p,'Back to dashboard',keep)
 w.label(n,p,72,110,656,count..' unsaved change'..(count==1 and ''or 's'),'large')
 for i,item in ipairs({{'Save & return',save},{'Discard & return',discard},{'Keep editing',keep}})do w.button(n,p,72,180+(i-1)*84,656,64,item[1],item[2],i==1)end
 w.draw(n)
end
return h
