local w=rf2.executeScript('LVGL/hangarWidgets')
local store=rf2.executeScript('F/modelPreferences')
return function(current,finish)
 local key=store.identity()
 local saved,revision,loadError=store.load(key,'speeds')
 local values=saved or {0,0,0,0}
 local slot,entry,notice,generation,pending=nil,'',loadError,0,nil
 local build,tick,retired
 local function valid()
  local v=tonumber(entry)
  if not v or v<900 or v>5500 or v%10>0 then return end
  for i=1,4 do if i~=slot and values[i]==v then return end end
  return v
 end
 local function alive()return not retired and key and key==store.identity() and current()end
 local function close(result)
  if retired then return end
  retired=true;generation=generation+1
  if rf2.hangarTick==tick then rf2.hangarTick=nil;finish(result)end
 end
 build=function()
  generation=generation+1;local token=generation
  local p=w.palette();local n=w.scene(function()close(false)end,p)
  local function button(x,y,width,text,fn,primary)
   return w.button(n,p,x,y,width,48,text,function()
    if alive() and token==generation and not pending then pending=fn end
   end,primary)
  end
  w.header(n,p,'Headspeed favorites',function()close(false)end)
  w.label(n,p,24,92,752,'Local to this model. Choosing a favorite never sends it to the FC.','small','muted')
  if slot then
   w.label(n,p,24,138,300,'Favorite '..slot,'bold')
   w.label(n,p,24,182,300,function()return entry=='' and '--' or entry..' RPM'end,'large','accent')
   w.label(n,p,24,245,300,'900–5500 RPM / step 10','small','muted')
   w.label(n,p,24,279,300,function()return valid() and 'Ready' or 'Enter a unique valid RPM'end,'small','muted')
   for i,k in ipairs({'1','2','3','4','5','6','7','8','9','Clear','0','Del'})do
    button(368+(i-1)%3*136,132+math.floor((i-1)/3)*62,124,k,function()
     if k=='Clear' then entry='' elseif k=='Del' then entry=string.sub(entry,1,-2)
     elseif #entry<4 then entry=entry..k end
    end)
   end
   button(24,344,300,'Clear this slot',function()values[slot]=0;slot=nil;build()end)
   button(24,416,180,'Cancel',function()slot=nil;build()end)
   local done=button(600,416,176,'Done',function()local v=valid();if v then values[slot]=v;slot=nil;build()end end,true)
   done.active=function()return valid()~=nil end
  else
   for i=1,4 do
    local x,y=24+(i-1)%2*388,142+math.floor((i-1)/2)*104
    button(x,y,364,'Slot '..i..': '..(values[i]>0 and values[i]..' RPM' or 'Not set'),function()slot=i;entry='';notice=nil;build()end)
   end
   w.label(n,p,24,354,752,function()return notice or 'Tap a slot to enter a headspeed. Empty slots stay hidden.'end,'small','muted')
   button(24,416,176,'Cancel',function()close(false)end)
   local save=button(536,416,240,'Save favorites',function()
    local ok,result=store.save(key,'speeds',values,revision,alive)
    if ok then close(values)else notice=result;build()end
   end,true)
   save.active=function()return alive() and not loadError end
  end
  for _,node in ipairs(n)do
   local callback=node.press or node.back
   if callback then
    local key=node.press and 'press' or 'back'
    node[key]=function()if alive() and token==generation then callback()end end
   end
  end
  w.draw(n)
 end
 tick=function()
  if not alive()then close(false);return end
  local action=pending;pending=nil;if action then action()end
 end
 rf2.hangarTick=tick
 build()
 return function()end
end
