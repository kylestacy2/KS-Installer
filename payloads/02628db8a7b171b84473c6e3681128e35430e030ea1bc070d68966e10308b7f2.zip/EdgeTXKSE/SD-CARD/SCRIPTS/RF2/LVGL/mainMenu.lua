if rf2.executeScript('F/hangarConfig').enabled() then return rf2.executeScript('LVGL/hangarHome') end
if LCD_W==480 and LCD_H==320 then return rf2.executeScript('LVGL/480x320/mainMenu') end
local theme=rf2.executeScript('LVGL/precision')
local navigation=rf2.executeScript('F/navigation')
local currentMenu,lastW,lastH,lastScale,lastControl
local show
show=function(menu)
    currentMenu=menu
    theme.refresh()
    local s=rf2.executeScript('LVGL/studio',theme)
    local w,h,m,g=s.w,s.h,s.margin,s.gap
    lastW,lastH,lastScale,lastControl=w,h,s.scale,s.control
    local state=menu.navigation
    local favorites=navigation.favorites()
    local items=navigation.items(menu,state.group,favorites)
    local rows=s.large and 5 or 4
    local count=math.max(1,math.ceil(#items/rows))
    state.page=math.max(1,math.min(state.page,count))
    local railW=s.large and 220 or w<480 and 96 or 138
    local x=railW+m*2
    local contentW=w-x-m
    local function connected() return rf2.offlineSimulator or getRSSI()>0 end
    local function metric(index)
        if not connected() or not menu.status.isReady then return '--' end
        if index==5 then return menu.status.labels[4].t end
        local d=menu.status.fields[index].data
        if d.value==nil then return '--' end
        return index<=2 and tostring(d.value+1) or string.format('%.1f%%',d.value/(d.scale or 1))
    end
    -- Model identity and compact instruments form a persistent left rail.
    local panelTop=math.floor(m/2)
    local statusPanel=s.panel(0,panelTop,railW+m,h-panelTop,theme.header or theme.surface)
    statusPanel.rounded=theme.round(4*s.scale)
    s.panel(m,m,3,s.large and 76 or 44,theme.accent)
    s.label(m+12,m,railW-18,'ROTORFLIGHT',theme.accent,SMLSIZE)
    local modelName=(model.getInfo() or {}).name or 'Model'
    -- The 800x480 rail has room for two standard-font lines above PID/RATE.
    local modelLabel=s.label(m+12,m+s.textH+(s.large and 2 or 6),railW-18,
        modelName,theme.ink,BOLD,s.large and 2 or nil)
    modelLabel.name='Model name'
    local numberFont=s.large and DBLSIZE or BOLD
    local numberH=select(2,theme.textSize('Ag',numberFont,s.scale))
    local y=s.large and (m+76+g) or 72
    for i,label in ipairs({'PID','RATE'}) do
        local xx=m+(i-1)*railW/2
        s.label(xx,y,railW/2-g,label,theme.muted)
        s.label(xx,y+s.textH+2,railW/2-g,function() return metric(i) end,theme.ink,numberFont)
    end
    y=y+s.textH+2+numberH+g
    s.panel(m,y,railW-g,1,theme.line)
    s.label(m,y+g,railW-g,function() return 'CPU  '..metric(4) end,theme.muted)
    if s.large then
        s.label(m,y+g+s.textH+6,railW-g,function() return 'RT load  '..metric(3) end,theme.muted)
        s.label(m,y+g+(s.textH+6)*2,railW-g,function() return 'Flash  '..metric(5) end,theme.muted)
        s.label(m,y+g+(s.textH+6)*3,railW-g,function() return 'Arming  '..(connected() and menu.status.labels[2].t or 'No link') end,theme.muted)
    end
    local footerH=s.large and 32 or 24
    local footerY=h-m-footerH
    for _,item in ipairs(menu.items) do
        if item.text=='Connection' then s.button(m,footerY,railW-g,footerH,'Connection',item.click) end
    end
    -- The smaller dashboard keeps full telemetry details on Connection/Status.
    local eraseY=s.large and footerY-footerH-g or footerY-footerH-4
    local erase=s.button(m,eraseY,railW-g,footerH,'Erase',function()
        local field=menu.status.fields[5]
        if connected() and field.preEdit then menu.run(field.preEdit,field,menu.status) end
    end)
    erase.active=function() return connected() and menu.status.fields[5].preEdit~=nil end
    erase.color=theme.header or theme.surface
    erase.textColor=theme.muted
    local tabsY=m
    local tabW=contentW/5
    local short={'All','Fav','Tune','Setup','ESC'}
    for i,group in ipairs(navigation.groups) do
        local key=group.key
        local tab=s.button(x+(i-1)*tabW,tabsY,tabW-2,s.control,s.large and group.title or short[i],
            function() state.group=key;state.page=1;show(menu) end,false,group.title)
        tab.color=theme.background
        tab.textColor=key==state.group and theme.ink or theme.muted
        if key==state.group then s.panel(tab.x,tabsY+s.control-2,tab.w,2,theme.accent) end
    end
    local top=tabsY+s.control+g
    local rowH=math.floor((footerY-g-top)/rows)
    local pageColor=theme.key=='titanium_ember' and (theme.header or theme.surface) or theme.background
    local pageButtons={}
    for slot=1,rows do
        local item=items[(state.page-1)*rows+slot]
        if item then
            local info=navigation.info[item.script]
            local yy=top+(slot-1)*rowH
            local pinW=s.large and 44 or 30
            local rowGap=s.large and 8 or 4
            local buttonH=rowH-rowGap
            local openW=contentW-pinW-g
            local titleX=x+(s.large and 48 or 10)
            local titleW=openW-(titleX-x)-12
            local titleH=select(2,theme.textSize(info.title,BOLD,s.scale))
            local open=s.button(x,yy,openW,buttonH,'',function() item.click(item.index) end,false,item.text)
            open.color=pageColor
            pageButtons[#pageButtons+1]=table.remove(s.children)
            if s.large then s.label(x+12,yy+(buttonH-s.textH)/2,30,string.format('%02d',(state.page-1)*rows+slot),theme.accent) end
            -- Keep both labels inside the same native button. Very short
            -- rows retain the title alone instead of overlapping another row.
            local subtitle=item.script=='rates' and info.detail
            local textH=titleH+(subtitle and s.textH+2 or 0)
            if subtitle and textH<=buttonH then
                local textY=yy+math.floor((buttonH-textH)/2)
                s.label(titleX,textY,titleW,info.title,theme.ink,BOLD)
                s.label(titleX,textY+titleH+2,titleW,subtitle,theme.muted,SMLSIZE)
            else
                s.label(titleX,yy+(buttonH-titleH)/2,titleW,info.title,theme.ink,BOLD)
            end
            local pin=s.button(x+contentW-pinW,yy,pinW,buttonH,
                favorites[item.script]==1 and '-' or '+',function() navigation.toggle(item.script);show(menu) end,false,'Pin '..item.text)
            pin.color=pageColor
            pin.textColor=favorites[item.script]==1 and theme.accent or theme.muted
        end
    end
    if #items==0 then
        s.label(x,top+g,contentW,'No pages here yet.',theme.ink)
        s.label(x,top+g*2+s.textH,contentW,state.group=='favorites' and 'Use + in All to save a page.' or 'Enable pages in Settings.',theme.muted)
    end
    local arrowW=s.large and 42 or 28
    s.label(x,footerY+(footerH-s.textH)/2,contentW-arrowW*2-g*2,string.format('%02d / %02d   %d pages',state.page,count,#items),theme.muted)
    local previous=s.button(w-m-arrowW*2-g,footerY,arrowW,footerH,'<',function()state.page=state.page-1;show(menu)end,false,'Previous pages')
    local next=s.button(w-m-arrowW,footerY,arrowW,footerH,'>',function()state.page=state.page+1;show(menu)end,false,'Next pages')
    previous.active=function()return state.page>1 end
    next.active=function()return state.page<count end
    -- EdgeTX focuses controls in creation order. Start on the first page and
    -- cycle through page rows before pin buttons or other menu controls.
    for i=#pageButtons,1,-1 do table.insert(s.children,1,pageButtons[i]) end
    local action=menu.settings and {text='Settings',press=function()menu.settings.click(menu.settings.index)end}
    local layout=theme.page(menu.title,rf2.executeScript('F/getLvglSubtitle','Workspace'),s.children,menu.back,action)
    layout[1].scrollBar=false
    lvgl.clear();lvgl.build(layout)
end
return {show=show,clear=function()
    -- Retain the renderer, never a retired menu, status page or its callbacks.
    currentMenu=nil
end,update=function(force)
    if not currentMenu then return end
    local w,h,scale,c=theme.metrics()
    if force or w~=lastW or h~=lastH or scale~=lastScale or c~=lastControl then show(currentMenu) end
end}
