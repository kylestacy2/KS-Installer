local lvglHelper = rf2.executeScript("LVGL/helper")
local theme = rf2.executeScript("LVGL/precision")
local hangarConfig=rf2.executeScript('F/hangarConfig')
local hangar=hangarConfig.enabled() and rf2.executeScript('LVGL/hangarPage')
local saving = false
local touch = LCD_W >= 800 and rf2.executeScript('LVGL/touch') or nil

local prepared

-- Prepare editor descriptions while the renderer is loading. Native controls
-- are still built together on the next refresh, under a fresh Lua budget.
local function makeEditors(page)
    local function invoke(callback, ...)
        if page.uiRun then return page.uiRun(callback, ...) end
        return callback(...)
    end

    local function formatVal(val, field)
        if field.data.scale then
            val = val / field.data.scale
            val = math.floor(val*100 + 0.5) / 100
        end
        if (field.data.scale or 1) <= 1 then
            val = math.floor(val)
        end

        return tostring(val) .. ((field.data and field.data.unit) or "")
    end

    local function fieldIsButton(f)
        -- TODO: refactor
        return f.t and string.sub(f.t, 1, 1) == "[" and not f.data
    end

    local children = {}
    local editors = {}
    -- Settings reuses the same Hide/Show and Off/On lists across many fields.
    -- Convert each shared list once per build; rebuilding it for every tile
    -- spends most of the widget's instruction budget on identical work.
    local choiceTables = {}
    local profileFields, profileItems = {}, {}
    for i, field in ipairs(page.fields) do
        local prefix = field.t == "Current PID profile" and "PID" or field.t == "Current rate profile" and "Rate"
        if prefix then
            profileFields[field] = true
            profileItems[#profileItems + 1] = {index = i, prefix = prefix}
        end
    end
    local profileStatus
    if #profileItems > 0 then
        profileStatus = function()
            local parts = {}
            for _, item in ipairs(profileItems) do
                local data = page.fields[item.index].data
                local value = data and data.value
                parts[#parts + 1] = item.prefix .. " " .. (value ~= nil and tostring(value + 1) or "-")
            end
            return table.concat(parts, "  ")
        end
    end
    -- Current renderers place every editor themselves. Do not construct the
    -- discarded legacy columns/captions first: their wrapping can exhaust a
    -- widget refresh before the actual form is even built.
    local screenMult = rf2.radio.screenMult or 1

    for i = 1, #page.fields do
        local field = page.fields[i]
        local firstChild = #children + 1
        if profileFields[field] then
            -- Active profiles are reported in the header, with no edit callback.
        elseif fieldIsButton(field) then
            children[#children + 1] = {
                type = "button",
                x = field.x,
                y = field.y,
                w = (field.w or 200) * screenMult,
                text = function()
                    local s = string.gsub(field.t, "[%[%]]", "") -- remove brackets around [button]
                    return  s
                end,
                press = function()
                    if field.preEdit then invoke(field.preEdit, field, page) end
                end,
            }
        elseif field.data and field.data.value ~= nil and type(field.data.value) == "string" then
            local child
            if field.readOnly then
                child = {
                    type = "label",
                    x = field.sp or field.x,
                    y = field.y + 3,
                    text = field.data.value,
                }
            else
                child = {
                    type = "textEdit",
                    x = field.sp or field.x,
                    y = field.y,
                    w = (field.w or 125) * screenMult,
                    value = field.data.value,
                    length = field.data.max or 10,
                }
            end

            children[#children + 1] = child
        elseif field.data and field.data.value ~= nil and type(field.data.value) == "number" then
            local child
            if field.readOnly then
                child = {
                    type = "label",
                    x = field.sp or field.x,
                    y = field.y + 3,
                    text = function()
                        return formatVal(field.data.value, field)
                    end,
                }
            elseif type(field.data.table) == "table" then
                local lists = choiceTables[field.data.table]
                if not lists then lists = {}; choiceTables[field.data.table] = lists end
                local limit = field.data.max + 1
                local choiceTable = lists[limit]
                if not choiceTable then
                    choiceTable = lvglHelper.toChoiceTable(field.data.table, limit)
                    lists[limit] = choiceTable
                end
                --rf2.print("Choice with value: " .. tostring(field.data.value))
                child = {
                    type = "choice",
                    --title = "todo",
                    values = choiceTable.values,
                    x = field.sp or field.x,
                    y = field.y,
                    w = (field.w or 100) * screenMult,
                    get = function() return choiceTable:getChoiceKey(field.data.value) end,
                    set = function(val)
                        field.data.value = choiceTable:getOriginalKey(val)
                        if field.postEdit then
                            invoke(field.postEdit, field, page)
                        end
                    end,
                }
            else
                child = {
                    type = "numberEdit",
                    x = field.sp or field.x,
                    y = field.y,
                    w = (field.w or 75) * screenMult,
                    get = function()
                        return field.data.value / (field.data.mult or 1)
                    end,
                    set = function(val)
                        local newVal = math.ceil(val * (field.data.mult or 1))
                        if field.change then
                            invoke(field.change, field, newVal, page)
                        end
                        field.data.value = newVal
                        --rf2.print("Value after editing: %s", tostring(field.data.value))
                    end,
                    display = function(val)
                        return formatVal(val * (field.data.mult or 1), field)
                    end,
                }
                if field.data.min then child.min = field.data.min / (field.data.mult or 1) end
                if field.data.max then child.max = field.data.max / (field.data.mult or 1) end
            end

            children[#children + 1] = child
        end

        if #children >= firstChild then editors[field] = children[#children] end
    end

    for _, child in pairs(editors) do
        if child.type == "label" then child.color = theme.ink end
        if child.type == "button" then theme.button(child) end
    end

    return {page=page, fields=page.fields, editors=editors,
        profileFields=profileFields, profileStatus=profileStatus}
end

local function show(page)
    if hangar and hangar.show(page) then prepared=nil; return end
    local form=prepared
    prepared=nil
    if not form or form.page~=page or form.fields~=page.fields then form=makeEditors(page) end
    local editors,profileFields,profileStatus=form.editors,form.profileFields,form.profileStatus
    local children
    local function invoke(callback,...)
        if page.uiRun then return page.uiRun(callback,...) end
        return callback(...)
    end
    lvgl.clear()

    if touch and page.title ~= 'Battery' then
        children = touch.layout(page, editors, theme, profileFields, function() show(page) end)
    elseif LCD_W == 480 and LCD_H == 320 then
        children = rf2.executeScript("LVGL/480x320/page", page, editors, theme, profileFields, function() show(page) end)
    elseif page.title == "PID Gains" then
        children = rf2.executeScript("LVGL/precisionPids", page, editors, theme, function() show(page) end)
    elseif page.rateFields then
        children = rf2.executeScript("LVGL/compactRates", page, editors, theme, function() show(page) end)
    elseif page.title == "Swash Trim" then
        children = rf2.executeScript("LVGL/swashTrim", page, editors, theme)
    elseif page.title == "Battery" then
        children = rf2.executeScript("LVGL/battery", page, editors, theme)
    elseif page.title == "Settings" then
        -- Preferences stay together in one scrolling form, with Theme first.
        for i, field in ipairs(page.fields) do
            if editors[field] then editors[field].name = "Field " .. i end
        end
        children = rf2.executeScript("LVGL/settings", page, editors, theme)
    elseif page.lvglWholeSections then
        children = rf2.executeScript("LVGL/480x320/form", page, editors, theme, profileFields, function() show(page) end)
    elseif LCD_W >= 480 then
        children = rf2.executeScript("LVGL/studioForm", page, editors, theme, profileFields, function() show(page) end)
    else
        children = rf2.executeScript("LVGL/compact", page, editors, theme, profileFields)
    end

    local subtitle = rf2.executeScript("F/getLvglSubtitle", page.title) -- EdgeTX < 2.11.4 don't support functions as argument for subtitle

    local action
    if page.isReady and not page.readOnly then
        saving = false
        action = {
            name = "Page save",
            text = function()
                if page.uiSaveText then return page.uiSaveText() end
                return page.uiSaved and page.uiSaved() and "Saved" or "Save"
            end,
            active = function()
                if page.uiCanSave then return page.uiCanSave() end
                return not saving and not (page.uiSaveState and page.uiSaveState())
            end,
            press = function()
                if page.uiSave then page.uiSave()
                else saving = true; invoke(page.write, page) end
            end,
        }
    end

    lvgl.build(theme.page("Rotorflight " .. rf2.luaVersion, subtitle, children,
        function() if page.back then page.back() end end, action, profileStatus, page.uiStatus, page.uiMenu))
end

return { show = show, prepare = function(page)
    prepared=nil
    if hangar and hangar.supported(page) then hangar.prepare(page)
    else
        prepared=makeEditors(page)
        if touch then touch.prepare(page) end
    end
end, edit = function(page,index,editor,caption,done)
    if editor.hangar then return rf2.executeScript('LVGL/hangarEditor')(page,index,editor,caption,done) end
    return touch.edit(page,index,editor,caption,theme,done)
end }
