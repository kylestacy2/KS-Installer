local theme = rf2.executeScript("LVGL/precision")
local function show(menu)
    local width, _, scale, control = theme.metrics()
    local gap = theme.round(8 * scale)
    local columns = width >= 480 and 2 or 1
    local rows = math.ceil(#menu.items / columns)
    local dialogW = math.min(width-gap*2, theme.round(460*scale))
    local titleH = theme.round(32*scale)
    local buttonH = math.min(control+gap, math.floor((LCD_H-titleH-gap*4)/rows)-gap)
    local buttonW = math.floor((dialogW-gap*(columns+1))/columns)
    local dg = lvgl.dialog({title=menu.title, w=dialogW, h=titleH+gap+rows*(buttonH+gap), close=menu.close})
    local children = {}
    for i, item in ipairs(menu.items) do
        children[#children+1] = theme.button({type="button",text=item.text,
            x=gap+(i-1)%columns*(buttonW+gap),y=gap+math.floor((i-1)/columns)*(buttonH+gap),
            w=buttonW,h=buttonH,press=function() dg:close(); if item.click then item.click(i) end end})
    end
    dg:build(children)
end
return {show=show}
