-- Presentation only. Native pages, controls and their callbacks remain in charge.
local themes = rf2.executeScript("F/uiThemes")
local t = {}
local hangarConfig=rf2.executeScript("F/hangarConfig")

function t.refresh()
    if hangarConfig.enabled() then
        local selected=hangarConfig.theme()
        local key='hangar-'..selected
        if selected=='radio' and type(getRadioThemeVersion)=='function' then key=key..tostring(getRadioThemeVersion())end
        if t.key==key then return end
        t.key=key
        local p=rf2.executeScript('LVGL/hangarWidgets').palette()
        t.background,t.surface,t.header=p.bg,p.panel,p.raised
        t.lightBackground=p.lightBackground
        t.ink,t.muted,t.line,t.accent,t.accentInk=p.ink,p.muted,p.line,p.accent,p.accentInk
        t.iconDir=rf2.baseDir..'IMAGES/precision/dark/'
        return
    end
    local selected = hangarConfig.unified() and 'radio' or rf2.loadSettings().uiTheme
    local key = themes.keys[themes.index(selected) + 1]
    local revision=key=="radio" and type(getRadioThemeVersion)=="function" and getRadioThemeVersion() or 0
    if t.key == key and t.revision==revision then return end
    t.key = key;t.revision=revision
    t.header = nil
    local palette=themes.palettes[key] or themes.palettes.dark
    if key=='radio' and type(getRadioTheme)=='function' then
        local ok,native=pcall(getRadioTheme)
        if ok and type(native)=='table' then
            local valid=true
            for name in pairs(palette) do
                local n=native[name]
                if type(n)~='number' or n~=n or n<0 or n>0xffffff then valid=false;break end
            end
            if valid then
                local mapped={};for name in pairs(palette)do mapped[name]=native[name]end
                palette=mapped
            end
        end
    end
    for name, color in pairs(palette) do
        t[name] = lcd.RGB(math.floor(color / 65536), math.floor(color / 256) % 256, color % 256)
    end
    local bg=palette.background
    t.lightBackground=3*math.floor(bg/65536)+4*(math.floor(bg/256)%256)+bg%256>1024
    t.iconDir = rf2.baseDir .. "IMAGES/precision/" .. (key == "light" and "" or key == "radio" and "dark/" or key .. "/")
end

t.refresh()

function t.round(value) return math.floor(value + 0.5) end

function t.metrics()
    local scale = tonumber(lvgl.LCD_SCALE) or rf2.radio.screenMult or 1
    local height = tonumber(lvgl.PAGE_BODY_HEIGHT) or (LCD_H - t.round(44 * scale))
    local control = tonumber(lvgl.UI_ELEMENT_HEIGHT) or t.round(28 * scale)
    return LCD_W, height, scale, control
end

function t.textSize(text, font, scale)
    if lcd.sizeText then return lcd.sizeText(text, font) end
    local size = (font == SMLSIZE and 13 or 16) * scale
    return #text * size * 0.6, size
end

function t.wrap(text, width, font, scale)
    local lines, line = {}, ""
    for word in string.gmatch(text or "---", "%S+") do
        local candidate = line == "" and word or line .. " " .. word
        if line ~= "" and t.textSize(candidate, font, scale) > width then
            lines[#lines + 1], line = line, word
        else
            line = candidate
        end
    end
    lines[#lines + 1] = line
    return table.concat(lines, "\n"), #lines
end

function t.fit(text, width, font, scale)
    if t.textSize(text, font, scale) <= width then return text end
    while #text > 0 and t.textSize(text .. "...", font, scale) > width do
        text = string.sub(text, 1, #text - 1)
    end
    return text .. "..."
end

function t.panel(x, y, w, h, color, radius)
    return {type = "rectangle", x = t.round(x), y = t.round(y), w = t.round(w), h = t.round(h),
        color = color or t.surface, filled = true, rounded = radius or 0}
end

function t.button(button, primary)
    local _, _, scale = t.metrics()
    button.color = primary and t.accent or (t.header or t.surface)
    button.textColor = primary and t.accentInk or t.ink
    button.cornerRadius = t.round(4 * scale)
    button.font = SMLSIZE
    return button
end

function t.page(title, subtitle, children, back, action, profileStatus, pageStatus, menuAction)
    if LCD_W == 480 and LCD_H == 320 then
        return rf2.executeScript("LVGL/480x320/header", t, title, subtitle, children, back, action, profileStatus, pageStatus, menuAction)
    end
    local width, height, scale, control = t.metrics()
    local headerHeight = LCD_H - height
    local margin = t.round(8 * scale)
    local background = t.panel(0, 0, width, height, t.background)
    background.floating = true
    table.insert(children, 1, background)
    -- Retain the native page for scrolling, navigation and hardware Back.
    local layout = {{type = "page", title = title, subtitle = subtitle, back = back,
        backButton = false, scrollBar = true, children = children}}
    layout[#layout + 1] = t.panel(0, 0, width, headerHeight, t.background)
    layout[#layout + 1] = t.panel(margin, headerHeight - 2, control, 2, t.accent)
    layout[#layout + 1] = t.button({type = "button", x = margin,
        y = t.round((headerHeight - control) / 2), w = control, h = control,
        text = "<", press = back})
    if width >= 800 and rf2.requestDashboardExit then
        -- Keep the same labelled exit on forms, editors, progress, errors,
        -- loading screens and the RF menu. Native Back stays independent.
        local dashboardW = math.ceil(t.textSize("Back to dashboard",SMLSIZE,scale))+24
        local dashboardX = width-margin-dashboardW
        local actionW = action and 112 or 0
        local menuW = menuAction and control+margin or 0
        local right = dashboardX-margin-(action and actionW+margin or 0)-menuW
        local titleX = margin*2+control
        local titleW = right-titleX
        local titleValue = function()
            local value=type(subtitle)=="function" and subtitle() or subtitle
            return t.fit(string.gsub(value~="" and value or title," %- SIMULATOR",""),titleW,BOLD,scale)
        end
        layout[#layout+1]={type="label",x=titleX,y=5,w=titleW,h=26,font=BOLD,color=t.ink,text=titleValue}
        layout[#layout+1]={type="label",x=titleX,y=31,w=titleW,h=24,font=SMLSIZE,color=t.muted,text=function()
            local status=pageStatus and pageStatus() or (rf2.offlineSimulator and "PREVIEW / SIMULATOR" or "ROTORFLIGHT "..rf2.luaVersion)
            if profileStatus then
                local withProfile=profileStatus().." | "..status
                if t.textSize(withProfile,SMLSIZE,scale)<=titleW then status=withProfile end
            end
            return status
        end}
        local cy=t.round((headerHeight-control)/2)
        layout[#layout+1]=t.button({type="button",name="Back to dashboard",text="Back to dashboard",
            x=dashboardX,y=cy,w=dashboardW,h=control,press=rf2.requestDashboardExit,active=rf2.canExitToDashboard})
        if action then
            action.type,action.x,action.y="button",dashboardX-margin-actionW,cy
            action.w,action.h=actionW,control
            layout[#layout+1]=t.button(action,true)
        end
        if menuAction then
            layout[#layout+1]=t.button({type="button",name="Page menu",text="...",x=right,y=cy,w=control,h=control,press=menuAction})
        end
        return layout
    end
    local actionWidth = t.round(84 * scale)
    local statusWidth = profileStatus and t.round(t.textSize(profileStatus(), SMLSIZE, scale) + 8 * scale) or 0
    local menuWidth = menuAction and control + margin or 0
    local statusX = width - margin - (action and actionWidth + margin or 0) - menuWidth - statusWidth
    local titleX = margin * 2 + control
    local titleWidth = statusX - titleX - (profileStatus and margin or 0)
    local displayTitle = function()
        local value = type(subtitle) == "function" and subtitle() or subtitle
        return t.fit(string.gsub(value ~= "" and value or title, " %- SIMULATOR", ""), titleWidth,
            width>=800 and MIDSIZE or BOLD, scale)
    end
    local displaySubtitle = pageStatus or (rf2.offlineSimulator and "PREVIEW / SIMULATOR" or "ROTORFLIGHT  "..rf2.luaVersion)
    local titleFont = width>=800 and MIDSIZE or BOLD
    local _, titleHeight = t.textSize("Ag", titleFont, scale)
    local _, subtitleHeight = t.textSize("Ag", SMLSIZE, scale)
    local titleY = math.max(1, t.round((headerHeight - titleHeight - subtitleHeight) / 2))
    layout[#layout + 1] = {type = "label", x = titleX, y = titleY,
        w = titleWidth, h = titleHeight, font = titleFont, color = t.ink, text = displayTitle}
    layout[#layout + 1] = {type = "label", x = titleX, y = t.round(titleY + titleHeight),
        w = titleWidth, h = subtitleHeight, font = SMLSIZE,
        color = pageStatus and t.accent or t.muted, text = displaySubtitle}
    if profileStatus then
        layout[#layout + 1] = {type = "label", x = statusX,
            y = t.round((headerHeight - subtitleHeight) / 2), w = statusWidth,
            font = SMLSIZE, color = t.ink, text = profileStatus, align = CENTER}
    end
    if action then
        action.type, action.x, action.y = "button", width - actionWidth - margin, t.round((headerHeight - control) / 2)
        action.w, action.h = actionWidth, control
        local actionText = type(action.text) == "function" and action.text() or action.text
        layout[#layout + 1] = t.button(action, actionText == "Save" or actionText == "Saved" or actionText == "Applied")
    end
    if menuAction then
        layout[#layout + 1] = t.button({type="button", name="Page menu", text="...",
            x=width-margin-(action and actionWidth+margin or 0)-control,
            y=t.round((headerHeight-control)/2), w=control, h=control, press=menuAction})
    end
    return layout
end

return t
