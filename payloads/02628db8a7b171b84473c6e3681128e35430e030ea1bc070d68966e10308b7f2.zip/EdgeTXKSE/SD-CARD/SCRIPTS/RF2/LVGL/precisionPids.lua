-- All three axes share the native editors and original PID field indexes.
local page,editors,theme,redraw=...
local s=rf2.executeScript('LVGL/studio',theme,page,editors)
local m,g,w=s.margin,s.gap,s.w
if page.uiAxis==3 then
    local actionW=s.large and 144 or 80
    s.label(m,m+(s.control-s.textH)/2,w-m*2-actionW-g,'Copy PID profile',theme.muted)
    s.button(w-m-actionW,m,actionW,s.control,'All axes',function()page.uiAxis=1;redraw()end)
    s.copy(17,18,m+s.control+g)
    return s.children
end

local ids={{1,4,7,10,13,19},{2,5,8,11,14,20},{3,6,9,12,15}}
local captions={'P','I','D','FF','Boost','HSI offset'}
local function panel(x,y,width,height,color,radius)
    local node=s.panel(x,y,width,height,color)
    node.rounded=radius or 0
end
-- Use the spare space above and below the cards for separation between rows.
local cardY=s.large and 8 or 4
local cardH=s.h-cardY*2
local minimumCardH=8+s.textH+2+s.control*5+s.textH+s.control+1
if w<480 or minimumCardH>cardH then
    -- A shared-label matrix fits the complete table on small/short displays.
    -- The last row is HSI for cyclic and CW/CCW stop gains for Yaw.
    m,g=4,4
    local labelW=math.max(64,math.ceil(theme.textSize('CW/CCW',SMLSIZE,s.scale))+4)
    local remaining=w-m*2-labelW-g*3
    local cyclicW=math.floor(remaining*0.28)
    local widths={cyclicW,cyclicW,remaining-cyclicW*2}
    local xs={m+labelW+g,m+labelW+g*2+cyclicW,m+labelW+g*3+cyclicW*2}
    for axis,name in ipairs({'Roll','Pitch','Yaw'}) do
        s.label(xs[axis],m,widths[axis],name,theme.accent,BOLD)
    end
    local y=m+s.textH
    local lastH=math.max(s.control,s.textH*2)
    local rowH=math.max(s.control,math.floor((s.h-m-y-lastH)/5))
    for row=1,6 do
        local yy=y+(row-1)*rowH
        local height=row==6 and lastH or rowH
        panel(m,yy,w-m*2,height,theme.header or theme.surface,3)
        local caption=row==6 and 'HSI /\nCW/CCW' or captions[row]
        local lines=row==6 and 2 or 1
        s.label(m+2,yy+(height-s.textH*lines)/2,labelW-2,caption,theme.muted,SMLSIZE,lines)
        for axis=1,3 do
            local editorY=yy+(height-s.control)/2
            if row==6 and axis==3 then
                local stopW=math.floor((widths[axis]-g)/2)
                s.editor(21,xs[axis],editorY,stopW)
                s.editor(22,xs[axis]+stopW+g,editorY,stopW)
            else s.editor(ids[axis][row],xs[axis],editorY,widths[axis]) end
        end
    end
    return s.children
end

-- Reserve a labelled pair for Yaw stops, then give the first five gains
-- identical row positions in all three cards. No page toolbar consumes space.
local cardW=math.floor((w-m*2-g*2)/3)
local inset=s.large and 14 or 6
local verticalInset=s.large and 12 or 4
local titleFont=MIDSIZE
local titleGap=s.large and 10 or 4
local stopGap=s.large and 4 or 2
local titleH=select(2,theme.textSize('Roll',titleFont,s.scale))
local stopH=s.textH+stopGap+s.control
if verticalInset*2+titleH+titleGap+s.control*5+stopH>cardH then
    -- Short displays use a compact heading, retaining native editor heights.
    inset,verticalInset,titleFont,titleGap,stopGap=4,4,BOLD,2,0
    titleH=select(2,theme.textSize('Roll',titleFont,s.scale))
    stopH=s.textH+s.control
end
local innerW=cardW-inset*2
local headingH=titleH+titleGap
local rowH=math.max(s.control,math.floor((cardH-verticalInset*2-headingH-stopH-1)/5))
local valueW=math.floor(innerW*0.48)
for axis,name in ipairs({'Roll','Pitch','Yaw'}) do
    local x=m+(axis-1)*(cardW+g)
    local radius=theme.round(s.large and 10 or 6)
    panel(x,cardY,cardW,cardH,theme.line,radius)
    panel(x+1,cardY+1,cardW-2,cardH-2,theme.header or theme.surface,radius-1)
    s.label(x+inset,cardY+verticalInset,innerW,name,theme.accent,titleFont)
    s.panel(x+inset,cardY+verticalInset+titleH+math.floor(titleGap/2),innerW,1,theme.line)
    local bodyY=cardY+verticalInset+headingH
    for row=1,5 do
        local yy=bodyY+(row-1)*rowH+(rowH-s.control)/2
        s.label(x+inset,yy+(s.control-s.textH)/2,innerW-valueW-g,captions[row],theme.muted)
        s.editor(ids[axis][row],x+cardW-inset-valueW,yy,valueW)
    end
    local stopY=bodyY+5*rowH
    local editorY=stopY+s.textH+stopGap
    if axis<3 then
        local caption='HSI offset'
        if theme.textSize(caption,SMLSIZE,s.scale)>innerW-valueW-g then caption='HSI' end
        s.label(x+inset,editorY+(s.control-s.textH)/2,innerW-valueW-g,caption,theme.muted)
        s.editor(ids[axis][6],x+cardW-inset-valueW,editorY,valueW)
    else
        local stopW=math.floor((innerW-g)/2)
        for i,label in ipairs({'CW stop','CCW stop'}) do
            local xx=x+inset+(i-1)*(stopW+g)
            if theme.textSize(label,SMLSIZE,s.scale)>stopW then label=i==1 and 'CW' or 'CCW' end
            s.label(xx,stopY,stopW,label,theme.muted)
            s.editor(20+i,xx,editorY,stopW)
        end
    end
end
return s.children
