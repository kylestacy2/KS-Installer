local page,axis,s,theme,x,y,w,h=...
local calculate=rf2.executeScript("F/rateCurve")
local collective=axis==4
local cachedKind,cachedRate,cachedSuper,cachedExpo,points,peak,half,limit
local left=s.large and 58 or 38
local right=s.large and 160 or 8
local top=s.large and 30 or 18
local bottom=s.large and 28 or 18
local pw,ph=w-left-right,h-top-bottom
local function update()
    local f=page.rateFields
    local kind,r,super,expo=f[13].data.value,f[axis].data.value,f[axis+4].data.value,f[axis+8].data.value
    if kind==cachedKind and r==cachedRate and super==cachedSuper and expo==cachedExpo then return end
    cachedKind,cachedRate,cachedSuper,cachedExpo=kind,r,super,expo
    peak=calculate(kind,r,super,expo,1,collective)
    -- Collective percentages describe the full bottom-to-top stick travel:
    -- 50% travel is centered (zero signed input), not half positive deflection.
    half=calculate(kind,r,super,expo,collective and 0 or 0.5,collective)
    local step=collective and 5 or 100
    limit=math.max(step,math.ceil(peak/step)*step)
    points={}
    for i=0,40 do
        -- EdgeTX line points are relative to the parent page, not to line x/y.
        local input=collective and (i/20-1) or i/40
        local output=calculate(kind,r,super,expo,input,collective)
        local height=collective and ((output/limit+1)/2) or output/limit
        points[#points+1]={theme.round(x+left+i/40*pw),theme.round(y+top+ph-height*ph)}
    end
end
update()
s.label(x,y,w,collective and "Collective command / nominal deg" or "Static response  /  deg/s",theme.muted)
for i=0,4 do
    s.panel(x+left,y+top+theme.round(ph*i/4),pw,1,theme.header or theme.surface)
    s.panel(x+left+theme.round(pw*i/4),y+top,1,ph,theme.header or theme.surface)
end
if collective then
    s.panel(x+left,y+top+theme.round(ph/2),pw,1,theme.line)
    s.panel(x+left+theme.round(pw/2),y+top,1,ph,theme.line)
end
s.children[#s.children+1]={type="line",name="Rate curve",
    pts=function()update();return points end,color=theme.accent,thickness=s.large and 3 or 2}
s.label(x,y+top,left-4,function()update();return tostring(limit)end,theme.muted)
s.label(x,y+top+ph-s.textH,left-4,function()update();return collective and tostring(-limit) or "0" end,theme.muted)
if collective and ph>=s.textH*3 then s.label(x,y+top+(ph-s.textH)/2,left-4,"0",theme.muted) end
s.label(x+left,y+h-s.textH,pw/2,"0% stick",theme.muted)
local tickW=math.ceil(theme.textSize("100%",SMLSIZE,s.scale))
s.label(x+left+pw/2-tickW/2,y+h-s.textH,tickW,"50%",theme.muted)
s.label(x+left+pw-tickW,y+h-s.textH,tickW,"100%",theme.muted)
if s.large then
    local xx=x+w-right+20
    if collective then
        local rowH=math.floor((h-top)/3)
        local valueFont=rowH>=s.textH+select(2,theme.textSize('Ag',MIDSIZE,s.scale))+4 and MIDSIZE or BOLD
        for i,position in ipairs({100,50,0}) do
            local percent=position
            local yy=y+top+(i-1)*rowH
            s.label(xx,yy,right-20,percent.."% STICK",theme.muted)
            local node=s.label(xx,yy+s.textH+4,right-20,function()
                update()
                local value=percent==100 and peak or percent==0 and -peak or half
                return string.format(value>0 and "+%.1f" or "%.1f",value)
            end,theme.ink,valueFont)
            node.name="Collective "..percent.."%"
        end
    else
        s.label(xx,y+top,right-20,"FULL STICK",theme.muted)
        s.label(xx,y+top+s.textH+4,right-20,function()update();return string.format("%.0f",peak)end,theme.ink,MIDSIZE)
        s.label(xx,y+top+90,right-20,"HALF STICK",theme.muted)
        s.label(xx,y+top+90+s.textH+4,right-20,function()update();return string.format("%.0f",half)end,theme.ink,MIDSIZE)
    end
end
