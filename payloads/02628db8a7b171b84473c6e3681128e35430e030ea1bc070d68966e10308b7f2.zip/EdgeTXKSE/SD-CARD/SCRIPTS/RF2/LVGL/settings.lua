-- Preferences use one continuous form. Place each native editor once, without
-- the generic form's repeated font/column fitting for every setting.
local page, editors, theme = ...
local width, _, scale, control = theme.metrics()
local round = theme.round
local margin, gap = round(8 * scale), round(6 * scale)
local columns = width >= 480 and 2 or 1
local columnWidth = math.floor((width - margin * 2 - gap * (columns - 1)) / columns)
local textH = select(2, theme.textSize('Ag', SMLSIZE, scale))
local children = {}
local function wrap(text, width, font)
    if theme.textSize(text,font,scale) <= width then return text,1 end
    return theme.wrap(text,width,font,scale)
end
local function label(text, x, y, w, lines, bold)
    children[#children+1] = {type='label', x=round(x), y=round(y), w=math.floor(w),
        h=math.ceil(textH * (lines or 1)), text=text, font=bold and BOLD or SMLSIZE,
        color=bold and theme.ink or theme.muted}
end
local function row(field, x, y, w)
    local editor = editors[field]
    if not editor then return 0 end
    local valueW = math.min(round(field == page.lvglHeaderField and 150 * scale or 90 * scale), w)
    local captionW = w - valueW - gap
    local stacked = captionW < round(90 * scale)
    local text, lines = wrap(field.t, stacked and w or captionW, SMLSIZE)
    local captionH = textH * lines
    local height = stacked and captionH + gap + control or math.max(captionH, control)
    label(text, x, y + (stacked and 0 or (height-captionH)/2), stacked and w or captionW, lines)
    editor.x, editor.y = round(x+w-valueW), round(y+(stacked and captionH+gap or (height-control)/2))
    editor.w, editor.h = math.floor(valueW), control
    children[#children+1] = editor
    return height + gap
end
local top = margin
if page.lvglHeaderField then
    top = top + row(page.lvglHeaderField, margin+gap, top+gap, width-margin*2-gap*2) + gap
end
local bottoms = {top, top}
local orderedFields = {}
for _, field in ipairs(page.fields) do orderedFields[#orderedFields+1] = field end
table.sort(orderedFields,function(a,b) return a.y < b.y end)
-- Settings labels mark its five groups. Keep the existing column mapping and
-- original field indexes (including the two appended preferences).
local fieldIndex = 1
for i, heading in ipairs(page.labels) do
    local column = columns == 1 and 1 or (page.lvglCompactSectionColumns or {})[i] or (i-1)%2+1
    local x, y = margin+(column-1)*(columnWidth+gap), bottoms[column]
    local start, panelY = #children+1, y
    local text, lines = wrap(heading.t, columnWidth-gap*2, BOLD)
    label(text,x+gap,y+gap,columnWidth-gap*2,lines,true)
    y = y+gap+textH*lines+gap
    local nextY = page.labels[i+1] and page.labels[i+1].y or math.huge
    while orderedFields[fieldIndex] and orderedFields[fieldIndex].y < nextY do
        local field = orderedFields[fieldIndex]
        if field ~= page.lvglHeaderField and field.y >= heading.y then
            y = y + row(field,x+gap,y,columnWidth-gap*2)
        end
        fieldIndex = fieldIndex+1
    end
    table.insert(children,start,theme.panel(x,panelY,columnWidth,y-panelY,theme.surface,margin))
    bottoms[column] = y+gap
end
return children
