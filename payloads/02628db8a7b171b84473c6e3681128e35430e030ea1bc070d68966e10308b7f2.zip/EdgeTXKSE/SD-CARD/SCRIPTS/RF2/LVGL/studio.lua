-- Shared presentation primitives. Editors and their callbacks remain native.
local theme, page, editors = ...
local s = {children={}}
s.w,s.h,s.scale,s.control = theme.metrics()
s.large = s.w >= 800
s.margin = s.large and 16 or 8
s.gap = s.large and 12 or 6
s.textH = select(2,theme.textSize("Ag",SMLSIZE,s.scale))
function s.label(x,y,w,text,color,font,lines)
    -- Labels retain their dimensions for this scene. Fit static text once;
    -- refit live text only when its actual value changes (including slider drags).
    local function fit(value)
        if lines then return theme.wrap(value,w,font or SMLSIZE,s.scale) end
        return theme.fit(value,w,font or SMLSIZE,s.scale)
    end
    local value
    if type(text)=='function' then
        local previous, fitted
        value=function()
            local current=text()
            if current~=previous or fitted==nil then
                previous=current; fitted=fit(current)
            end
            return fitted
        end
    else value=fit(text) end
    local node={type="label",x=theme.round(x),y=theme.round(y),w=math.floor(w),
        h=math.ceil(select(2,theme.textSize("Ag",font or SMLSIZE,s.scale))*(lines or 1)),
        text=value,color=color or theme.ink,font=font or SMLSIZE}
    s.children[#s.children+1]=node
    return node
end
function s.panel(x,y,w,h,color)
    local node=theme.panel(x,y,w,h,color or theme.header or theme.surface,0)
    s.children[#s.children+1]=node
    return node
end
function s.button(x,y,w,h,text,press,selected,name)
    local node=theme.button({type="button",name=name or text,text=text,press=press,
        x=theme.round(x),y=theme.round(y),w=math.floor(w),h=math.floor(h)},selected)
    s.children[#s.children+1]=node
    return node
end
function s.tabs(names,selected,change,y)
    y=y or s.margin
    local w=(s.w-s.margin*2)/#names
    -- EdgeTX focuses the first control created after a rebuild. Start with the
    -- active tab, keeping its screen position and cycling the remaining tabs
    -- in visual order, so switching tabs does not jump focus back to tab one.
    for offset=0,#names-1 do
        local i=(selected-1+offset)%#names+1
        local name=names[i]
        local index=i
        local caption=s.w<480 and ({Collective="Coll",Options="Opts",Profile="Copy",["Roll / Pitch"]="Roll/Pitch",["Yaw / Governor"]="Yaw/Gov"})[name] or name
        local node=s.button(s.margin+(i-1)*w,y,w-s.gap,s.control,caption,function() change(index) end,false,name)
        node.color=i==selected and theme.surface or theme.background
        node.textColor=i==selected and theme.ink or theme.muted
    end
    return y+s.control+s.gap
end
function s.editor(index,x,y,w,h)
    local child=editors[page.fields[index]]
    if not child then return end
    child.x,child.y,child.w,child.h=theme.round(x),theme.round(y),math.floor(w),math.floor(h or s.control)
    child.name="Field "..index
    s.children[#s.children+1]=child
    return child
end
function s.card(index,caption,x,y,w,h,kicker)
    s.panel(x,y,w,h)
    local inset=s.large and 14 or 6
    local kickerH=select(2,theme.textSize("Ag",MIDSIZE,s.scale))
    local _,lines=theme.wrap(caption,w-inset*2,SMLSIZE,s.scale)
    local labelY=y+inset
    local labelBottom
    local textGap=s.large and 8 or 2
    if kicker and s.large then
        s.label(x+inset,labelY,w-inset*2,kicker,theme.accent,MIDSIZE)
        if inset*2+kickerH+4+s.textH*lines+textGap+s.control>h then
            -- Dense cards put the symbol and caption on one line, retaining
            -- room for the native editor and its focus border inside the card.
            local kickerW=theme.textSize(kicker,MIDSIZE,s.scale)
            s.label(x+inset+kickerW+8,labelY+(kickerH-s.textH)/2,
                w-inset*2-kickerW-8,caption,theme.ink)
            labelBottom=labelY+kickerH
        else
            labelY=labelY+kickerH+4
        end
    end
    if not labelBottom then
        s.label(x+inset,labelY,w-inset*2,caption,theme.ink,SMLSIZE,lines)
        labelBottom=labelY+s.textH*lines
    end
    local editorY=math.max(labelBottom+textGap,y+h-s.control-inset)
    s.editor(index,x+inset,editorY,w-inset*2)
    local marker=s.panel(x,y+h-2,w,2,theme.background)
    if page.uiChanged then
        marker.color=function() return page.uiChanged(index) and theme.accent or (theme.header or theme.surface) end
    end
end
function s.copy(destination,copy,y)
    local captionW=s.large and 190 or 130
    local valueW=s.large and 74 or 50
    s.panel(s.margin,y,s.w-s.margin*2,1,theme.line)
    y=y+s.gap
    s.label(s.margin,y+(s.control-s.textH)/2,captionW,"Copy to profile",theme.muted)
    s.editor(destination,s.margin+captionW,y,valueW)
    local button=s.editor(copy,s.w-s.margin-(s.large and 210 or 160),y,s.large and 210 or 160)
    if button then button.text="Copy profile" end
end
return s
