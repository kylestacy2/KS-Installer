-- Reflow the original form into section pages. No field data is copied,
-- renumbered or discarded when navigating between sections.
local page,editors,theme,hidden,redraw=...
local s=rf2.executeScript("LVGL/studio",theme,page,editors)
if not s.large then s.gap=4 end
local m,g,w=s.margin,s.gap,s.w
local template=rf2.executeScript(rf2.radio.template)
local entries,groups={},{}
for i,field in ipairs(page.fields) do
    if not hidden[field] and editors[field] then
        entries[#entries+1]={item=field,index=i,y=field==page.lvglHeaderField and -10000 or field.y}
    end
end
for i,label in ipairs(page.labels) do
    if label.t~="" then entries[#entries+1]={item=label,y=label.y,order=i} end
end
table.sort(entries,function(a,b)
    if a.y~=b.y then return a.y<b.y end
    if not a.index~=not b.index then return not a.index end
    return (a.index or a.order)<(b.index or b.order)
end)
local current
local function group(title)
    current={title=title,items={}}
    groups[#groups+1]=current
end
for _,entry in ipairs(entries) do
    local item=entry.item
    if not entry.index and item.bold~=false and item.x==template.margin then
        group(item.t)
    else
        if not current then group("Overview") end
        current.items[#current.items+1]=entry
    end
end
if #groups==0 then group("Overview") end
local perPage=4
local pages={}
for _,section in ipairs(groups) do
    for first=1,math.max(1,#section.items),perPage do
        local chunk={title=section.title,items={}}
        for j=first,math.min(#section.items,first+perPage-1) do chunk.items[#chunk.items+1]=section.items[j] end
        chunk.title=chunk.title..(#section.items>perPage and ("  "..math.ceil(first/perPage).."/"..math.ceil(#section.items/perPage)) or "")
        pages[#pages+1]=chunk
    end
end
page.uiPanel=math.max(1,math.min(page.uiPanel or 1,#pages))
local selected=pages[page.uiPanel]
local values={}
for _,section in ipairs(pages) do values[#values+1]=section.title end
local selectW=math.min(w-m*2-80,s.large and 390 or 280)
s.label(m,m+(s.control-s.textH)/2,s.large and 118 or 70,"SECTION",theme.accent)
local choice={type="choice",name="Sections",x=m+(s.large and 118 or 70),y=m,
    w=math.min(selectW,w-m*2-(s.large and 118 or 70)),h=s.control,values=values,
    get=function()return page.uiPanel end,
    set=function(value)page.uiPanel=value;redraw()end}
s.children[#s.children+1]=choice
local y=m+s.control+g
local footerH=s.large and 32 or 24
local footerY=s.h-m-footerH
local rows=2
local cardW=math.floor((w-m*2-g)/2)
local cardH=math.floor((footerY-g-y-g*(rows-1))/rows)
for slot,entry in ipairs(selected.items) do
    local x=m+(slot-1)%2*(cardW+g)
    local yy=y+math.floor((slot-1)/2)*(cardH+g)
    if entry.index then
        local caption=entry.item.t or ("Value "..entry.index)
        if editors[entry.item].type=="button" then
            s.panel(x,yy,cardW,cardH)
            local button=s.editor(entry.index,x+g,yy+(cardH-s.control)/2,cardW-g*2)
            theme.button(button)
        else
            -- Compact cards use one caption line when possible. Taller text
            -- remains scrollable instead of hiding a setting or its value.
            s.card(entry.index,caption,x,yy,cardW,cardH)
        end
    else
        s.panel(x,yy,cardW,cardH)
        local label=entry.item
        s.label(x+g,yy+g,cardW-g*2,function()return label.t end,theme.muted,SMLSIZE,
            math.max(1,math.floor((cardH-g*2)/s.textH)))
    end
end
if #selected.items==0 then s.label(m,y+g,w-m*2,"No values available.",theme.muted) end
local arrowW=s.large and 44 or 30
s.label(m,footerY+(footerH-s.textH)/2,w-m*2-arrowW*2-g*2,
    string.format("%02d / %02d",page.uiPanel,#pages),theme.muted)
local previous=s.button(w-m-arrowW*2-g,footerY,arrowW,footerH,"<<",function()page.uiPanel=page.uiPanel-1;redraw()end,false,"Previous section")
local next=s.button(w-m-arrowW,footerY,arrowW,footerH,">>",function()page.uiPanel=page.uiPanel+1;redraw()end,false,"Next section")
previous.active=function()return page.uiPanel>1 end
next.active=function()return page.uiPanel<#pages end
return s.children
