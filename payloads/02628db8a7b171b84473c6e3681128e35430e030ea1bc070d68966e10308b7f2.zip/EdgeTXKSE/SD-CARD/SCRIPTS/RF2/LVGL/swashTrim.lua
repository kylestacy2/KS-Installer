local page, editors, theme = ...
local s = rf2.executeScript("LVGL/studio", theme, page, editors)
local m, g = s.margin, s.gap
local inset = s.large and 14 or 6
local rowH = math.max(s.control + s.textH + inset * 2 + g,
    math.floor((s.h - m * 2 - g * 2) / 3))
local width = s.w - m * 2
local valueW = s.large and 180 or 110
for i, field in ipairs(page.fields) do
    local y = m + (i - 1) * (rowH + g)
    local innerW = width - inset * 2
    s.panel(m, y, width, rowH)
    s.label(m + inset, y + inset + (s.control - s.textH) / 2,
        innerW - valueW - g, field.t, theme.ink, BOLD)
    s.editor(i, s.w - m - inset - valueW, y + inset, valueW)
    local hintY = y + rowH - inset - s.textH
    local hintW = math.floor((innerW - g) / 2)
    s.label(m + inset, hintY, hintW, field.negativeHint, theme.muted)
    s.label(m + inset + hintW + g, hintY, hintW, field.positiveHint, theme.muted)
end
return s.children
