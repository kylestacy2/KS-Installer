-- Compact TX16S MK3 controls. Original editors retain all data conversion and
-- action callbacks; the focused editor keeps its draft local until Done.
local edits = rf2.executeScript('F/editSession')
local t = {}

local function orderedEntries(page,editors,hidden)
    local entries={}
    for i,f in ipairs(page.fields) do
        if not hidden[f] and (not editors or editors[f]) then
            entries[#entries+1]={index=i,y=f==page.lvglHeaderField and -10000 or f.y,x=f.x or 0}
        end
    end
    for i,label in ipairs(page.labels or {}) do
        if label.t~='' then entries[#entries+1]={label=label,y=label.y,x=label.x or 0,order=i} end
    end
    table.sort(entries,function(a,b)
        if a.y~=b.y then return a.y<b.y end
        if a.x~=b.x then return a.x<b.x end
        return (a.index or -a.order)<(b.index or -b.order)
    end)
    return entries
end

function t.prepare(page)
    -- Sort during the existing preparation pass, before building controls and
    -- running their live getters. Consume this order once: later redraws must
    -- respect any fields/sections changed by a page callback.
    if page.title~='PID Gains' and page.title~='Battery' and not page.rateFields then
        page.uiTouchEntries={entries=orderedEntries(page,nil,{}),
            fields=page.fields,labels=page.labels,header=page.lvglHeaderField}
    end
end

function t.layout(page, editors, theme, hidden, redraw)
    local s = rf2.executeScript('LVGL/studio', theme, page, editors)
    local m,g,w = s.margin,8,s.w
    local tileH = 100
    local cornerRadius=theme.round(4*s.scale)
    local titleH=select(2,theme.textSize('Ag',MIDSIZE,s.scale))
    local boldH=select(2,theme.textSize('Ag',BOLD,s.scale))
    local function heading(index,caption,x,y,width,font,lines)
        local h=(font==MIDSIZE and titleH or boldH)*lines
        s.children[#s.children+1]={type='label',name='Title '..index,
            x=x,y=y,w=width,h=h,text=caption,color=theme.ink,font=font}
        return h
    end
    local function tile(index, caption, x,y,width,height)
        local field=page.fields[index]
        local editor=editors[field]
        if not editor then return end
        if editor.type=='button' then
            return s.editor(index,x,y,width,height)
        end
        if field.readOnly then
            s.panel(x,y,width,height)
            s.label(x+12,y+8,width-24,caption,theme.ink,BOLD)
            return s.editor(index,x+10,y+height-s.control-6,width-20)
        end
        local label=caption or edits.label(page,index)
        local inset=height<70 and 6 or 12
        local innerW=width-inset*2
        local titleFont=height<76 and BOLD or MIDSIZE
        local valueFont=height>=84 and MIDSIZE or SMLSIZE
        local valueH=valueFont==MIDSIZE and titleH or s.textH
        local gap=height<70 and 2 or 6
        local text,lines=label,1
        if theme.textSize(label,titleFont,s.scale)>innerW then
            -- A two-line large title leaves too little room on a compact tile.
            -- Choose the bold face before wrapping instead of laying it out twice.
            if titleH*2+valueH+gap+8>height then titleFont=BOLD end
            text,lines=theme.wrap(label,innerW,titleFont,s.scale)
        end
        local labelH=(titleFont==MIDSIZE and titleH or boldH)*lines
        if labelH+valueH+gap+8>height then valueFont,valueH=SMLSIZE,s.textH end
        local top=y+math.floor((height-labelH-valueH-gap)/2)
        -- Separate native labels give titles and values independent typography.
        -- Labels are non-interactive in LVGL; the full button beneath owns taps.
        local node={type='button',name='Field '..index,text='',
            x=x,y=y,w=width,h=height,font=SMLSIZE,cornerRadius=cornerRadius,
            color=theme.header or theme.surface,press=function()
                page.uiEditField(index,editor,edits.label(page,index))
            end}
        s.children[#s.children+1]=node
        heading(index,text,x+inset,top,innerW,titleFont,lines)
        s.children[#s.children+1]={type='label',name='Value '..index,
            x=x+inset,y=top+labelH+gap,w=innerW,h=valueH,font=valueFont,color=theme.accent,
            text=function()
                local value=edits.format(field,field.data.value)
                return page.uiChanged and page.uiChanged(index) and value..' *' or value
            end}
        return node
    end
    -- Fields with large ranges/text keep wide native inputs. A slider over a
    -- multi-thousand range is not an efficient way to enter an exact value.
    local function wide(index)
        local f=page.fields[index]
        local e=editors[f]
        if f.touchTile then return false end
        return e and (e.type=='textEdit' or e.type=='numberEdit' and
            ((f.data.max or 0)/(f.data.scale or 1)>=1000 or
             (f.data.max or 0)-(f.data.min or 0)>2000))
    end
    local function wideField(index,caption,x,y,width,height)
        s.panel(x,y,width,height)
        s.label(x+12,y+8,width-24,caption,theme.ink,MIDSIZE)
        return s.editor(index,x+10,y+height-s.control-8,width-20)
    end
    if page.title=='PID Gains' then
        if page.uiAxis==3 then
            s.button(w-m-144,m,144,s.control,'All axes',function()page.uiAxis=1;redraw()end)
            s.copy(17,18,m+s.control+g)
            return s.children
        end
        local ids={{1,4,7,10,13,19},{2,5,8,11,14,20},{3,6,9,12,15}}
        local captions={'P','I','D','Feedforward','Boost','HSI offset'}
        local cw=math.floor((w-m*2-g*2)/3)
        local top=m+s.textH+g
        local h=math.floor((s.h-m-top-g*5)/6)
        for axis,name in ipairs({'Roll','Pitch','Yaw'}) do
            local x=m+(axis-1)*(cw+g)
            s.label(x,m,cw,name,theme.accent,BOLD)
            for row,index in ipairs(ids[axis]) do
                tile(index,captions[row],x,top+(row-1)*(h+g),cw,h)
            end
            if axis==3 then
                local half=math.floor((cw-g)/2)
                tile(21,'CW stop',x,top+5*(h+g),half,h)
                tile(22,'CCW stop',x+half+g,top+5*(h+g),half,h)
            end
        end
        return s.children
    end
    if page.rateFields then
        local function index(original) return page.rateFieldIndices[original] end
        local top=m
        if not page.collectiveOnly then
            tile(index(13),'Rates type',m,m,280,64)
            s.button(m+292,m,220,64,page.uiCollectiveCurve and 'All axes' or 'Collective curve',function()
                page.uiCollectiveCurve=not page.uiCollectiveCurve;page.uiRatesOptions=false;redraw()
            end)
            s.button(w-m-144,m,144,64,page.uiRatesOptions and 'All axes' or 'Options',function()
                page.uiRatesOptions=not page.uiRatesOptions;page.uiCollectiveCurve=false;redraw()
            end)
            top=m+64+g
        end
        if page.collectiveOnly or page.uiCollectiveCurve then
            local height=90
            local y=s.h-m-height
            rf2.executeScript('LVGL/ratePlot',page,4,s,theme,m,top,w-m*2,y-top-g)
            local cw=math.floor((w-m*2-g*2)/3)
            for col=1,3 do
                local a,b=page.rateLabels[5+col*2],page.rateLabels[6+col*2]
                tile(index((col-1)*4+4),(a.t~='' and a.t..' ' or '')..b.t,m+(col-1)*(cw+g),y,cw,height)
            end
            return s.children
        end
        if page.uiRatesOptions then
            for col,original in ipairs({17,18}) do
                if index(original) then tile(index(original),page.rateFields[original].t,m+(col-1)*((w-m*2-g)/2+g),top,(w-m*2-g)/2,100) end
            end
            s.copy(index(15),index(16),top+112)
        else
            local cw=math.floor((w-m*2-g*3)/4)
            for axis,name in ipairs({'Roll','Pitch','Yaw','Collective'}) do
                local x=m+(axis-1)*(cw+g)
                s.label(x,top,cw,name,theme.accent,BOLD)
                local y=top+s.textH+g
                local h=math.floor((s.h-m-y-g*2)/3)
                for col=1,3 do
                    local a,b=page.rateLabels[5+col*2],page.rateLabels[6+col*2]
                    local caption=(a.t~='' and a.t..' ' or '')..b.t
                    if caption=='Center Sens' then caption='Center sensitivity' end
                    tile(index((col-1)*4+axis),caption,x,y+(col-1)*(h+g),cw,h)
                end
            end
        end
        return s.children
    end
    -- Keep real section headings, hints, read-only values and immediate action
    -- buttons. Long pages scroll; no fields are hidden behind artificial chunks.
    local prepared=page.uiTouchEntries
    page.uiTouchEntries=nil
    local entries=prepared and prepared.fields==page.fields and prepared.labels==page.labels
        and prepared.header==page.lvglHeaderField and prepared.entries or orderedEntries(page,editors,hidden)
    local y,col=m,0
    local cw=math.floor((w-m*2-g*2)/3)
    local function flush() if col>0 then y=y+tileH+g;col=0 end end
    for _,entry in ipairs(entries) do
        if entry.label then
            flush()
            local text,lines=theme.wrap(entry.label.t,w-m*2,SMLSIZE,s.scale)
            -- Section captions are already wrapped and never change during a
            -- page build. Avoid wrapping them again in a getter every frame.
            s.children[#s.children+1]={type='label',x=m,y=y,w=w-m*2,h=lines*s.textH,
                text=text,color=entry.label.bold==false and theme.muted or theme.accent,font=SMLSIZE}
            y=y+lines*s.textH+g
        elseif editors[page.fields[entry.index]] and not hidden[page.fields[entry.index]] then
            local i=entry.index
            local f=page.fields[i]
            local caption=edits.label(page,i)
            local isWide=wide(i)
            local span=(isWide or f==page.lvglHeaderField) and 3 or 1
            if span==3 then
                flush()
                if isWide then wideField(i,caption,m,y,w-m*2,tileH)
                else tile(i,caption,m,y,w-m*2,tileH) end
                y=y+tileH+g
            else
                tile(i,caption,m+col*(cw+g),y,cw,tileH)
                col=col+1
                if col==3 then flush() end
            end
        end
    end
    return s.children
end

function t.edit(page,index,original,caption,theme,done)
    local field=page.fields[index]
    local data=field.data
    local s=rf2.executeScript('LVGL/studio',theme,page)
    local x,width=64,s.w-128
    local y,height=36,math.min(340,s.h-72)
    local gap=16
    local draft=original.get()
    local start=draft
    local function clamp(value)
        return math.max(original.min or -32768,math.min(original.max or 32767,value))
    end
    local function build(exact)
        s.children={}
        s.panel(x,y,width,height,theme.header or theme.surface)
        s.label(x+gap,y+gap,width-gap*2,caption,theme.ink,MIDSIZE)
        s.label(x+gap,y+56,width-gap*2,'Starting value '..edits.format(field,data.value),theme.muted)
        if original.type=='choice' then
            s.children[#s.children+1]={type='choice',name='Touch value',x=x+gap,y=y+106,w=width-gap*2,h=56,
                values=original.values,get=function()return draft end,set=function(value)draft=value end}
        else
            -- NumberEdit caches external values. Keep slider mode on a live label;
            -- construct an exact input from the current draft only when requested.
            local live=s.label(x+gap+70,y+102,width-gap*2-140,function()
                return original.display and original.display(draft) or tostring(draft)
            end,theme.accent,MIDSIZE)
            live.name='Live value'
            if exact then
                s.children[#s.children+1]={type='numberEdit',name='Touch value',x=x+gap+70,y=y+158,w=width-gap*2-140,h=44,
                    min=original.min,max=original.max,get=function()return draft end,
                    set=function(value)draft=clamp(value)end,display=original.display}
                s.button(x+gap+70,y+224,width-gap*2-140,44,'Use slider',function()build(false)end)
            else
                s.button(x+gap+70,y+158,width-gap*2-140,44,'Type exact value',function()build(true)end)
                s.button(x+gap,y+94,56,56,'-',function()draft=clamp(draft-1)end,false,'Decrease value')
                s.button(x+width-gap-56,y+94,56,56,'+',function()draft=clamp(draft+1)end,false,'Increase value')
                if original.min and original.max and original.max>original.min then
                    -- Native sliders use integer positions; offset them so negative
                    -- ranges and fractional bounds preserve the original field step.
                    local low=original.min
                    local steps=math.ceil(original.max-low)
                    s.children[#s.children+1]={type='slider',name='Touch slider',x=x+gap+14,y=y+224,w=width-gap*2-28,h=32,
                        min=0,max=steps,color=theme.accent,get=function()return math.floor(draft-low+0.5)end,
                        set=function(value)draft=clamp(low+value)end}
                end
            end
        end
        local by=y+height-64
        s.button(x+gap,by,144,48,'Cancel',function()done(false)end)
        s.button(x+width-gap-144,by,144,48,'Done',function()done(true)end,true)
        lvgl.clear()
        lvgl.build(theme.page('Rotorflight '..rf2.luaVersion,page.title..' - Edit',s.children,function()done(false)end))
    end
    build(false)
    return function()
        -- A rebuild/model change retires this editor rather than writing into
        -- a replacement field or applying a stale draft.
        if page.fields[index]~=field or field.data~=data then return end
        if draft~=start then original.set(draft) end
    end
end
return t
