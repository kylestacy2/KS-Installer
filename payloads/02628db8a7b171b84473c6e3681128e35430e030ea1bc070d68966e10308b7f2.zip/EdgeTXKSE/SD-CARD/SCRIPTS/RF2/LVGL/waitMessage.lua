local t = {}
local theme = rf2.executeScript("LVGL/precision")

t.setWaitMessage = function(title, message, back, detail)
    --rf2.print("Setting wait message: "..message)
    if message ~= t.message or detail ~= t.detail or not t.shown then
        t.message = message
        t.detail = detail
        t.title = title
        t.back = back
        t.shown = false
    end
end

t.clearWaitMessage = function()
    --rf2.print("Clearing wait message")
    if not t.message then return end
    t.message = nil
    t.detail = nil
    t.shown = false
end

t.updateWaitMessage = function()
    if not t.message or t.shown then return end

    t.shown = true

    theme.refresh() -- This view survives page changes and must pick up a saved theme.
    lvgl.clear();

    local s=rf2.executeScript("LVGL/studio",theme)
    -- Every progress state uses the same physical-screen center. Preserve
    -- deliberate line breaks and wrap long messages instead of truncating them.
    -- Measuring and building happen only when the message changes, never per frame.
    local function centeredLabel(value,font,color)
        local paragraphs,lines={},0
        local width=s.w-s.margin*2
        for paragraph in string.gmatch(value.."\n","(.-)\n") do
            local wrapped,count=theme.wrap(paragraph,width,font,s.scale)
            paragraphs[#paragraphs+1]=wrapped
            lines=lines+count
        end
        local label={type="label",x=s.margin,w=width,
            h=math.ceil(select(2,theme.textSize("Ag",font,s.scale))*lines),
            text=table.concat(paragraphs,"\n"),color=color,font=font,align=CENTER}
        s.children[#s.children+1]=label
        return label
    end
    local main=centeredLabel(t.message,MIDSIZE,theme.ink)
    local detail=t.detail and centeredLabel(t.detail,SMLSIZE,theme.muted)
    local gap=detail and (s.large and 12 or 8) or 0
    main.y=math.max(s.margin,math.floor((LCD_H-main.h-gap-(detail and detail.h or 0))/2-(LCD_H-s.h)))
    if detail then detail.y=main.y+main.h+gap end
    if t.message=="Loading Setup..." and not detail then
        -- A static opening illustration only. Ordinary page loads and saves
        -- stay text-only; unchanged wait frames never reload this image.
        local scale=math.min(s.w/800,LCD_H/480)
        local artH=math.floor(136*scale)
        local imageW,imageH=math.floor(512*scale),math.floor(87*scale)
        local gap=math.floor(24*scale)
        local y=math.floor((LCD_H-artH-gap-main.h)/2-(LCD_H-s.h))
        -- The PNG already has alpha; let the page show through around the logo.
        s.children[#s.children+1]={type="image",x=math.floor((s.w-imageW)/2),
            y=y+math.floor((artH-imageH)/2),w=imageW,h=imageH,
            file=rf2.baseDir.."IMAGES/"..(theme.lightBackground and "setup-light.png" or "setup.png"),fill=false}
        s.panel((s.w-52*scale)/2,y+artH+math.floor(11*scale),52*scale,math.max(2,3*scale),theme.accent)
        main.y=y+artH+gap
    end
    lvgl.build(theme.page("Rotorflight "..rf2.luaVersion,t.title or "",s.children,t.back))
end

return t
