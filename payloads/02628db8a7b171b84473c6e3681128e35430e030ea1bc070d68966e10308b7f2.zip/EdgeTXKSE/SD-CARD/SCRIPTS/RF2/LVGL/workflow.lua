local theme = rf2.executeScript("LVGL/precision")
local w = {}
local hangar=rf2.executeScript('F/hangarConfig').enabled() and rf2.executeScript('LVGL/hangarWorkflow')

-- Native scrolling pages keep long messages usable on 480px radios.
function w.show(title, lines, back, action)
    if hangar then return hangar.show(title,lines,back,action)end
    theme.refresh()
    local width, _, scale = theme.metrics()
    local margin = theme.round(12 * scale)
    local children, y = {}, margin
    for _, line in ipairs(lines) do
        local value = type(line) == "table" and line.text or line
        local color = type(line) == "table" and line.accent and theme.accent or theme.ink
        local text, count = theme.wrap(type(value) == "function" and value() or value, width - margin * 2, SMLSIZE, scale)
        local _, height = theme.textSize("Ag", SMLSIZE, scale)
        children[#children + 1] = {type = "label", x = margin, y = y,
            w = width - margin * 2, font = SMLSIZE, color = color,
            text = type(value) == "function" and value or text}
        y = y + count * height + margin
    end
    lvgl.clear()
    lvgl.build(theme.page("Rotorflight " .. rf2.luaVersion,
        rf2.executeScript("F/getLvglSubtitle", title), children, back, action))
end

function w.diagnostics(queue, back)
    local function d() return queue:diagnostics() end
    local lines = {
        {text = rf2.offlineSimulator and "OFFLINE PREVIEW - data and saves are simulated." or "Live FC connection", accent = true},
        {text = function() return "Waiting requests: " .. d().queued end},
        {text = function() local v = d(); return "Active MSP: " .. tostring(v.command or "none") .. "   Attempts: " .. v.attempts end},
        {text = function() return string.format("Current request: %.1f s", d().elapsed) end},
        {text = function() local v = d(); return "Replies: " .. v.replies .. "   Retries: " .. v.retries .. "   Failures: " .. v.failures end},
        {text = function() local v = d(); return v.lastLatency and string.format("Last MSP %d: %.0f ms", v.lastCommand, v.lastLatency * 1000) or "No completed requests yet." end},
        {text = function() return "Last error: " .. (d().lastError or "none") end},
        "These counters observe the shared queue. Opening this screen sends no requests.",
    }
    for _, line in ipairs(rf2.executeScript("F/diagnostics").lines()) do lines[#lines + 1] = line end
    w.show("Connection", lines, back)
end

function w.leave(count, keep, discard, save)
    if hangar then return hangar.leave(count,keep,discard,save)end
    local s=rf2.executeScript("LVGL/studio",theme)
    local x,width=48,s.w-96
    s.label(x,24,width,count.." unsaved change"..(count==1 and "" or "s"),theme.ink,MIDSIZE)
    local y=80
    for _,item in ipairs({{"Save & return",save},{"Discard & return",discard},{"Keep editing",keep}}) do
        s.button(x,y,width,56,item[1],item[2],item[1]=="Save & return")
        y=y+68
    end
    lvgl.clear()
    lvgl.build(theme.page("Rotorflight "..rf2.luaVersion,"Back to dashboard",s.children,keep))
end

return w
