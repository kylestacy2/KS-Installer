-- Main-rotor calibration uses mixer inputs, not MSP_MIXER_CONFIG.
-- UI pitch values are tenths of a degree; the wire uses 1000 units per 12 deg.
local axes = {1, 2, 4} -- stabilized roll, pitch, collective (zero-based on wire)
local keys = {'cyclic_calibration', 'collective_calibration', 'cyclic_pitch_limit', 'collective_pitch_limit'}

local function getDefaults()
    return {
        cyclic_calibration = {min=250, max=1000, scale=10, unit=rf2.units.percentage},
        collective_calibration = {min=250, max=1000, scale=10, unit=rf2.units.percentage},
        cyclic_pitch_limit = {min=0, max=200, scale=10, unit=rf2.units.degrees},
        collective_pitch_limit = {min=0, max=200, scale=10, unit=rf2.units.degrees},
    }
end

local function decode(message, buf)
    if #buf < 30 or #buf % 6 ~= 0 then
        rf2.mspQueue:reject(message, 'Incomplete mixer inputs. Reload before saving.')
        return
    end
    local raw = {}
    for _, index in ipairs(axes) do
        buf.offset = index * 6 + 1
        raw[index] = {rate=rf2.mspHelper.readS16(buf), min=rf2.mspHelper.readS16(buf), max=rf2.mspHelper.readS16(buf)}
    end
    return raw
end

local function read(callback, callbackParam, data)
    data = data or getDefaults()
    rf2.mspQueue:add({command=170, processReply=function(message, buf)
        local raw = decode(message, buf)
        if not raw then return end
        local roll, pitch, coll = raw[1], raw[2], raw[4]
        data.cyclic_calibration.value = math.abs(roll.rate)
        data.collective_calibration.value = math.abs(coll.rate)
        data.cyclic_pitch_limit.value = math.floor(pitch.max * 12 / 100 + 0.5)
        data.collective_pitch_limit.value = math.floor(coll.max * 12 / 100 + 0.5)
        -- A single tile cannot faithfully represent differing cyclic scales or
        -- asymmetric endpoints. Keep those controls read-only, as Configurator
        -- does for custom mixers, while preserving their exact wire values.
        data.cyclic_calibration.locked = math.abs(roll.rate) ~= math.abs(pitch.rate)
        data.collective_calibration.locked = false
        data.cyclic_pitch_limit.locked = roll.max ~= pitch.max or roll.min ~= -roll.max or pitch.min ~= -pitch.max
        data.collective_pitch_limit.locked = coll.min ~= -coll.max
        data.baseline = {}
        for _, key in ipairs(keys) do
            local field = data[key]
            field.locked = field.locked or field.value < field.min or field.value > field.max
            data.baseline[key] = field.value
        end
        data.raw = raw
        callback(callbackParam, data)
    end})
end

local function write(data, callback)
    assert(data.raw and data.baseline, 'Mixer inputs have not loaded')
    -- Validate the whole draft before queuing anything. Unedited custom values
    -- are preserved, even if they are outside the standard editor's range.
    local changed = {}
    for _, key in ipairs(keys) do
        local field = data[key]
        changed[key] = field.value ~= data.baseline[key]
        if changed[key] then
            assert(not field.locked, 'Custom mixer input requires Configurator')
            assert(type(field.value)=='number' and field.value%1==0 and field.value>=field.min and field.value<=field.max, 'Invalid mixer input')
        end
    end
    local expected = {}
    for _, index in ipairs(axes) do
        local calibration = index==4 and 'collective_calibration' or 'cyclic_calibration'
        local limit = index==4 and 'collective_pitch_limit' or 'cyclic_pitch_limit'
        if changed[calibration] or changed[limit] then
            local original = data.raw[index]
            local value = {rate=original.rate, min=original.min, max=original.max}
            if changed[calibration] then value.rate = data[calibration].value * (original.rate<0 and -1 or 1) end
            if changed[limit] then
                value.max = math.floor(data[limit].value * 100 / 12 + 0.5)
                value.min = -value.max
            end
            expected[index] = value
        end
    end
    if not next(expected) then callback(); return end
    for _, index in ipairs(axes) do
        local value = expected[index]
        if value then
            local payload = {index}
            rf2.mspHelper.writeU16(payload, value.rate)
            rf2.mspHelper.writeU16(payload, value.min)
            rf2.mspHelper.writeU16(payload, value.max)
            rf2.mspQueue:add({command=171, payload=payload})
        end
    end
    -- Check the complete signed records before allowing the EEPROM request.
    -- A rejected write cancels this owned operation through the shared queue.
    rf2.mspQueue:add({command=170, processReply=function(message, buf)
        local actual = decode(message, buf)
        if not actual then return end
        for index, value in pairs(expected) do
            local got = actual[index]
            if got.rate~=value.rate or got.min~=value.min or got.max~=value.max then
                rf2.mspQueue:reject(message, 'Mixer input readback differs. Reload before saving.')
                return
            end
        end
        callback()
    end})
end

return {getDefaults=getDefaults, read=read, write=write}
