-- MspQueueController class
local MspQueueController = {}
MspQueueController.__index = MspQueueController
local writeSafety = rf2.executeScript("F/writeSafety")

local mspSendRequest, mspProcessTxQ, mspPollReply, mspClearRxTxBufs, mspAbortTx
local simulator
if rf2.offlineSimulator then
    simulator = rf2.executeScript("MSP/simulator")
else
    mspSendRequest, mspProcessTxQ, mspPollReply, mspClearRxTxBufs, mspAbortTx = rf2.executeScript("MSP/common")
end

function MspQueueController.new()
    local self = setmetatable({}, MspQueueController)
    self.messageQueue = {}
    self.currentMessage = nil
    self.lastTimeCommandSent = nil
    self.retryCount = 0
    self.maxRetries = -1 -- retry indefinitely
    -- Reads retain the upstream retry policy. Owned operations and battery
    -- profile transactions have bounded deadlines and cancellation.
    self.stats = { replies = 0, retries = 0, failures = 0 }
    return self
end

function MspQueueController:withOwner(owner, callback, ...)
    local previous = self.ownerContext
    self.ownerContext = owner
    local ok, result = pcall(callback, ...)
    self.ownerContext = previous
    if not ok then error(result) end
    return result
end

function MspQueueController:isOwnerProcessed(owner)
    if self.currentMessage and self.currentMessage._rf2Owner == owner then return false end
    for _, message in ipairs(self.messageQueue) do
        if message._rf2Owner == owner then return false end
    end
    return true
end

function MspQueueController:cancelOwner(owner)
    if not owner then return end
    owner.cancelled = true
    for i = #self.messageQueue, 1, -1 do
        if self.messageQueue[i]._rf2Owner == owner then table.remove(self.messageQueue, i) end
    end
    -- Stop unsent fragments immediately, retaining RX to drain a possible reply.
    -- Only the active request owns transport buffers; preserve other consumers.
    if self.currentMessage and self.currentMessage._rf2Owner == owner and mspAbortTx then
        mspAbortTx()
    end
end

function MspQueueController:failOwned(message, reason)
    local owner = message._rf2Owner
    if not owner or owner.cancelled then return end
    self:cancelOwner(owner)
    owner.failed = reason
    if owner.onError then owner.onError(reason, message.command) end
end

function MspQueueController:checkWriteSafety(proof)
    return writeSafety.check(proof)
end

local function supportsDeferredSave(message)
    return message.command == 250 and message.deferOnDisarm == true
        and type(message.processDeferredReply) == "function"
        and (rf2.apiVersion or 0) >= 12.08 and not message._rf2ProfileGroup
end

function MspQueueController:confirmDeferredSave(message)
    -- RF API 12.08+ marks configuration dirty when MSP 250 is rejected while
    -- armed. The FC saves it on disarm, even if this Lua tool has been closed.
    -- Confirm the armed state before interpreting a NACK as that outcome.
    local check = {message=message, started=rf2.clock()}
    local status = {command=101, _rf2Owner=message._rf2Owner, _rf2DeferredCheck=check,
        processReply=function(probe, buf)
            if writeSafety.armed(buf) ~= true then
                self:reject(probe, "EEPROM rejected; deferred save not confirmed.")
                return
            end
            message:processDeferredReply()
        end}
    self.currentMessage, self.lastTimeCommandSent = nil, nil
    table.insert(self.messageQueue,1,status)
end

function MspQueueController:prepareWrite(message, proofStore)
    message._rf2SafetyBegan = message._rf2SafetyBegan or rf2.clock()
    local check = {message=message, started=message._rf2SafetyBegan, proof={}}
    message._rf2SafetyCheck = check
    local function request(command, validate)
        return {command=command, _rf2Owner=message._rf2Owner,
            _rf2ProfileGroup=message._rf2ProfileGroup, _rf2SafetyProbe=check,
            processReply=function(probe, buf)
                local safe, reason = validate(buf, check.proof)
                if not safe then self:reject(probe, reason); return end
                if check.proof.checkedAt then proofStore._rf2WriteProof=check.proof end
            end}
    end
    -- Use the same queue/transport. Neither a second frame consumer nor a
    -- callback from a widget can turn a missing safety reply into a write.
    self.currentMessage, self.lastTimeCommandSent = nil, nil
    table.insert(self.messageQueue,1,message)
    table.insert(self.messageQueue,1,request(139,writeSafety.motors))
    table.insert(self.messageQueue,1,request(101,writeSafety.status))
end

-- Legacy consumers submit 176 -> 175 -> 250 without an owner. Recognize that
-- exact adjacent sequence before sending it, preserving its original messages
-- and callbacks. Never claim unrelated traffic merely because it is unowned.
function MspQueueController:protectProfileSelection(message)
    local group = {target = message.payload and message.payload[1], started = rf2.clock()}
    message._rf2ProfileGroup = group
    local verify, save = self.messageQueue[1], self.messageQueue[2]
    if verify and save and verify.command == 175 and save.command == 250
        and verify._rf2Owner == message._rf2Owner and save._rf2Owner == message._rf2Owner then
        verify._rf2ProfileGroup, save._rf2ProfileGroup = group, group
    end
end

function MspQueueController:reject(message, reason)
    if message._rf2DeferredCheck then message = message._rf2DeferredCheck.message end
    local check = message._rf2SafetyProbe or message._rf2SafetyCheck
    if check then
        for i = #self.messageQueue, 1, -1 do
            local queued = self.messageQueue[i]
            if queued == check.message or queued._rf2SafetyProbe == check then table.remove(self.messageQueue,i) end
        end
        message = check.message
    end
    local group = message._rf2ProfileGroup
    if group then
        group.failed = true
        for i = #self.messageQueue, 1, -1 do
            if self.messageQueue[i]._rf2ProfileGroup == group then table.remove(self.messageQueue, i) end
        end
    end
    self.currentMessage, self.lastTimeCommandSent = nil, nil
    if mspClearRxTxBufs then mspClearRxTxBufs() end
    self.stats.failures = self.stats.failures + 1
    self.stats.lastError = reason
    if message._rf2Owner then self:failOwned(message, reason)
    elseif message.errorHandler then pcall(message.errorHandler, message) end
end

function MspQueueController:diagnostics()
    local message = self.currentMessage
    return {
        queued = #self.messageQueue,
        command = message and message.command,
        elapsed = message and self.requestStarted and (rf2.clock() - self.requestStarted) or 0,
        attempts = message and self.retryCount or 0,
        replies = self.stats.replies, retries = self.stats.retries, failures = self.stats.failures,
        lastCommand = self.stats.lastCommand, lastLatency = self.stats.lastLatency,
        simulated = simulator ~= nil,
        lastError = self.stats.lastError,
    }
end

function MspQueueController:isProcessed()
    return not self.currentMessage and #self.messageQueue == 0
end

--[[
local function joinTableItems(table, delimiter)
    if table == nil or #table == 0 then return "" end
    delimiter = delimiter or ""
    local result = table[1]
    for i = 2, #table do
        result = result .. delimiter .. table[i]
    end
    return result
end
--]]

local function popFirstElement(tbl)
    if tbl == nil or #tbl == 0 then return nil end
    local firstElement = tbl[1]

    for i = 1, #tbl - 1 do
        tbl[i] = tbl[i + 1]
    end
    tbl[#tbl] = nil

    return firstElement
end

function MspQueueController:processQueue()
    if self.retired then return end
    if self:isProcessed() then
        return
    end

    if not self.currentMessage then
        self.currentMessage = popFirstElement(self.messageQueue)
        self.retryCount = 0
        self.requestStarted = rf2.clock()
        if self.currentMessage.command == 176 and not self.currentMessage._rf2ProfileGroup then
            self:protectProfileSelection(self.currentMessage)
        end
    end

    local message = self.currentMessage
    local owner = message._rf2Owner
    if owner and owner.cancelled then
        -- A command already received by the FC cannot be undone. Never retry
        -- it or finish an unsent payload after its caller has cancelled.
        if self.lastTimeCommandSent and not message.buf and not simulator and not rf2.runningInSimulator then
            local timeout = (owner.timeout or 12) + (message.retryDelay or 0) + (message.postSendDelay or 0)
            if rf2.clock() - self.requestStarted > timeout then
                if mspClearRxTxBufs then mspClearRxTxBufs() end
            elseif mspPollReply() ~= message.command then
                return
            end
        end
        self.currentMessage, self.lastTimeCommandSent = nil, nil
        return
    end
    if message._rf2DeferredCheck and rf2.clock() - message._rf2DeferredCheck.started > 6 then
        self:reject(message, "No FC status reply; deferred save not confirmed.")
        return
    end
    if message._rf2SafetyProbe and rf2.clock() - message._rf2SafetyProbe.started > 6 then
        self:reject(message, "No fresh FC safety reply. Write cancelled.")
        return
    end
    local group = message._rf2ProfileGroup
    if group then
        if group.failed or (owner and owner.cancelled) or rf2.clock() - group.started > 18 then
            self:reject(message, "Battery profile transaction cancelled or timed out.")
            return
        end
        if type(group.target) ~= "number" or group.target ~= math.floor(group.target)
            or group.target < 0 or group.target > 5 then
            self:reject(message, "Invalid battery profile selection.")
            return
        end
        if message.command == 250 and not group.verified then
            self:reject(message, "Battery profile was not verified. Save cancelled.")
            return
        end
    end
    if message.command == 176 or (message.command == 250 and not supportsDeferredSave(message)) then
        -- Battery-profile and legacy commits need fresh disarmed/RPM proof.
        -- RF UI saves opt into the firmware's separate save-on-disarm path.
        local proofStore = message.command == 250 and message or group or owner or message
        local safe, reason, needsProof = writeSafety.check(proofStore._rf2WriteProof)
        if not safe then
            if needsProof and self.retryCount == 0 then self:prepareWrite(message,proofStore)
            else self:reject(message, reason) end
            return
        end
    end
    local timeout = owner and owner.timeout
    if timeout and rf2.clock() - self.requestStarted > timeout + (message.retryDelay or 0) + (message.postSendDelay or 0) then
        self:reject(message, "No reply received")
        return
    end

    if self.currentMessage.postSendDelay and self.currentMessage.buf then
        if self.lastTimeCommandSent + self.currentMessage.postSendDelay > rf2.clock() then
            -- Use postSendDelay to wait a bit before handling the response.
            -- Useful when waiting on asynchronous tasks such as writing ESC parameters.
            return
        end
        self:handleReply()
        return
    end

    local cmd, buf, err
    --rf2.print("retryCount: "..self.retryCount)

    local retryDelay = 0.8 + (self.currentMessage.retryDelay or 0)
    if simulator then
        self.lastTimeCommandSent = rf2.clock()
        cmd = self.currentMessage.command
        buf = simulator.reply(self.currentMessage)
    elseif not rf2.runningInSimulator then
        if not self.lastTimeCommandSent or (self.lastTimeCommandSent + retryDelay < rf2.clock()) then
            if self.currentMessage.payload then
                --rf2.print("Sending  cmd "..self.currentMessage.command..": {" .. joinTableItems(self.currentMessage.payload, ", ") .. "}")
                mspSendRequest(self.currentMessage.command, self.currentMessage.payload)
            else
                --rf2.print("Sending  cmd "..self.currentMessage.command)
                mspSendRequest(self.currentMessage.command, {})
            end
            self.lastTimeCommandSent = rf2.clock()
            self.retryCount = self.retryCount + 1
            if self.retryCount > 1 then self.stats.retries = self.stats.retries + 1 end
        end

        mspProcessTxQ()
        cmd, buf, err = mspPollReply()
    end

    --if cmd then
    --    rf2.print("Received cmd: "..tostring(cmd))
    --end
    --if err then
    --    rf2.print("  ERROR flag set!")
    --end

    --if cmd == 217 then   -- MSP_ESC_PARAMETERS
    --     buf = self.currentMessage.simulatorResponse
    --     err = nil
    --end

    if (cmd == self.currentMessage.command and not err) or (self.currentMessage.command == 68 and self.retryCount == 2) then -- 68 = MSP_REBOOT
        --rf2.print("Received cmd "..self.currentMessage.command..": {" .. joinTableItems(buf, ", ") .. "}")
        self.currentMessage.buf = buf
        if self.currentMessage.postSendDelay then return end
        self:handleReply()
    elseif (err and not self.currentMessage.ignoreErrors) or (self.maxRetries >= 0 and self.retryCount > self.maxRetries) then
        --rf2.print("Error or max retries reached, aborting cmd "..self.currentMessage.command)
        if err and cmd == message.command and supportsDeferredSave(message)
            and not (owner and owner.cancelled) then
            self:confirmDeferredSave(message)
        else
            self:reject(message, "Request rejected")
        end
        collectgarbage()
    end
end

function MspQueueController:handleReply()
    if self.retired then return end
    local message = self.currentMessage
    local owner = message._rf2Owner
    local group = message._rf2ProfileGroup
    if group and message.command == 175 then
        if not group.setAck or type(message.buf) ~= "table" or message.buf[1] ~= group.target then
            self:reject(message, "FC battery profile does not match. Save cancelled.")
            return
        end
        group.verified = true
    elseif group and message.command == 176 then
        group.setAck = true
    end
    self.stats.replies = self.stats.replies + 1
    self.stats.lastCommand = message.command
    self.stats.lastLatency = rf2.clock() - self.requestStarted
    if message.processReply and not (owner and owner.cancelled) then
        local ok = pcall(self.withOwner, self, owner, message.processReply, message, message.buf)
        if not ok then
            self:reject(message, "Could not read reply")
            return
        end
    end
    self.currentMessage = nil
    self.lastTimeCommandSent = nil
    -- A normal reply retires one message, not the whole UI. Advance GC with
    -- the same step size as EdgeTX's widget loop instead of a full heap walk.
    -- Explicit queue teardown and error recovery still collect fully.
    collectgarbage("step", 10)
end

function MspQueueController:clear()
    --rf2.print("Clearing MSP queue")
    self.messageQueue = {}
    self.currentMessage = nil
    self.lastTimeCommandSent = nil
    if mspClearRxTxBufs then mspClearRxTxBufs() end
    collectgarbage()
end

-- Model retirement is permanent. References held by an old page/consumer
-- cannot enqueue or transmit against the next model's global RF core.
function MspQueueController:retire()
    if self.retired then return end
    self.retired = true
    if self.currentMessage and self.currentMessage._rf2Owner then
        self.currentMessage._rf2Owner.cancelled = true
    end
    for _, message in ipairs(self.messageQueue) do
        if message._rf2Owner then message._rf2Owner.cancelled = true end
    end
    if mspAbortTx then mspAbortTx() end
    self:clear()
    self.ownerContext = nil
end

local function deepCopy(original)
    local copy
    if type(original) == "table" then
        copy = {}
        for key, value in next, original, nil do
            copy[deepCopy(key)] = deepCopy(value)
        end
        setmetatable(copy, deepCopy(getmetatable(original)))
    else -- number, string, boolean, etc
        copy = original
    end
    return copy
end

function MspQueueController:add(message, copy)
    if self.retired then return self end
    if copy then message = deepCopy(message) end
    local owner = self.ownerContext
    if owner and owner.cancelled then return self end
    message._rf2Owner = owner
    --rf2.print("Queueing command "..message.command.." at position "..#self.messageQueue + 1)
    self.messageQueue[#self.messageQueue + 1] =  message
    return self
end

return MspQueueController.new()

--[[ Usage example

local myMspMessage =
{
    command = 111,
    processReply = function(self, buf)
        print("Do something with the response buffer")
    end,
    
}

local anotherMspMessage =
{
    command = 123,
    processReply = function(self, buf)
        print("Received response for command "..tostring(self.command).." with length "..tostring(#buf))
    end,
    
}

local myMspQueue = MspQueueController.new()
myMspQueue
  :add(myMspMessage)
  :add(anotherMspMessage)

while not myMspQueue:isProcessed() do
    myMspQueue:processQueue()
end
--]]
