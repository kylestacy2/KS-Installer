-- Temporary offline preview controller for radios and Companion. No RF transport.
assert(rf2.offlineSimulator, "Offline preview only")
local samples = rf2.executeScript("MSP/simulatorData")
local saved = {}
local pid, rate, battery = 0, 0, 0
local writeMap = {
    [11]=10, [13]=12, [15]=14, [33]=32, [43]=42, [93]=92, [95]=94,
    [143]=142, [147]=146, [149]=148, [159]=158, [202]=112, [204]=111,
    [216]=123, [239]=240, [16385]=16384
}
local profileCommands = { [112]=true, [94]=true, [146]=true, [148]=true }

local function copy(bytes)
    local result = {}
    for i, value in ipairs(bytes) do result[i] = value end
    return result
end

local function key(command)
    if command == 217 then return rf2.simulatorPage end
    local profile = profileCommands[command] and pid or command == 111 and rate or 0
    return command .. ":" .. profile
end

local function reply(message)
    local command, payload = message.command, message.payload
    if payload then
        -- Platinum V5 writes carry the full header and sixteen item bytes.
        -- Retain them for the normal save/readback workflow in offline tests.
        if command == 218 and rf2.simulatorPage == 'esc_hwpl5' and payload[1] == 253 then
            saved[key(217)] = copy(payload)
        end
        if writeMap[command] then saved[key(writeMap[command])] = copy(payload) end
        if command == 210 then
            if payload[1] >= 128 then rate = payload[1] - 128 else pid = payload[1] end
        elseif command == 176 then
            battery = payload[1]
        elseif command == 212 and saved[key(120)] then
            local servos = saved[key(120)]
            for i = 2, #payload do servos[payload[1] * 16 + i] = payload[i] end
        elseif command == 171 then
            local inputs = saved[key(170)] or copy(samples[170])
            assert(#payload==7 and payload[1]>=0 and payload[1]<#inputs/6, 'Invalid preview mixer input')
            for i = 2, 7 do inputs[payload[1]*6+i-1] = payload[i] end
            saved[key(170)] = inputs
        elseif command == 183 then
            local group = payload[1] == 0 and {112, 94, 146, 148} or {111}
            for _, cmd in ipairs(group) do
                local source = saved[cmd .. ":" .. payload[3]] or samples[cmd]
                if source then saved[cmd .. ":" .. payload[2]] = copy(source) end
            end
        end
    end

    local sampleKey = command == 217 and rf2.simulatorPage or command
    local response = saved[key(command)] or samples[sampleKey] or message.simulatorResponse
    if response then
        -- Cache embedded examples too; profile copies must retain unedited defaults.
        if not samples[sampleKey] then samples[sampleKey] = copy(response) end
        response = copy(response)
        if command == 101 then response[24], response[26] = pid, rate end
        if command == 175 then response[1] = battery end
        if command == 120 then saved[key(command)] = copy(response) end
        return response
    end
    -- These actions acknowledge only in memory.
    if payload or command == 250 or command == 68 or command == 72 or command == 205 then
        return {}
    end
    error("No offline sample for MSP " .. tostring(command))
end

return { reply = reply }
