return rf2.executeScript("PAGES/helpers/rates", true)
