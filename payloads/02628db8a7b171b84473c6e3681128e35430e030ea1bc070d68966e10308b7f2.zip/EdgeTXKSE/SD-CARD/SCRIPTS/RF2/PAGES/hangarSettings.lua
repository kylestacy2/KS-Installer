local config=rf2.executeScript('F/hangarConfig')
local catalog=rf2.executeScript('LVGL/Hangar/catalog')
local fields={}
local function choice(names)
 local t={};for i,name in ipairs(names)do t[i-1]=name end;return t
end
for _,o in ipairs(config.options)do fields[#fields+1]={t=o.title,x=0,y=#fields*40,data={min=0,max=#o.names-1,table=choice(o.names)}} end
for _,axis in ipairs({'Roll','Pitch','Yaw'})do fields[#fields+1]={t=axis..' slider maximum',x=0,y=#fields*40,data={min=10,max=1000,mult=5,unit='°/s'}} end
local names={};for _,id in ipairs(config.pageIds)do names[#names+1]=catalog[id][1]end
for i=1,5 do fields[#fields+1]={t='Home tile '..i,x=0,y=#fields*40,data={min=0,max=#names-1,table=choice(names)}}end
for _,title in ipairs({'P','I','D','Feedforward (FF)','Boost (B)'})do fields[#fields+1]={t=title..' maximum',x=0,y=#fields*40,data={min=0,max=1000}}end
local page={title='Settings',fields=fields,labels={},hangarSettings=true}
local loadedSettings
page.read=function(self)
 -- Retain the dirty-tracked snapshot for editing. saveSettings merges changed
 -- keys with a fresh disk read, so reloading here again during Save is wasteful.
 loadedSettings=rf2.loadSettings()
 local p=config.normalize(loadedSettings)
 rf2.hangarPreferences=p
 for i,o in ipairs(config.options)do for k,v in ipairs(o.values)do if p[o.key]==v then fields[i].data.value=k-1 end end end
 for i,axis in ipairs({'roll','pitch','yaw'})do fields[8+i].data.value=p.rateSliderMax[axis] end
 for i,id in ipairs(p.homePages)do for k,key in ipairs(config.pageIds)do if key==id then fields[11+i].data.value=k-1 end end end
 for i,key in ipairs(config.pidGainKeys)do fields[16+i].data.value=p.pidGainMax[key]end
 rf2.onPageReady(self)
end
page.write=function(self)
 local settings=assert(loadedSettings,'Settings have not loaded')
 local p={version=1,homePages={},rateSliderMax={},pidGainMax={},lastPage=config.get().lastPage}
 local seen={}
 for i,o in ipairs(config.options)do p[o.key]=assert(o.values[fields[i].data.value+1])end
 for i,axis in ipairs({'roll','pitch','yaw'})do p.rateSliderMax[axis]=fields[8+i].data.value end
 for i,key in ipairs(config.pidGainKeys)do
  local v=fields[16+i].data.value
  assert(type(v)=='number' and v>=0 and v<=1000 and v%1==0,'Invalid PID gain maximum')
  p.pidGainMax[key]=v
 end
 for i=1,5 do
  local id=assert(config.pageIds[fields[11+i].data.value+1])
  assert(not seen[id],'Choose five different home pages');seen[id]=true;p.homePages[i]=id
 end
 local restart=settings.useAdjustmentTeller~=(p.adjustmentVoice=='on' and 1 or 0)
 settings.hangar=p
 settings.useAdjustmentTeller=p.adjustmentVoice=='on' and 1 or 0
 if not rf2.saveSettings(settings) then return end
 config.invalidate()
 if restart then rf2.executeScript('F/pilotConfigReset')() end
 -- Hangar always lists all supported pages. Preferences only change the live
 -- home/theme/editor state, so rebuilding pages here repeats SD reads inside
 -- the save callback and can exhaust its CPU budget after a successful write.
 rf2.settingsSaved(false,false)
end
return page
