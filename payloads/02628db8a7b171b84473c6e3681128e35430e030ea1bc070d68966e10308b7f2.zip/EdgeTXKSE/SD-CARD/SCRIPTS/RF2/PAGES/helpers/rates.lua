-- Rates exposes all four axes over one RC tuning payload. The legacy single-axis
-- entry point remains compatible with callers outside the main menu.
local collectiveOnly = ...
--rf2.showMemoryUsage(">>>>> PAGE LOAD <<<<<<")
local template = rf2.executeScript(rf2.radio.template)
--rf2.showMemoryUsage("after template")
local mspStatus = rf2.useApi("mspStatus")
--rf2.showMemoryUsage("after mspStatus")
local margin = template.margin
local indent = template.indent
local lineSpacing = template.lineSpacing
local tableSpacing = template.tableSpacing
local sp = template.listSpacing.field
template = nil
local yMinLim = rf2.radio.yMinLimit
local x = margin
local y = yMinLim - lineSpacing
local function incY(val) y = y + val return y end
local labels = {}
local fields = {}
local rcTuning = rf2.useApi("mspRcTuning").getDefaults()
--rf2.showMemoryUsage("after getDefaults")
collectgarbage()
local editing = false
local profileAdjustmentTS = nil

local startEditing = function(field, page)
    editing = true
end

local endRateEditing = function(field, page)
    rf2.useApi("mspSetProfile").setRateProfile(field.data.value, function() rf2.reloadPage() end, nil)
end

local function copyProfile(field, page)
    local source = page.rateFields[14].data.value
    local dest = page.rateFields[15].data.value
    if source == dest then return end

    local mspCopyProfile = {
        command = 183, -- MSP_COPY_PROFILE
        payload = { 1, dest, source } -- 1 = copy rates
    }

    rf2.mspQueue:add(mspCopyProfile)
    rf2.settingsSaved(true, false)
end

local function buildForm()
    --rf2.showMemoryUsage("before buildform")
    local tableStartY = yMinLim - lineSpacing
    y = tableStartY
    labels = {}
    fields = {}

    labels[#labels + 1] = { t = "",      x = x, y = incY(tableSpacing.header) }
    labels[#labels + 1] = { t = "",      x = x, y = incY(tableSpacing.header) }
    labels[#labels + 1] = { t = "Roll",  x = x, y = incY(tableSpacing.row) }
    labels[#labels + 1] = { t = "Pitch", x = x, y = incY(tableSpacing.row) }
    labels[#labels + 1] = { t = "Yaw",   x = x, y = incY(tableSpacing.row) }
    labels[#labels + 1] = { t = "Coll",  x = x, y = incY(tableSpacing.row) }

    x = x + tableSpacing.col
    y = tableStartY
    labels[#labels + 1] = { t = rcTuning.columnHeaders[1], x = x, y = incY(tableSpacing.header) }
    labels[#labels + 1] = { t = rcTuning.columnHeaders[2], x = x, y = incY(tableSpacing.header) }
    fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), data = rcTuning[0] }
    fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), data = rcTuning[3] }
    fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), data = rcTuning[6] }
    fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), data = rcTuning[9] }

    x = x + tableSpacing.col
    y = tableStartY
    labels[#labels + 1] = { t = rcTuning.columnHeaders[3], x = x, y = incY(tableSpacing.header) }
    labels[#labels + 1] = { t = rcTuning.columnHeaders[4], x = x, y = incY(tableSpacing.header) }
    fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), data = rcTuning[2] }
    fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), data = rcTuning[5] }
    fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), data = rcTuning[8] }
    fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), data = rcTuning[11] }

    x = x + tableSpacing.col
    y = tableStartY
    labels[#labels + 1] = { t = rcTuning.columnHeaders[5], x = x, y = incY(tableSpacing.header) }
    labels[#labels + 1] = { t = rcTuning.columnHeaders[6], x = x, y = incY(tableSpacing.header) }
    fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), data = rcTuning[1] }
    fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), data = rcTuning[4] }
    fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), data = rcTuning[7] }
    fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), data = rcTuning[10] }

    x = margin
    incY(lineSpacing * 0.5)
    fields[13] = { t = "Rates type",     x = x, y = incY(lineSpacing), sp = x + sp, data = rcTuning.rates_type, postEdit = function(self, page) page.updateRatesType(page) end }

    incY(lineSpacing * 0.5)
    fields[14] = { t = "Current rate profile",            x = x,          y = incY(lineSpacing), sp = x + sp * 1.17, data = { min = 0, max = 5, value = rcTuning.currentRateProfile, table = { [0] = "1", "2", "3", "4", "5", "6" } }, preEdit = startEditing, postEdit = endRateEditing }
    fields[15] = { t = "Destination profile",             x = x,          y = incY(lineSpacing), sp = x + sp * 1.17, data = { min = 0, max = 5, value = rcTuning.destRateProfile, table = { [0] = "1", "2", "3", "4", "5", "6" } } }
    fields[#fields + 1] = { t = "[Copy Current to Dest]", x = x + indent, y = incY(lineSpacing), preEdit = copyProfile }

    if rf2.apiVersion >= 12.09 then
        incY(lineSpacing * 0.5)
        fields[#fields + 1] = { t = "Cyclic ring",       x = x, y = incY(lineSpacing), sp = x + sp, data = rcTuning[31] }
        fields[#fields + 1] = { t = "Polar coordinates", x = x, y = incY(lineSpacing), sp = x + sp, data = rcTuning[32] }
    end

    if LCD_W >= 800 then
        -- Touch layout: start the stacked profiles at the table heading row.
        -- Keep the original field order and LCD positions for rotary navigation.
        local profileX = margin * 2 + tableSpacing.col * 4
        fields[14].lvglPosition = { x = profileX, y = fields[1].y, labelY = labels[8].y + 3 }
        fields[15].lvglPosition = { x = profileX, y = fields[3].y, labelY = labels[4].y + 3 }
        local footerValueX = margin + tableSpacing.col + indent
        local bottomY = fields[13].y
        if rf2.apiVersion >= 12.09 then
            -- Two compact footer rows keep the added settings on the same screen.
            bottomY = fields[4].y + lineSpacing
            fields[17].lvglPosition = { x = margin, sp = footerValueX, y = bottomY + lineSpacing }
            fields[18].lvglPosition = { x = profileX, sp = profileX + 120, y = bottomY + lineSpacing, w = 50 }
        end
        fields[13].lvglPosition = { sp = footerValueX, y = bottomY }
        fields[16].lvglPosition = { x = profileX, y = bottomY }

        -- Rotorflight/Raceflight use one heading line. Remove their unused top
        -- row while retaining a small inset and the existing table spacing.
        if rcTuning.columnHeaders[1] == "" and rcTuning.columnHeaders[3] == "" and rcTuning.columnHeaders[5] == "" then
            local tableLift = labels[8].y - (yMinLim - 1)
            for _, label in ipairs(labels) do
                if label.t ~= "" then label.lvglPosition = { y = label.y - tableLift } end
            end
            for _, field in ipairs(fields) do
                local position = field.lvglPosition or {}
                position.y = (position.y or field.y) - tableLift
                if position.labelY then position.labelY = position.labelY - tableLift end
                field.lvglPosition = position
            end
        end
    end
    --rf2.showMemoryUsage("after buildform")
end

buildForm()

local function configurePage(page)
    page.rateFields, page.rateLabels = fields, labels
    page.fields, page.labels = {}, {}
    page.rateFieldIndices, page.rateFieldOrder = {}, {}
    local order = collectiveOnly and {4, 8, 12, 14} or {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18}
    for _, index in ipairs(order) do
        if fields[index] then
            local visible = #page.fields + 1
            page.fields[visible] = fields[index]
            page.rateFieldIndices[index], page.rateFieldOrder[visible] = visible, index
        end
    end
    for index, label in ipairs(labels) do
        if index < 3 or index > 6 or (collectiveOnly and index == 6) or not collectiveOnly then
            page.labels[#page.labels + 1] = label
        end
    end
    if collectiveOnly then
        -- The LCD frontend gets the same three columns, on a single axis row.
        for _, index in ipairs({4, 8, 12}) do fields[index].y = fields[1].y end
        labels[6].y = labels[3].y
        fields[14].y = fields[1].y + lineSpacing * 2
    end
end

local function rebuildForm(page)
    labels = nil
    fields = nil
    page.labels = nil
    page.fields = nil
    collectgarbage()
    buildForm()
    configurePage(page)
end

local function receivedRcTuning(page)
    rebuildForm(page)
    rf2.onPageReady(page)
end

local page = {
    read = function(self)
        mspStatus.getStatus(self.onProcessedMspStatus, self)
        rf2.useApi("mspRcTuning").read(receivedRcTuning, self, rcTuning)
    end,
    write = function(self)
        if rcTuning.rates_type.value then
            rf2.useApi("mspRcTuning").write(rcTuning)
            rf2.settingsSaved(true, false)
        end
    end,
    title       = collectiveOnly and "Collective Pitch" or "Rates",
    collectiveOnly = collectiveOnly == true,

    updateRatesType = function(self, applyDefaults)
        rf2.useApi("mspRcTuning").getRateDefaults(rcTuning, rcTuning.rates_type.value)
        rebuildForm(self)
        rf2.onPageReady(self)
    end,

    timer = function(self)
        if profileAdjustmentTS and rf2.clock() - profileAdjustmentTS > 0.35 then
            rf2.reloadPage()
        elseif rf2.mspQueue:isProcessed() and not editing then
            mspStatus.getStatus(self.onProcessedMspStatus, self)
        end
    end,

    onProcessedMspStatus = function(self, status)
        local currentField = self.rateFields[14]
        if currentField.data.value ~= status.rateProfile and not editing then
            if currentField.data.value then
                profileAdjustmentTS = rf2.clock()
            end
            currentField.data.value = status.rateProfile
            rcTuning.currentRateProfile = status.rateProfile
        end
        local destField = self.rateFields[15]
        if not destField.data.value then
            if status.rateProfile < 5 then
                destField.data.value = status.rateProfile + 1
            else
                destField.data.value = 4
            end
            rcTuning.destRateProfile = destField.data.value
        end

        self.isReady = true
    end,
}

configurePage(page)
return page
