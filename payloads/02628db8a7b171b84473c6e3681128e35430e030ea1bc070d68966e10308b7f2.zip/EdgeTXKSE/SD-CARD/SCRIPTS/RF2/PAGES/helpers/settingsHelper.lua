local filename = rf2.baseDir .. "settings.lua"
local backup = rf2.baseDir .. "settings_backup.lua"
local pending = rf2.baseDir .. "settings_pending.lua"

local function report(message)
    rf2.executeScript("F/diagnostics").report("settings", message, "preferences")
    return false, message
end

local function addDirtyTrackingToTable(originalTable)
    local proxy, changes = {}, {}
    function proxy:resetDirtyFlag() changes = {} end
    function proxy:isDirty() return next(changes) ~= nil end
    function proxy:changedKeys() return changes end
    setmetatable(proxy, {
        __index = originalTable,
        __newindex = function(_, key, value)
            if originalTable[key] ~= value then
                changes[key] = true
                originalTable[key] = value
            end
        end
    })
    return proxy
end

-- Serialize before opening any file. Reject unsupported values/cycles without
-- touching the last good settings. Sorting makes verification deterministic.
local function serialize(value, seen, cache)
    local kind = type(value)
    if kind == "string" then return string.format("%q", value) end
    if kind == "boolean" then return tostring(value) end
    if kind == "number" and value == value and value ~= math.huge and value ~= -math.huge then
        return math.type(value) == "integer" and tostring(value) or string.format("%.9g", value)
    end
    assert(kind == "table", "unsupported settings value: " .. kind)
    seen = seen or {}
    assert(not seen[value], "cyclic settings table")
    if cache and cache[value] then return cache[value] end
    seen[value] = true
    local keys, parts = {}, {"{\n"}
    local keyKind, mixedKeys
    for key in pairs(value) do
        local kind = type(key)
        assert(kind == "string" or kind == "number", "unsupported settings key")
        if keyKind and keyKind ~= kind then mixedKeys = true end
        keyKind = kind
        keys[#keys + 1] = key
    end
    -- Ordinary preference maps and arrays have one key type. Lua's native
    -- comparison avoids calling a Lua comparator for every sorting step.
    -- Mixed keys retain the same deterministic number-before-string order.
    table.sort(keys, mixedKeys and function(a, b)
        if type(a) == type(b) then return a < b end
        return type(a) < type(b)
    end or nil)
    for _, key in ipairs(keys) do
        -- Keys are already restricted to scalars above. Avoid recursive table
        -- serialization setup for every key in both pending and backup copies.
        local encoded
        if type(key) == 'string' then encoded = string.format('%q', key)
        else
            assert(key == key and key ~= math.huge and key ~= -math.huge, 'unsupported settings key')
            encoded = math.type(key) == 'integer' and tostring(key) or string.format('%.9g', key)
        end
        parts[#parts + 1] = "[" .. encoded .. "]=" .. serialize(value[key], seen, cache) .. ",\n"
    end
    parts[#parts + 1] = "}"
    seen[value] = nil
    local text = table.concat(parts)
    if cache then cache[value] = text end
    return text
end

-- Reading needs the same data checks as serialization, but not sorted keys,
-- formatted numbers or a second copy of the file. Repeated UI reads must fit
-- inside EdgeTX's widget instruction budget.
local function validate(value, seen)
    local kind = type(value)
    if kind == "string" or kind == "boolean" then return end
    if kind == "number" and value == value and value ~= math.huge and value ~= -math.huge then return end
    assert(kind == "table", "unsupported settings value: " .. kind)
    seen = seen or {}
    assert(not seen[value], "cyclic settings table")
    seen[value] = true
    for key, item in pairs(value) do
        local keyType = type(key)
        assert(keyType == 'string' or (keyType == 'number' and key == key and key ~= math.huge and key ~= -math.huge), 'unsupported settings key')
        validate(item, seen)
    end
    seen[value] = nil
end

local function loadTable(path)
    -- Preferences are mutable data. Never use a timestamp-tied .luac cache or
    -- generate one while reading, including when recovering from the backup.
    local ok, result = pcall(function()
        local chunk, err = loadScript(path, "tx", {})
        assert(chunk, err or "cannot read settings")
        local value = chunk()
        assert(type(value) == "table", "settings must return a table")
        validate(value)
        return value
    end)
    if ok then return result end
    return nil, tostring(result)
end

local function currentSettings()
    local value, err
    if not rf2.settingsUseBackup then value, err = loadTable(filename) end
    if value then return value, false end
    value = loadTable(backup)
    if value then return value, true end
    return nil, nil, err or "no readable settings or backup"
end

local function loadSettings()
    local value, recovered, err = currentSettings()
    if recovered and not (rf2.runtimeErrors and rf2.runtimeErrors.settings and rf2.runtimeErrors.settings.active) then
        report("Settings recovered from backup. Review preferences and save again.")
    elseif not value then
        report("Cannot load settings. Check the SD card. " .. tostring(err))
    end
    return addDirtyTrackingToTable(value or {})
end

local function verifiedWrite(path, text)
    local file
    local ok, err = pcall(function()
        file = assert(io.open(path, "w"), "cannot open " .. path)
        -- Handle explicit IO errors and also verify bytes after close; some
        -- radio implementations return no status even on a short write.
        local result, message = io.write(file, text)
        assert(result ~= false and not message, message or "write failed")
        result, message = io.close(file)
        file = nil
        assert(result ~= false and not message, message or "close failed")
        file = assert(io.open(path, "r"), "cannot verify " .. path)
        local offset = 1
        while offset <= #text do
            local expected = string.sub(text, offset, offset + 255)
            assert(io.read(file, #expected) == expected, "incomplete write: " .. path)
            offset = offset + #expected
        end
        assert(io.read(file, 1) == "", "unexpected trailing data: " .. path)
        io.close(file)
        file = nil
        -- text was produced by the validated serializer above. Exact byte
        -- readback already verifies it; executing and recursively validating
        -- all three copies again can exhaust the widget's instruction budget
        -- after a successful write, falsely reporting a corrupt primary.
    end)
    if file then pcall(io.close, file) end
    return ok, err
end

local function saveSettings(settings)
    if not settings:isDirty() then return true end
    local original = getmetatable(settings).__index
    local previous, recovered, err = currentSettings()
    if not previous then return report("Settings were not saved: " .. tostring(err)) end
    -- A page can stay open while the background service updates name recovery.
    -- Merge only edited keys so that a later UI save preserves those updates.
    local merged = {}
    for key, value in pairs(previous) do merged[key] = value end
    for key in pairs(settings:changedKeys()) do merged[key] = original[key] end
    -- The merge shares unchanged nested tables with the previous preferences.
    -- Serialize those once for pending/primary and backup, only within this
    -- synchronous transaction; never cache mutable settings across callbacks.
    local serializedTables = {}
    local ok, text = pcall(serialize, merged, nil, serializedTables)
    if not ok then return report("Settings were not saved: " .. tostring(text)) end
    text = "return " .. text .. "\n"
    ok, err = verifiedWrite(pending, text)
    if not ok then return report("Settings were not saved: " .. tostring(err)) end
    -- Never overwrite the only good backup when recovering a damaged primary.
    if not recovered then
        ok, err = verifiedWrite(backup, "return " .. serialize(previous, nil, serializedTables) .. "\n")
        if not ok then return report("Settings were not saved: " .. tostring(err)) end
    end
    -- Keep the verified backup even after success. This also supports firmware
    -- without rename(), and recovers a power loss during the primary write.
    ok, err = verifiedWrite(filename, text)
    if not ok then
        rf2.settingsUseBackup = true
        return report("Settings save was not confirmed; the previous settings are in the backup. " .. tostring(err))
    end
    rf2.settingsUseBackup = nil
    for key in pairs(original) do original[key] = nil end
    for key, value in pairs(merged) do original[key] = value end
    settings:resetDirtyFlag()
    rf2.executeScript("F/diagnostics").recover("settings", true)
    return true
end

return {loadSettings = loadSettings, saveSettings = saveSettings}
