local template = rf2.executeScript(rf2.radio.template)
local margin = template.margin
local indent = template.indent
local lineSpacing = template.lineSpacing
local tableSpacing = template.tableSpacing
local sp = template.listSpacing.field
local yMinLim = rf2.radio.yMinLimit
local x = margin
local y = yMinLim - lineSpacing
local function incY(val) y = y + val return y end
local labels = {}
local fields = {}
local mixerConfig = rf2.useApi("mspMixer").getDefaults()
local mixerInputs = rf2.useApi("mspMixerInputs").getDefaults()
local inputFields = {}
local mixerOverride = false
local overridePending = false
local overrideField

local function clearOverrides(callback)
    local api = rf2.useApi("mspMixer")
    for i = 1, 4 do api.disableOverride(i, i == 4 and callback or nil) end
end

local function onClickOverride(field, page)
    -- Native button callbacks can outlive their scene. Never reactivate setup
    -- controls from a retired page, an editor/notice overlay, or a pending save.
    if overridePending or not page.isReady or page._rf2Unloaded
        or (page.uiCanInteract and not page.uiCanInteract()) then return end
    local enabled = not mixerOverride
    overridePending = true
    field.t = "[Updating passthrough...]"
    local function confirmed()
        mixerOverride, overridePending = enabled, false
        field.t = enabled and "[Disable Mixer Passthrough]" or "[Enable Mixer Passthrough]"
        rf2.onPageReady(page)
    end
    local mspMixer = rf2.useApi("mspMixer")
    for i = 1, 4 do
        if enabled then
            mspMixer.enableOverride(i, i == 4 and confirmed or nil)
        else
            mspMixer.disableOverride(i, i == 4 and confirmed or nil)
        end
    end
end

local function input(title, key)
    local field = {t=title, x=x+indent, y=incY(lineSpacing), sp=x+sp, data=mixerInputs[key]}
    inputFields[#inputFields+1] = field
    fields[#fields+1] = field
end

labels[#labels + 1] = { t = "Calibration",              x = x,          y = incY(lineSpacing) }
input("Cyclic calibration", "cyclic_calibration")
input("Collective calibration", "collective_calibration")
fields[#fields + 1] = { t = "Geometry correction",      x = x + indent, y = incY(lineSpacing), sp = x + sp, data = mixerConfig.swash_geo_correction }
incY(lineSpacing * 0.25)
labels[#labels + 1] = { t = "Blade pitch limits",       x = x,          y = incY(lineSpacing) }
input("Cyclic pitch limit", "cyclic_pitch_limit")
input("Collective pitch limit", "collective_pitch_limit")
fields[#fields + 1] = { t = "Total pitch limit",        x = x + indent, y = incY(lineSpacing), sp = x + sp, data = mixerConfig.swash_pitch_limit, touchTile = true }
local customNote = {t="", x=x, y=incY(lineSpacing), bold=false}
labels[#labels+1] = customNote
incY(lineSpacing * 0.25)
labels[#labels + 1] = { t = "Swashplate",               x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "Phase angle",              x = x + indent, y = incY(lineSpacing), sp = x + sp, data = mixerConfig.swash_phase }
if rf2.apiVersion >= 12.08 then
    fields[#fields + 1] = { t = "Pos coll tilt corr",   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = mixerConfig.collective_tilt_correction_pos }
    fields[#fields + 1] = { t = "Neg coll tilt corr",   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = mixerConfig.collective_tilt_correction_neg }
end
fields[#fields + 1] = { t = "TTA precomp",              x = x + indent, y = incY(lineSpacing), sp = x + sp, data = mixerConfig.swash_tta_precomp }

incY(lineSpacing * 0.25)
labels[#labels + 1] = { t = "Motorised Tail",           x = x,          y = incY(lineSpacing) }
fields[#fields + 1] = { t = "Motor idle thrott",        x = x + indent, y = incY(lineSpacing), sp = x + sp, data = mixerConfig.tail_motor_idle }
fields[#fields + 1] = { t = "Center trim",              x = x + indent, y = incY(lineSpacing), sp = x + sp, data = mixerConfig.tail_center_trim }

if rf2.apiVersion >= 12.08 then
    incY(lineSpacing * 0.5)

    overrideField = { t = "[Enable Mixer Passthrough]", x = x, y = incY(lineSpacing), w = 250, preEdit = onClickOverride }
    fields[#fields + 1] = overrideField
end

local function receivedMixerInputs(page, _)
    local custom = false
    for _, field in ipairs(inputFields) do
        field.readOnly = field.data.locked
        custom = custom or field.readOnly
    end
    customNote.t = custom and "Custom mixer inputs: use Configurator for locked values." or ""
    if not overrideField then rf2.onPageReady(page); return end
    clearOverrides(function()
        mixerOverride, overridePending = false, false
        overrideField.t = "[Enable Mixer Passthrough]"
        rf2.onPageReady(page)
    end)
end

local function receivedMixerConfig(page, _)
    rf2.useApi("mspMixerInputs").read(receivedMixerInputs, page, mixerInputs)
end

return {
    read = function(self)
        self.isReady = false
        rf2.useApi("mspMixer").read(receivedMixerConfig, self, mixerConfig)
    end,
    unload = function(self)
        if overrideField then clearOverrides() end
    end,
    write = function(self)
        if mixerConfig.swash_phase.value then
            self.isReady = false
            rf2.useApi("mspMixerInputs").write(mixerInputs, function()
                rf2.useApi("mspMixer").write(mixerConfig)
                rf2.settingsSaved(true, false)
            end)
        end
    end,
    title       = "Mixer",
    lvglIndependentColumns = true,
    lvglSectionColumns = { 1, 2, 1, 2 },
    labels      = labels,
    fields      = fields
}
