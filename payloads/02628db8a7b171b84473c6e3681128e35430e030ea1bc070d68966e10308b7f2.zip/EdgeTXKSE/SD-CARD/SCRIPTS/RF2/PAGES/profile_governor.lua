local template = rf2.executeScript(rf2.radio.template)
local margin = template.margin
local indent = template.indent
local lineSpacing = template.lineSpacing
local tableSpacing = template.tableSpacing
local sp = template.listSpacing.field
local yMinLim = rf2.radio.yMinLimit
local x = margin
local y = yMinLim - lineSpacing
local function incY(val) y = y + val return y end
local labels = {}
local fields = {}
local profileSwitcher = rf2.executeScript("PAGES/helpers/profileSwitcher.lua")
local governorProfile = rf2.useApi("mspGovernorProfile").getDefaults()

fields[#fields + 1] = { t = "Current PID profile", x = x, y = incY(lineSpacing), sp = x + sp * 1.17, data = { value = nil, min = 0, max = 5, table = { [0] = "1", "2", "3", "4", "5", "6" } }, preEdit = profileSwitcher.startPidEditing, postEdit = profileSwitcher.endPidEditing }

incY(lineSpacing * 0.25)
fields[#fields + 1] = { t = "Full headspeed",      x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.headspeed,            w = 100}
fields[#fields + 1] = { t = "Max throttle",        x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.max_throttle }
if rf2.apiVersion >= 12.07 then
    fields[#fields + 1] = { t = "Min throttle",    x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.min_throttle }
end
if rf2.apiVersion >= 12.09 then
    fields[#fields+1] = { t = "Throttle fallback", x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.fallback_drop }
end
incY(lineSpacing * 0.5)
labels[#labels + 1] = { t = "Governor Gains", x = x, y = incY(lineSpacing) }
for _,item in ipairs({
    {"Governor master gain", "gain"}, {"Governor P", "p_gain"},
    {"Governor I", "i_gain"}, {"Governor D", "d_gain"}, {"Governor FF", "f_gain"},
}) do
    fields[#fields + 1] = { t = item[1], x = x, y = incY(lineSpacing),
        sp = x + sp, data = governorProfile[item[2]] }
end
incY(lineSpacing * 0.5)
labels[#labels + 1] = { t = "Precompensation",     x = x, y = incY(lineSpacing) }
fields[#fields + 1] = { t = "Collective",          x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.collective_weight }
fields[#fields + 1] = { t = "Cyclic",              x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.cyclic_weight }
fields[#fields + 1] = { t = "Yaw",                 x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.yaw_weight }
incY(lineSpacing * 0.5)
labels[#labels + 1] = { t = "TTA",                 x = x, y = incY(lineSpacing) }
fields[#fields + 1] = { t = "TTA gain",            x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.tta_gain }
fields[#fields + 1] = { t = "TTA limit",           x = x, y = incY(lineSpacing), sp = x + sp, data = governorProfile.tta_limit }

local function receivedGovernorProfile(page, _)
    rf2.onPageReady(page)
end

return {
    read = function(self)
        self.profileSwitcher.getStatus(self)
        rf2.useApi("mspGovernorProfile").read(receivedGovernorProfile, self, governorProfile)
    end,
    write = function(self)
        if governorProfile.headspeed.value then
            rf2.useApi("mspGovernorProfile").write(governorProfile)
            rf2.settingsSaved(true, false)
        end
    end,
    title       = "Governor",
    -- Keep master/P/I/D/FF together in one section at every resolution.
    lvglWholeSections = true,
    lvglSectionTabs = {"Overview", "Gains", "Precomp", "TTA"},
    lvglIndependentColumns = true,
    labels      = labels,
    fields      = fields,
    profileSwitcher = profileSwitcher,

    timer = function(self)
        self.profileSwitcher.checkStatus(self)
    end,
}
