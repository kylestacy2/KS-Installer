local template = rf2.executeScript(rf2.radio.template)
local mspStatus = rf2.useApi("mspStatus")
local margin = template.margin
local indent = template.indent
local lineSpacing = template.lineSpacing
local tableSpacing = template.tableSpacing
local colSpacing = tableSpacing.col * 0.65
local sp = template.listSpacing.field
template = nil
local yMinLim = rf2.radio.yMinLimit
local x = margin
local y = yMinLim - lineSpacing
local function incY(val) y = y + val return y end
local labels = {}
local fields = {}
local editing = false
local profileAdjustmentTS = nil
local pids = rf2.useApi("mspPidTuning").getDefaults()
local pidProfile = rf2.useApi("mspPidProfile").getDefaults()
local statusReady = false
local pidTuningReady = false
local pidProfileReady = false
collectgarbage()

local function updateReady(page)
    if statusReady and pidTuningReady and pidProfileReady and not page.isReady then
        rf2.onPageReady(page)
    end
end

local startEditing = function(field, page)
    editing = true
end

local endPidEditing = function(field, page)
    rf2.useApi("mspSetProfile").setPidProfile(field.data.value, function() rf2.reloadPage() end, nil)
end

local function copyProfile(field, page)
    if not page.isReady then return end
    local source = page.fields[16].data.value
    local dest = page.fields[17].data.value
    if source == dest then return end

    local mspCopyProfile = {
        command = 183, -- MSP_COPY_PROFILE
        payload = { 0, dest, source } -- 0 = copy pids
    }

    rf2.mspQueue:add(mspCopyProfile)
    rf2.settingsSaved(true, false)
end

x = margin
local tableStartY = yMinLim - lineSpacing
y = tableStartY
labels[#labels + 1] = { t = "",      x = x, y = incY(tableSpacing.header) }
labels[#labels + 1] = { t = "Roll",  x = x, y = incY(tableSpacing.row) }
labels[#labels + 1] = { t = "Pitch", x = x, y = incY(tableSpacing.row) }
labels[#labels + 1] = { t = "Yaw",   x = x, y = incY(tableSpacing.row) }

x = x + tableSpacing.col
y = tableStartY
labels[#labels + 1] = { t = "P",     x = x, y = incY(tableSpacing.header) }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[0] }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[4] }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[8] }

x = x + colSpacing
y = tableStartY
labels[#labels + 1] = { t = "I",     x = x, y = incY(tableSpacing.header) }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[1] }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[5] }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[9] }

x = x + colSpacing
y = tableStartY
labels[#labels + 1] = { t = "D",     x = x, y = incY(tableSpacing.header) }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[2] }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[6] }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[10] }

x = x + colSpacing
y = tableStartY
labels[#labels + 1] = { t = "FF",    x = x, y = incY(tableSpacing.header) }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[3] }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[7] }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[11] }

x = x + colSpacing
y = tableStartY
labels[#labels + 1] = { t = "B",     x = x, y = incY(tableSpacing.header) }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[12] }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[13] }
fields[#fields + 1] = {              x = x, y = incY(tableSpacing.row), w = 50, data = pids[14] }
local oGainX = x + colSpacing

x = margin
incY(lineSpacing * 0.5)
fields[16] = { t = "Current PID profile",             x = x,          y = incY(lineSpacing), sp = x + sp * 1.17, data = { value = nil, min = 0, max = 5, table = { [0] = "1", "2", "3", "4", "5", "6" } }, preEdit = startEditing, postEdit = endPidEditing }
fields[17] = { t = "Destination profile",             x = x,          y = incY(lineSpacing), sp = x + sp * 1.17, data = { value = nil, min = 0, max = 5, table = { [0] = "1", "2", "3", "4", "5", "6" } } }
fields[#fields + 1] = { t = "[Copy Current to Dest]", x = x + indent, y = incY(lineSpacing), preEdit = copyProfile }

-- Append these fields so the existing profile/copy indices stay unchanged.
-- O is HSI Offset Gain, available only on the Roll and Pitch axes.
if LCD_W >= 800 then
    local headerY = labels[5].y + 3 -- Lower touch headings by 5.25 pixels.
    for i = 5, 9 do labels[i].lvglPosition = { y = headerY } end
    labels[#labels + 1] = { t = "O", x = oGainX, y = labels[5].y, lvglPosition = { y = headerY } }
    for axis = 1, 2 do
        fields[#fields + 1] = { x = oGainX, y = fields[axis].y, w = 50, data = pids[14 + axis] }
    end
else
    incY(lineSpacing * 0.5)
    labels[#labels + 1] = { t = "HSI Offset Gain", x = margin, y = incY(lineSpacing) }
    fields[#fields + 1] = { t = "Roll",  x = margin + indent, y = incY(lineSpacing), sp = margin + sp, data = pids[15] }
    fields[#fields + 1] = { t = "Pitch", x = margin + indent, y = incY(lineSpacing), sp = margin + sp, data = pids[16] }
end

incY(lineSpacing * 0.5)
labels[#labels + 1] = { t = "Tail Stop Gains", x = margin, y = incY(lineSpacing) }
fields[#fields + 1] = { t = "CW stop gain",  x = margin + indent, y = incY(lineSpacing), sp = margin + sp, data = pidProfile[20] }
fields[#fields + 1] = { t = "CCW stop gain", x = margin + indent, y = incY(lineSpacing), sp = margin + sp, data = pidProfile[21] }
-- Error limits remain in pidProfile so saving preserves the FC's existing values.

local function receivedPidTuning(page, data)
    pidTuningReady = true
    updateReady(page)
end

local function receivedPidProfile(page, data)
    pidProfileReady = true
    updateReady(page)
end

return {
    read = function(self)
        self.isReady = false
        statusReady = false
        pidTuningReady = false
        pidProfileReady = false
        mspStatus.getStatus(self.onProcessedMspStatus, self)
        rf2.useApi("mspPidTuning").read(receivedPidTuning, self, pids)
        rf2.useApi("mspPidProfile").read(receivedPidProfile, self, pidProfile)
    end,
    write = function(self)
        if self.isReady and statusReady and pidTuningReady and pidProfileReady then
            rf2.useApi("mspPidTuning").write(pids)
            rf2.useApi("mspPidProfile").write(pidProfile)
            rf2.settingsSaved(true, false)
        end
    end,
    title       = "PID Gains",
    labels      = labels,
    fields      = fields,

    timer = function(self)
        if profileAdjustmentTS and rf2.clock() - profileAdjustmentTS > 0.35 then
            rf2.reloadPage()
        elseif rf2.mspQueue:isProcessed() and not editing then
            mspStatus.getStatus(self.onProcessedMspStatus, self)
        end
    end,

    onProcessedMspStatus = function(self, status)
        local currentField = self.fields[16]
        if currentField.data.value ~= status.profile and not editing then
            if currentField.data.value then
                profileAdjustmentTS = rf2.clock()
            end
            currentField.data.value = status.profile
        end

        local destField = self.fields[17]
        if not destField.data.value then
            if status.profile < 5 then
                destField.data.value = status.profile + 1
            else
                destField.data.value = 4
            end
        end

        
        statusReady = true
        updateReady(self)
    end,
}
