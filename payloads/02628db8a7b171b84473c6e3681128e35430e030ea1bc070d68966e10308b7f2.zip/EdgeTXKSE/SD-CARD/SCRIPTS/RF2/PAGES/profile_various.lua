local template = rf2.executeScript(rf2.radio.template)
local margin = template.margin
local indent = template.indent
local lineSpacing = template.lineSpacing
local tableSpacing = template.tableSpacing
local sp = template.listSpacing.field
template = nil
local yMinLim = rf2.radio.yMinLimit
local x = margin
local y = yMinLim - lineSpacing
local function incY(val) y = y + val return y end
local labels = {}
local fields = {}
local sections = {}
local function startSection()
    sections[#sections + 1] = { firstLabel = #labels, firstField = #fields + 1 }
end
local profileSwitcher = rf2.executeScript("PAGES/helpers/profileSwitcher.lua")
local pidProfile = rf2.useApi("mspPidProfile").getDefaults()
collectgarbage()

fields[#fields + 1] = { t = "Current PID profile",     x = x,          y = incY(lineSpacing), sp = x + sp * 1.17, data = { value = nil, min = 0, max = 5, table = { [0] = "1", "2", "3", "4", "5", "6" } }, preEdit = profileSwitcher.startPidEditing, postEdit = profileSwitcher.endPidEditing }

incY(lineSpacing * 0.25)
labels[#labels + 1] = { t = "Main Rotor",              x = x,            y = incY(lineSpacing) }
startSection()
fields[#fields + 1] = { t = "Coll to pitch gain",      x = x + indent,   y = incY(lineSpacing), sp = x + sp, data = pidProfile[27] }
labels[#labels + 1] = { t = "Cross-Coupling",          x = x + indent,   y = incY(lineSpacing), bold = false }
fields[#fields + 1] = { t = "Gain",                    x = x + indent*2, y = incY(lineSpacing), sp = x + sp, data = pidProfile[33] }
fields[#fields + 1] = { t = "Ratio",                   x = x + indent*2, y = incY(lineSpacing), sp = x + sp, data = pidProfile[34] }
fields[#fields + 1] = { t = "Cutoff",                  x = x + indent*2, y = incY(lineSpacing), sp = x + sp, data = pidProfile[35] }

incY(lineSpacing * 0.25)
labels[#labels + 1] = { t = "Tail Rotor",              x = x,          y = incY(lineSpacing) }
startSection()
-- Tail stop gains are edited on PID Gains; retain them in the complete profile.
fields[#fields + 1] = { t = "Precomp cutoff",          x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[22] }
fields[#fields + 1] = { t = "Cyclic FF gain",          x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[23] }
fields[#fields + 1] = { t = "Coll FF gain",            x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[24] }
if rf2.apiVersion >= 12.08 then
    fields[#fields + 1] = { t = "Inertia gain",        x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[41] }
    fields[#fields + 1] = { t = "Inertia cutoff",      x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[42] }
else
    fields[#fields + 1] = { t = "Coll imp FF gain",    x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[25]  }
    fields[#fields + 1] = { t = "Coll imp FF decay",   x = x + indent, y = incY(lineSpacing), sp = x + sp, data = pidProfile[26] }
end

-- Hidden leveling settings remain in pidProfile for complete MSP reads/writes.

if LCD_W >= 800 then
    -- Keep nested Cross-Coupling labels with Main Rotor in the touch grid.
    local columnSpacing = (LCD_W / 1.75 - margin * 2) / 2
    local valueOffset = sp - lineSpacing * 1.5
    local rowY = labels[sections[1].firstLabel].y
    local rowBottom = rowY
    for i, section in ipairs(sections) do
        local sectionX = margin + ((i - 1) % 2) * columnSpacing
        local startY = labels[section.firstLabel].y
        local lastLabel = sections[i + 1] and sections[i + 1].firstLabel - 1 or #labels
        local lastField = sections[i + 1] and sections[i + 1].firstField - 1 or #fields
        for j = section.firstLabel, lastLabel do
            local label = labels[j]
            label.lvglPosition = { x = sectionX + label.x - margin, y = rowY + label.y - startY }
        end
        for j = section.firstField, lastField do
            local field = fields[j]
            local fieldY = rowY + field.y - startY
            field.lvglPosition = { x = sectionX + field.x - margin, sp = sectionX + valueOffset, y = fieldY }
            rowBottom = math.max(rowBottom, fieldY)
        end
        if i % 2 == 0 then
            rowY = rowBottom + lineSpacing
            rowBottom = rowY
        end
    end
end

local function receivedPidProfile(page, _)
    rf2.onPageReady(page)
end

return {
    read = function(self)
        self.profileSwitcher.getStatus(self)
        rf2.useApi("mspPidProfile").read(receivedPidProfile, self, pidProfile)
    end,
    write = function(self)
        if pidProfile[27].value then
            rf2.useApi("mspPidProfile").write(pidProfile)
            rf2.settingsSaved(true, false)
        end
    end,
    title       = "Profile - Various",
    labels      = labels,
    fields      = fields,
    profileSwitcher = profileSwitcher,

    timer = function(self)
        self.profileSwitcher.checkStatus(self)
    end,
}
