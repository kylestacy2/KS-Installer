return rf2.executeScript("PAGES/helpers/rates", false)
