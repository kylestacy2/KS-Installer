local template = rf2.executeScript(rf2.radio.template)
local mspServos = rf2.useApi("mspServos")
local margin = template.margin
local indent = template.indent
local lineSpacing = template.lineSpacing
local tableSpacing = template.tableSpacing
local sp = template.listSpacing.field
local yMinLim = rf2.radio.yMinLimit
local x = margin
local y = yMinLim - lineSpacing
local function incY(val) y = y + val return y end
local labels = {}
local fields = {}
local servoConfigs = {}
local selectedServoIndex = 0
local updateSelectedServoConfiguration = false
local overrideAllServos = false
local overridePending = false

local function clearOverrides(callback)
    if not servoConfigs[0] then return end
    for i = 0, #servoConfigs do
        mspServos.disableServoOverride(i, i == #servoConfigs and callback or nil)
    end
end

local  function setValues(servoIndex)
    fields[1].data.value = servoIndex
    fields[2].data = servoConfigs[servoIndex].mid
    fields[3].data = servoConfigs[servoIndex].min
    fields[4].data = servoConfigs[servoIndex].max
    fields[5].data = servoConfigs[servoIndex].scaleNeg
    fields[6].data = servoConfigs[servoIndex].scalePos
    fields[7].data = servoConfigs[servoIndex].rate
    fields[8].data = servoConfigs[servoIndex].speed
end

-- Field event functions

local function onChangeServo(field, page)
    selectedServoIndex = field.data.value
    rf2.lastChangedServo = selectedServoIndex
    setValues(selectedServoIndex)
    rf2.onPageReady(page)
end

local function onPreEditCenter(field, page)
    if not overrideAllServos then
        mspServos.enableServoOverride(selectedServoIndex)
    end
end

local function onChangeCenter(field, page)
    updateSelectedServoConfiguration = true
end

local function onPostEditCenter(field, page)
    if not overrideAllServos then
        mspServos.disableServoOverride(selectedServoIndex)
    end
end

local function onClickOverride(field, page)
    if overridePending or not page.isReady then return end
    local enabled = not overrideAllServos
    overridePending = true
    field.t = "[Updating overrides...]"
    local function confirmed()
        overrideAllServos, overridePending = enabled, false
        field.t = enabled and "[Disable Override]" or "[Override All Servos]"
        rf2.onPageReady(page)
    end
    for i = 0, #servoConfigs do
        if enabled then
            mspServos.enableServoOverride(i, i == #servoConfigs and confirmed or nil)
        else
            mspServos.disableServoOverride(i, i == #servoConfigs and confirmed or nil)
        end
    end
end

fields[1] = { t = "Servo",      x = x,          y = incY(lineSpacing), sp = x + sp, data = { min = 0, max = 7, table = { [0] = "ELEVATOR", "CYCL L", "CYCL R", "TAIL", "5", "6", "7", "8" } }, postEdit = onChangeServo }
fields[2] = { t = "Center",     x = x + indent, y = incY(lineSpacing), sp = x + sp, preEdit = onPreEditCenter, change = onChangeCenter, postEdit = onPostEditCenter }
fields[3] = { t = "Min",        x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[4] = { t = "Max",        x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[5] = { t = "Scale neg",  x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[6] = { t = "Scale pos",  x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[7] = { t = "Rate",       x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[8] = { t = "Speed",      x = x + indent, y = incY(lineSpacing), sp = x + sp }
incY(lineSpacing * 0.5)
fields[9] = { t = "[Override All Servos]", x = x + indent * 2, y = incY(lineSpacing), preEdit = onClickOverride }

local function receivedServoConfigurations(page, configs)
    servoConfigs = configs
    selectedServoIndex = rf2.lastChangedServo or 0
    setValues(selectedServoIndex)
    page.fields[1].data.max = #configs
    -- Establish a known disabled state before exposing setup controls, also
    -- recovering overrides left by a previous interrupted tool session.
    clearOverrides(function()
        overrideAllServos, overridePending = false, false
        fields[9].t = "[Override All Servos]"
        rf2.onPageReady(page)
    end)
end

return {
    read = function(self)
        self.isReady = false
        mspServos.getServoConfigurations(receivedServoConfigurations, self)
    end,
    unload = function(self)
        updateSelectedServoConfiguration = false
        clearOverrides()
    end,
    write = function(self)
        if servoConfigs[0] then
            for servoIndex = 0, #servoConfigs do
                mspServos.setServoConfiguration(servoIndex, servoConfigs[servoIndex])
            end
            rf2.settingsSaved(true, false)
        end
    end,
    timer = function(self)
        if updateSelectedServoConfiguration then
            mspServos.setServoConfiguration(selectedServoIndex, servoConfigs[selectedServoIndex])
            updateSelectedServoConfiguration = false
        end
    end,
    title       = "Servos",
    lvglTopFields = 1,
    labels      = labels,
    fields      = fields
}
