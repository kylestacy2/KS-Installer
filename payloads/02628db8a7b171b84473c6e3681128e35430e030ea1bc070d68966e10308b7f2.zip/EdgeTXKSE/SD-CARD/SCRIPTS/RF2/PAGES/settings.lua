if rf2.executeScript('F/hangarConfig').enabled() then return rf2.executeScript('PAGES/hangarSettings') end
local template = rf2.executeScript(rf2.radio.template)
local settings = rf2.loadSettings()
local defaults = rf2.executeScript("F/pageDefaults")
local margin = template.margin
local indent = template.indent
local lineSpacing = template.lineSpacing
local tableSpacing = template.tableSpacing
local sp = template.listSpacing.field
local yMinLim = rf2.radio.yMinLimit
local x = margin
local y = yMinLim - lineSpacing
local function incY(val) y = y + val return y end
local labels = {}
local fields = {}
local hideShow = { [0] = "Hide", "Show" }
local offOn = { [0] = "Off", "On" }
local canUseLvgl = rf2.executeScript("F/canUseLvgl")()
local themes = canUseLvgl and rf2.executeScript("F/uiThemes")

y = yMinLim - tableSpacing.header
labels[1] = { t = "Display FC Pages",        x = x, y = incY(lineSpacing) }
fields[1] = { t = "Status",                  x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[2] = { t = "Rates",                   x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[3] = { t = "Rate Dynamics",           x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[4] = { t = "PID Gains",               x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[5] = { t = "PID Controller",          x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[6] = { t = "Profile - Various",       x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[7] = { t = "Profile - Rescue",        x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[8] = { t = "Governor",               x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[9] = { t = "Battery",                 x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[10] = { t = "Smart Fuel",             x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[11] = { t = "Servos",                 x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[12] = { t = "Mixer",                  x = x + indent, y = incY(lineSpacing), sp = x + sp }
local swashTrimField = { t = "Swash Trim",    x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[13] = { t = "Gyro Filters",           x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[14] = { t = "Governor Setup",         x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[15] = { t = "Accelerometer Trim",     x = x + indent, y = incY(lineSpacing), sp = x + sp }

incY(lineSpacing * 0.5)
labels[2] = { t = "Display Various Pages",   x = x, y = incY(lineSpacing) }
fields[16] = { t = "Model",                  x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[17] = { t = "Experimental (!)",       x = x + indent, y = incY(lineSpacing), sp = x + sp }

incY(lineSpacing * 0.5)
labels[3] = { t = "Display ESC Pages",       x = x, y = incY(lineSpacing) }
fields[18] = { t = "AM32",                   x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[19] = { t = "BLHeli_S",               x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[20] = { t = "Bluejay",                x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[21] = { t = "FLYROTOR",               x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[22] = { t = "HW Platinum V5",         x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[23] = { t = "Scorpion Tribunus",      x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[24] = { t = "XDFly/OMP/ZTW",          x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[25] = { t = "YGE",                    x = x + indent, y = incY(lineSpacing), sp = x + sp }
fields[26] = { t = "ESC Sensor",             x = x + indent, y = incY(lineSpacing), sp = x + sp }

incY(lineSpacing * 0.5)
labels[4] = { t = "Rf2bg Options",           x = x, y = incY(lineSpacing) }
fields[27] = { t = "Adjustment Teller",      x = x + indent, y = incY(lineSpacing), sp = x + sp }

if canUseLvgl then
    incY(lineSpacing * 0.5)
    labels[5] = { t = "Tool Options",        x = x, y = incY(lineSpacing) }
    fields[28] = { t = "Use touch UI",       x = x + indent, y = incY(lineSpacing), sp = x + sp }
    fields[29] = { t = "Theme",              x = x + indent, y = incY(lineSpacing), sp = x + sp }
end

-- Append the new preference without shifting existing field indexes. Its
-- original form position keeps it beside Mixer in the displayed settings.
fields[#fields + 1] = swashTrimField

local function setValues()
    swashTrimField.data = { value = settings.showSwashTrim or defaults.showSwashTrim, min = 0, max = 1, table = hideShow }
    fields[1].data = { value = settings.showStatus or defaults.showStatus, min = 0, max = 1, table = hideShow }
    fields[2].data = { value = settings.showRates or defaults.showRates, min = 0, max = 1, table = hideShow }
    fields[3].data = { value = settings.showRateDynamics  or 1, min = 0, max = 1, table = hideShow }
    fields[4].data = { value = settings.showPidGains or defaults.showPidGains, min = 0, max = 1, table = hideShow }
    fields[5].data = { value = settings.showPidController or defaults.showPidController, min = 0, max = 1, table = hideShow }
    fields[6].data = { value = settings.showProfileVarious or defaults.showProfileVarious, min = 0, max = 1, table = hideShow }
    fields[7].data = { value = settings.showProfileRescue or defaults.showProfileRescue, min = 0, max = 1, table = hideShow }
    fields[8].data = { value = settings.showProfileGovernor or defaults.showProfileGovernor, min = 0, max = 1, table = hideShow }
    fields[9].data = { value = settings.showBattery or defaults.showBattery, min = 0, max = 1, table = hideShow }
    fields[10].data = { value = settings.showSmartFuel or defaults.showSmartFuel, min = 0, max = 1, table = hideShow }
    fields[11].data = { value = settings.showServos or defaults.showServos, min = 0, max = 1, table = hideShow }
    fields[12].data = { value = settings.showMixer or defaults.showMixer, min = 0, max = 1, table = hideShow }
    fields[13].data = { value = settings.showGyroFilters or defaults.showGyroFilters, min = 0, max = 1, table = hideShow }
    fields[14].data = { value = settings.showGovernor or defaults.showGovernor, min = 0, max = 1, table = hideShow }
    fields[15].data = { value = settings.showAccelerometerTrim or defaults.showAccelerometerTrim, min = 0, max = 1, table = hideShow }
    fields[16].data = { value = settings.showModelOnTx or defaults.showModelOnTx, min = 0, max = 1, table = hideShow }
    fields[17].data = { value = settings.showExperimental or defaults.showExperimental, min = 0, max = 1, table = hideShow }
    fields[18].data = { value = settings.showAm32 or defaults.showAm32, min = 0, max = 1, table = hideShow }
    fields[19].data = { value = settings.showBlheliS or defaults.showBlheliS, min = 0, max = 1, table = hideShow }
    fields[20].data = { value = settings.showBluejay or defaults.showBluejay, min = 0, max = 1, table = hideShow }
    fields[21].data = { value = settings.showFlyRotor or defaults.showFlyRotor, min = 0, max = 1, table = hideShow }
    fields[22].data = { value = settings.showPlatinumV5 or defaults.showPlatinumV5, min = 0, max = 1, table = hideShow }
    fields[23].data = { value = settings.showTribunus or defaults.showTribunus, min = 0, max = 1, table = hideShow }
    fields[24].data = { value = settings.showXdfly or defaults.showXdfly, min = 0, max = 1, table = hideShow }
    fields[25].data = { value = settings.showYge or defaults.showYge, min = 0, max = 1, table = hideShow }
    fields[26].data = { value = settings.showEscSensor or defaults.showEscSensor, min = 0, max = 1, table = hideShow }
    fields[27].data = { value = settings.useAdjustmentTeller or 0, min = 0, max = 1, table = offOn }
    if canUseLvgl then
        fields[28].data = { value = settings.useLvgl or 1, min = 0, max = 1, table = offOn }
        fields[29].data = { value = themes.index(settings.uiTheme), min = 0, max = #themes.keys - 1, table = themes.names }
    end
end

return {
    read = function(self)
        setValues()
        rf2.onPageReady(self)
    end,
    write = function(self)
        settings.showStatus = fields[1].data.value
        settings.showRates = fields[2].data.value
        settings.showRateDynamics = fields[3].data.value
        settings.showPidGains = fields[4].data.value
        settings.showPidController = fields[5].data.value
        settings.showProfileVarious = fields[6].data.value
        settings.showProfileRescue = fields[7].data.value
        settings.showProfileGovernor = fields[8].data.value
        settings.showBattery = fields[9].data.value
        settings.showSmartFuel = fields[10].data.value
        settings.showServos = fields[11].data.value
        settings.showMixer = fields[12].data.value
        settings.showSwashTrim = swashTrimField.data.value
        settings.showGyroFilters = fields[13].data.value
        settings.showGovernor = fields[14].data.value
        settings.showAccelerometerTrim = fields[15].data.value
        settings.showModelOnTx = fields[16].data.value
        settings.showExperimental = fields[17].data.value
        settings.showAm32 = fields[18].data.value
        settings.showBlheliS = fields[19].data.value
        settings.showBluejay = fields[20].data.value
        settings.showFlyRotor = fields[21].data.value
        settings.showPlatinumV5 = fields[22].data.value
        settings.showTribunus = fields[23].data.value
        settings.showXdfly = fields[24].data.value
        settings.showYge = fields[25].data.value
        settings.showEscSensor = fields[26].data.value
        local restartBackground = settings.useAdjustmentTeller ~= fields[27].data.value
        settings.useAdjustmentTeller = fields[27].data.value
        if canUseLvgl then
            settings.useLvgl = fields[28].data.value
            settings.uiTheme = themes.keys[fields[29].data.value + 1] or "light"
        end
        if not rf2.saveSettings(settings) then return end
        if restartBackground then rf2.executeScript("F/pilotConfigReset")() end
        rf2.reloadMainMenu(true)
        rf2.settingsSaved(false, false)
    end,
    title       = "Settings",
    lvglHeaderField = canUseLvgl and fields[29] or nil,
    lvglCompactSectionColumns = { 1, 2, 2, 2, 2 },
    labels      = labels,
    fields      = fields
}
