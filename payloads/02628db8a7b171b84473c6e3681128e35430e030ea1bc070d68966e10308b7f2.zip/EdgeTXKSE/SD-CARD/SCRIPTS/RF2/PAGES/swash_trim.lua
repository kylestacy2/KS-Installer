local template = rf2.executeScript(rf2.radio.template)
-- Keep the complete mixer configuration so saving trims preserves all other
-- mixer settings in the existing MSP_MIXER_CONFIG / MSP_SET_MIXER_CONFIG pair.
local mixerConfig = rf2.useApi("mspMixer").getDefaults()
local fields, labels = {}, {}
local y = rf2.radio.yMinLimit
local function addTrim(title, data, negative, positive)
    fields[#fields + 1] = {
        t = title, data = data,
        x = template.margin + template.indent, y = y,
        sp = template.margin + template.listSpacing.field,
        negativeHint = "- " .. negative, positiveHint = "+ " .. positive,
    }
    for _, hint in ipairs({"- " .. negative, "+ " .. positive}) do
        y = y + template.lineSpacing
        labels[#labels + 1] = {t = hint, x = template.margin + template.indent, y = y}
    end
    y = y + template.lineSpacing * 1.5
end
addTrim("Roll trim", mixerConfig.swash_trim_roll, "Left roll", "Right roll")
addTrim("Elevator trim", mixerConfig.swash_trim_pitch, "Forward elevator", "Back elevator")
addTrim("Collective trim", mixerConfig.swash_trim_collective, "Negative pitch", "Positive pitch")

return {
    title = "Swash Trim",
    labels = labels,
    fields = fields,
    read = function(self)
        rf2.useApi("mspMixer").read(function(page) rf2.onPageReady(page) end, self, mixerConfig)
    end,
    write = function(self)
        if self.isReady then
            rf2.useApi("mspMixer").write(mixerConfig)
            rf2.settingsSaved(true, false)
        end
    end,
}
