Per-model KSE layout and RotorFlight headspeed favorites are saved here.
Keep both .a and .b files: they are alternating verified recovery copies.
These are local radio preferences, never flight-controller tuning values.
