local initTask = nil
local adjTellerTask = nil
local crsfTelemetryTask = nil
local frskyTelemetryTask = nil
local isInitialized = false
local modelIsConnected = false
local lastTimeRssi = nil
local updateModelName = nil
local modelNameRestored = false
local connectionResetDelay = 5

local function pilotConfigHasBeenReset()
    return model.getGlobalVariable(7, 8) == 0
end

local diagnostics = rf2.executeScript("F/diagnostics")
local stage, lastState, resumeState = "connection", nil, nil
local retryAt, failures = 0, 0

local hasSensor = rf2.executeScript("F/hasSensor")

local function setState(widget, state)
    lastState = state
    if widget == nil then return end
    widget:setState(state)
end

local function run(widget)
    stage = "connection"
    rf2.diagnosticStage = stage
    if rf2.offlineSimulator then
        -- The preview needs no live initialization, sensor discovery or model-name writes.
        rf2.apiVersion = 12.09
        rf2.modelName = "Offline preview"
        setState(widget, "simulator")
        return
    end

    if isInitialized and crsfTelemetryTask and not hasSensor("*Cnt") then
        isInitialized = false -- user probably deleted all sensors on TX
    elseif getRSSI() > 0 then
        lastTimeRssi = rf2.clock()
        modelIsConnected = true
        if modelNameRestored and updateModelName then
            updateModelName(true)
            modelNameRestored = false
        end
        if isInitialized and pilotConfigHasBeenReset() then
            -- Since EdgeTX 2.11 the background script will resume execution instead of starting it again after running a tool.
            rf2.mspQueue:clear()
            isInitialized = false
        end
    elseif getRSSI() == 0 then
        -- Restore on the first serviced disconnect, independently of the
        -- longer transport/pilot reset grace. A short loss must not restart
        -- setup or discard the aircraft identity used by the debrief.
        if not modelNameRestored and updateModelName then
            updateModelName(false)
            modelNameRestored = true
        end
        if lastTimeRssi and rf2.clock() - lastTimeRssi < connectionResetDelay then
            -- Do not re-initialise if the RSSI is 0 for less than 5 seconds.
            -- This is also a work-around for https://github.com/ExpressLRS/ExpressLRS/issues/3207 (AUX channel bug in ELRS TX < 3.5.5)
            -- setState(widget, "telemetry lost") -- also needs telemetry recoverede/connected
            return
        end
        if modelIsConnected then
            rf2.executeScript("F/pilotConfigReset")()
            if initTask then
                initTask.reset()
                initTask = nil
            end
            adjTellerTask = nil
            crsfTelemetryTask = nil
            frskyTelemetryTask = nil
            modelIsConnected = false
            isInitialized = false
            updateModelName = nil
            modelNameRestored = false
            collectgarbage()
        end
    end

    if not isInitialized then
        stage = "initialization"
        rf2.diagnosticStage = "background initialization"
        adjTellerTask = nil
        crsfTelemetryTask = nil
        frskyTelemetryTask = nil
        -- Waiting for telemetry/API replies can last indefinitely. Collect
        -- discarded tasks once when entering initialization, not on every
        -- service pass; EdgeTX already advances the collector between passes.
        if not initTask then
            collectgarbage()
            initTask = rf2.executeScript("background_init")
            -- Module loading reads preferences. Name recovery and its verified
            -- settings transaction must start in subsequent callbacks.
            setState(widget, getRSSI() == 0 and "disconnected" or "initializing")
            return
        else
            collectgarbage("step", 10)
        end
        local initTaskResult = initTask.run(modelIsConnected)
        if not initTaskResult.isInitialized then
            --rf2.print("Not initialized yet")
            if getRSSI() == 0 then
                setState(widget, "disconnected")
            else
                setState(widget, "initializing")
            end
            return
        end
        if initTaskResult.crsfCustomTelemetryEnabled then
            local requestedSensorsBySid = rf2.executeScript("rf2tlm_sensors", initTaskResult.crsfCustomTelemetrySensors)
            crsfTelemetryTask = rf2.executeScript("rf2tlm", requestedSensorsBySid)
        elseif sportTelemetryPush() ~= nil then
            frskyTelemetryTask = rf2.executeScript("rf2frsky_tlm")
        end
        if initTask.useAdjustmentTeller then
            adjTellerTask = rf2.executeScript("adj_teller")
        end
        updateModelName = initTask.updateModelName
        initTask = nil
        isInitialized = true
        setState(widget, "connected")
    end

    if getRSSI() == 0 and not rf2.runningInSimulator then
        return
    end

    -- MSP and custom telemetry share EdgeTX's receive FIFO. A deferred service
    -- pass must not consume a configuration reply that the UI still awaits.
    if rf2.mspQueue and rf2.mspQueue.isProcessed and not rf2.mspQueue:isProcessed() then
        return
    end

    stage = "adjustment teller"
    rf2.diagnosticStage = stage
    if adjTellerTask and adjTellerTask.run() == 2  then
        -- no adjustment sensors found
        adjTellerTask = nil
    end

    stage = "telemetry"
    rf2.diagnosticStage = stage
    if crsfTelemetryTask then
        crsfTelemetryTask.run()
    elseif frskyTelemetryTask then
        frskyTelemetryTask.run()
    end
end

-- widget is optional and will be provided by the RfTool widget.
-- If the background script runs as a special function, widget will be nil.
local function runProtected(widget)
    -- UI/profile work may already have spent most of this widget callback.
    -- Defer without changing connection/retry state; the next pass resumes it.
    local used = getCurrentUsage and getCurrentUsage()
    if used and used >= 35 then return 0 end
    local now = rf2.clock()
    if now < retryAt then
        if widget then pcall(widget.setState, widget, "background error") end
        return 0
    end
    local ok, err = pcall(run, widget)
    if ok then
        if failures > 0 and widget and widget.state == "background error" then
            pcall(widget.setState, widget, resumeState or lastState or "initializing")
        end
        failures, retryAt, resumeState = 0, 0, nil
        diagnostics.recover("background")
    else
        failures = math.min(failures + 1, 5)
        retryAt = now + failures -- bounded 1..5 second retry delay
        diagnostics.report("background", err, stage)
        if widget then
            -- RF Tool owns armed/disarmed transitions. Restore its actual state
            -- after recovery, unless this pass already published a newer one.
            if widget.state ~= "background error" then resumeState = widget.state end
            pcall(widget.setState, widget, "background error")
        end
    end
    return 0
end

return runProtected
