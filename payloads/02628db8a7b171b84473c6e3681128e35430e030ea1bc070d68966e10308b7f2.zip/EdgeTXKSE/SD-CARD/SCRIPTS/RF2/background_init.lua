local initializationDone = false
local nameUpdateNeeded = false
local crsfCustomTelemetryEnabled = false
local crsfCustomTelemetrySensors = nil
local craftName = nil

local settings = rf2.loadSettings()
local autoSetName = settings.autoSetName == 1 or false
local useAdjustmentTeller = settings.useAdjustmentTeller == 1 or false

local pilotConfigSetMagic = -765
local function pilotConfigSet()
    model.setGlobalVariable(7, 8, pilotConfigSetMagic)
end

local function pilotConfigHasBeenSet()
    return model.getGlobalVariable(7, 8) == pilotConfigSetMagic
end

local function setTimer(index, paramValue)
    model.resetTimer(index)
    local timer = model.getTimer(index)
    timer.value = paramValue
    model.setTimer(index, timer)
end

local function setParam(paramType, paramValue)
    --rf2.print(paramType .. ": " .. paramValue)
    if paramType == "NONE" then return end
    if paramType == "TIMER1" then
        setTimer(0, paramValue)
    elseif paramType == "TIMER2" then
        setTimer(1, paramValue)
    elseif paramType == "TIMER3" then
        setTimer(2, paramValue)
    elseif paramType == "GV1" then
        model.setGlobalVariable(0, 0, paramValue)
    elseif paramType == "GV2" then
        model.setGlobalVariable(1, 0, paramValue)
    elseif paramType == "GV3" then
        model.setGlobalVariable(2, 0, paramValue)
    elseif paramType == "GV4" then
        model.setGlobalVariable(3, 0, paramValue)
    elseif paramType == "GV5" then
        model.setGlobalVariable(4, 0, paramValue)
    elseif paramType == "GV6" then
        model.setGlobalVariable(5, 0, paramValue)
    elseif paramType == "GV7" then
        model.setGlobalVariable(6, 0, paramValue)
    elseif paramType == "GV8" then
        model.setGlobalVariable(7, 0, paramValue)
    elseif paramType == "GV9" then
        model.setGlobalVariable(8, 0, paramValue)
    end
end

-- Shared with KSE4/KSE5: a display-name restore keeps the aircraft identity.
-- A fresh table is published only after a new controller initialization.
local nameSession = nil
local nameSavePending = nil
local nameResetDone = false
local nameResetPending = nil
local nameResetAttempts, nameResetRetryAt = 0, 0
local initialModel = model.getInfo()
local function sameModel(info, expected)
    if expected.filename and expected.filename ~= "" then
        return info.filename == expected.filename
    end
    return info.id == expected.id
end

local function writeModelName(info, name)
    if info.name ~= name then
        info.name = name
        model.setInfo(info)
    end
    -- EdgeTX may limit the stored name length. Publish the actual display name.
    return model.getInfo().name
end

local function setModelName(name)
    if not name or name == "" then return true end
    local info = model.getInfo()
    if not sameModel(info, initialModel) then nameSavePending = nil; return true end
    if nameSession then
        -- A short dropout must not overwrite a manual rename or another model.
        if info.name ~= nameSession.displayName then return true end
        nameSession.displayName = writeModelName(info, name)
        return true
    end
    if nameSavePending then
        if info.name ~= nameSavePending.name then nameSavePending = nil; return true end
        local used = getCurrentUsage and getCurrentUsage()
        if used and used > 20 then return false end
        rf2.diagnosticStage = "saving original model name"
        -- Never rename the radio until its original name is recoverable.
        local saved = rf2.saveSettings(nameSavePending.settings)
        nameSavePending = nil
        if not saved then return true end -- Leave name unchanged and surface the diagnostic.
    elseif info.name ~= name then
        -- Read preferences on one pass and persist on the next, outside the
        -- MSP reply callback. saveSettings still merges concurrent UI edits.
        local settings = rf2.loadSettings()
        settings.previousModelName = info.name
        nameSavePending = {settings = settings, name = info.name}
        return false
    end
    local originalName = info.name
    local displayName = writeModelName(info, name)
    nameSession = {
        version = 1, filename = info.filename, id = info.id,
        craftName = displayName, displayName = displayName,
        originalName = originalName
    }
    rf2.modelNameSession = nameSession
    return true
end

local function resetModelName(temporary)
    -- Restore the display name first, then give persistence its own callback.
    -- Keep the recovery flag until the pending/backup/primary transaction is
    -- verified; a failed save must not permanently latch recovery as finished.
    if not temporary then
        if nameResetDone then return end
        if nameResetPending then
            if nameResetAttempts >= 3 or rf2.clock() < nameResetRetryAt then return end
            local used = getCurrentUsage and getCurrentUsage()
            if used and used > 20 then return end
            local info = model.getInfo()
            if not sameModel(info, initialModel) or info.name ~= nameResetPending.name then
                nameResetPending, nameResetDone = nil, true
                return
            end
            rf2.diagnosticStage = "saving name recovery"
            nameResetAttempts = nameResetAttempts + 1
            nameResetRetryAt = rf2.clock() + nameResetAttempts
            if rf2.saveSettings(nameResetPending.settings) then
                nameResetPending, nameResetDone = nil, true
            end
            return
        end
    end
    -- Brief disconnects can restore directly from this model's session. Keep
    -- disk recovery/persistence on the full-reset path, not each link flicker.
    local settings = temporary and nameSession and nameSession.originalName
        and {previousModelName = nameSession.originalName} or rf2.loadSettings()
    if not settings.previousModelName then
        if not temporary then nameResetDone = true end
        return
    end
    local info = model.getInfo()
    local session = rf2.modelNameSession
    -- Ignore stale metadata after an actual radio model/manual name change.
    if not sameModel(info, initialModel) or
        (session and (not sameModel(info, session) or info.name ~= session.displayName)) then
        if not temporary then nameResetDone = true end
        return
    end
    local displayName = writeModelName(info, settings.previousModelName)
    if session then session.displayName = displayName end
    -- Keep the recovery name until the full disconnect is confirmed.
    if temporary then return end
    settings.previousModelName = nil
    nameResetPending = {settings = settings, name = displayName}
end

local function updateModelName(connected)
    if connected then
        rf2.modelName = craftName
        if autoSetName then
            return setModelName(craftName)
        else
            rf2.modelNameSession = nil
        end
    else
        resetModelName(true)
        -- RF Tool also reads this value before falling back to the TX name.
        rf2.modelName = nil
    end
    return true
end

local function onPilotConfigReceived(_, config)
    if rf2.apiVersion >= 12.09 then
        -- RF 2.0 to 2.2 (MSP API 12.06 to 12.08) used settings.autoSetName (a global radio setting) to set the model name.
        -- RF 2.3+ (MSP API 12.09+) uses a setting on the model to set the model name.
        local getBit = rf2.executeScript("F/getBit")
        autoSetName = getBit(config.model_flags.value, config.model_flags.MODEL_SET_NAME) == 1 or false
        --rf2.print("MODEL_SET_NAME: " .. tostring(autoSetName))
    end

    -- A newly owned RF core still needs the FC's name policy when this model
    -- already has its pilot parameters applied. Read policy without resetting
    -- timers/GVs a second time (for example, a connected dashboard reload).
    if pilotConfigHasBeenSet() then return end

    local paramValue = config.model_param1_value.value
    local paramType = config.model_param1_type.table[config.model_param1_type.value]
    setParam(paramType, paramValue)

    paramValue = config.model_param2_value.value
    paramType = config.model_param2_type.table[config.model_param2_type.value]
    setParam(paramType, paramValue)

    paramValue = config.model_param3_value.value
    paramType = config.model_param3_type.table[config.model_param3_type.value]
    setParam(paramType, paramValue)

    pilotConfigSet()
end

local sensorsDiscoveredTimeout = 0
local hasSensor = rf2.executeScript("F/hasSensor")
local function waitForCrsfSensorsDiscovery()
    if crossfireTelemetryPush() == nil then
        -- Model does not use CRSF/ELRS
        return 0
    end

    local sensorsDiscovered = hasSensor("TPWR") or hasSensor("RFMD")
    if not sensorsDiscovered then
        -- Wait 2 secs to discover all CRSF sensors before continuing.
        sensorsDiscoveredTimeout = rf2.clock() + 2
    end

    if sensorsDiscoveredTimeout ~= 0 then
        if rf2.clock() < sensorsDiscoveredTimeout then
            return 1 -- wait for sensors to be discovered
        end
        sensorsDiscoveredTimeout = 0
    end

    --rf2.print("Sensors already discovered")
    return 0
end

local queueInitialized = false
local function initializeQueue()
    --rf2.print("Initializing MSP queue")

    rf2.useApi("mspApiVersion").getApiVersion(
        function(_, version)
            rf2.apiVersion = version

            rf2.useApi("mspName").getModelName(function(_, name)
                craftName = name
                rf2.modelName = name
            end)

            if rf2.apiVersion >= 12.07 then
                rf2.useApi("mspPilotConfig").read(onPilotConfigReceived)

                if crossfireTelemetryPush() then
                    rf2.useApi("mspTelemetryConfig").getTelemetryConfig(
                        function(_, config)
                            crsfCustomTelemetryEnabled = config.crsf_telemetry_mode.value == 1
                            if crsfCustomTelemetryEnabled then
                                crsfCustomTelemetrySensors = config.crsf_telemetry_sensors
                            else
                                crsfCustomTelemetrySensors = nil
                            end
                        end)
                end
            end

            rf2.useApi("mspSetRtc").setRtc(
                function()
                    -- The MSP reply already consumed part of this callback.
                    -- Restore/name persistence runs in later service passes.
                    nameUpdateNeeded = true
                    initializationDone = true
                end)
        end)
end

local function initialize(modelIsConnected)
    if modelIsConnected then
        -- Reconnection owns the recovery name again. Never commit an old
        -- disconnected proxy after a new controller session has started.
        nameResetPending = nil
        nameResetAttempts, nameResetRetryAt = 0, 0
        local sensorsDiscoveryWaitState = waitForCrsfSensorsDiscovery()
        if sensorsDiscoveryWaitState == 1 then
            return false
        end
    end

    if not modelIsConnected then
        if pilotConfigHasBeenSet() then
            rf2.executeScript("F/pilotConfigReset")()
        end
        resetModelName()
        return false
    end

    if not queueInitialized then
        initializeQueue()
        queueInitialized = true
    end

    if initializationDone and nameUpdateNeeded then
        if not updateModelName(true) then return false end
        nameUpdateNeeded = false
        playTone(784, 125, 0)   -- G5
        playTone(880, 125, 0)   -- A5
        playTone(988, 125, 0)   -- B5
        playTone(1047, 125, 0)  -- C6
        -- Publishing "connected" can start widget/profile work. Do that on
        -- the following pass, after the settings transaction has returned.
        return false
    end

    rf2.mspQueue:processQueue()

    return initializationDone and not nameUpdateNeeded
end

local function run(modelIsConnected)
    return
    {
        isInitialized = initialize(modelIsConnected),
        crsfCustomTelemetryEnabled = crsfCustomTelemetryEnabled,
        crsfCustomTelemetrySensors = crsfCustomTelemetrySensors
    }
end

local function reset()
    rf2.mspQueue:clear()
    rf2.apiVersion = nil
end

return { run = run, reset = reset, useAdjustmentTeller = useAdjustmentTeller,
    updateModelName = updateModelName }
