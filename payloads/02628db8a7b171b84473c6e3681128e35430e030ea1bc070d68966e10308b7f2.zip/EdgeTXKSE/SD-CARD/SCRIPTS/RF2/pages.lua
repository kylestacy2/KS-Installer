local PageFiles = {}
local settings = rf2.loadSettings()
local defaults = rf2.executeScript("F/pageDefaults")

local hangar=rf2.executeScript("F/hangarConfig").enabled()

local function addPage(key, title, script)
    local visible = settings[key]
    if visible == nil then visible = defaults[key] end
    if hangar or visible == 1 then
        PageFiles[#PageFiles + 1] = { title = title, script = script }
    end
end

addPage("showStatus", "Status", "status")
addPage("showRates", "Rates", "rates")
addPage("showRateDynamics", "Rate Dynamics", "rate_dynamics")
addPage("showPidGains", "PID Gains", "profile_pids")
addPage("showPidController", "PID Controller", "profile_pidcon")
addPage("showProfileVarious", "Profile - Various", "profile_various")
addPage("showProfileRescue", "Profile - Rescue", "profile_rescue")
addPage("showProfileGovernor", "Governor", "profile_governor")
if rf2.apiVersion >= 12.09 then
    addPage("showBattery", "Battery", "battery")
    addPage("showSmartFuel", "Smart Fuel", "smartfuel")
end
addPage("showServos", "Servos", "servos")
addPage("showMixer", "Mixer", "mixer")
addPage("showSwashTrim", "Swash Trim", "swash_trim")
addPage("showGyroFilters", "Gyro Filters", "filters")
addPage("showGovernor", "Governor Setup", "governor")
addPage("showAccelerometerTrim", "Accelerometer Trim", "accelerometer")
addPage("showEscSensor", "ESC Sensor", "esc_sensor")

if rf2.apiVersion >= 12.07 then
    addPage("showModelOnTx", "Model", "model")
    addPage("showExperimental", "Experimental (!)", "experimental")
    if rf2.apiVersion >= 12.09 then
        addPage("showAm32", "ESC - AM32", "esc_am32")
        addPage("showBlheliS", "ESC - BLHeli_S", "esc_blhelis")
        addPage("showBluejay", "ESC - Bluejay", "esc_bluejay")
    end
    addPage("showFlyRotor", "ESC - FLYROTOR", "esc_flyrotor")
    addPage("showPlatinumV5", "ESC - HW Platinum V5", "esc_hwpl5")
    addPage("showTribunus", "ESC - Scorpion Tribunus", "esc_scorp")
    if rf2.apiVersion >= 12.08 then
        addPage("showXdfly", "ESC - XDFly/OMP/ZTW", "esc_xdfly")
    end
    addPage("showYge", "ESC - YGE", "esc_yge")

    PageFiles[#PageFiles + 1] = { title = "Settings", script = "settings" }
end

return PageFiles
