--
-- Rotorflight Custom Telemetry Decoder for ELRS
--

local RFSensors = ...

local function decU8(data, pos)
    return data[pos], pos+1
end

local function decU16(data, pos)
    return bit32.lshift(data[pos],8) + data[pos+1], pos+2
end

local telemetryFrameId = 0
local telemetryFrameSkip = 0
local telemetryFrameCount = 0

local function crossfirePop()
    local CRSF_FRAME_CUSTOM_TELEM   = 0x88
    local command, data = crossfireTelemetryPop()
    if command and data then
        if command == CRSF_FRAME_CUSTOM_TELEM then
            -- A short custom frame must not throw into background retry/backoff.
            if #data < 3 then return true end
            local fid, sid, val
            local ptr = 3
            fid,ptr = decU8(data, ptr)
            local delta = bit32.band(fid - telemetryFrameId, 0xFF)
            if delta > 1 then
                telemetryFrameSkip = telemetryFrameSkip + 1
            end
            telemetryFrameId = fid
            telemetryFrameCount = telemetryFrameCount + 1
            while ptr < #data do
                sid,ptr = decU16(data, ptr)
                local sensor = RFSensors[sid]
                if sensor then
                    local size = sensor[5]
                    if size == -1 then size = data[ptr] and data[ptr] + 1 end
                    if not size or ptr + size - 1 > #data then break end
                    val,ptr = (sensor[4])(data, ptr)
                    if val then
                        setTelemetryValue(sid, 0, 0, val, sensor[2], sensor[3], sensor[1])
                    end
                else
                    break
                end
            end
            setTelemetryValue(0xEE01, 0, 0, telemetryFrameCount, UNIT_RAW, 0, "*Cnt")
            setTelemetryValue(0xEE02, 0, 0, telemetryFrameSkip, UNIT_RAW, 0, "*Skp")
            --setTelemetryValue(0xEE03, 0, 0, telemetryFrameId, UNIT_RAW, 0, "*Frm")
        end
        return true
    end
    return false
end

local function crossfirePopAll()
    -- A widget shares its instruction budget with its UI and connection work.
    -- Leave the rest of a telemetry burst in EdgeTX's FIFO for the next pass.
    local used = getCurrentUsage and getCurrentUsage()
    local frames = used and 16 or 2
    for _ = 1, frames do
        if used and getCurrentUsage() >= 45 then break end
        if not crossfirePop() then break end
    end
end

return {
    run = crossfirePopAll
}
