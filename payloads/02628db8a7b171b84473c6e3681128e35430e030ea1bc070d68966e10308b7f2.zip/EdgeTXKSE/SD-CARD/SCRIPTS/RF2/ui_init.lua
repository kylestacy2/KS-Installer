local mspApiVersion = rf2.useApi("mspApiVersion")
local returnTable = { f = nil, t = "" }
local apiVersion
local lastRunTS
local requestOwner

local function init()
    if getRSSI() == 0 and not rf2.offlineSimulator then
        returnTable.t = "Waiting for connection..."
        returnTable.detail = "Connect your Flight Controller"
        return false
    end

    if returnTable.detail then
        returnTable.t = "Loading Setup..."
        returnTable.detail = nil
    end

    if not apiVersion and (not lastRunTS or lastRunTS + 2 < rf2.clock()) and
        (not requestOwner or rf2.mspQueue:isOwnerProcessed(requestOwner)) then
        returnTable.t = "Loading Setup..."
        requestOwner = {timeout = 12, onError = function()
            returnTable.t = "No API reply. Retrying connection..."
            lastRunTS = rf2.clock()
        end}
        rf2.mspQueue:withOwner(requestOwner, function()
            mspApiVersion.getApiVersion(function(_, version) apiVersion = version end)
        end)
        lastRunTS = rf2.clock()
    end

    rf2.mspQueue:processQueue()

    if rf2.mspQueue:isProcessed() and apiVersion then
        local apiVersionAsString = string.format("%.2f", apiVersion)
        if apiVersion < 12.06 then
            returnTable.t = "This version of the Lua\nscripts can't be used\nwith the selected model\nwhich has version "..apiVersionAsString.."."
        else
            -- received correct API version, proceed
            rf2.apiVersion = apiVersion
            collectgarbage()
            return true
        end
    end

    return false
end

returnTable.f = init

return returnTable
