local lcdShared = rf2.executeScript("LCD/shared")
local waitMessage = rf2.executeScript("LCD/waitMessage", lcdShared)
local messageBox = nil -- loaded on demand
local popupMenu = nil  -- loaded on demand
local Page = nil       -- loaded on demand
local mainMenu = nil   -- loaded on demand

local PageFiles
local CurrentPageIndex = 1

local uiStatus =
{
    init     = 1,
    mainMenu = 2,
    pages    = 3,
    confirm  = 4,
}

local uiState = uiStatus.init
local prevUiState
local pageState = lcdShared.pageStatus.display
local init
local queue = rf2.mspQueue
local cleanup = rf2.executeScript("F/pageCleanup")
local diagnostics = rf2.executeScript("F/diagnostics")
local owner, failure
local saveComplete, exitRequested = false, false

local function newOwner()
    local nextOwner = {timeout = 12}
    nextOwner.onError = function(reason, command)
        if owner == nextOwner then failure = reason .. " (MSP " .. command .. ")" end
    end
    return nextOwner
end

local function scoped(callback, ...)
    local ok, result = pcall(queue.withOwner, queue, owner, callback, ...)
    if not ok then
        queue:cancelOwner(owner)
        failure = "Could not complete this action."
    end
    return result
end

-- Color radios on EdgeTX >= 2.11 do not send EVT_VIRTUAL_ENTER anymore after EVT_VIRTUAL_ENTER_LONG
local useKillEnterBreak = not(lcd.setColor and (select(3, getVersion()) >= 3 or select(3, getVersion()) >= 2 and select(4, getVersion()) >= 11))

rf2.setWaitMessage = function(message)
    waitMessage.text = message
end

rf2.clearWaitMessage = function()
    waitMessage.text = nil
end

local function invalidatePages()
    queue:cancelOwner(owner)
    cleanup.release(Page)
    owner = nil
    Page = nil
    saveComplete = false
    pageState = lcdShared.pageStatus.display
    rf2.clearWaitMessage()
end

rf2.onPageReady = function(page)
    page.isReady = true
    -- ESC programming pages complete by reading their parameters back.
    if page == Page and pageState == lcdShared.pageStatus.saving then saveComplete = true end
end

local function rebootFc()
    --rf2.print("Attempting to reboot the FC...")
    rf2.setWaitMessage("Rebooting...")
    pageState = lcdShared.pageStatus.rebooting
    rf2.mspQueue:add({
        command = 68, -- MSP_REBOOT
        processReply = function(self, buf)
            saveComplete = true
        end,
        simulatorResponse = {}
    })
end

local function createMessageBox(title, text)
    messageBox = rf2.executeScript("LCD/messageBox", lcdShared)
    messageBox.show(title, text)
end

rf2.settingsSaved = function(eepromWrite, reboot)
    -- check if this page requires writing to eeprom to save (most do)
    if eepromWrite then
        -- don't write again if we're already responding to earlier page.write()s
        if pageState ~= lcdShared.pageStatus.eepromWrite then
            pageState = lcdShared.pageStatus.eepromWrite
            local mspEepromWrite =
            {
                command = 250, -- RF API 12.08+ defers persistence while armed
                deferOnDisarm = true,
                processReply = function(self, buf)
                    if reboot then
                        rebootFc()
                    else
                        saveComplete = true
                    end
                end,
                processDeferredReply = function(self)
                    saveComplete = true
                    if not rf2.saveWarningShown then
                        createMessageBox("Applied in RAM", "Settings will be saved\nafter disarming.")
                        rf2.saveWarningShown = true
                    end
                end,
                errorHandler = function(self)
                    createMessageBox("Save error", "Save not confirmed.\nDisarm, reload and check.")
                end,
                simulatorResponse = {}
            }
            rf2.mspQueue:add(mspEepromWrite)
        end
    elseif pageState ~= lcdShared.pageStatus.eepromWrite then
        -- If we're not already trying to write to eeprom from a previous save, then we're done.
        -- ESC writes may still be queued when this notification is made.
        -- Wait for their acknowledgements before disposing of the owner.
        saveComplete = true
    end
end

local function saveSettings()
    if Page and Page.isReady and pageState == lcdShared.pageStatus.display then
        queue:cancelOwner(owner)
        owner = newOwner()
        saveComplete = false
        rf2.setWaitMessage("Updating...")
        pageState = lcdShared.pageStatus.saving
        scoped(Page.write, Page)
    end
end

local function confirm(page)
    prevUiState = uiState
    uiState = uiStatus.confirm
    invalidatePages()
    Page = rf2.executeScript(page)
    owner = newOwner()
    Page.lcdp = rf2.executeScript("LCD/page", lcdShared, Page)
end

local function createPopupMenu()
    local menu = { title = "Menu:", items = {} }

    if uiState == uiStatus.pages then
        if Page.isReady and not Page.readOnly then
            menu.items[#menu.items + 1] = { text = "Save", click = saveSettings }
        end
        menu.items [#menu.items + 1] = { text = "Reload", click = invalidatePages }
    end

    menu.items[#menu.items + 1] = { text = "Reboot", click = function()
        owner = owner or newOwner()
        scoped(rebootFc)
    end }
    menu.items[#menu.items + 1] = { text = "Acc Cal", click = function() confirm("CONFIRM/acc_cal.lua") end }

    popupMenu = rf2.executeScript("LCD/popupMenu", lcdShared)
    popupMenu.show(menu)
end

local function incPage(inc)
    CurrentPageIndex = rf2.executeScript("F/incMax")(CurrentPageIndex, inc, #PageFiles)
    invalidatePages()
end

local function reloadPageFiles(setCurrentPageToLastPage)
    PageFiles = rf2.executeScript("pages")
    if setCurrentPageToLastPage then
        CurrentPageIndex = #PageFiles
    end
end

local function run_ui(event)
    local pendingCleanup = cleanup.pending()
    local cleanupError = cleanup.takeError()
    if cleanupError then failure = cleanupError end
    local notice = diagnostics.takeNotice()
    if notice then failure = notice end
    if Page and not rf2.offlineSimulator and getRSSI() == 0 then
        failure = failure or "Connection lost. Reconnect and reload."
    end
    if failure then
        local message = failure
        failure, exitRequested = nil, false
        invalidatePages()
        createMessageBox("Action not confirmed", message .. "\nReload and check the FC values.")
    end
    if exitRequested then
        if not pendingCleanup then return 2 end
        rf2.setWaitMessage("Releasing setup controls...")
        waitMessage.update()
        queue:processQueue()
        return 0
    end
    if saveComplete and queue:isOwnerProcessed(owner) then invalidatePages() end
    -- if event and event ~= 0 then
    --     rf2.print("uiState: " .. uiState .. " pageState: " .. pageState .. " Event: " .. string.format("0x%X", event))
    -- end

    if messageBox and messageBox.update(event) then
        if lcdShared.forceReload then
            messageBox = nil
            invalidatePages()
        end
    elseif popupMenu and popupMenu.update(event) then
        if popupMenu.menu == nil then
            popupMenu = nil
        end
    elseif uiState == uiStatus.init then
        lcd.clear()
        lcdShared.drawScreenTitle("Rotorflight " .. rf2.luaVersion)
        init = init or rf2.executeScript("ui_init")
        lcdShared.drawTextMultiline(4, rf2.radio.yMinLimit, init.t)
        if not init.f() then
            return 0
        end
        init = nil
        reloadPageFiles()
        invalidatePages()
        uiState = prevUiState or uiStatus.mainMenu
        prevUiState = nil
    elseif uiState == uiStatus.mainMenu then
        if not mainMenu then
            mainMenu = rf2.executeScript("LCD/mainMenu", lcdShared, PageFiles, CurrentPageIndex)
        end
        if event == EVT_VIRTUAL_EXIT then
            invalidatePages()
            if not cleanup.pending() then return 2 end
            exitRequested = true
        elseif event == EVT_VIRTUAL_ENTER then
            CurrentPageIndex = mainMenu.getSelectedPageIndex()
            uiState = uiStatus.pages
        elseif event == EVT_VIRTUAL_ENTER_LONG then
            if useKillEnterBreak then lcdShared.killEnterBreak = true end
            createPopupMenu()
        else
            mainMenu.update(event)
        end
    elseif uiState == uiStatus.pages then
        mainMenu = nil
        if Page then
            local previous = pageState
            local nextState = scoped(Page.lcdp.update, pageState, event)
            -- Immediate actions (e.g. Copy) can start an owned save inside
            -- update(); do not overwrite its state with the editor's return.
            if pageState == previous then pageState = nextState or previous end
        end

        if pageState == lcdShared.pageStatus.display then
            if event == EVT_VIRTUAL_PREV_PAGE then
                incPage(-1)
                killEvents(event) -- X10/T16 issue: pageUp is a long press
            elseif event == EVT_VIRTUAL_NEXT_PAGE then
                incPage(1)
            elseif event == EVT_VIRTUAL_ENTER_LONG then
                if useKillEnterBreak then lcdShared.killEnterBreak = true end
                createPopupMenu()
            elseif event == EVT_VIRTUAL_EXIT then
                invalidatePages()
                uiState = uiStatus.mainMenu
                if rf2.logfile then
                    io.close(rf2.logfile)
                    rf2.logfile = nil
                end
                return 0
            end
        end
        if not Page then
            --rf2.showMemoryUsage("before loading page")
            Page = rf2.executeScript("PAGES/" .. PageFiles[CurrentPageIndex].script)
            owner = newOwner()
            Page.lcdp = rf2.executeScript("LCD/page", lcdShared, Page)
            --rf2.showMemoryUsage("after loading page")
        end
    elseif uiState == uiStatus.confirm then
        Page.lcdp.draw(pageState)
        if event == EVT_VIRTUAL_ENTER then
            uiState = uiStatus.init
            init = Page.init
            invalidatePages()
        elseif event == EVT_VIRTUAL_EXIT then
            invalidatePages()
            uiState = prevUiState
            prevUiState = nil
        end
    end

    waitMessage.update()

    if getRSSI() == 0 and not rf2.offlineSimulator then
        lcd.drawText(rf2.radio.NoTelem[1], rf2.radio.NoTelem[2], rf2.radio.NoTelem[3], rf2.radio.NoTelem[4])
    end

    rf2.mspQueue:processQueue()

    return 0
end

rf2.reloadPage = invalidatePages
rf2.reloadMainMenu = reloadPageFiles

return run_ui
