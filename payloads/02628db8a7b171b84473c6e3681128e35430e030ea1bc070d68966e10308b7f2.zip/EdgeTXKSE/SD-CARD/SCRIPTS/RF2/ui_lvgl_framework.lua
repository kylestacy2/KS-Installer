local waitMessage = rf2.executeScript("LVGL/waitMessage")
local edits = rf2.executeScript("F/editSession")
local ui = { status = {init = 1, mainMenu = 2, pages = 3, exit = 4}, state = 1 }
local PageFiles, Page, HomeStatus, MainMenuView, PageView
local CurrentPageIndex = -1
local baseline, loadedContext, expected, resultMessage
local owner, operation, readyPending, overlay, overlayBack, errorPending
local saveAck, saveDeferred, rebootPending, saveWaitingSince
local saveResult
local queue = rf2.mspQueue
local cleanup = rf2.executeScript("F/pageCleanup")
local diagnostics = rf2.executeScript("F/diagnostics")
local exitRequested = false
local pendingExitPreferences=false
local fieldApply, dashboardAfterSave
local startSave, queueSave
local hangarConfig=rf2.executeScript('F/hangarConfig')
local openingPending=true
local initialPage
local lastSessionReport
local setupRoutes={home=true,rates=true,profile_pids=true,profile_governor=true,settings=true}
local navigation = rf2.executeScript("F/navigation")
local navigationState = {group="favorites", page=1}

local function workflow() return rf2.executeScript("LVGL/workflow") end
local function changeCount() return edits.countChanges(Page, baseline) end
local function busy() return operation == "saveRequested" or operation == "startingSave" or operation == "saving" or operation == "verifying" or operation == "waitingSave" or operation == "cleanup" or operation == "switching" end
local function nativeEpoch()
    if lvgl and type(lvgl.appServiceProtocol)=='function' and lvgl.appServiceProtocol()==1 and type(lvgl.appSessionEpoch)=='function' then
        local value=lvgl.appSessionEpoch();if value and value>0 then return value end
    end
end
local function captureEpoch()
    local value=nativeEpoch()
    if rf2.nativeSessionEpoch~=value then rf2.sessionWritePending=nil;lastSessionReport=nil end
    rf2.nativeSessionEpoch=value
end
local function cancelNativeEditor()
    if lvgl and type(lvgl.cancelAppNumber)=='function' then lvgl.cancelAppNumber() end
end
local function scoped(callback, ...)
    local ok, result = pcall(queue.withOwner, queue, owner, callback, ...)
    if not ok then
        queue:cancelOwner(owner)
        errorPending = {reason = "Could not complete this action. Reload and try again.", saving = busy()}
    end
    return result
end
local function newOwner()
    local nextOwner = {timeout = 12}
    nextOwner.onError = function(reason, command)
        if owner ~= nextOwner then return end
        errorPending = {reason = reason, command = command, saving = busy()}
    end
    return nextOwner
end

ui.setWaitMessage = function(message, detail)
    waitMessage.setWaitMessage(Page and Page.title or "", message, ui.back, detail)
end
ui.clearWaitMessage = function()
    if waitMessage.message then ui.redraw = true end
    waitMessage.clearWaitMessage()
end
ui.refresh = function() readyPending = Page end
ui.deferReload = function() ui.reloadRequested = true end

ui.unloadPage = function()
    cancelNativeEditor()
    if Page and ui.sessionStatus then
        lastSessionReport=ui.sessionStatus(false)
        -- Discarded local drafts are no longer pending edits.
        if lastSessionReport.state==3 then lastSessionReport.state=0;lastSessionReport.changes=0 end
    end
    saveResult = nil
    rf2.hangarTick=nil
    fieldApply = nil
    queue:cancelOwner(owner)
    cleanup.release(Page)
    if MainMenuView and MainMenuView.clear then MainMenuView.clear() end
    -- 800x480 and other studio menus can release their page context while
    -- retaining the renderer. Older/special-size menus keep the old lifetime.
    if not MainMenuView or not MainMenuView.clear then MainMenuView=nil end
    Page, HomeStatus, PageView = nil, nil, nil
    baseline, loadedContext, readyPending = nil, nil, nil
    operation, overlay, overlayBack, errorPending = nil, nil, nil, nil
    saveAck, saveDeferred, rebootPending, saveWaitingSince = false, false, false, nil
    ui.clearWaitMessage()
    ui.redraw = false
    ui.reloadRequested = false
end

ui.exit = function()
    dashboardAfterSave = false
    ui.unloadPage()
    if hangarConfig.enabled() and hangarConfig.get().openingPage=='last' and rf2.hangarLastPage then
        pendingExitPreferences,exitRequested,operation=true,true,'cleanup'
    elseif cleanup.pending() then
        exitRequested, operation = true, "cleanup"
        ui.setWaitMessage("Releasing setup controls...")
    else
        ui.state = ui.status.exit
    end
end

ui.loadMainMenu = function(setCurrentPageToLastPage)
    PageFiles = rf2.executeScript("pages")
    -- This already owns a preparation pass. Load the renderer here so the
    -- first visible menu does not also pay for its theme/navigation modules.
    MainMenuView = MainMenuView or rf2.executeScript("LVGL/mainMenu")
    if setCurrentPageToLastPage then CurrentPageIndex = #PageFiles end
end

ui.showPage = function()
    if not Page then return end
    -- LVGL can evaluate the outgoing scene during a deferred reload. Keep
    -- its getters bound to their owning page, never the replacement page.
    local page = Page
    rf2.diagnosticStage = "render page"
    rf2.diagnosticPage = page.uiScript or page.title
    overlay, overlayBack = nil, nil
    ui.clearWaitMessage()
    ui.redraw = false
    page.back = function() ui.requestLeave(ui.showMainMenu) end
    page.uiEditField = ui.openField
    page.uiRun = scoped
    page.uiCanInteract = function() return Page == page and not operation and not overlay end
    page.uiCanSave = function()
        return page.uiCanInteract() and page.isReady and not page.readOnly
            and type(page.write) == "function" and (not baseline or changeCount() > 0)
    end
    page.uiHasChanges = function() return Page == page and baseline and edits.countChanges(page,baseline)>0 or false end
    page.uiSaveState = function()
        if Page ~= page then return nil end
        if saveResult and (page.uiHasChanges() or edits.context(page) ~= loadedContext) then
            saveResult = nil
        end
        return saveResult
    end
    page.uiSaved = function() return page.uiSaveState() == "saved" end
    page.uiSaveText = function()
        if page.hangarSettings or not baseline then return "Save" end
        local state = page.uiSaveState()
        return state == "saved" and "Saved" or state == "applied" and "Applied" or "Save"
    end
    page.uiSaveNotice = function()
        if page.uiSaveState() == "applied" then return "Applied - saves on disarm" end
    end
    page.uiRefresh = function() ui.redraw=true end
    page.uiOpenScript = ui.openScript
    page.uiSelectBattery = ui.selectBattery
    page.uiNative = function() page.uiHangarLegacy=true;ui.redraw=true end
    page.uiNotice = function(message)
        overlay,overlayBack="notice",ui.showPage
        workflow().show(page.title,{message},ui.showPage)
    end
    page.uiProfileStatus = function()
        for _,f in ipairs(page.fields)do
            if f.t=="Current PID profile" or f.t=="Current rate profile" then
                return (f.t=="Current PID profile" and "PID " or "Rate ")..(f.data.value~=nil and tostring(f.data.value+1) or "--")
            end
        end
        return page.uiStatus and page.uiStatus() or ""
    end
    page.uiSave = function()
        -- Native LVGL may retain callbacks from a retired page/scene.
        if page.uiCanSave() then queueSave() end
    end
    page.uiMenu = ui.showPopupMenu
    page.uiChanged = function(index)
        local field = page.fields[index]
        return Page == page and baseline and baseline[index] ~= nil and field and field.data
            and field.data.value ~= baseline[index] or false
    end
    page.uiStatus = function()
        if Page ~= page then return "Loading values..." end
        local prefix = rf2.offlineSimulator and "PREVIEW  |  " or ""
        local count = baseline and edits.countChanges(page, baseline) or 0
        if count > 0 then return prefix .. count .. " unsaved change" .. (count == 1 and "" or "s") end
        return prefix .. (resultMessage or (baseline and "No unsaved changes" or "Values loaded"))
    end
    PageView = PageView or rf2.executeScript("LVGL/page")
    PageView.show(page)
    ui.state = ui.status.pages
end

ui.loadPage = function(verification)
    if type(verification) ~= "table" then verification = nil end
    local script=PageFiles[CurrentPageIndex].script
    rf2.diagnosticStage,rf2.diagnosticPage = "load page",script
    local view=Page and Page.uiScript==script and {axis=Page.uiAxis,panel=Page.uiPanel} or nil
    ui.unloadPage()
    captureEpoch()
    owner = newOwner()
    Page = rf2.executeScript("PAGES/" .. script)
    Page.uiScript=script
    if view then Page.uiAxis,Page.uiPanel=view.axis,view.panel end
    expected = verification and verification.expected
    loadedContext = verification and verification.context
    resultMessage = verification and verification.message
    saveDeferred = verification and verification.deferred or false
    operation = expected and "verifying" or "loading"
    ui.state = ui.status.pages
    ui.setWaitMessage(verification and "Saving Settings..." or "Loading values...")
    scoped(Page.read, Page)
end

ui.openScript = function(script)
    ui.requestLeave(function()
        for i,entry in ipairs(PageFiles or {})do if entry.script==script then CurrentPageIndex=i;ui.loadPage();return end end
    end)
end

ui.selectBattery = function(value)
    if busy() or not Page or Page.uiScript~='battery' or changeCount()>0 then return end
    if type(value)~='number' or value%1~=0 or value<0 or value>5 then return end
    local safety=rf2.executeScript('F/writeSafety')
    local api=rf2.useApi('mspBatteryProfile')
    local proof={}
    queue:cancelOwner(owner);owner=newOwner();operation='switching'
    ui.setWaitMessage('Checking battery selection...')
    local function fail(reason) errorPending={reason=reason,saving=true} end
    local function send()
        local safe,reason=safety.check(proof);if not safe then fail(reason);return end
        api.write({batteryProfile={value=value}},function()
            api.read(function(_,result)
                if result.batteryProfile.value~=value then fail('Battery selection readback differs. Reload before continuing.');return end
                operation=nil;ui.deferReload()
            end)
        end)
    end
    scoped(function()
        if rf2.offlineSimulator then send();return end
        queue:add({command=101,processReply=function(_,buf)
            local ok,reason=safety.status(buf,proof);if not ok then fail(reason);return end
            queue:add({command=139,processReply=function(_,motors)
                local good,why=safety.motors(motors,proof);if not good then fail(why);return end
                send()
            end})
        end})
    end)
end

ui.requestLeave = function(nextAction)
    if busy() then return end
    if Page and baseline and changeCount() > 0 then
        overlay = "leave"
        overlayBack = ui.showPage
        workflow().show("Unsaved changes", {
            "Keep editing to retain your changes, or discard them to continue.",
            "Only changes on this page will be discarded.",
        }, ui.showPage, {text = "Discard", press = nextAction})
    else
        nextAction()
    end
end

ui.finishField = function(commit)
    if overlay ~= "field" then return end
    cancelNativeEditor()
    rf2.hangarTick=nil
    local apply = fieldApply
    fieldApply, overlay, overlayBack = nil, nil, nil
    if commit and apply then
        apply()
        if Page and Page.uiHasChanges and Page.uiHasChanges() then saveResult = nil end
    end
    -- Keep the editor painted until the next refresh replaces it in one pass.
    -- That refresh owns the page rebuild and its full instruction budget.
    ui.redraw = true
end

ui.openField = function(index, editor, caption)
    if busy() or operation or overlay or not Page then return end
    rf2.diagnosticStage = caption or "open field editor"
    overlay = "field"
    local page, token = Page, {}
    page.editorToken = token
    editor.current = function() return Page == page and overlay == "field" and page.editorToken == token end
    overlayBack = function() ui.finishField(false) end
    fieldApply = PageView.edit(Page,index,editor,caption,ui.finishField)
end

ui.dashboard = function()
    if busy() then return end
    if fieldApply then ui.finishField(true) end
    if Page and baseline and changeCount() > 0 then
        local page = Page
        overlay, overlayBack = "leave", ui.showPage
        workflow().leave(changeCount(), ui.showPage, ui.exit, function()
            if Page ~= page or busy() or overlay ~= "leave" then return end
            dashboardAfterSave = true
            queueSave()
        end)
    else ui.exit() end
end

ui.home = function()
    if busy() then return end
    -- Keep the focused edit in the local draft so leaving uses the same
    -- unsaved-change guard as every other page. No controller write occurs.
    if fieldApply then ui.finishField(true) end
    ui.requestLeave(function()
        navigationState.hangarView='home'
        navigationState.page=1
        openingPending=false
        ui.showMainMenu()
    end)
end

ui.back = function()
    if operation == "waitingSave" then operation = nil; dashboardAfterSave = false; ui.showPage(); return end
    if busy() then return end
    if overlayBack then overlayBack()
    elseif ui.state == ui.status.pages then ui.requestLeave(ui.showMainMenu)
    else ui.exit() end
end

ui.showMainMenu = function()
    rf2.diagnosticStage,rf2.diagnosticPage = "render RF home","home"
    dashboardAfterSave = false
    ui.unloadPage()
    expected, resultMessage = nil, nil
    owner = newOwner()
    if openingPending and initialPage then
        local target=initialPage
        initialPage=nil
        openingPending=false -- explicit firmware route wins over Last page
        if target~='home' then
            for i,entry in ipairs(PageFiles or {}) do
                if entry.script==target then CurrentPageIndex=i;ui.loadPage();return end
            end
            -- Never load a page outside the API-gated catalog.
            errorPending={reason='This page is unavailable for the connected controller.'}
        end
        navigationState.hangarView='home'
    end
    HomeStatus = rf2.executeScript("PAGES/status")
    if openingPending and hangarConfig.enabled() then
        openingPending=false
        local prefs=hangarConfig.get()
        navigationState.hangarView=prefs.openingPage=='all' and 'all' or 'home'
        if prefs.openingPage=='last' and prefs.lastPage then
            for i,entry in ipairs(PageFiles)do if entry.script==prefs.lastPage and entry.script~='settings' then CurrentPageIndex=i;ui.loadPage();return end end
        end
    end
    local menu = {diagnostics=ui.showDiagnostics,title = "Rotorflight " .. rf2.luaVersion, subtitle = "Main Menu",
        items = {}, status = HomeStatus, back = ui.exit, run = scoped, navigation = navigationState}
    for i, entry in ipairs(PageFiles) do
        local index = i
        local item = {text = string.gsub(entry.title, "^ESC %- ", ""), index = i, script = entry.script,
            click = function() CurrentPageIndex = index; ui.loadPage() end}
        if entry.script == "settings" then menu.settings = item
        else menu.items[#menu.items + 1] = item end
    end
    menu.items[#menu.items + 1] = {text = "Connection", click = ui.showDiagnostics}
    ui.state = ui.status.mainMenu
    MainMenuView = MainMenuView or rf2.executeScript("LVGL/mainMenu")
    MainMenuView.show(menu)
    ui.redraw = false
    scoped(HomeStatus.read, HomeStatus)
end

local function rebootFc()
    queue:add({command = 68, simulatorResponse = {}})
end

ui.saveSettingsToEeprom = function(eepromWrite, reboot)
    saveResult = nil
    -- This entry is also used by existing Copy Profile and ESC actions.
    if not operation then operation = "saving" end
    ui.setWaitMessage("Saving Settings...")
    if not eepromWrite then saveAck = true; return end
    queue:add({command = 250, simulatorResponse = {}, deferOnDisarm = true,
        processReply = function()
            rf2.sessionWritePending=false
            saveAck = true
            if reboot then rebootPending = true; rebootFc() end
        end,
        processDeferredReply = function()
            rf2.sessionWritePending=true
            saveAck, saveDeferred = true, true
            -- Do not reboot or keep the UI waiting for disarm. The firmware
            -- owns persistence; read back the live RAM values now.
        end})
end

local function validPageConnection()
    if rf2.nativeSessionEpoch and not rf2.offlineSimulator and Page and Page.uiScript~='settings' and nativeEpoch()~=rf2.nativeSessionEpoch then
        queue:cancelOwner(owner)
        rf2.sessionWritePending=nil
        errorPending={reason='Connection changed. Reload this page before editing or saving.',saving=busy()}
        return false
    end
    return true
end

local function writePage()
    if owner.cancelled or not validPageConnection() then return end
    scoped(Page.write, Page)
end

startSave = function()
    if not Page or (busy() and operation ~= "waitingSave") or not validPageConnection() then return end
    saveResult = nil
    if Page.uiScript~="settings" and not rf2.offlineSimulator and getRSSI() == 0 then
        errorPending = {reason = "Connection lost. Reload before saving.", saving = true}
        return
    end
    if baseline and edits.context(Page) ~= loadedContext then
        errorPending = {reason = "Active profile changed. Reload before saving.", saving = true}
        return
    end
    if not queue:isProcessed() then
        operation, overlay, overlayBack = "waitingSave", nil, nil
        saveWaitingSince = saveWaitingSince or rf2.clock()
        ui.setWaitMessage("Waiting for the shared connection...\nBack cancels this save.")
        return
    end
    expected = baseline and edits.capture(Page) or nil
    queue:cancelOwner(owner)
    owner = newOwner()
    operation, saveAck, saveDeferred, rebootPending, overlay, overlayBack = "saving", false, false, false, nil, nil
    ui.setWaitMessage("Saving Settings...")
    -- Check the profile again immediately before queuing writes. KSE5 may have
    -- selected another battery profile since this page was loaded.
    local pid, rate, battery
    for _, field in ipairs(Page.fields or {}) do
        if field.t == "Current PID profile" then pid = field.data.value
        elseif field.t == "Current rate profile" then rate = field.data.value
        elseif field.t == "Current battery" then battery = field.data.value end
    end
    local function mismatch()
        queue:cancelOwner(owner)
        errorPending = {reason = "Active profile changed. Reload before saving.", saving = true}
    end
    if pid ~= nil or rate ~= nil then
        scoped(function()
            rf2.useApi("mspStatus").getStatus(function(_, status)
                if (pid ~= nil and pid ~= status.profile) or (rate ~= nil and rate ~= status.rateProfile) then mismatch()
                else writePage() end
            end)
        end)
    elseif battery ~= nil then
        scoped(function()
            rf2.useApi("mspBatteryProfile").read(function(_, status)
                if battery ~= status.batteryProfile.value then mismatch() else writePage() end
            end)
        end)
    else writePage() end
end

queueSave = function()
    -- Paint progress in its own refresh before starting any writes, including
    -- synchronous local Settings saves. Repeated taps cannot enqueue a second save.
    operation, overlay, overlayBack = "saveRequested", nil, nil
    saveResult, saveWaitingSince = nil, nil
    ui.setWaitMessage("Saving Settings...")
end

ui.showDiagnostics = function()
    if busy() then return end
    overlay = "diagnostics"
    overlayBack = Page and ui.showPage or ui.showMainMenu
    workflow().diagnostics(queue, overlayBack)
end

ui.showPopupMenu = function()
    if busy() or operation or overlay then return end
    local menu = {diagnostics=ui.showDiagnostics,title = "Menu", items = {}}
    if Page then
        local script = PageFiles[CurrentPageIndex].script
        if navigation.info[script] and not hangarConfig.enabled() then
            menu.items[#menu.items + 1] = {text = navigation.favorites()[script] == 1 and "Unpin favorite" or "Pin favorite",
                click = function() navigation.toggle(script); ui.showPage() end}
        end
        if hangarConfig.enabled() then
            menu.items[#menu.items+1]={text='Home favorites',click=function()rf2.hangarSettingsSection='favorites';ui.openScript('settings')end}
            menu.items[#menu.items+1]={text='Hangar view',click=function()Page.uiHangarLegacy=nil;Page.uiAxis=nil;Page.uiRatesOptions=nil;Page.uiCollectiveCurve=nil;ui.showPage()end}
        end
        menu.items[#menu.items + 1] = {text = "Reload", click = function() ui.requestLeave(ui.loadPage) end}
        if Page.write and not Page.readOnly then
            menu.items[#menu.items + 1] = {text = "Save", click = Page.uiSave}
        end
        if Page.title == "PID Gains" then
            menu.items[#menu.items + 1] = {text = "Copy PID profile", click = function()
                Page.uiAxis = 3
                Page.uiHangarLegacy=true
                ui.showPage()
            end}
        end
        if Page.title == "Rates" then
            menu.items[#menu.items + 1] = {text = Page.uiCollectiveCurve and "All axes" or "Collective curve", click = function()
                Page.uiCollectiveCurve = not Page.uiCollectiveCurve
                Page.uiRatesOptions = false
                ui.showPage()
            end}
        end
        menu.items[#menu.items + 1] = {text = "Page help", click = function()
            overlay, overlayBack = "help", ui.showPage
            local lines = {
                baseline and "Edit values, then press Save to apply this page. Back offers to discard unsaved edits."
                    or "This page uses its original Save and action controls. Actions such as Copy may take effect immediately.",
                rf2.offlineSimulator and "PREVIEW: FC data and saves are simulated in memory. Favorites and Settings are saved on the radio."
                    or "Save applies values to the FC. While armed, RF 2.3 saves them to EEPROM after disarm. Supported pages read back values to check the result.",
            }
            if Page.title == "PID Gains" or Page.title == "Rates" then
                lines[#lines+1] = "The active profile is shown in the top bar. Destination profile and Copy duplicate the current profile; they do not select the active profile."
            end
            if Page.title == "PID Gains" then table.insert(lines, 1, "Roll, Pitch and Yaw gains are shown together. HSI offset applies to Roll and Pitch. Yaw CW/CCW are the clockwise and counterclockwise tail stop gains. Copy PID profile is in the page menu. Governor gains are on the Governor page.") end
            if Page.title == "Rates" then
                table.insert(lines,1,"Roll, Pitch, Yaw and Collective rates are shown together. Names and units follow the rates type above the values. Options contains cyclic settings and Copy. Changing the type loads its defaults.")
                lines[#lines+1]="Collective curve opens a graph within this page. It shows nominal commanded pitch, not measured blade pitch or mixer limits/calibration."
            elseif Page.collectiveOnly then
                table.insert(lines,1,"Edit collective response for the rate profile shown in the top bar. Rates type and profile Copy remain on the Rates page.")
                lines[#lines+1]="The graph shows nominal commanded pitch across negative and positive stick. It does not measure blade pitch or include mixer limits/calibration or response dynamics."
            end
            workflow().show(Page.title .. " - Help", lines, ui.showPage)
        end}
    end
    menu.items[#menu.items + 1] = {text = "Connection", click = ui.showDiagnostics}
    menu.items[#menu.items + 1] = {text = "Reboot", click = function()
        ui.requestLeave(function()
            queue:withOwner({timeout = 12}, rebootFc)
            ui.showMainMenu()
        end)
    end}
    menu.items[#menu.items + 1] = {text = "Close", click = Page and ui.showPage or ui.showMainMenu}
    menu.close = function()
        if overlay == "menu" then overlay, overlayBack = nil, nil end
    end
    overlay, overlayBack = "menu", Page and ui.showPage or ui.showMainMenu
    rf2.executeScript("LVGL/popupMenu").show(menu)
end

ui.incPage = function(inc)
    if not PageFiles then return end
    ui.requestLeave(function()
        CurrentPageIndex = rf2.executeScript("F/incMax")(CurrentPageIndex, inc, #PageFiles)
        ui.loadPage()
    end)
end

ui.onPageReady = function(page)
    if page ~= Page and page ~= HomeStatus then return end
    page.isReady = true
    if page == Page then readyPending = page end
end

local function showError()
    cancelNativeEditor()
    saveResult = nil
    rf2.hangarTick=nil
    dashboardAfterSave = false
    fieldApply = nil
    local failure = errorPending
    errorPending, operation, readyPending, expected = nil, nil, nil, nil
    queue:cancelOwner(owner)
    cleanup.release(Page)
    exitRequested = false
    ui.clearWaitMessage()
    overlay = "error"
    overlayBack = ui.showMainMenu
    local lines = {failure.reason}
    if failure.command then lines[#lines + 1] = "Request: MSP " .. failure.command end
    if failure.saving then lines[#lines + 1] = "Save was not confirmed. Reload to check the current values before trying again." end
    workflow().show(failure.saving and "Save not confirmed" or "Unable to load", lines, ui.showMainMenu,
        {text = "Reload", press = Page and ui.loadPage or ui.showMainMenu})
    ui.redraw = false
end

ui.update = function()
    rf2.diagnosticStage = overlay or operation or "UI update"
    if overlay~='error' then validPageConnection() end
    if errorPending then showError();return end
    if overlay=="field" and rf2.hangarTick then rf2.hangarTick() end
    local pendingCleanup = cleanup.pending()
    local cleanupError = cleanup.takeError()
    if cleanupError then errorPending = {reason = cleanupError} end
    local notice = ui.state ~= ui.status.init and diagnostics.takeNotice()
    if notice then errorPending = {reason = notice, saving = busy()} end
    if errorPending then showError(); return end
    if pendingExitPreferences then
        pendingExitPreferences=false
        if not hangarConfig.saveLast() then
            exitRequested=false
            errorPending={reason='Last page preference was not saved. Your previous settings are retained.'}
        end
        return true
    end
    if exitRequested then
        if not pendingCleanup then ui.state = ui.status.exit
        else waitMessage.updateWaitMessage() end
        return
    end
    if ui.state == ui.status.exit then return end
    if ui.reloadRequested and Page and not busy() then
        ui.reloadRequested = false
        if baseline and changeCount() > 0 and edits.context(Page) ~= loadedContext then
            errorPending = {reason = "Active profile changed. Reload before editing or saving."}
        else
            ui.requestLeave(ui.loadPage)
        end
        return
    end
    if operation == "saveRequested" then
        operation = "startingSave"
        waitMessage.updateWaitMessage()
        return true
    elseif operation == "startingSave" then
        operation = nil
        startSave()
        return true
    end
    if operation == "waitingSave" then
        if queue:isProcessed() then startSave()
        elseif rf2.clock() - saveWaitingSince > 15 then
            errorPending = {reason = "The shared connection is busy. Try again when it is idle."}
        end
        waitMessage.updateWaitMessage()
        return
    end
    if not rf2.offlineSimulator and getRSSI() == 0 and Page and Page.uiScript~="settings" and overlay ~= "error" then
        errorPending = {reason = "Connection lost. Reconnect and reload this page.", saving = busy()}
        showError()
        return
    end
    if operation == "saving" and queue:isOwnerProcessed(owner) then
        if not saveAck and not readyPending then
            errorPending = {reason = "No save acknowledgement received.", saving = true}
        elseif rebootPending and not rf2.offlineSimulator then
            operation, expected, baseline = nil, nil, nil
            overlay, overlayBack = "reboot", ui.showMainMenu
            ui.clearWaitMessage()
            workflow().show("Saved - restarting", {"Save acknowledged. Reconnect and reload to check the values."}, ui.showMainMenu,
                {text = "Reload", press = ui.loadPage})
        else
            local message = rf2.offlineSimulator and "Preview saved - no FC writes"
                or (saveDeferred and "Applied in RAM; save after disarm" or "Write acknowledged")
            if PageFiles[CurrentPageIndex].script == "settings" then
                message, expected = "Radio preferences updated", nil
            end
            ui.loadPage({expected = expected, context = loadedContext, message = message, deferred = saveDeferred})
        end
        return
    end
    if readyPending == Page and Page and queue:isOwnerProcessed(owner) and
        (not busy() or operation == "verifying") then
        -- Loading the renderer/theme reads preferences. Give construction of
        -- the form a fresh refresh budget, separate from that initialization.
        if not PageView then
            PageView = rf2.executeScript("LVGL/page")
            if PageView.prepare then PageView.prepare(Page) end
            return true
        end
        readyPending = nil
        if expected then
            if not edits.matches(Page, expected, loadedContext) then
                errorPending = {reason = "Readback differs from the requested values.", saving = true}
                return
            end
            resultMessage = rf2.offlineSimulator and "Preview saved and checked"
                or (saveDeferred and "Applied in RAM; save after disarm" or "Saved values read back")
            -- Only verified persistence earns Saved. An armed RAM-only write
            -- remains pending even when its live values match the request.
            saveResult = Page.uiScript ~= 'settings' and (saveDeferred and 'applied' or 'saved') or nil
            expected = nil
            if hangarConfig.enabled() then hangarConfig.sound() end
        end
        if operation == "loading" or operation == "verifying" then
            baseline = edits.supports(PageFiles[CurrentPageIndex].script) and edits.capture(Page) or nil
            loadedContext = edits.context(Page)
            operation = nil
            if hangarConfig.enabled() and Page.uiScript~='settings' then hangarConfig.remember(Page.uiScript)end
            if hangarConfig.enabled() and resultMessage=='Radio preferences updated' then hangarConfig.sound()end
        end
        if dashboardAfterSave then ui.exit(); return true end
        if not overlay then ui.showPage(); return true end
    end
    waitMessage.updateWaitMessage()
    if ui.redraw and not operation and not overlay then
        ui.redraw = false
        if Page then ui.showPage()
        elseif MainMenuView then MainMenuView.update(true) end
        return true
    end
    -- Do not poll behind an editor/diagnostics screen or while a write/readback
    -- is pending. Existing page timers still gate themselves on the shared queue.
    if not overlay and not operation then
        if Page and Page.timer and (not Page.lastTimeTimerFired or Page.lastTimeTimerFired + 0.5 < rf2.clock()) then
            Page.lastTimeTimerFired = rf2.clock()
            scoped(Page.timer, Page)
        elseif ui.state == ui.status.mainMenu and HomeStatus then
            if not HomeStatus.lastTimeTimerFired or HomeStatus.lastTimeTimerFired + 0.5 < rf2.clock() then
                HomeStatus.lastTimeTimerFired = rf2.clock()
                scoped(HomeStatus.timer, HomeStatus)
            end
            if MainMenuView and not waitMessage.message then MainMenuView.update() end
        end
    end
end

-- Only the existing RF host can request an initial route, before opening.
-- Active-page navigation continues to use requestLeave and save/cleanup guards.
ui.validInitialPage = function(script) return script==nil or setupRoutes[script]==true end
ui.restart = function(script)
    dashboardAfterSave = false
    ui.unloadPage()
    captureEpoch()
    exitRequested = false
    pendingExitPreferences=false
    ui.state = ui.status.init
    openingPending=true
    initialPage=setupRoutes[script] and script or nil
end

-- Read-only native status. A throttled host call uses the existing edit/save
-- state; it never polls the controller or grants permission to write.
ui.sessionStatus = function(active)
    if not Page and lastSessionReport then
        lastSessionReport.active=not not active
        return lastSessionReport
    end
    local count=Page and baseline and changeCount() or 0
    local state=overlay=='error' and 7 or busy() and 4 or operation and 1 or
        count>0 and 3 or saveResult=='applied' and 5 or saveResult=='saved' and 6 or Page and 2 or 0
    return {page=Page and Page.title or 'RF Setup',state=state,changes=count,
        preview=not not rf2.offlineSimulator,active=not not active,
        pendingSave=rf2.sessionWritePending==true,epoch=rf2.nativeSessionEpoch or 0}
end

rf2.requestDashboardExit = ui.dashboard
rf2.requestRFHome = ui.home
rf2.canExitToDashboard = function() return not busy() end

return ui
