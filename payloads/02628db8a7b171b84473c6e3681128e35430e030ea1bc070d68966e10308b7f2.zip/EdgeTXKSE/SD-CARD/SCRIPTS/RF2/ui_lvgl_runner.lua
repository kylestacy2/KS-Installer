local ui = rf2.executeScript("ui_lvgl_framework")

local IsInitialized = false
local InitTask
local MenuLoaded = false
local IgnoreNextKeyEvent = false

local function run(event, touchState, noUi)
    rf2.diagnosticStage = "UI update"
    -- RfTool.background calls this with no arguments. Keep that service pass
    -- from rebuilding LVGL over KSE5 or polling a hidden configuration page.
    if noUi == nil then noUi = event == nil and rf2.widget ~= nil end
    -- Do not drop Back on a pass reserved for renderer initialization/build.
    -- The framework still enforces unsaved-edit and in-flight-save guards.
    if not noUi and event == EVT_EXIT_BREAK then
        ui.back()
        return ui.state == ui.status.exit and 2 or 0, true
    end
    -- A freshly constructed form gets its own pass; process MSP next frame.
    if not noUi and ui.update() then return 0, true end

    if not IsInitialized then
        rf2.diagnosticStage = "UI initialization"
        InitTask = InitTask or rf2.executeScript("ui_init")
        local gotApiVersion = InitTask.f()
        ui.setWaitMessage(InitTask.t, InitTask.detail)
        if not gotApiVersion then
            if ui.state == ui.status.exit then return 2, true end
            return 0, true
        end
        InitTask = nil
        ui.clearWaitMessage()
        IsInitialized = true
        -- Give menu construction its own widget refresh budget.
        return 0, true
    end

    if noUi then
        rf2.diagnosticStage = "hidden UI MSP"
        rf2.mspQueue:processQueue()
        return 0
    end

    -- Initialization can finish while RF Tool is a hidden host for KSE5.
    if ui.state == ui.status.init then
        rf2.diagnosticStage = "opening RF home"
        if not MenuLoaded then
            ui.loadMainMenu()
            MenuLoaded = true
            return 0, true
        end
        ui.showMainMenu()
        return 0, true
    end

    if ui.state == ui.status.exit then
        return 2
    end

    -- if event and event ~= 0 then
    --     rf2.print(" Event: " .. string.format("0x%X", event))
    -- end

    if event then
        if event == 0x20D or event == EVT_VIRTUAL_PREV_PAGE or event == EVT_VIRTUAL_NEXT_PAGE then
            -- For some reason the tool gets all key events twice, so we need to ignore the second one.
            if not IgnoreNextKeyEvent then
                if rf2.isTool then IgnoreNextKeyEvent = true end
                if event == 0x20D then -- SYS break
                    ui.showPopupMenu()
                elseif event == EVT_VIRTUAL_PREV_PAGE then
                    ui.incPage(-1)
                elseif event == EVT_VIRTUAL_NEXT_PAGE then
                    ui.incPage(1)
                end
            else
                IgnoreNextKeyEvent = false
            end
        end
    end

    rf2.diagnosticStage = "foreground MSP"
    rf2.mspQueue:processQueue() -- Note: if a Lua error occurs here, an error message will be shown by EdgeTX and run_ui will not be called anymore.

    return 0
end

-- Implement required functions for the RF2 interface
rf2.reloadPage = ui.deferReload
rf2.reloadMainMenu = ui.loadMainMenu
rf2.setWaitMessage = ui.setWaitMessage
rf2.clearWaitMessage = ui.clearWaitMessage
rf2.settingsSaved = ui.saveSettingsToEeprom
rf2.onPageReady = ui.onPageReady
rf2.setupProtocol = 1
rf2.validInitialPage = ui.validInitialPage
rf2.getSessionStatus = ui.sessionStatus
rf2.restartUi = function(script)
    IsInitialized = false
    MenuLoaded = false
    ui.restart(script)
end

-- Return the run function to be called by the RF2 tool
return run
