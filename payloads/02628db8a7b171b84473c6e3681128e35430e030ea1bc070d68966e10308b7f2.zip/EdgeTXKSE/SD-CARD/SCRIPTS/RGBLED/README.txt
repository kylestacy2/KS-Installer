Custom Colors saves your own LED configuration here. Keep this folder. Existing model_leds_config.lua and recovery files must be preserved during updates.
