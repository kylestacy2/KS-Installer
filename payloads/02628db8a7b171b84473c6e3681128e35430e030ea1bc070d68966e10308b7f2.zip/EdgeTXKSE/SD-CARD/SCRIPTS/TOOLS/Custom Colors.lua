-- Custom colors - responsive LVGL model LED editor for EdgeTX 2.12

local CONFIG_PATH = "/SCRIPTS/RGBLED/model_leds_config.lua"
local LEGACY_BACKUP_PATH = "/SCRIPTS/RGBLED/model_leds_before_global.lua"

-- EdgeTX exposes some firmware globals through the environment metatable, so
-- use normal table lookup rather than rawget when reading screen/font values.
local function firmwareGlobal(name)
    return _G[name]
end

local lvgl = lvgl
if not lvgl and type(require) == "function" then
    local ok, lib = pcall(require, "lvgl")
    if ok then
        lvgl = lib
    end
end

local colorNames = {
    "OFF", "WHITE", "PURPLE", "ORANGE", "YELLOW", "BLUE", "GREEN", "RED",
    "POLICE", "SCR", "SCL", "SAPP", "RUNNER", "RGBLOP", "RAINBW", "PFWRD", "PBACK", "FLOW", "BFWRD",
    "BBACK", "GBLBLU", "GBLCYN", "GBLGRE", "GBLLIM", "GBLMAG", "GBLORG",
    "GBLPNK", "GBLPUR", "GBLRED", "GBLTRQ", "GBLYEL"
}
local switchColorNames = { "NONE", "OFF", "WHITE", "PURPLE", "ORANGE", "YELLOW", "BLUE", "GREEN", "RED" }
local modeNames = { "OFF", "ON" }
local effectLabels = {
    BBACK = "Blue backward",
    GBLBLU = "Gimbal Blue", GBLCYN = "Gimbal Cyan", GBLGRE = "Gimbal Green",
    GBLLIM = "Gimbal Lime", GBLMAG = "Gimbal Magenta", GBLORG = "Gimbal Orange",
    GBLPNK = "Gimbal Pink", GBLPUR = "Gimbal Purple", GBLRED = "Gimbal Red",
    GBLTRQ = "Gimbal Turquoise", GBLYEL = "Gimbal Yellow",
}
-- Display labels are separate from the stable keys used by the LED scripts
-- and model_leds_config.lua. Keep every saved value and choice index unchanged.
local function displayNames(names)
    local labels = {}
    for i, name in ipairs(names) do
        -- EdgeTX builds can disable string metatables, so name:sub() and
        -- other string-method calls fail before the tool can initialize.
        labels[i] = effectLabels[name] or (string.upper(string.sub(name, 1, 1)) .. string.lower(string.sub(name, 2)))
    end
    return labels
end
local colorLabels = displayNames(colorNames)
local switchLabels = displayNames(switchColorNames)
local modeLabels = displayNames(modeNames)
local colors = {
    OFF    = { r = 0,   g = 0,   b = 0   },
    WHITE  = { r = 255, g = 255, b = 255 },
    PURPLE = { r = 255, g = 0,   b = 255 },
    ORANGE = { r = 255, g = 100, b = 0   },
    YELLOW = { r = 255, g = 255, b = 0   },
    BLUE   = { r = 0,   g = 0,   b = 128 },
    GREEN  = { r = 0,   g = 255, b = 0   },
    RED    = { r = 50,  g = 0,   b = 0   },
}

local currentModel = ""
local currentModelFile = nil
local color1Index = 1
local color2Index = 1
local gimbalModeIndex = 1
local allChoices = {}
local swIndices = {1,1,1,1,1,1}
local enableSwitch = 0
local disableSwitch = 0
local ledsEnabled = nil
local appliedSelection = nil

-- Slots 13-16 are reserved by Custom Colors (see README). This RAM-only
-- handoff preserves the latch across the separate editor/function Lua states.
local SHM_BASE = 13
local SHM_TAG = 4408064
local function readHandoff(enable, disable, editorOnly)
    if type(getShmVar) ~= "function" then return nil end
    local ok, tag, en, dis, stamp = pcall(function()
        return getShmVar(SHM_BASE), getShmVar(SHM_BASE + 1),
            getShmVar(SHM_BASE + 2), getShmVar(SHM_BASE + 3)
    end)
    if not ok or type(tag) ~= "number" or type(stamp) ~= "number" then return nil end
    local flags = tag - SHM_TAG
    local age = getTime() - stamp
    if flags < 0 or flags > 3 or flags ~= math.floor(flags) or age < 0 or age > 200
        or (enable ~= nil and (en ~= enable or dis ~= disable)) or (editorOnly and flags < 2) then return nil end
    return flags % 2 == 1, en, dis
end
local function publishHandoff(enable, disable, enabled, editor)
    if type(setShmVar) ~= "function" then return end
    pcall(function()
        setShmVar(SHM_BASE + 1, enable)
        setShmVar(SHM_BASE + 2, disable)
        setShmVar(SHM_BASE + 3, getTime())
        setShmVar(SHM_BASE, SHM_TAG + (enabled and 1 or 0) + (editor and 2 or 0))
    end)
end

local function normalizeSwitch(value)
    value = tonumber(value)
    if not value or value ~= math.floor(value) or math.abs(value) > 32767 then return 0 end
    return value
end

-- With two conditions, retain the last state between them. With just one,
-- follow that condition (inverted for Disable). Disable always takes priority.
-- A configured Enable starts off until its condition is first satisfied.
local function switchControlEnabled(enable, disable, previous)
    if enable == 0 and disable == 0 then return true end
    if type(getSwitchValue) ~= "function" then return false end
    local function active(index)
        if index == 0 then return false end
        local ok, value = pcall(getSwitchValue, index)
        return ok and value == true
    end
    if active(disable) then return false end
    if active(enable) then return true end
    if enable == 0 then return true end
    if disable == 0 then return false end
    return previous == true
end

local effects = {}
local previewEffect = nil

local function rainbowColor(phase, length)
    local position = (phase % length) / length
    local r, g, b = 0, 0, 0
    local maxBrightness = 255
    if position < 1/3 then
        r = maxBrightness * (1 - 3 * position)
        g = maxBrightness * (3 * position)
    elseif position < 2/3 then
        position = position - 1/3
        g = maxBrightness * (1 - 3 * position)
        b = maxBrightness * (3 * position)
    else
        position = position - 2/3
        b = maxBrightness * (1 - 3 * position)
        r = maxBrightness * (3 * position)
    end
    return r, g, b
end

local function rainbowColorSkip(phase, length, bg_r, bg_g, bg_b, threshold)
    local r, g, b = rainbowColor(phase, length)
    if math.abs(r - bg_r) < threshold and math.abs(g - bg_g) < threshold and math.abs(b - bg_b) < threshold then
        return rainbowColorSkip((phase + 1) % length, length, bg_r, bg_g, bg_b, threshold)
    end
    return r, g, b
end

effects.POLICE = {
    continuous = true,
    state = { oldtime = 0, cycle = 0 },
    init = function(s)
        s.oldtime = getTime()
        s.cycle = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        for i = 0, total - 1, 1 do
            if (i % 2 == s.cycle) then
                setRGBLedColor(i, 0, 0, 50)
            else
                setRGBLedColor(i, 50, 0, 0)
            end
        end
        if ((getTime() - s.oldtime) > 8) then
            s.oldtime = getTime()
            s.cycle = 1 - s.cycle
        end
        applyRGBLedColors()
    end
}

effects.SCR = {
    continuous = true,
    state = { oldtime = 0, cycle = 0 },
    init = function(s)
        s.oldtime = getTime()
        s.cycle = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        for i = 0, total - 1, 1 do
            if (i == s.cycle) then
                setRGBLedColor(i, 0, 50, 0)
            else
                setRGBLedColor(i, 0, 0, 50)
            end
        end
        if ((getTime() - s.oldtime) > 8) then
            s.oldtime = getTime()
            s.cycle = s.cycle + 1
            if s.cycle >= total then
                s.cycle = 0
            end
        end
        applyRGBLedColors()
    end
}

effects.SCL = {
    continuous = true,
    state = { oldtime = 0, cycle = 0 },
    init = function(s)
        local total = LED_STRIP_LENGTH or 0
        s.oldtime = getTime()
        s.cycle = math.max(0, total - 1)
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        for i = 0, total - 1, 1 do
            if (i == s.cycle) then
                setRGBLedColor(i, 0, 50, 0)
            else
                setRGBLedColor(i, 0, 0, 50)
            end
        end
        if ((getTime() - s.oldtime) > 8) then
            s.oldtime = getTime()
            s.cycle = s.cycle - 1
            if s.cycle < 0 then
                s.cycle = total - 1
            end
        end
        applyRGBLedColors()
    end
}

effects.SAPP = {
    continuous = false,
    state = {},
    init = function(s)
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        for i = 0, total - 1, 1 do
            setRGBLedColor(i, 0, 255, 255)
        end
        applyRGBLedColors()
    end
}

effects.RUNNER = {
    continuous = true,
    state = { colorTime = 0, phase = 0, currentLed = 0 },
    init = function(s)
        s.colorTime = getTime()
        s.phase = 0
        s.currentLed = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        if ((getTime() - s.colorTime) > 2) then
            s.colorTime = getTime()
            s.phase = s.phase + 1
            s.currentLed = (s.currentLed + 1) % total
        end
        for i = 0, total - 1, 1 do
            local r, g, b = rainbowColor(s.phase, 255)
            if i <= s.currentLed then
                setRGBLedColor(i, r, g, b)
            else
                local bg_r = (r + 128) % 256
                local bg_g = (g + 128) % 256
                local bg_b = (b + 128) % 256
                local maxBackgroundBrightness = 255
                bg_r = math.min(bg_r, maxBackgroundBrightness)
                bg_g = math.min(bg_g, maxBackgroundBrightness)
                bg_b = math.min(bg_b, maxBackgroundBrightness)
                if bg_r > bg_g and bg_r > bg_b then
                    bg_r = 0
                elseif bg_g > bg_r and bg_g > bg_b then
                    bg_g = 0
                else
                    bg_b = 0
                end
                setRGBLedColor(i, bg_r, bg_g, bg_b)
            end
        end
        applyRGBLedColors()
    end
}

effects.RGBLOP = {
    continuous = true,
    state = { cycleTime = 0, phase = 0 },
    init = function(s)
        s.cycleTime = getTime()
        s.phase = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        if ((getTime() - s.cycleTime) > 2) then
            s.cycleTime = getTime()
            s.phase = s.phase + 1
        end
        for i = 0, total - 1, 1 do
            local r, g, b = rainbowColor(s.phase, 255)
            setRGBLedColor(i, r, g, b)
        end
        applyRGBLedColors()
    end
}

effects.RAINBW = {
    continuous = true,
    state = { colorTime = 0, phase = 0 },
    init = function(s)
        s.colorTime = getTime()
        s.phase = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        if ((getTime() - s.colorTime) > 2) then
            s.colorTime = getTime()
            s.phase = (s.phase + 1) % 255
            for i = 0, total - 1, 1 do
                local r, g, b = rainbowColor(s.phase + i * 64, 255)
                setRGBLedColor(i, r, g, b)
            end
            applyRGBLedColors()
        end
    end
}

effects.PFWRD = {
    continuous = true,
    state = { oldtime = 0, cycle = 0, phase = 0 },
    init = function(s)
        s.oldtime = getTime()
        s.cycle = 0
        s.phase = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        for i = 0, total - 1, 1 do
            if (i == s.cycle) then
                local r, g, b = rainbowColorSkip(s.phase, 255, 72, 0, 72, 30)
                setRGBLedColor(i, r, g, b)
            else
                setRGBLedColor(i, 72, 0, 72)
            end
        end
        if ((getTime() - s.oldtime) > 8) then
            s.oldtime = getTime()
            s.cycle = s.cycle + 1
            if s.cycle >= total then
                s.cycle = 0
            end
        end
        s.phase = (s.phase + 1) % 255
        applyRGBLedColors()
    end
}

effects.PBACK = {
    continuous = true,
    state = { oldtime = 0, cycle = 0, phase = 0 },
    init = function(s)
        s.oldtime = getTime()
        s.cycle = 0
        s.phase = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        for i = total - 1, 0, -1 do
            if (i == s.cycle) then
                local r, g, b = rainbowColorSkip(s.phase, 255, 72, 0, 72, 30)
                setRGBLedColor(i, r, g, b)
            else
                setRGBLedColor(i, 72, 0, 72)
            end
        end
        if ((getTime() - s.oldtime) > 8) then
            s.oldtime = getTime()
            s.cycle = s.cycle - 1
            if s.cycle < 0 then
                s.cycle = total - 1
            end
        end
        s.phase = (s.phase + 1) % 255
        applyRGBLedColors()
    end
}

effects.FLOW = {
    continuous = true,
    state = { colorTime = 0, phase = 0 },
    init = function(s)
        s.colorTime = getTime()
        s.phase = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        if ((getTime() - s.colorTime) > 1) then
            s.colorTime = getTime()
            s.phase = (s.phase + 1) % 255
            for i = 0, total - 1, 1 do
                local r, g, b = rainbowColor(s.phase + i * 64, 255)
                setRGBLedColor(i, math.floor(r), math.floor(g), math.floor(b))
            end
            applyRGBLedColors()
        end
    end
}

effects.BFWRD = {
    continuous = true,
    state = { oldtime = 0, cycle = 0, phase = 0 },
    init = function(s)
        s.oldtime = getTime()
        s.cycle = 0
        s.phase = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then
            return
        end
        for i = 0, total - 1, 1 do
            if (i == s.cycle) then
                local r, g, b = rainbowColorSkip(s.phase, 255, 0, 0, 72, 30)
                setRGBLedColor(i, r, g, b)
            else
                setRGBLedColor(i, 0, 0, 72)
            end
        end
        if ((getTime() - s.oldtime) > 8) then
            s.oldtime = getTime()
            s.cycle = s.cycle + 1
            if s.cycle >= total then
                s.cycle = 0
            end
        end
        s.phase = (s.phase + 1) % 255
        applyRGBLedColors()
    end
}

-- Missing presets from Workspaces/Flying/RGBLED. Keep these implementations
-- identical in Custom Colors.lua and FUNCTIONS/GBLED.lua.
effects.BBACK = {
    continuous = true,
    state = { oldtime = 0, cycle = 0, phase = 0 },
    init = function(s)
        s.oldtime = getTime()
        s.cycle = 0
        s.phase = 0
    end,
    run = function(s)
        local total = LED_STRIP_LENGTH or 0
        if total <= 0 then return end
        for i = total - 1, 0, -1 do
            if i == s.cycle then
                local r, g, b = rainbowColorSkip(s.phase, 255, 0, 0, 72, 30)
                setRGBLedColor(i, r, g, b)
            else
                setRGBLedColor(i, 0, 0, 72)
            end
        end
        if getTime() - s.oldtime > 8 then
            s.oldtime = getTime()
            s.cycle = s.cycle - 1
            if s.cycle < 0 then s.cycle = total - 1 end
        end
        s.phase = (s.phase + 1) % 255
        applyRGBLedColors()
    end,
}

local function gimbalEffect(red, green, blue)
    return {
        continuous = true,
        state = {},
        init = function(s)
            s.ail, s.ele, s.rud, s.thr = 0, 0, 0, 0
            -- Paint even without movement, including when re-enabled.
            s.firstFrame = true
        end,
        run = function(s)
            local total = LED_STRIP_LENGTH or 0
            if total <= 0 then return end
            local ail = tonumber(getValue("ail")) or 0
            local ele = tonumber(getValue("ele")) or 0
            local rud = tonumber(getValue("rud")) or 0
            local thr = tonumber(getValue("thr")) or 0
            local da, de = math.abs(ail - s.ail), math.abs(ele - s.ele)
            local dr, dt = math.abs(rud - s.rud), math.abs(thr - s.thr)
            if not s.firstFrame and math.max(da, de, dr, dt) < 3 then return end

            for i = 0, total - 1 do setRGBLedColor(i, red, green, blue) end
            local function ringHighlight(ring, h, v, delta)
                local magnitude = math.sqrt(h * h + v * v)
                if magnitude < 0.1 then return end
                local angle = math.atan2 and math.atan2(v, h) or math.atan(v, h)
                angle = (math.deg(angle) + 360) % 360
                local center = math.floor(angle / 36 + 0.5) % 10
                local intensity = math.min(255, 250 * magnitude * math.min(1 + delta / 200, 2))
                for offset = -2, 2 do
                    local index = (center + offset) % 10 + ring * 10
                    if index < total then
                        local value = math.floor(intensity * math.exp(-0.5 * offset * offset))
                        setRGBLedColor(index, value, value, value)
                    end
                end
            end
            -- Preserve the supplied presets' ring mapping and movement boost.
            -- Older firmware without stick-mode reporting keeps the base color.
            local mode = type(getStickMode) == "function" and getStickMode() or 0
            if mode == 1 then
                ringHighlight(0, -ail / 1024, thr / 1024, da + dt)
                ringHighlight(1, rud / 1024, -ele / 1024, dr + de)
            elseif mode == 2 then
                ringHighlight(0, -ail / 1024, ele / 1024, da + dt)
                ringHighlight(1, rud / 1024, -thr / 1024, dr + de)
            end
            s.ail, s.ele, s.rud, s.thr = ail, ele, rud, thr
            s.firstFrame = false
            applyRGBLedColors()
        end,
    }
end

effects.GBLBLU = gimbalEffect(0, 0, 255)
effects.GBLCYN = gimbalEffect(0, 255, 255)
effects.GBLGRE = gimbalEffect(0, 255, 0)
effects.GBLLIM = gimbalEffect(191, 255, 0)
effects.GBLMAG = gimbalEffect(255, 0, 255)
effects.GBLORG = gimbalEffect(255, 165, 0)
effects.GBLPNK = gimbalEffect(255, 20, 147)
effects.GBLPUR = gimbalEffect(128, 0, 128)
effects.GBLRED = gimbalEffect(255, 0, 0)
effects.GBLTRQ = gimbalEffect(64, 224, 208)
effects.GBLYEL = gimbalEffect(255, 255, 0)

local function isEffect(name)
    return name ~= nil and effects[name] ~= nil
end

local function normalizeMode(mode)
    if string.upper(tostring(mode or "OFF")) == "ON" then
        return "ON"
    end
    return "OFF"
end

local function showEffectMismatchWarning()
    if lvgl and lvgl.message then
        lvgl.message({
            title = "Warning",
            message = "Effect selections must match.\nSet color 1 and color 2 to the same effect."
        })
    end
end

local function showPerGimbalWarning()
    if lvgl and lvgl.message then
        lvgl.message({
            title = "Warning",
            message = "Per-gimbal mode supports static colors only.\nSet per gimbal to Off to use effects."
        })
    end
end

local function validateColorSelection(leftChoice, rightChoice, modeName)
    if modeName == "ON" then
        if isEffect(leftChoice) or isEffect(rightChoice) then
            showPerGimbalWarning()
            return false
        end
        return true
    end

    if (isEffect(leftChoice) or isEffect(rightChoice)) and leftChoice ~= rightChoice then
        showEffectMismatchWarning()
        return false
    end
    return true
end

local function trim(s)
    return string.gsub(s, "^%s*(.-)%s*$", "%1")
end

local function getModelName()
    local info = model and model.getInfo and model.getInfo() or nil
    local name = (info and info.name) or ""
    return trim(name), info and info.filename or nil
end

local function buildChoices()
    allChoices = {}
    for i, name in ipairs(colorNames) do
        allChoices[#allChoices + 1] = name
    end
end

local function findChoiceIndex(name)
    for i, choice in ipairs(allChoices) do
        if choice == name then
            return i
        end
    end
    return 1
end

local function findSwitchIndex(name)
    for i, choice in ipairs(switchColorNames) do
        if choice == name then
            return i
        end
    end
    return 1
end

-- Read source explicitly: FAT timestamps can tie after consecutive saves,
-- so a cached .luac must never override a newly saved configuration.
local PREVIOUS_PATH = "/SCRIPTS/RGBLED/model_leds_previous.lua"
local CONFIG_DIR = "/SCRIPTS/RGBLED"
local function fileInfo(path)
    if type(fstat) ~= "function" then return nil, false end
    local ok, info = pcall(fstat, path)
    return info, ok
end
local function validConfig(cfg)
    if type(cfg) ~= "table" then return false end
    local models = cfg
    if cfg.version == 2 then
        if type(cfg.models) ~= "table" or (cfg.global ~= nil and type(cfg.global) ~= "table") then return false end
        models = cfg.models
    end
    for name, entry in pairs(models) do
        if type(name) ~= "string" or type(entry) ~= "table" then return false end
        for _, key in ipairs({"mode", "left", "right", "sw1", "sw2", "sw3", "sw4", "sw5", "sw6"}) do
            if entry[key] ~= nil and type(entry[key]) ~= "string" then return false end
        end
    end
    return true
end
local function readConfigFile(path)
    local ok, chunk = pcall(loadScript, path, "tx")
    if not ok or type(chunk) ~= "function" then return nil end
    local loaded, cfg = pcall(chunk)
    if loaded and validConfig(cfg) then return cfg end
    return nil
end
local configSeen = false
local function loadConfig()
    local info, known = fileInfo(CONFIG_PATH)
    if not known then return nil, "Cannot inspect the configuration file." end
    if info then
        local cfg = readConfigFile(CONFIG_PATH)
        if cfg then configSeen = true; return cfg end
        return nil, "Cannot read the existing configuration. It has not been replaced."
    end
    -- A power interruption between the two renames leaves the last good
    -- configuration here. Never consume an uncommitted pending file.
    local previous, previousKnown = fileInfo(PREVIOUS_PATH)
    if not previousKnown then return nil, "Cannot inspect the recovery file." end
    if previous then
        local cfg = readConfigFile(PREVIOUS_PATH)
        if cfg then configSeen = true; return cfg, "Recovered previous settings" end
        return nil, "Cannot read the recovery configuration."
    end
    local directory, directoryKnown = fileInfo(CONFIG_DIR)
    local binary, binaryKnown = fileInfo(string.gsub(CONFIG_PATH, "%.lua$", ".luac"))
    if configSeen or not directoryKnown or not directory or not binaryKnown or binary then
        return nil, "Configuration unavailable. Check the SD card and RGBLED folder."
    end
    return {}, "New configuration"
end

-- Version 2 separates radio-wide controls from model color presets. Old files
-- still supply colors, but their model-specific switch assignments are ignored.
local function configSections(cfg)
    if cfg.version == 2 and type(cfg.models) == "table" then
        return cfg.models, type(cfg.global) == "table" and cfg.global or {}
    end
    return cfg, {}
end

local function escapeLuaString(s)
    s = s or ""
    s = string.gsub(s, "\\", "\\\\")
    s = string.gsub(s, "\"", "\\\"")
    s = string.gsub(s, "\n", "\\n")
    s = string.gsub(s, "\r", "\\r")
    return s
end

-- Build the complete document before touching the filesystem.
local function serializeConfig(cfg, legacy)
    local parts = {"return {\n"}
    if not legacy then
        parts[#parts + 1] = string.format(
            "  version = 2,\n  global = { enableSwitch = %d, disableSwitch = %d },\n  models = {\n",
            normalizeSwitch(cfg.global.enableSwitch), normalizeSwitch(cfg.global.disableSwitch))
    end
    local models = legacy and cfg or cfg.models
    local names = {}
    for name in pairs(models) do names[#names + 1] = name end
    table.sort(names)
    for _, modelName in ipairs(names) do
        local settings = models[modelName]
        local values = {escapeLuaString(modelName), escapeLuaString(normalizeMode(settings.mode)),
            escapeLuaString(settings.left or "OFF"), escapeLuaString(settings.right or "OFF")}
        for i = 1, 6 do values[#values + 1] = escapeLuaString(settings["sw" .. i] or "NONE") end
        local oldControls = legacy and string.format(
            ", enableSwitch = %d, disableSwitch = %d",
            normalizeSwitch(settings.enableSwitch), normalizeSwitch(settings.disableSwitch)) or ""
        parts[#parts + 1] = string.format(
            '    ["%s"] = { mode = "%s", left = "%s", right = "%s", sw1 = "%s", sw2 = "%s", sw3 = "%s", sw4 = "%s", sw5 = "%s", sw6 = "%s"%s },\n',
            values[1], values[2], values[3], values[4], values[5], values[6], values[7], values[8], values[9], values[10], oldControls)
    end
    parts[#parts + 1] = legacy and "}\n" or "  },\n}\n"
    return table.concat(parts)
end

local function fsCall(fn, ...)
    if type(fn) ~= "function" then return false end
    local ok, result = pcall(fn, ...)
    return ok and result == 0
end
local function writeVerified(path, text)
    local opened, f = pcall(io.open, path, "w")
    if not opened or not f then return false end
    -- EdgeTX returns a handle on success and nil/error on media failure.
    local wrote, result = pcall(io.write, f, text)
    local closed, closeResult, closeError = pcall(io.close, f)
    if not wrote or result == nil or result == false or not closed or closeResult == false or closeError then return false end
    local info, known = fileInfo(path)
    if not known or not info or info.size ~= #text then return false end
    local readOpened, input = pcall(io.open, path, "r")
    if not readOpened or not input then return false end
    local matched = true
    for offset = 1, #text, 512 do
        local count = math.min(512, #text - offset + 1)
        local ok, bytes = pcall(io.read, input, count)
        if not ok or bytes ~= string.sub(text, offset, offset + count - 1) then matched = false; break end
    end
    local readClosed = pcall(io.close, input)
    return matched and readClosed
end
local function saveConfig(cfg, path, legacy)
    path = path or CONFIG_PATH
    if type(rename) ~= "function" or type(del) ~= "function" then return false end
    local encoded, text = pcall(serializeConfig, cfg, legacy)
    if not encoded then return false end
    local pending = string.gsub(path, "%.lua$", "_pending.lua")
    local previous = path == CONFIG_PATH and PREVIOUS_PATH or string.gsub(path, "%.lua$", "_previous.lua")
    if not writeVerified(pending, text) then return false end
    local existing, known = fileInfo(path)
    if not known then return false end
    if existing then
        local old, oldKnown = fileInfo(previous)
        if not oldKnown or (old and not fsCall(del, previous)) then return false end
        if not fsCall(rename, path, previous) then return false end
    end
    if not fsCall(rename, pending, path) then
        -- If rollback also fails, loadConfig can still use the previous file.
        if existing then fsCall(rename, previous, path) end
        return false
    end
    return true
end

local function applySwitchColors(disabled)
    for i = 1, 6 do
        local cName = appliedSelection.switchColors[i]
        if cName ~= "NONE" then
            local c = (not disabled and colors[cName]) or colors.OFF
            if setCFSLedColor then
                setCFSLedColor("SW"..i, c.r, c.g, c.b)
            end
        end
    end
end

local function applyPerGimbal(leftName, rightName)
    local left = colors[leftName] or colors.OFF
    local right = colors[rightName] or colors.OFF
    local total = LED_STRIP_LENGTH or 0
    if total <= 0 then
        applySwitchColors()
        return true
    end

    local rightEnd = math.floor(total / 2)
    if rightEnd > (total - 1) then
        rightEnd = total - 1
    end
    local leftStart = rightEnd - 3
    if leftStart < 0 then
        leftStart = 0
    end

    for i = 0, rightEnd, 1 do
        setRGBLedColor(i, right.r, right.g, right.b)
    end
    for j = leftStart, total - 1, 1 do
        setRGBLedColor(j, left.r, left.g, left.b)
    end

    applySwitchColors()
    applyRGBLedColors()
    return true
end

local function applyColors()
    local leftChoice = appliedSelection.left
    local rightChoice = appliedSelection.right
    local modeName = appliedSelection.mode

    ledsEnabled = switchControlEnabled(appliedSelection.enableSwitch, appliedSelection.disableSwitch, ledsEnabled)
    if not ledsEnabled then
        previewEffect = nil
        for i = 0, (LED_STRIP_LENGTH or 0) - 1 do
            setRGBLedColor(i, 0, 0, 0)
        end
        if (LED_STRIP_LENGTH or 0) > 0 then applyRGBLedColors() end
        applySwitchColors(true)
        return true
    end

    if modeName == "ON" then
        previewEffect = nil
        return applyPerGimbal(leftChoice, rightChoice)
    end

    if leftChoice == rightChoice and effects[leftChoice] then
        local effect = effects[leftChoice]
        if effect.init then
            effect.init(effect.state)
        end
        effect.run(effect.state)
        if effect.continuous then
            previewEffect = leftChoice
        else
            previewEffect = nil
        end
        applySwitchColors()
        return true
    end

    previewEffect = nil
    local left = colors[leftChoice] or colors.OFF
    local right = colors[rightChoice] or colors.OFF

    local total = LED_STRIP_LENGTH or 0
    if total <= 0 then
        applySwitchColors()
        return true
    end

    for i = 0, total - 1, 1 do
        local c = ((i % 2) == 0) and left or right
        setRGBLedColor(i, c.r, c.g, c.b)
    end
    applyRGBLedColors()
    applySwitchColors()
    return true
end

local function activateSelection()
    if not appliedSelection then
        ledsEnabled = readHandoff(enableSwitch, disableSwitch, false)
    elseif enableSwitch ~= appliedSelection.enableSwitch or disableSwitch ~= appliedSelection.disableSwitch then
        ledsEnabled = nil
    end
    -- Keep running the saved selection while the user edits the controls.
    appliedSelection = {
        left = allChoices[color1Index], right = allChoices[color2Index],
        mode = modeNames[gimbalModeIndex] or "OFF",
        enableSwitch = enableSwitch, disableSwitch = disableSwitch,
        switchColors = {},
    }
    for i = 1, 6 do appliedSelection.switchColors[i] = switchColorNames[swIndices[i]] end
    applyColors()
    publishHandoff(enableSwitch, disableSwitch, ledsEnabled, true)
end

-- Retained UI state is independent of layout so resizing or changing tabs
-- never reloads the model or discards unsaved selections.
local activeTab = "gimbals"
local rebuildPending = false
local layoutSignature = nil
local statusText = "Ready"
local exitRequested = false

local function loadModelSettings()
    previewEffect = nil
    currentModel, currentModelFile = getModelName()
    buildChoices()
    local cfg, message = loadConfig()
    if not cfg then
        appliedSelection = nil
        statusText = "Config read failed"
        if lvgl and lvgl.message then lvgl.message({title = "Config read failed", message = message}) end
        return false
    end
    local models, global = configSections(cfg)
    local modelCfg = models[currentModel] or models["*"] or models["_default"] or {}
    enableSwitch = normalizeSwitch(global.enableSwitch)
    disableSwitch = normalizeSwitch(global.disableSwitch)
    gimbalModeIndex = (normalizeMode(modelCfg.mode) == "ON") and 2 or 1
    color1Index = findChoiceIndex(modelCfg.left)
    color2Index = findChoiceIndex(modelCfg.right)
    for i = 1, 6 do
        swIndices[i] = findSwitchIndex(modelCfg["sw" .. i])
    end
    -- Function scripts pause while this tool is open. Keep the saved colors
    -- and switch control running here, including before the first Save.
    activateSelection()
    statusText = message or "Ready"
    return true
end

local function selectionChanged()
    statusText = "Unsaved changes"
end

local function saveSelection()
    -- A reconnect/automatic RF rename can land between refresh and a tap.
    -- Never commit a previous aircraft's draft under a new model identity.
    local name, filename = getModelName()
    if name ~= currentModel or filename ~= currentModelFile then
        if loadModelSettings() then statusText = "Model changed - choose colors again" end
        rebuildPending = true
        return
    end
    local leftChoice = allChoices[color1Index]
    local rightChoice = allChoices[color2Index]
    local modeName = modeNames[gimbalModeIndex] or "OFF"
    if not validateColorSelection(leftChoice, rightChoice, modeName) then
        return
    end
    local savedCfg, readError = loadConfig()
    if not savedCfg then
        statusText = "Save blocked"
        if lvgl and lvgl.message then lvgl.message({title = "Save blocked", message = readError}) end
        return
    end
    -- A failed initial load has no trustworthy draft to save. Reload first.
    if not appliedSelection then
        loadModelSettings()
        rebuildPending = true
        return
    end
    local models = configSections(savedCfg)
    local nextCfg = {
        version = 2,
        global = { enableSwitch = enableSwitch, disableSwitch = disableSwitch },
        models = {},
    }
    for name, entry in pairs(models) do nextCfg.models[name] = entry end
    local settings = {
        mode = modeName, left = leftChoice, right = rightChoice,
    }
    for i = 1, 6 do
        settings["sw" .. i] = switchColorNames[swIndices[i]]
    end
    nextCfg.models[currentModel] = settings
    -- Keep the original model presets and old assignments before the first
    -- format upgrade. Never replace an existing migration backup.
    local backedUp = true
    if models == savedCfg and next(savedCfg) ~= nil then
        local backup, known = fileInfo(LEGACY_BACKUP_PATH)
        backedUp = known and (backup ~= nil or saveConfig(savedCfg, LEGACY_BACKUP_PATH, true))
    end
    if backedUp and saveConfig(nextCfg) then
        configSeen = true
        activateSelection()
        statusText = "Saved"
    else
        statusText = "Save failed"
        if lvgl and lvgl.message then
            lvgl.message({title = "Save failed", message = "Could not save colors and global controls. Check the SD card and RGBLED folder."})
        end
    end
end

local function screenMetrics()
    local width = math.max(1, tonumber(firmwareGlobal("LCD_W")) or 480)
    local scale = math.max(0.5, tonumber(lvgl.LCD_SCALE) or 1)
    local height = tonumber(lvgl.PAGE_BODY_HEIGHT)
    if not height or height < 1 then
        height = (tonumber(firmwareGlobal("LCD_H")) or 272) - math.floor(44 * scale + 0.5)
    end
    height = math.max(1, height)
    local control = math.max(math.floor(32 * scale + 0.5), tonumber(lvgl.UI_ELEMENT_HEIGHT) or 0)
    return width, height, scale, control,
        table.concat({width, height, scale, control}, ":")
end

local function buildUI()
    if not lvgl then
        if lcd and lcd.clear and lcd.drawText then
            lcd.clear()
            lcd.drawText(12, 12, "LVGL not available", 0)
            lcd.drawText(12, 38, "Enable LVGL in EdgeTX.", 0)
        end
        return
    end

    local screenW, screenH, scale, controlH, signature = screenMetrics()
    local function u(value) return math.max(1, math.floor(value * scale + 0.5)) end
    local margin, gap, pad = u(8), u(6), u(8)
    local contentW = math.max(1, screenW - 2 * margin)
    local wide = contentW >= u(540)
    local small = firmwareGlobal("SMLSIZE") or 0
    local normal = 0
    local titleFont = firmwareGlobal("MIDSIZE") or normal
    local labelH, labelGap = u(18), u(3)
    local fieldH = labelH + labelGap + controlH
    local radius = u(9)
    local function rgb(r, g, b)
        return lcd and lcd.RGB and lcd.RGB(r, g, b) or 0
    end
    local palette = {
        background = rgb(10, 16, 25), panel = rgb(23, 32, 46),
        line = rgb(43, 57, 75), text = rgb(240, 245, 251),
        muted = rgb(162, 180, 200), accent = rgb(80, 204, 223),
    }
    local objects = {}

    -- Use actual firmware text metrics when available, including long model
    -- names. Font selectors are discrete EdgeTX values, never added together.
    local function fitText(text, width, font)
        local function textWidth(value)
            if lcd and type(lcd.sizeText) == "function" then
                return lcd.sizeText(value, font)
            end
            return #value * u(font == small and 8 or 10)
        end
        if textWidth(text) <= width then return text end
        while #text > 0 and textWidth(text .. "...") > width do
            text = string.sub(text, 1, -2)
        end
        return text .. "..."
    end

    local function rectangle(nodes, x, y, w, h, color, rounded)
        nodes[#nodes + 1] = {
            type = "rectangle", x = x, y = y, w = w, h = h,
            color = color, filled = true, rounded = rounded or 0,
            scrollBar = false, scrollDir = lvgl.SCROLL_OFF
        }
        return nodes[#nodes]
    end
    local function label(nodes, x, y, w, text, color, font)
        local function fitted()
            return fitText(type(text) == "function" and text() or text, w, font or small)
        end
        nodes[#nodes + 1] = {
            type = "label", x = x, y = y, w = w,
            text = type(text) == "function" and fitted or fitted(),
            color = color or palette.text, font = font or small
        }
    end
    local function button(nodes, x, y, w, h, text, press, checked)
        nodes[#nodes + 1] = {
            type = "button", x = x, y = y, w = w, h = h,
            text = text, font = normal, cornerRadius = radius,
            checked = checked or false, press = press
        }
    end
    local function swatch(name)
        local c = colors[name]
        if not c then return name == "NONE" and palette.line or palette.accent end
        local peak = math.max(c.r, c.g, c.b)
        if peak == 0 then return rgb(0, 0, 0) end
        -- Swatches show the hue at readable brightness, not LED power output.
        return rgb(math.floor(c.r * 255 / peak), math.floor(c.g * 255 / peak), math.floor(c.b * 255 / peak))
    end
    local function choice(nodes, x, y, w, caption, title, values, get, set, key)
        local inset = key and u(17) or 0
        local swatchName
        if key then
            swatchName = "swatch_" .. title
            local square = rectangle(nodes, x, y + u(3), u(11), u(11), swatch(key()), u(3))
            square.name = swatchName
        end
        label(nodes, x + inset, y, w - inset, caption, palette.muted)
        nodes[#nodes + 1] = {
            type = "choice", x = x, y = y + labelH + labelGap,
            w = w, h = controlH, title = title, values = values,
            popupWidth = math.min(contentW, math.max(w, u(180))),
            get = get, set = function(value)
                set(value)
                selectionChanged()
                -- Update the retained square when the popup commits a choice.
                -- This leaves the page, focus and scroll position in place.
                local square = swatchName and objects[swatchName]
                if square then square:set({color = swatch(key())}) end
            end
        }
    end

    local children, panels = {}, {}
    rectangle(children, 0, 0, screenW, screenH, palette.background)
    local top = margin
    do
        local tabs = wide and {{"gimbals", "Colors"}, {"control", "Control"}}
            or {{"gimbals", "Gimbals"}, {"switches", "Switches"}, {"control", "Control"}}
        local tabW = math.floor((contentW - gap * (#tabs - 1)) / #tabs)
        for i, tab in ipairs(tabs) do
            local tabId = tab[1]
            button(children, margin + (i - 1) * (tabW + gap), top, tabW, controlH, tab[2], function()
                if activeTab ~= tabId then
                    activeTab = tabId
                    rebuildPending = true
                end
            end, activeTab == tabId or (wide and tabId == "gimbals" and activeTab == "switches"))
        end
        top = top + controlH + gap
    end

    local buttonH = math.max(controlH, u(34))
    local footerY = screenH - margin - buttonH
    local viewportH = math.max(1, footerY - gap - top)
    local viewportW = contentW
    -- Reserve space for a vertical scrollbar even on narrow portrait screens.
    local panelAreaW = math.max(1, viewportW - u(4))
    local panelW = wide and activeTab ~= "control" and math.floor((panelAreaW - gap) / 2) or panelAreaW

    local function buildPanel(kind, x)
        local nodes = {}
        local innerW = math.max(1, panelW - pad * 2)
        local y = pad
        if wide and kind ~= "control" then
            label(nodes, pad, y, innerW, kind == "gimbals" and "Gimbals" or "Switches", palette.text, titleFont)
            y = y + u(32)
            label(nodes, pad, y, innerW, kind == "gimbals" and "Colors and motion" or "Individual switch colors", palette.muted)
            y = y + labelH + gap
        end
        if kind == "control" then
            label(nodes, pad, y, innerW, function()
                return ledsEnabled and "Global lights: Enabled" or "Global lights: Disabled"
            end, palette.accent)
            y = y + labelH + gap
            local columns = innerW >= u(244) and 2 or 1
            local fieldW = math.floor((innerW - (columns - 1) * gap) / columns)
            for i, caption in ipairs({"Enable when", "Disable when"}) do
                local isEnable = i == 1
                local x = pad + ((i - 1) % columns) * (fieldW + gap)
                local fieldY = y + math.floor((i - 1) / columns) * (fieldH + gap)
                label(nodes, x, fieldY, fieldW, caption, palette.muted)
                nodes[#nodes + 1] = {
                    type = "switch", x = x, y = fieldY + labelH + labelGap,
                    w = fieldW, h = controlH,
                    filter = lvgl.SW_SWITCH + lvgl.SW_LOGICAL_SWITCH + lvgl.SW_CLEAR,
                    get = function() return isEnable and enableSwitch or disableSwitch end,
                    set = function(value)
                        if isEnable then enableSwitch = normalizeSwitch(value)
                        else disableSwitch = normalizeSwitch(value) end
                        selectionChanged()
                    end,
                }
            end
            y = y + math.ceil(2 / columns) * (fieldH + gap)
            for _, hint in ipairs({
                "Applies to every model.",
                "Clear both: always enabled.",
                "Both set: hold state between them.",
                "Disable wins; controlled LEDs turn off.",
            }) do
                label(nodes, pad, y, innerW, hint, palette.muted)
                y = y + labelH + labelGap
            end
        elseif kind == "gimbals" then
            local modeW = math.min(u(108), math.floor(innerW / 2))
            label(nodes, pad, y + math.floor((controlH - labelH) / 2), innerW - modeW - gap, "Per gimbal", palette.text)
            nodes[#nodes + 1] = {
                type = "choice", x = pad + innerW - modeW, y = y,
                w = modeW, h = controlH, title = "Per gimbal", values = modeLabels,
                popupWidth = math.min(contentW, u(180)),
                get = function() return gimbalModeIndex end,
                set = function(value) gimbalModeIndex = value; selectionChanged() end
            }
            y = y + controlH + gap
            local columns = innerW >= u(244) and 2 or 1
            local fieldW = math.floor((innerW - (columns - 1) * gap) / columns)
            choice(nodes, pad, y, fieldW,
                function() return gimbalModeIndex == 2 and "Color 1 / Left" or "Color 1" end,
                "Select color 1", colorLabels,
                function() return color1Index end, function(value) color1Index = value end,
                function() return allChoices[color1Index] end)
            local secondY = columns == 2 and y or y + fieldH + gap
            choice(nodes, columns == 2 and pad + fieldW + gap or pad, secondY, fieldW,
                function() return gimbalModeIndex == 2 and "Color 2 / Right" or "Color 2" end,
                "Select color 2", colorLabels,
                function() return color2Index end, function(value) color2Index = value end,
                function() return allChoices[color2Index] end)
            y = secondY + fieldH + gap
            label(nodes, pad, y, innerW, function()
                return gimbalModeIndex == 2 and "Left / right: static colors only." or "Effects: choose the same for both."
            end, palette.muted)
            y = y + labelH
        else
            local columns = math.max(1, math.min(3, math.floor((innerW + gap) / (u(112) + gap))))
            local fieldW = math.floor((innerW - (columns - 1) * gap) / columns)
            for i = 1, 6 do
                local index = i
                local column, row = (i - 1) % columns, math.floor((i - 1) / columns)
                choice(nodes, pad + column * (fieldW + gap), y + row * (fieldH + gap), fieldW,
                    "Switch " .. index, "Switch " .. index .. " color", switchLabels,
                    function() return swIndices[index] end, function(value) swIndices[index] = value end,
                    function() return switchColorNames[swIndices[index]] end)
            end
            y = y + math.ceil(6 / columns) * (fieldH + gap) - gap
            if viewportH >= y + pad + gap + labelH then
                y = y + gap
                label(nodes, pad, y, innerW, "None keeps the current color.", palette.muted)
                y = y + labelH
            end
        end
        local height = math.max(y + pad, viewportH)
        rectangle(panels, x, 0, panelW, height, palette.panel, radius)
        for _, node in ipairs(nodes) do
            node.x = node.x + x
            panels[#panels + 1] = node
        end
        return height
    end

    local contentH
    if wide and activeTab ~= "control" then
        local gimbalH = buildPanel("gimbals", 0)
        local switchH = buildPanel("switches", panelW + gap)
        contentH = math.max(gimbalH, switchH)
    else
        contentH = buildPanel(activeTab, 0)
    end
    children[#children + 1] = {
        type = "box", x = margin, y = top, w = viewportW, h = viewportH,
        borderPad = 0, scrollBar = contentH > viewportH,
        scrollDir = lvgl.SCROLL_VER, children = panels
    }

    local actionW = math.min(u(120), math.floor((contentW - gap * 2) / 3))
    local fromDashboard = type(lvgl.isDashboardTool) == "function" and lvgl.isDashboardTool()
    local backW = math.min(u(fromDashboard and 180 or 88), contentW - actionW - gap * 2 - u(40))
    local statusX = margin + backW + gap
    local statusW = contentW - backW - actionW - gap * 2
    local actionX = screenW - margin - actionW
    -- Use the normal standalone return code on the next run, never tear down
    -- the Lua state inside its own LVGL callback. Exit does not implicitly Save.
    button(children, margin, footerY, backW, buttonH,
        fromDashboard and "Back to dashboard" or "Close", function() exitRequested = true end)
    label(children, statusX, footerY + math.floor((buttonH - labelH) / 2), statusW,
        function() return statusText end, palette.accent)
    button(children, actionX, footerY, actionW, buttonH, "Save", saveSelection, true)

    lvgl.clear()
    objects = lvgl.build({{
        type = "page", title = "Custom colors",
        subtitle = fitText(activeTab == "control" and "All models" or (currentModel ~= "" and currentModel or "No model"), math.max(1, screenW - u(150)), small),
        back = function() exitRequested = true end,
        scrollBar = false, scrollDir = lvgl.SCROLL_OFF, children = children
    }}) or {}
    layoutSignature = signature
    rebuildPending = false
end

local initialized = false
local setupPrompted = false

local setupMessages = {
    existing_disabled = "GBLED is already configured but is disabled or not set to run continuously. Your existing Special Function has been kept.",
    functions_disabled = "Special Functions are disabled for this model. Enable them in Model Settings, then reopen Custom Colors.",
    no_slot = "There is no empty Special Function slot. Free a slot in Model Settings, then reopen Custom Colors.",
    script_limit = "The radio has reached its background Lua script limit. Remove an unused script assignment before adding GBLED.",
    missing_script = "GBLED is missing from /SCRIPTS/FUNCTIONS. Install the Custom Colors files, then reopen this tool.",
    wrong_model = "The model changed while setup was open. Reopen Custom Colors on the model you want to set up.",
    tool_required = "Background scripts cannot restart right now. Close this tool and try again after restarting the radio.",
}

local function checkBackgroundSetup()
    if setupPrompted then return end
    setupPrompted = true
    -- Older firmware retains manual setup. Never guess function slots or use a
    -- partial model.setCustomFunction write without the native checks.
    if not model or type(model.getCustomColorsSetup) ~= "function" or
        type(model.setupCustomColors) ~= "function" or not lvgl or
        type(lvgl.confirm) ~= "function" then return end
    local ok, setup = pcall(model.getCustomColorsSetup)
    if not ok or type(setup) ~= "table" then
        statusText = "Could not check GBLED setup"
        return
    end
    if setup.state == "existing" then return end
    if setup.state == "existing_disabled" then
        lvgl.message({title = "GBLED already configured", message = setupMessages.existing_disabled})
        return
    end
    local expectedModel = setup.model
    local answered = false
    lvgl.confirm({
        title = "Enable Custom Colors?",
        message = "Turn on Custom Colors for this model? This adds and enables GBLED. You can choose and save colors immediately.",
        confirm = function()
            if answered then return end
            answered = true
            local installed, result = pcall(model.setupCustomColors, expectedModel)
            if installed and type(result) == "table" and
                (result.state == "added" or result.state == "existing") then
                -- The native entry is already ON and enabled. Refresh this
                -- model and apply its saved colors now, while the editor owns
                -- the LEDs; GBLED takes over automatically when we leave.
                if loadModelSettings() then statusText = "GBLED enabled - ready to save" end
                rebuildPending = true
            else
                statusText = "GBLED was not added"
                lvgl.message({title = "GBLED setup", message =
                    (installed and type(result) == "table" and setupMessages[result.state]) or
                    "Could not add GBLED. Your existing Special Functions have been kept."})
            end
        end,
        cancel = function()
            answered = true
            statusText = "GBLED not added"
        end,
    })
end

local function init()
    exitRequested = false
    activeTab = "gimbals"
    appliedSelection = nil
    ledsEnabled = nil
    setupPrompted = false
    loadModelSettings()
    buildUI()
    initialized = true
end

local function run(event, touchState)
    if exitRequested or (event ~= nil and (event == EVT_EXIT_BREAK or event == EVT_VIRTUAL_EXIT)) then
        previewEffect = nil
        return 2
    end
    if not initialized then init() end
    local name, filename = getModelName()
    if name ~= currentModel or filename ~= currentModelFile then
        loadModelSettings()
        rebuildPending = true
    end
    if lvgl then
        local _, _, _, _, signature = screenMetrics()
        if rebuildPending or layoutSignature ~= signature then buildUI() end
    end

    -- Present after the page exists. Never repeat on Save, a tab change, or a
    -- frame refresh, and never infer consent from dismissing the prompt.
    checkBackgroundSetup()

    if not appliedSelection then return 0 end
    local enabled = switchControlEnabled(appliedSelection.enableSwitch, appliedSelection.disableSwitch, ledsEnabled)
    if enabled ~= ledsEnabled then
        ledsEnabled = enabled
        applyColors()
    end

    if ledsEnabled and previewEffect and appliedSelection.mode == "OFF" then
        local leftChoice = appliedSelection.left
        local rightChoice = appliedSelection.right
        if leftChoice == rightChoice and leftChoice == previewEffect and effects[previewEffect] then
            effects[previewEffect].run(effects[previewEffect].state)
        else
            previewEffect = nil
        end
    else
        previewEffect = nil
    end
    publishHandoff(appliedSelection.enableSwitch, appliedSelection.disableSwitch, ledsEnabled, true)
    return 0
end

-- Let EdgeTX route the scroll wheel and ENTER to the native LVGL controls.
-- Without this flag the legacy script window captures rotary input instead.
return { run = run, init = init, useLvgl = true }
