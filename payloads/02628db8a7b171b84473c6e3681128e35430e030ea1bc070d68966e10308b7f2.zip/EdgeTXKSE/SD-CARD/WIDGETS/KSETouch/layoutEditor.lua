-- On-demand native LVGL scene. No telemetry polling, MSP, timers or file writes
-- in getters/press callbacks. The host services one deferred action per frame.
return function(api,values,revision)
 local e={caution=true,draft={},selected=1,revision=revision,generation=0,returnSettings=api.integrated}
 for i=1,8 do e.draft[i]=values[i]end
 local choices={'battery','bec','cell','current','temp','gov','rpm','pack','link','tail','timer','capacity','empty'}
 local names={battery='Battery telemetry',bec='BEC output',cell='Cell voltage',current='Current',temp='ESC temperature',gov='Governor mode',rpm='Head RPM',pack='Pack voltage',link='Link quality',tail='Tail RPM',timer='Timer 1',capacity='Used capacity',empty='Empty tile'}
 local page=1
 local telemetry,store=api.telemetry,api.store
 local function stopDiscovery()
  if e.startedDiscovery then
   if lvgl and type(lvgl.setSensorDiscovery)=='function'then pcall(lvgl.setSensorDiscovery,false)end
   e.startedDiscovery=nil;e.discovering=false
  end
 end
 local function pollDiscovery(force)
  local now=getTime()
  if not force and e.discoveryPoll and now>=e.discoveryPoll and now-e.discoveryPoll<20 then return end
  e.discoveryPoll=now
  local getter=lvgl and lvgl.getSensorDiscovery
  e.discoveryAvailable=type(getter)=='function'and type(lvgl.setSensorDiscovery)=='function'
  if e.discoveryAvailable then
   local ok,active,count,maximum=pcall(getter)
   if ok and type(active)=='boolean' and type(count)=='number' and type(maximum)=='number'
      and count>=0 and count<=maximum and maximum<=128 and count%1==0 and maximum%1==0 then
    e.discovering=active;e.sensorCount=count;e.sensorMaximum=maximum
    if e.startedDiscovery and count==maximum then stopDiscovery();e.notice='Sensor limit reached' end
    -- A full catalog scan is spread over frames. Keep the old list on screen
    -- until the new scan is complete; never restart an in-progress scan.
    if telemetry and telemetry.complete and not telemetry.error and count~=#telemetry.entries then
     telemetry.restart()
    end
   else
    stopDiscovery();e.discoveryAvailable=false;e.notice='Sensor discovery unavailable'
   end
  end
  local count=e.sensorCount or (telemetry and #telemetry.entries or 0)
  local maximum=e.sensorMaximum or (telemetry and telemetry.maximum or 0)
  e.sensorStatus='Sensors: '..count..' / '..maximum..(e.discovering and '  •  Discovering...'or'')
 end
 local function toggleDiscovery()
  pollDiscovery(true)
  if not e.discoveryAvailable then e.notice='Sensor discovery needs updated KSE firmware';e.build();return end
  local enable=not e.discovering
  if enable and e.sensorCount>=e.sensorMaximum then e.notice='Sensor limit reached';e.build();return end
  local ok,accepted=pcall(lvgl.setSensorDiscovery,enable)
  if ok and accepted==true then
   e.startedDiscovery=enable or nil;e.discovering=enable;e.notice=nil
   if telemetry and telemetry.complete then telemetry.restart()end
  else e.notice='Could not change sensor discovery' end
  pollDiscovery(true);e.build()
 end
 local function nameOf(id)
  return names[id]or(telemetry and telemetry.title(id))or'Sensor'
 end
 local function assign(id)
  local key=store and store.fieldKey(id)or id
  if id~='empty'then for j=1,8 do
   if (store and store.fieldKey(e.draft[j])or e.draft[j])==key then e.draft[j]=e.draft[e.selected];break end
  end end
  e.draft[e.selected]=id;e.picker=false;e.details=nil;e.notice=nil;e.build()
 end
 function e.retire()stopDiscovery();e.generation=e.generation+1;e.closed=true;e.pending=nil;e.commit=nil;e.keyboard=nil end
 -- RTN cancels only the current name edit; the surrounding layout is kept.
 function e.back()
  if e.keyboard and not e.closed then
   e.keyboard=nil;e.pending=nil;e.generation=e.generation+1;e.rebuild=true
   return true
  end
  return false
 end
 -- Only model/scene retirement cancels deferred edits. Telemetry changes
 -- are independent of these local dashboard preferences.
 local function safe()
  if api.guard() then return true end
  e.retire();return false
 end
 function e.build()
  if e.picker~='radio' or e.details then stopDiscovery()end
  e.generation=e.generation+1;local token=e.generation
  lvgl.clear();local p=api.colors
  local function rect(x,y,w,h,c)lvgl.rectangle({x=x,y=y,w=w,h=h,filled=true,color=c,rounded=6})end
  local function label(x,y,w,text,font,c)
   lvgl.label({x=x,y=y,w=w,h=font==api.large and 44 or 28,text=text,font=font or api.small,color=c or p.text})
  end
  local function button(x,y,w,h,text,fn,primary,name,exit)
   local props={x=x,y=y,w=w,h=h,text=text,name=name or text,font=api.small,cornerRadius=6,color=primary and p.accent or p.panel,textColor=primary and p.accentText or p.text,
    press=function()
     if e.closed or e.pending or token~=e.generation then return end
     if exit then e.cancelRequested=true;return end
     if not safe() then return end
     e.pending=fn
    end}
   return lvgl.button(props)
  end
  rect(0,0,800,480,p.bg)
  if e.caution then
   label(20,16,740,api.integrated and 'Dashboard · Layout' or 'Dashboard layout',api.bold)
   rect(40,72,720,304,p.panel)
   lvgl.label({x=76,y=98,w=648,h=44,text='Caution',font=api.large,color=p.warning or p.accent,align=CENTERED})
   lvgl.label({x=76,y=160,w=648,h=126,font=api.large,color=p.text,align=CENTERED,
    text='Remove power from the aircraft or disconnect the motor out of an abundance of caution'})
   button(76,304,300,56,'Cancel',nil,false,nil,true)
   button(424,304,300,56,'Continue',function()e.caution=nil;e.build()end,true)
   return
  end
  if e.keyboard then
   local k=e.keyboard
   local function update(text)
    k.text=text;k.preview=text~='' and text or 'Sensor name';k.count=#text..' / 8'
   end
   update(k.text)
   label(20,16,740,'Tile name',api.bold)
   label(20,48,740,'Up to 8 characters. Leave blank to use the sensor name.',api.small,p.dim)
   rect(20,80,760,62,p.panel)
   label(36,86,630,function()return k.preview end,api.large,p.text)
   label(690,96,76,function()return k.count end,api.small,p.dim)
   local function key(x,y,w,char)
    button(x,y,w,48,char,function()
     if #k.text<8 then update(k.text..char)end
    end,false,'Key '..char)
   end
   local rows=k.symbols and {'1234567890','-_/:%+*=.,','!@#$&()[]',"'\"<>?\\|"}
     or {'1234567890','QWERTYUIOP','ASDFGHJKL','ZXCVBNM'}
   for row=1,4 do
    local text=rows[row]
    if not k.upper and not k.symbols then text=string.lower(text)end
    local width=row<=2 and 68 or row==3 and 76 or 66
    local start=row<=2 and 24 or row==3 and 26 or 118
    for i=1,#text do key(start+(i-1)*(width+8),152+(row-1)*56,width,string.sub(text,i,i))end
   end
   button(20,320,90,48,'Aa',function()k.upper=not k.upper;k.symbols=false;e.build()end,k.upper,'Case')
   button(636,320,144,48,'Delete',function()update(string.sub(k.text,1,-2))end,false,'Backspace')
   button(20,412,150,56,'Cancel',function()e.keyboard=nil;e.build()end)
   button(180,412,110,56,'Clear',function()update('')end)
   button(300,412,180,56,'Space',function()if #k.text<8 then update(k.text..' ')end end)
   button(490,412,135,56,k.symbols and 'ABC' or '#+=',function()k.symbols=not k.symbols;e.build()end,false,'Symbols')
   button(635,412,145,56,'Done',function()e.details.title=k.text;e.keyboard=nil;e.build()end,true)
   return
  end
  label(20,16,740,e.details and 'Telemetry tile options' or e.picker and 'Choose telemetry field' or (api.integrated and 'Dashboard · Layout' or 'Dashboard layout'),api.bold)
  if not e.picker and not e.details and not e.commit and not e.notice then
   lvgl.label({x=20,y=46,w=760,h=48,font=api.small,color=p.accent,
    text='Remove power from the aircraft or disconnect the motor out of an abundance of caution'})
  else
   label(20,48,750,e.picker=='radio' and function()return (e.sensorStatus or 'Reading sensors...')..(e.notice and '  •  '..e.notice or '')end
     or e.notice or 'Choose the information shown on your dashboard.',api.small,p.dim)
  end
  if e.commit then
   label(24,160,752,'Saving layout...',api.large)
  elseif e.details then
   local b=e.details
   local views=telemetry.views(b.unit)
   if e.units then
    label(20,88,740,'Display label only; the sensor value is not converted.',api.small,p.dim)
    local options={{255,'Auto'},{0,'None'},{1,'Volts (V)'},{2,'Amps (A)'},{11,'Celsius (°C)'},{12,'Fahrenheit (°F)'},{13,'Percent (%)'},{18,'RPM'},{20,'Degrees (°)'},{14,'Capacity (mAh)'},{15,'Watts (W)'},{16,'Power (mW)'},{17,'Signal (dB)'},{29,'Signal (dBm)'},{3,'Milliamps (mA)'}}
    for i=1,6 do local option=options[(page-1)*6+i];if option then
     button(20+(i-1)%2*390,138+math.floor((i-1)/2)*82,370,70,option[2],function()b.override=option[1];e.units=false;e.build()end,b.override==option[1])
    end end
    button(20,420,170,48,'Back',function()e.units=false;e.build()end)
    if page>1 then button(400,420,170,48,'Previous',function()page=page-1;e.build()end)end
    if page*6<#options then button(610,420,170,48,'Next',function()page=page+1;e.build()end)end
   else
    label(20,94,740,'Source: '..b.name..'  •  '..telemetry.unitName(b.unit),api.bold)
    local viewName='Current value';local index=1
    for i,view in ipairs(views)do if view[1]==b.view then index=i;viewName=view[2]end end
    button(20,146,760,52,'Display: '..viewName,function()b.view=views[index%#views+1][1];e.build()end)
    button(20,210,760,52,'Unit: '..(b.override==255 and 'Auto' or telemetry.unitName(b.override)),function()e.units=true;page=1;e.build()end)
    label(20,282,210,'Title (optional)',api.small,p.dim)
    button(240,274,540,52,b.title~='' and b.title or 'Name this tile',function()
     e.keyboard={text=b.title,upper=true};e.build()
    end,false,'Edit title')
    label(20,348,740,function()return e.preview or ''end,api.bold,p.accent)
    button(20,420,170,48,'Back',function()e.details=nil;e.picker='radio';page=1;e.build()end)
    button(540,420,240,48,'Use this sensor',function()
     local value=store.bind(b.key,b.view,b.override,b.title)
     if value then assign(value)end
    end,true)
   end
  elseif e.picker then
   button(20,88,370,42,'Standard tiles',function()e.picker='standard';page=1;e.build()end,e.picker~='radio')
   button(410,88,370,42,'Radio telemetry',function()e.picker='radio';page=1;e.build()end,e.picker=='radio')
   if e.picker=='radio'then
    e.catalogRevision=telemetry and telemetry.revision
    local entries=telemetry and telemetry.entries or {}
    if not telemetry or #entries==0 then
     label(24,180,752,function()
      if not telemetry then return 'Telemetry catalog unavailable' end
      if not telemetry.complete then return 'Reading telemetry '..telemetry.cursor..' / '..telemetry.maximum end
      return telemetry.error or 'No configured telemetry sensors'
     end,api.small,p.dim)
    else
     local pages=math.ceil(#entries/6);page=math.min(page,pages)
     for i=1,6 do local entry=entries[(page-1)*6+i];if entry then
      button(20+(i-1)%2*390,142+math.floor((i-1)/2)*82,370,70,
       entry.name..'  (#'..(entry.slot+1)..')\n'..telemetry.unitName(entry.unit),function()
        if telemetry.byKey[entry.key]==false then e.notice='Identical sensors: give each a unique name';e.build();return end
        local value=store.bind(entry.key,telemetry.defaultView(entry.unit))
        e.details=store.binding(value);e.picker=false;e.preview=nil;e.build()
       end,false,'Sensor '..(entry.slot+1))
     end end
     label(680,16,100,page..' / '..pages,api.small,p.dim)
     if page>1 then button(490,420,140,48,'Previous',function()page=page-1;e.build()end)end
     if page<pages then button(640,420,140,48,'Next',function()page=page+1;e.build()end)end
    end
    button(20,420,100,48,'Back',function()e.picker=false;e.build()end)
    button(130,420,110,48,'Refresh',function()if telemetry then telemetry.restart()end;page=1;e.build()end)
    button(250,420,230,48,function()return e.discovering and 'Stop Discovery'or'Discover Sensors'end,
      toggleDiscovery,true,'Discover Sensors')
   else
   local available={};for _,id in ipairs(choices)do if api.supported(id)then available[#available+1]=id end end
   local pages=math.ceil(#available/6);page=math.min(page,pages)
   for i=1,6 do
    local id=available[(page-1)*6+i]
    if id then button(20+(i-1)%2*390,142+math.floor((i-1)/2)*82,370,70,names[id],function()assign(id)end,false,'Field '..id)end
   end
   button(20,420,170,48,'Back',function()e.picker=false;e.build()end)
   if page>1 then button(400,420,170,48,'Previous',function()page=page-1;e.build()end)end
   if page<pages then button(610,420,170,48,'Next',function()page=page+1;e.build()end)end
   label(230,431,140,page..' / '..pages,api.small,p.dim)
   end
  else
   rect(20,94,360,176,p.panel)
   label(40,119,320,'Model image',api.bold,p.dim)
   label(40,165,320,'Image and dock stay fixed.',api.small,p.dim)
   for i=1,8 do
    local x,y,width,height
    if i<=4 then x=400+(i-1)%2*190;y=94+math.floor((i-1)/2)*88;width,height=180,80
    else x=20+(i-5)*192;y=280;width,height=184,80 end
    local text=nameOf(e.draft[i])
    if lcd.sizeText(text,api.small)>width-12 then text=string.gsub(text,' telemetry','');text=string.gsub(text,'temperature','temp');text=string.gsub(text,'Governor','Gov')end
    button(x,y,width,height,text,function()
     if e.swap then local old=e.draft[e.selected];e.draft[e.selected]=e.draft[i];e.draft[i]=old;e.swap=false end
     e.selected=i;e.notice=nil;e.build()
    end,e.selected==i,'Tile '..i)
   end
   button(20,368,184,44,'Choose field',function()e.picker='standard';e.swap=false;page=1;e.build()end)
   button(212,368,184,44,e.swap and 'Tap target' or 'Swap position',function()e.swap=not e.swap;e.build()end)
   button(404,368,184,44,'Tile options',function()
    local b=store and store.binding(e.draft[e.selected])
    if b and telemetry then e.details=b;e.preview=nil else e.notice='Options are available for radio telemetry tiles' end
    e.build()
   end)
   button(596,368,184,44,'Reset layout',function()e.draft=api.defaults();e.swap=false;e.build()end)
   button(20,424,api.integrated and 300 or 176,48,api.integrated and 'Cancel layout' or 'Cancel',nil,false,nil,true)
   button(540,424,240,48,'Save layout',function()
    local commit,reason=api.prepare(e.draft,e.revision)
    if commit then e.commit=commit else e.notice=reason end
    e.build()
   end,true)
  end
 end
 function e.tick()
  if e.closed then return false end
  if e.cancelRequested then e.retire();return false end
  if not safe()then return false end
  if e.rebuild then e.rebuild=nil;e.build();return true end
  if e.picker=='radio'then pollDiscovery()end
  if e.details and not e.keyboard and telemetry then
   local b=e.details;local value=store.bind(b.key,b.view,b.override,b.title)
   if value then local text,unit=telemetry.read(value);e.preview=text..(unit~='' and ' '..unit or '')end
  end
  if e.picker=='radio' and telemetry and telemetry.revision~=e.catalogRevision then e.build()end
  if e.commit then
   local commit=e.commit;e.commit=nil
   local ok,reason=commit()
   if ok then e.retire()else e.notice=reason;e.build()end
  else local action=e.pending;e.pending=nil;if action then action()end end
  return not e.closed
 end
 if safe()or not e.closed then e.build()end
 return e
end
