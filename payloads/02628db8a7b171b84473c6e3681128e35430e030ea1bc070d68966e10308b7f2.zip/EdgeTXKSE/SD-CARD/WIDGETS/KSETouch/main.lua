--[[
  KSE Touch - a touch home and RotorFlight tuning surface for EdgeTX.

  Based on KSE5: preserves its recorder, counters, alerts and profile safety.
  Large interactive screens use the touch home; compact zones use ring gauges.
]]

local G = {
  referenceW=480, referenceH=320,
  screenW=tonumber(_G.LCD_W) or 480,
  screenH=tonumber(_G.LCD_H) or 320,
  originX=0, originY=0, w=480, h=320,
  scaleX=1, scaleY=1, scaleMin=1,
  compact=true, largeScreen=false,
}
-- EdgeTX appends "-simu" to the radio name in Companion. A disconnected
-- physical radio must never be mistaken for the simulator.
G.companion = {active=false}
if type(getVersion) == "function" then
  local ok, _, radio = pcall(getVersion)
  G.companion.active = ok and type(radio) == "string"
                       and string.sub(radio, -5) == "-simu"
end
local SMLSIZE      = rawget(_G, "SMLSIZE")      or SMLSIZE      or 0
local MIDSIZE      = rawget(_G, "MIDSIZE")      or MIDSIZE      or 0
local BOLD_FONT    = _G.BOLD or SMLSIZE
G.fontSmall, G.fontRingValue, G.fontTileValue = SMLSIZE, MIDSIZE, MIDSIZE
G.fontGovernorValue, G.fontTop, G.fontTimer = MIDSIZE, MIDSIZE, MIDSIZE
G.signalHeights = { 6, 10, 14, 18 }
local VALUE  = rawget(_G, "VALUE")  or 0
local BOOL   = rawget(_G, "BOOL")   or 2
local CHOICE = rawget(_G, "CHOICE") or 10
local STRING = rawget(_G, "STRING") or 3
local SOURCE = rawget(_G, "SOURCE") or _G.SOURCE or 1
-- EdgeTX exposes these flags through its read-only global lookup table. The
-- public Lua name for CENTERED is CENTER, so rawget("CENTERED") silently
-- returned nil and made every intended centered/right-aligned label align left.
local RIGHT = rawget(_G, "RIGHT") or _G.RIGHT or 0
local CENTERED = rawget(_G, "CENTER") or rawget(_G, "CENTERED")
                 or _G.CENTER or _G.CENTERED or 0
G.rounded = function(v)
  return math.floor(v + 0.5)
end
G.x = function(v)
  return G.rounded(v * G.scaleX)
end
G.y = function(v)
  return G.rounded(v * G.scaleY)
end
G.min = function(v)
  return G.rounded(v * G.scaleMin)
end
G.positiveSize = function(v, fallback)
  v = tonumber(v)
  if not v or v < 1 then return fallback end
  return G.rounded(v)
end
G.bounds = function(zone, fullScreen)
  if fullScreen then return 0, 0, G.screenW, G.screenH end
  local w = G.positiveSize(zone and zone.w, G.screenW)
  local h = G.positiveSize(zone and zone.h, G.screenH)
  local x = G.rounded(tonumber(zone and zone.x) or 0)
  local y = G.rounded(tonumber(zone and zone.y) or 0)
  return x, y, w, h
end
G.signature = function(x, y, w, h)
  return table.concat({ x, y, w, h }, ":")
end
G.configure = function(x, y, w, h)
  G.originX, G.originY, G.w, G.h = x, y, w, h
  G.scaleX = w / G.referenceW
  G.scaleY = h / G.referenceH
  G.scaleMin = math.min(G.scaleX, G.scaleY)
  G.compact = w <= 520
  G.largeScreen = w >= 700 and h >= 420

  -- EdgeTX font constants are discrete selectors, not arithmetic style flags.
  -- Keep general values at MIDSIZE. On compact governor tiles, standalone
  -- BOLD is the useful step between SMLSIZE and MIDSIZE; it must not be added
  -- to another font selector. Fall back to SMLSIZE if firmware omits BOLD.
  G.fontSmall = SMLSIZE
  G.fontRingValue = MIDSIZE
  G.fontTileValue = MIDSIZE
  G.fontGovernorValue = G.compact and BOLD_FONT or MIDSIZE
  G.fontTop = MIDSIZE
  G.fontTimer = MIDSIZE
end
local C_BG, C_TOP, C_PANEL, C_PANEL_ALT, C_BORDER, C_TRACK
local C_TEXT, C_DIM, C_ACCENT, C_IMAGE_BG
local C_GREEN, C_YELLOW, C_RED, C_BLUE, C_CYAN, C_ORANGE
-- Rectangle opacity affects only the fill, so child arcs stay fully legible.
-- Leave the wallpaper untouched in the gutters; shade only content surfaces.
local TRANSPARENT_PANEL_OPACITY, TRANSPARENT_HEADER_OPACITY = 115, 208

-- RotorFlight 2.3 exposes six battery-profile slots. MSP uses zero-based
-- indexes while the BAT# telemetry sensor and the user-facing UI use 1..6.
local BATTERY_PROFILE_COUNT = 6

local GOV_STATES = {
  [0]="OFF",      [1]="IDLE",     [2]="SPOOLUP", [3]="RECOVERY",
  [4]="ACTIVE",   [5]="THR-OFF",  [6]="LOST-HS",
  [7]="AUTOROT",  [8]="BAILOUT",  [9]="BYPASS",
}
local GOV_RUNNING_STATE = { [2]=true, [3]=true, [4]=true, [8]=true, [9]=true }
local GOV_STOP_STATE = { [0]=true, [5]=true, [7]=true }
local GOV_PAUSE_HOLD_STATE = { [0]=true, [1]=true, [5]=true, [7]=true }
local GOV_COLOR, GOV_FALLBACK = {}, {}

local function applyTheme(name)
  local rgb = lcd.RGB
  -- KSE4-inspired opaque palettes. Each entry retains KSE4's background,
  -- tile, border, muted-text, and accent colors; KSE Touch derives its additional
  -- top-bar, alternate-panel, and ring-track layers from those five anchors.
  -- Only the selected palette is allocated, which keeps radio memory bounded.
  local p
  if name == "red" then
    p = {100,18,18, 130,28,28, 180,50,50, 240,165,165, 255,95,95}
  elseif name == "blue" then
    p = {4,20,54, 10,32,74, 28,72,124, 150,180,220, 80,165,255}
  elseif name == "pink" then
    p = {145,0,83, 184,0,105, 255,20,147, 255,196,225, 255,222,239}
  elseif name == "purple" then
    p = {34,12,60, 50,22,82, 92,46,140, 190,165,225, 175,110,245}
  elseif name == "graphite" then
    p = {18,21,25, 34,39,46, 75,85,98, 165,175,188, 215,225,235}
  elseif name == "sunset" then
    p = {96,12,10, 160,48,8, 230,105,20, 255,191,145, 255,190,48}
  elseif name == "synthwave" then
    p = {22,10,55, 59,13,70, 147,35,126, 205,154,226, 71,229,255}
  elseif name == "voltage" then
    p = {9,19,10, 26,37,17, 83,117,31, 183,204,145, 185,255,50}
  elseif name == "titanium_ember" then
    p = {11,14,18, 41,49,58, 100,113,125, 174,184,193, 255,138,61}
  end
  if p then
    C_BG        = rgb(p[1], p[2], p[3])
    C_TOP       = rgb(math.floor((p[1] * 2 + p[4]) / 3 + 0.5),
                      math.floor((p[2] * 2 + p[5]) / 3 + 0.5),
                      math.floor((p[3] * 2 + p[6]) / 3 + 0.5))
    C_PANEL     = rgb(p[4], p[5], p[6])
    C_PANEL_ALT = rgb(math.floor((p[4] * 2 + p[7]) / 3 + 0.5),
                      math.floor((p[5] * 2 + p[8]) / 3 + 0.5),
                      math.floor((p[6] * 2 + p[9]) / 3 + 0.5))
    C_BORDER    = rgb(p[7], p[8], p[9])
    C_TRACK     = rgb(math.floor((p[4] + p[7]) / 2 + 0.5),
                      math.floor((p[5] + p[8]) / 2 + 0.5),
                      math.floor((p[6] + p[9]) / 2 + 0.5))
    C_TEXT      = rgb(245, 245, 245)
    C_DIM       = rgb(p[10], p[11], p[12])
    C_ACCENT    = rgb(p[13], p[14], p[15])
    C_IMAGE_BG  = C_PANEL_ALT
  elseif name == "obsidian" then
    C_BG        = rgb(9, 10, 12)
    C_TOP       = rgb(14, 16, 19)
    C_PANEL     = rgb(20, 23, 27)
    C_PANEL_ALT = rgb(34, 38, 45)
    C_BORDER    = rgb(68, 75, 85)
    C_TRACK     = rgb(46, 52, 61)
    C_TEXT      = rgb(244, 246, 248)
    C_DIM       = rgb(178, 187, 198)
    C_ACCENT    = rgb(224, 231, 239)
    C_IMAGE_BG  = C_PANEL_ALT
  elseif name == "copper" then
    C_BG        = rgb(18, 16, 15)
    C_TOP       = rgb(25, 21, 19)
    C_PANEL     = rgb(33, 29, 26)
    C_PANEL_ALT = rgb(48, 41, 37)
    C_BORDER    = rgb(102, 82, 71)
    C_TRACK     = rgb(72, 59, 50)
    C_TEXT      = rgb(250, 240, 231)
    C_DIM       = rgb(204, 185, 169)
    C_ACCENT    = rgb(242, 173, 121)
    C_IMAGE_BG  = C_PANEL_ALT
  elseif name == "amethyst" then
    C_BG        = rgb(20, 18, 24)
    C_TOP       = rgb(28, 24, 34)
    C_PANEL     = rgb(36, 31, 44)
    C_PANEL_ALT = rgb(52, 43, 64)
    C_BORDER    = rgb(101, 84, 119)
    C_TRACK     = rgb(70, 56, 84)
    C_TEXT      = rgb(245, 239, 251)
    C_DIM       = rgb(197, 180, 215)
    C_ACCENT    = rgb(205, 176, 237)
    C_IMAGE_BG  = C_PANEL_ALT
  elseif name == "light" then
    -- Keep white surfaces untinted, including the inherited image backdrop.
    C_BG        = rgb(255, 255, 255)
    C_TOP       = rgb(255, 255, 255)
    C_PANEL     = rgb(255, 255, 255)
    C_PANEL_ALT = rgb(255, 255, 255)
    C_BORDER    = rgb(176, 176, 176)
    C_TRACK     = rgb(216, 216, 216)
    C_TEXT      = rgb(8, 27, 43)
    C_DIM       = rgb(61, 88, 111)
    C_ACCENT    = rgb(0, 137, 224)
    C_IMAGE_BG  = C_PANEL_ALT
  elseif name == "transparent" then
    C_BG        = rgb(8, 12, 18)
    C_TOP       = rgb(8, 12, 18)
    C_PANEL     = rgb(8, 12, 18)
    C_PANEL_ALT = rgb(8, 12, 18)
    C_BORDER    = rgb(93, 107, 121)
    C_TRACK     = rgb(39, 51, 65)
    C_TEXT      = rgb(255, 255, 255)
    C_DIM       = rgb(210, 220, 230)
    C_ACCENT    = rgb(157, 220, 246)
    C_IMAGE_BG  = C_PANEL
  elseif name == "arctic" then
    C_BG        = rgb(2, 10, 21)
    C_TOP       = rgb(4, 19, 37)
    C_PANEL     = rgb(7, 29, 53)
    C_PANEL_ALT = rgb(9, 40, 70)
    C_BORDER    = rgb(24, 85, 128)
    C_TRACK     = rgb(14, 55, 88)
    C_TEXT      = rgb(239, 249, 255)
    C_DIM       = rgb(115, 172, 208)
    C_ACCENT    = rgb(26, 211, 255)
    C_IMAGE_BG  = C_PANEL_ALT
  elseif name == "orange" then
    C_BG        = rgb(18, 5, 0)
    C_TOP       = rgb(44, 12, 0)
    C_PANEL     = rgb(62, 18, 0)
    C_PANEL_ALT = rgb(86, 26, 0)
    C_BORDER    = rgb(190, 68, 0)
    C_TRACK     = rgb(126, 35, 0)
    C_TEXT      = rgb(255, 250, 238)
    C_DIM       = rgb(255, 176, 92)
    C_ACCENT    = rgb(255, 132, 0)
    C_IMAGE_BG  = C_PANEL_ALT
  else
    C_BG        = rgb(2, 2, 2)
    C_TOP       = rgb(5, 5, 5)
    C_PANEL     = rgb(10, 10, 10)
    C_PANEL_ALT = rgb(15, 15, 15)
    C_BORDER    = rgb(42, 42, 42)
    C_TRACK     = rgb(26, 26, 26)
    C_TEXT      = rgb(245, 245, 245)
    C_DIM       = rgb(150, 150, 150)
    C_ACCENT    = rgb(230, 230, 230)
    C_IMAGE_BG  = C_PANEL_ALT
  end
  -- Telemetry and status colors always match Dark, independently of the
  -- decorative palette: battery/current bars, MAX values, and governor states.
  -- Opt-in native palette, sampled only on scene/options or version change.
  -- The shared telemetry status colors below remain unchanged.
  if name == "radio" and type(getRadioTheme) == "function" then
    local ok, palette = pcall(getRadioTheme)
    if ok and type(palette) == "table" then
      local function color(role, fallback)
        local n = palette[role]
        if type(n) ~= "number" or n ~= n or n < 0 or n > 0xffffff then return fallback end
        return rgb(math.floor(n / 65536), math.floor(n / 256) % 256, n % 256)
      end
      C_BG=color("background", C_BG); C_TOP=C_BG
      C_PANEL=color("surface", C_PANEL); C_PANEL_ALT=C_PANEL
      C_BORDER=color("line", C_BORDER); C_TRACK=C_BORDER
      C_TEXT=color("ink", C_TEXT); C_DIM=color("muted", C_DIM)
      C_ACCENT=color("accent", C_ACCENT); C_IMAGE_BG=C_PANEL
    end
  end
  C_GREEN  = rgb(28, 232, 119)
  C_YELLOW = rgb(255, 196, 48)
  C_ORANGE = rgb(255, 112, 28)
  C_RED    = rgb(255, 64, 80)
  C_BLUE   = rgb(55, 136, 255)
  C_CYAN   = rgb(30, 220, 240)
  GOV_COLOR.ACTIVE      = C_GREEN
  GOV_COLOR.IDLE        = C_YELLOW
  GOV_COLOR.SPOOLUP     = C_YELLOW
  GOV_COLOR.RECOVERY    = C_YELLOW
  GOV_COLOR.OFF         = C_RED
  GOV_COLOR["THR-OFF"] = C_RED
  GOV_COLOR["LOST-HS"] = C_RED
  GOV_COLOR.AUTOROT     = C_BLUE
  GOV_COLOR.BAILOUT     = C_BLUE
  GOV_COLOR.BYPASS      = C_BLUE
  GOV_FALLBACK          = C_DIM
end

local function clamp(v, lo, hi)
  if v < lo then return lo end
  if v > hi then return hi end
  return v
end

local function round(v)
  if v >= 0 then return math.floor(v + 0.5) end
  return math.ceil(v - 0.5)
end
-- Shared, SD-card-wide flight history. Keeping one authoritative root file
-- lets other dashboards use the same per-model counters without migration or
-- competing widget-local copies.
local FLIGHTS_PATH              = "/flights-count.csv"
local TOPBAR_MIN_DUR_DEFAULT    = 20
local FLIGHT_CACHE_MAX_ENTRIES  = 200
local flightCache       = nil
local modelFlights      = 0
local minFlightDur      = TOPBAR_MIN_DUR_DEFAULT
local flightModel       = "__default__"
local timerThresholdArmed = nil
-- Flight totals can belong either to KSE's Timer 1/CSV counter or to
-- RotorFlight's persistent FC statistics. Keeping the FC runtime in one table
-- makes source changes explicit and avoids adding another telemetry transport.
local FC = {
  STACYDASH=1, ROTORFLIGHT=2, SIM_PREVIEW=3,
  disarmStableTicks=150,
  confirmMaxReads=6,
  count=nil, status="STACYDASH", stale=false,
  wanted=false, pending=false, stableSince=nil,
  state=nil, armState=nil, model=nil, flightSeenArmed=false,
  refreshBase=nil, refreshAttempts=0,
  minArmedSeconds=nil, armedSince=nil, refreshQualified=false,
}
local S = {
  rpmMax = 0,
  currMax = 0, tempMax = 0,
  becMin = nil, cellMin = nil,
}
local D = {
  adjustedPercent = 0,
  hasBattData     = false,
  isLiHV          = false,
  capacity        = 0,
  minCellVoltage  = nil,
  voltage         = 0,
  cellsResolved   = 0,
  rxVoltage       = nil,
  rxCellVoltage   = nil,
  rxPercent       = 0,
  minRxVoltage    = nil,
  packVoltageValid= false,
  cellCountValid  = false,
  cellVoltageValid= false,
  batteryPercentValid = false,
  capacityValid   = false,
  currentValid    = false,
  tempValid       = false,
  becValid        = false,
  rpmValid        = false,
  tailRpmValid    = false,
  govValid        = false,
  govCurrentInvalid = false,
}
local PROFILE_CONFIRMED = {
  value = nil,
  tick = nil,
}
local A = {
  displayPercent     = 0,
  displayPercentInit = false,
  battAlertPrevPct       = nil,
  battAlertPrevSource    = nil,
  battVoicePlayed        = {},
  battZeroReached        = false,
  deadVoiceNextTick      = 0,
  flightDeadVoiceLatched = false,
  flightDeadVoiceAcknowledged = false,
  flightDeadVoiceStartPosition = nil,
  motorSwitchPosition    = nil,
  motorSwitchLastPosition= nil,
  motorPausedPosition    = nil,
  motorGateCandidateFrom = nil,
  motorGateCandidateTo   = nil,
  motorGateCandidateTick = nil,
  govGateLastState       = nil,
  govGateRunningPosition = nil,
  govGateStopTick        = nil,
  govGateStopSince       = nil,
  electricRpmGateRunningPosition = nil,
  electricRpmGateZeroSince       = nil,
  ompGateRunningPosition = nil,
  ompGateZeroSince       = nil,
  flightBatteryAlertsPaused = false,
  batteryAlertPauseTick  = nil,
  motorPauseProof        = nil,
  battAlert5HapticPlayed = false,
  battAlert0HapticPlayed = false,
  battAlertNextTick      = 0,
  battHapticState        = 0,
  battHapticBurstCount   = 0,
  battHapticNextTick     = 0,
  battHapticEndTick      = 0,
  battLinkWasAvailable   = false,
  battConnectionZeroPending = false,
  battConnectionZeroSince = nil,
  ompStartup = nil,
  ompStartupWarning = false,
  escTempAlertPlayed = false,
  becAlertPlayed     = false,
  liHvHighSamples       = 0,
  motorSourcePhysical   = false,
  motorSourceReadable   = false,
  motorConfigError      = "SET MOTOR SWITCH",
  flightSaveError       = false,
  linkAvailable          = false,
  linkSourceKnown        = false,
  linkSourceSeen         = false,
  battReplacementSince  = nil,
  rxLowSinceTick         = nil,
  rxLowHapticNext        = 0,
  rxDeadVoiceLatched     = false,
  rxDeadVoiceAcknowledged= false,
  rxDeadVoiceStartPosition = nil,
  rxDeadVoiceNextTick    = 0,
  escTempHighSince       = nil,
  becLowSince            = nil,
  lastDataTick = -1,
}
local HELI_ELECTRIC, HELI_NITRO, HELI_OMPHOBBY, AIRCRAFT_FIXED_WING = 1, 2, 3, 4
local OPT = {
  heliType     = HELI_ELECTRIC,
  battBarMode   = 0,
  reservePct    = 0,
  battVoice     = false,
  rxPackMin     = 6.6,
  rxPackMax     = 8.4,
  rxPackValid   = true,
  bgTransparent = false,
  themeName     = "dark",
  simTelemetry  = false,
  flightCounter = FC.ROTORFLIGHT,
}
local BATTERY_VOICE = {
  levels       = { 50, 40, 30, 20, 10, 0 },
  path         = "/WIDGETS/KSETouch/BatterySounds/",
  available    = {},
  initialDelay = 250,
  repeatDelay  = 220,
  replacementConfirm = 100, -- require a one-second rise before rearming for a new pack
}
BATTERY_VOICE.deadPath = BATTERY_VOICE.path .. "dead.wav"
-- Percentage clips are currently about 0.8-1.0s and dead.wav is ~1.18s.
-- These conservative delays keep files from continuously filling the EdgeTX
-- audio queue and leave clear silence between critical repetitions.
local SAFETY = {
  batteryAlertCooldown = 220, -- comfortably longer than the percentage clips
  batteryHapticThreshold = 10,
  batteryConnectionZeroConfirm = 300, -- 3s continuous 0% after link acquisition
  ompStartupCellVoltage = 4.0, -- average RxBt voltage per M1/M2 cell, startup only
  ompStartupConfirmTicks = 150, -- 1.5s of confirmed startup evidence
  batteryPercentUnit = rawget(_G, "UNIT_PERCENT") or 13,
  rxLowArmTicks = 200,        -- low receiver pack must persist for 2.0s
  rxLowHapticInterval = 20,   -- then buzz every 0.2s while it stays low
  escTempThreshold = 110,
  escTempRearm = 100,
  becAlertMinVoltage = 4.0, -- ignore USB leakage when no receiver pack is powered
  becVoltThreshold = 4.8,
  becVoltRearm = 5.0,
  alertConfirmTicks = 50,     -- ESC/BEC conditions must persist for 0.5s
  displayPercentAlpha = 0.15,
  rxPackMinAllowed = 4.0,
  rxPackMaxAllowed = 9.0,
  maxCellCount = 16,
  maxCellSanityV = 4.5,
  cellRedThreshold = 3.50,
  liHvDetectCellV = 4.22,
  liHvConfirmSamples = 10, -- one continuous second at the 10 Hz service rate
  govMotorCorrelationTicks = 150, -- switch/Gov events may arrive 1.5s apart
  govMotorStopConfirmTicks = 20,  -- require 0.2s of recognized stopped state
  electricMotorStopWindowTicks = 3000, -- allow a 30s Hspd coast-down
  electricMotorZeroConfirmTicks = 30, -- require 0.3s of displayed-zero Hspd
  electricMotorRunningRpm = 1, -- raw Hspd below 1 RPM matches displayed zero
  ompMotorStopWindowTicks = 3000, -- allow a 30s autorotation/spindown
  ompMotorZeroConfirmTicks = 30,   -- require 0.3s of displayed-zero RPM telemetry
  ompMotorRunningRpm = 1, -- raw RPM below 1 matches the displayed zero state
}
-- Source metadata distinguishes a missing zero from a live value. This matters
-- most for Smart Fuel: Bat%=0 is meaningful only when a flight pack is actually
-- present, while positive current values can stand on their own.
local txIsLiIon = false
local F = {}
local RESOLVED = {}
local function clearFrameCache()
  for k in pairs(F) do F[k] = nil end
end
-- Localize the hottest host globals so per-call lookups skip the global table.
local getValue = getValue
local getTime  = getTime
-- getTime(), cached once per frame. Alert paths ask for "now" repeatedly
-- within a single frame; this collapses those into one host call.
local function frameNow()
  local t = F.now
  if t ~= nil then return t end
  t = (getTime and getTime()) or 0
  F.now = t
  return t
end
local SRC = {}
local function getValSrc(srcId)
  if not srcId or srcId == 0 then return nil end
  local ok, v = pcall(getValue, srcId)
  if not ok or v == nil then return nil end
  if type(v) == "table" then v = v.value end
  return tonumber(v)
end
-- Parse an Rx-pack voltage typed as text ("6.60"), tolerant of whether EdgeTX
-- text entry offers a ".", and backward-compatible with the old integer scale:
--   <=15 -> volts as typed (6.6) ; 16-150 -> old tenths (66->6.6) ; >150 -> hundredths (660->6.6)
local function parseVolt(s, default)
  local str = string.match(tostring(s or ""), "^%s*(.-)%s*$")
  local validText = string.match(str, "^%d+$")
                    or string.match(str, "^%d+[.,]%d+$")
                    or string.match(str, "^[.,]%d+$")
  if not validText then return default end
  str = string.gsub(str, ",", ".")
  local v = tonumber(str)
  if not v or v <= 0 then return default end
  if v > 150 then return v / 100 end
  if v > 15  then return v / 10  end
  return v
end
local getFieldInfoFn = getFieldInfo
local getSourceNameFn = getSourceName
local function isPhysicalMotorSource(src)
  local id = tonumber(src)
  if not id or id == 0 then return false end

  local inspected = false
  if getFieldInfoFn then
    local ok, info = pcall(getFieldInfoFn, id)
    inspected = ok
    if ok and type(info) == "table" then
      local name = string.upper(tostring(info.name or ""))
      local desc = string.upper(tostring(info.desc or ""))
      if string.match(name, "^S[A-Z]$") or string.match(desc, "^SWITCH%s+[A-Z]") then
        return true
      end
    end
  end
  if getSourceNameFn then
    local ok, name = pcall(getSourceNameFn, id)
    inspected = inspected or ok
    if ok and string.match(string.upper(tostring(name or "")), "^S[A-Z]$") then
      return true
    end
  end

  -- Older supported firmwares may not expose source inspection. A configured,
  -- readable SOURCE is still safer than silently falling back to a channel.
  return not inspected
end
G.appearanceLinked = function()
  return type(getAppAppearanceMode)=="function" and getAppAppearanceMode()==true
end
G.applyAppearance = function(opts)
  local rawTheme = tonumber(opts and opts.Theme) or 0
  -- Theme schema 2: compact kept choices; migrate saved numeric options at install.
  local themeNames = {
    [1]="dark",
    [2]="light",
    [3]="arctic",
    [4]="orange",
    [5]="red",
    [6]="blue",
    [7]="pink",
    [8]="purple",
    [9]="graphite",
    [10]="sunset",
    [11]="synthwave",
    [12]="voltage",
    [13]="titanium_ember",
    [14]="transparent",
    [15]="obsidian",
    [16]="copper",
    [17]="amethyst",
    [18]="radio",
  }
  OPT.themeLinked = G.appearanceLinked()
  OPT.themeName = OPT.themeLinked and "radio" or themeNames[rawTheme] or "dark"
  OPT.bgTransparent = OPT.themeName == "transparent"
  -- Native firmware owns the one radio-wide decoded image. Sample only when
  -- options/scenes change, never touch the SD card in the Lua refresh loop.
  OPT.hasBackground = lvgl and type(lvgl.hasHomeBackground)=="function" and lvgl.hasHomeBackground() or false
  applyTheme(OPT.themeName)
  OPT.themeRevision=type(getRadioThemeVersion)=="function" and getRadioThemeVersion() or nil
end

local function applyOptions(opts)
  local voltageSource = tonumber(opts and opts.FwVolt) or 0
  if voltageSource < 0 or voltageSource > 65535 or voltageSource ~= math.floor(voltageSource) then voltageSource = 0 end
  OPT.fwVoltageSource = voltageSource
  local cells = (tonumber(opts and opts.FwCells) or 1) - 1
  if cells < 0 or cells > 16 or cells ~= math.floor(cells) then cells = 0 end
  OPT.fwCells = cells
  OPT.ompPack = tonumber(opts and opts.OmpPack) or 1
  if OPT.ompPack < 1 or OPT.ompPack > 3 or OPT.ompPack ~= math.floor(OPT.ompPack) then OPT.ompPack = 1 end
  local debriefSwitch = tonumber(opts and opts.DebriefSw) or 0
  if debriefSwitch < 0 or debriefSwitch ~= debriefSwitch or math.abs(debriefSwitch) == math.huge
     or debriefSwitch ~= math.floor(debriefSwitch) then debriefSwitch = 0 end
  if G.debrief and OPT.debriefSwitch ~= debriefSwitch then
    G.debrief.state.switchId, G.debrief.state.switchActive = nil, nil
  end
  OPT.debriefSwitch = debriefSwitch
  G.applyAppearance(opts)
  -- CountSrc keeps slot 10 and preserves the first nine saved option
  -- positions.
  local rawCounter = tonumber(opts and (opts.CountSrc
                                         or opts["Flight Counter"]))
  if rawCounter == nil and opts and (opts.SimTelem == 1 or opts.SimTelem == true) then rawCounter = FC.SIM_PREVIEW end
  if rawCounter ~= FC.STACYDASH
     and rawCounter ~= FC.SIM_PREVIEW and rawCounter ~= FC.ROTORFLIGHT then
    rawCounter = FC.ROTORFLIGHT
  end
  OPT.flightCounter = rawCounter
  OPT.simTelemetry = G.companion.active or rawCounter == FC.SIM_PREVIEW
  local rawBatt = tonumber(opts and opts.TxBatt) or 0
  txIsLiIon = (rawBatt == 2)
  local rawDur = tonumber(opts and (opts.MinFlight
                                    or opts["KSE Counter Min (sec)"]
                                    or opts["Min. Flight Time (sec)"]
                                    or opts.TopMinDur))
                 or TOPBAR_MIN_DUR_DEFAULT
  if rawDur < 0 then rawDur = math.abs(rawDur) end
  if rawDur < 1 then rawDur = 1 end
  minFlightDur = rawDur
  local sgInfo = type(getFieldInfo) == "function" and getFieldInfo("SG") or nil
  local defaultMotorSwitch = type(sgInfo) == "table" and sgInfo.id or 0
  SRC.motorSwitch = defaultMotorSwitch
  if opts then
    -- Rotorflight Gov/Hspd or OMP RPM telemetry validates Motor Switch
    -- movement; telemetry sensors auto-detect independently of the two controls.
    SRC.motorSwitch = opts.MotorSw or opts["Motor Switch"]
                      or defaultMotorSwitch
    -- Keep the existing option key/slot and helicopter values compatible.
    -- Aircraft Type adds Fixed Wing=4 without rewriting saved models.
    local bb = tonumber(opts.HeliType or opts["Aircraft Type"] or opts["Heli Type"]) or 1
    if bb < 1 or bb > 4 or bb ~= math.floor(bb) then bb = 1 end
    OPT.heliType = bb
    OPT.battBarMode = (bb == HELI_NITRO) and 1 or 0
    OPT.reservePct  = tonumber(opts.BattRsv or opts["Batt Reserve %"]) or 0
    if OPT.reservePct < 0 then OPT.reservePct = 0 end
    if OPT.reservePct > 50 then OPT.reservePct = 50 end
    OPT.battVoice   = (opts.BattVoice == 1 or opts.BattVoice == true)
    local parsedMin = parseVolt(opts.RxPackMin, nil)
    local parsedMax = parseVolt(opts.RxPackMax, nil)
    OPT.rxPackMin = parsedMin or 6.6
    OPT.rxPackMax = parsedMax or 8.4
    OPT.rxPackValid = parsedMin ~= nil and parsedMax ~= nil
                       and parsedMin >= SAFETY.rxPackMinAllowed
                       and parsedMax <= SAFETY.rxPackMaxAllowed
                       and (parsedMax - parsedMin) >= 0.1
  end
  A.motorSourcePhysical = isPhysicalMotorSource(SRC.motorSwitch)
  A.motorSourceReadable = A.motorSourcePhysical
                          and getValSrc(SRC.motorSwitch) ~= nil
  if OPT.simTelemetry then
    A.motorConfigError = nil
  elseif not A.motorSourcePhysical then
    A.motorConfigError = "SELECT A PHYSICAL MOTOR SWITCH"
  elseif not A.motorSourceReadable then
    A.motorConfigError = "MOTOR SWITCH UNAVAILABLE"
  else
    A.motorConfigError = nil
  end
end
local modelImageCache = { key=nil, path=nil }
local READ_ALL_MAX_BYTES = 32 * 1024
local function readAll(path)
  local f = io.open(path, "r")
  if not f then return nil, false end
  local parts = {}
  local total = 0
  local ok = pcall(function()
    while true do
      local chunk = io.read(f, 1024)
      if chunk == nil or chunk == "" then break end
      total = total + #chunk
      if total > READ_ALL_MAX_BYTES then error("Flight database too large") end
      parts[#parts+1] = chunk
      if #chunk < 1024 then break end
    end
  end)
  pcall(io.close, f)
  if not ok then return nil, true end
  return table.concat(parts), true
end
local function writeAll(path, content)
  local renameFn = _G.rename or (type(os) == 'table' and os.rename)
  local deleteFn = _G.del or (type(os) == 'table' and os.remove)
  -- Missing safe replacement APIs must not fall back to truncating the total.
  if type(renameFn) ~= 'function' or type(deleteFn) ~= 'function' then return false end
  local function call(fn, ...)
    local ok, result = pcall(fn,...)
    return ok and (result == nil or result == true or result == 0)
  end
  local tmp, backup = path..'.tmp', path..'.bak'
  local f = io.open(tmp,'w')
  if not f then return false end
  local written, result = pcall(io.write,f,content)
  local closed = pcall(io.close,f)
  if not written or result == nil or result == false or not closed
     or readAll(tmp) ~= content then return false end
  local previous, exists = readAll(path)
  local moved = false
  if exists then
    if G.flightStore.parse(previous) then
      local _, backupExists = readAll(backup)
      if backupExists and not call(deleteFn,backup) then return false end
      if not call(renameFn,path,backup) then return false end
      moved = true
    elseif not call(deleteFn,path) then return false end
  end
  if call(renameFn,tmp,path) then
    -- Keep the previous known-good total as recovery material.
    return readAll(path) == content
  end
  if moved then call(renameFn,backup,path) end
  -- Keep a verified temp after a failed replace for recovery on the next load.
  return false
end
local function trim(s) return string.match(s or "", "^%s*(.-)%s*$") end
local function sanitizeFsName(name)
  if not name then return nil end
  local s = (string.gsub(name, "[\\/:*?\"<>|]", "_"))
  return trim(s)
end
local function get(name)
  local source = name
  local sourceKey
  local sourceKnown = false
  if type(name) == "string" and getFieldInfoFn then
    sourceKey = "$" .. name
    local cached = RESOLVED[sourceKey]
    if cached ~= nil then
      source = cached
      sourceKnown = true
    else
      local infoOk, info = pcall(getFieldInfoFn, name)
      if infoOk and type(info) == "table" and info.id ~= nil then
        source = info.id
        RESOLVED[sourceKey] = source
        sourceKnown = true
      elseif infoOk then
        -- getValue(name) returns zero for a missing source. A successful
        -- metadata lookup returning nil lets us distinguish that from a live
        -- telemetry source whose legitimate value is zero.
        return nil, false, false, false
      end
    end
  end

  local sourceValueFn = rawget(_G, "getSourceValue") or _G.getSourceValue
  if type(sourceValueFn) == "function" then
    local ok, v, isCurrent, isFresh, ageTicks = pcall(sourceValueFn, source)
    if not ok or v == nil or isCurrent == false then
      -- Source ids can change after telemetry discovery. Re-resolve a stale id
      -- on the next sample instead of pinning the model to it indefinitely.
      if sourceKey then RESOLVED[sourceKey] = nil end
      return nil, false, isFresh == true, sourceKnown
    end
    if type(v) == "table" then v = v.value end
    if v == nil then return nil, false, isFresh == true, sourceKnown end
    return v, true, isFresh ~= false, true, isCurrent == true and type(isFresh) == "boolean" and type(v) == "number", ageTicks
  end

  local ok, v = pcall(getValue, source)
  if not ok or v == nil then return nil, false, false, sourceKnown end
  if type(v) == "table" then v = v.value end
  return v, true, true, true
end
local function getModelInfo()
  local v = F.modelInfo
  if v ~= nil then return v ~= false and v or nil end
  local ok, info = pcall(model.getInfo)
  v = ok and type(info) == "table" and info or false
  F.modelInfo = v
  return v ~= false and v or nil
end
local function getModelName()
  local v = F.modelName
  if v ~= nil then return v end
  local info = getModelInfo()
  local n = info and info.name or nil
  if not n or n == "" then n = "MODEL" end
  v = (string.gsub(n, ",", " "))
  F.modelFilename = info and type(info.filename) == "string" and info.filename ~= ""
                    and info.filename or nil
  -- RF Lua publishes its own automatic renames. The displayed radio name
  -- may revert during telemetry loss while the aircraft/counter stays put.
  -- Exact filename + display-name matching excludes manual/other-model edits.
  local shared = rawget(_G, "rf2")
  local session = type(shared) == "table" and shared.modelNameSession
  if type(session) == "table" and session.version == 1
     and F.modelFilename and session.filename == F.modelFilename
     and session.displayName == n and type(session.craftName) == "string"
     and session.craftName ~= "" then
    F.modelNameSession = session
    F.aircraftName = (string.gsub(session.craftName, ",", " "))
  else
    F.aircraftName = v
  end
  F.modelIdentity = tostring(F.modelFilename or "") .. ":" .. F.aircraftName
  F.modelName = v
  return v
end
local function getAircraftName()
  getModelName()
  return F.aircraftName
end

-- Telemetry names are case-sensitive. Resolve each discovered source to its
-- numeric id, prefer getSourceValue() current-state reporting, and retain the
-- legacy getValue() path only as a compatibility fallback. Electric/Nitro use
-- the Rotorflight contract; OMPHOBBY uses the receiver's smaller contract.
local ROTORFLIGHT_SENSOR = {
  headspeed        = "Hspd",
  tailHeadspeed    = "Tspd",
  becVoltage       = "Vbec",
  cellVoltage      = "Vcel",
  cellCount        = "Cel#",
  -- The AMPS tile (and its session maximum) always reads Rotorflight's
  -- dedicated current sensor rather than the ESC telemetry source.
  current          = "Curr",
  capacity         = "Capa",
  -- Rotorflight publishes getBatteryChargeLevel() here. With Smart Fuel
  -- enabled, this is the FC's sag-compensated/rate-limited estimate.
  batteryPercent   = "Bat%",
  escTemperature   = "Tesc",
  governorMode     = "Gov",
  batteryProfile   = "BAT#",
  pidProfile       = "PID#",
  rateProfile      = "RTE#",
  -- Pack voltage remains a separate input used to validate electric packs.
  packVoltage      = "Vbat",
}
local OMPHOBBY_SENSOR = {
  headspeed        = "RPM",
  packVoltage      = "RxBt",
  current          = "Curr",
  capacity         = "Capa",
  batteryPercent   = "Bat%",
  escTemperature   = "Temp", -- OMP ESC MOSFET temperature (OFS3 telemetry)
}
local function activeSensorName(key)
  local sensors = OPT.heliType == HELI_OMPHOBBY
                  and OMPHOBBY_SENSOR or ROTORFLIGHT_SENSOR
  return sensors[key]
end
local function getSensorNumber(key)
  local name = activeSensorName(key)
  if not name then return nil end
  local v, current, fresh, exists, native, age = get(name)
  if key == "headspeed" then F.rpmRaw, F.rpmCurrent, F.rpmExists, F.rpmNative, F.rpmAge = v, current, exists, native, age end
  F[key .. "Fresh"] = current == true and fresh == true
  return tonumber(v), current, fresh, exists
end
-- Link quality is the one remaining name-variant fallback chain. Remember the
-- variant that resolves so later frames do not re-probe every candidate.
local NAMES = {
  lq = { "RQly", "RQLY", "LQ" },
}
local function resolveNamed(key)
  local names = NAMES[key]
  local cached = RESOLVED[key]
  if cached then
    local raw, _, _, exists = get(cached)
    if exists then A.linkSourceKnown = true end
    local v = tonumber(raw)
    if v ~= nil then return v end
    RESOLVED[key] = nil
  end
  for i = 1, #names do
    local raw, _, _, exists = get(names[i])
    if exists then A.linkSourceKnown = true end
    local v = tonumber(raw)
    if v ~= nil then
      RESOLVED[key] = names[i]
      return v
    end
  end
  return nil
end
-- Fixed Wing uses only the chosen live voltage source. Total voltage cannot
-- identify a partly discharged pack's cell count; never guess from that value.
-- One metadata/value lookup per frame, bounded to at most 16 individual cells.
function G.readFixedWingBattery()
  if F.fwBatteryRead then return end
  F.fwBatteryRead = true
  F.packVolt, F.cellCount, F.cellVoltage = 0, 0, 0
  D.packVoltageValid, D.cellCountValid, D.cellVoltageValid = false, false, false
  F.packVoltageFresh, F.cellVoltageFresh, F.cellCountFresh = false, false, false
  F.fwBatteryError = "SET BATTERY SENSOR"
  local source = OPT.fwVoltageSource
  if source == 0 then return end
  F.fwBatteryError = "NO BATTERY DATA"
  if type(getFieldInfoFn) ~= "function" or type(getSourceValue) ~= "function" then return end
  if not G.fwTelemetryFirst then
    local found, first = pcall(getFieldInfoFn, "telem1")
    if found and type(first) == "table" and type(first.id) == "number" then G.fwTelemetryFirst = first.id end
  end
  local offset = G.fwTelemetryFirst and source - G.fwTelemetryFirst
  if not offset or offset < 0 or offset >= (rawget(_G, "MAX_SENSORS") or 75) * 3 or offset % 3 ~= 0 then
    F.fwBatteryError = "CHECK BATTERY SENSOR"
    return
  end
  local ok, info = pcall(getFieldInfoFn, source)
  local cellsUnit = rawget(_G, "UNIT_CELLS") or 38
  if not ok or type(info) ~= "table" then return end
  if info.unit ~= (rawget(_G, "UNIT_VOLTS") or 1) and info.unit ~= cellsUnit then
    F.fwBatteryError = "CHECK BATTERY SENSOR"
    return
  end
  local current, fresh, value
  ok, value, current, fresh = pcall(getSourceValue, source)
  if not ok or current ~= true then return end
  local count, total = OPT.fwCells, value
  if info.unit == cellsUnit then
    if type(value) ~= "table" or #value < 1 or #value > 16 then return end
    if count > 0 and count ~= #value then F.fwBatteryError = "CHECK CELL COUNT"; return end
    count, total = #value, 0
    for i = 1, count do
      local cell = value[i]
      if type(cell) ~= "number" or not (cell > 0 and cell <= 4.5) then return end
      total = total + cell
    end
  end
  if type(total) ~= "number" or not (total > 0 and total <= 72) then return end
  F.packVolt, D.packVoltageValid = total, true
  F.packVoltageFresh = fresh == true
  if count == 0 then F.fwBatteryError = "SET CELL COUNT"; return end
  local cell = total / count
  if cell > 4.5 then F.fwBatteryError = "CHECK CELL COUNT"; return end
  F.cellCount, F.cellVoltage = count, cell
  D.cellCountValid, D.cellVoltageValid = true, true
  F.cellCountFresh, F.cellVoltageFresh = fresh == true, fresh == true
  F.fwBatteryError = nil
end
local function getCellCount()
  if OPT.heliType == AIRCRAFT_FIXED_WING then G.readFixedWingBattery(); return F.cellCount end
  local v = F.cellCount
  if v ~= nil then return v end
  if OPT.heliType == HELI_OMPHOBBY then
    -- OMP receivers do not stream cell count. Model names containing M2 are
    -- 3S; names containing M1 are 2S LiHV (8.5-8.7 V fully charged). Match
    -- case-insensitively anywhere and make the M1 chemistry deterministic
    -- instead of waiting for a high-voltage sample to identify it.
    local modelName = string.upper(getModelName())
    if OPT.ompPack == 3 or (OPT.ompPack == 1 and string.find(modelName, "M2", 1, true)) then
      v = 3
    elseif OPT.ompPack == 2 or (OPT.ompPack == 1 and string.find(modelName, "M1", 1, true)) then
      v = 2
      D.isLiHV = true
      A.liHvHighSamples = SAFETY.liHvConfirmSamples
    else
      v = 0
    end
  else
    v = getSensorNumber("cellCount") or 0
  end
  v = math.floor(v + 0.5)
  D.cellCountValid = v >= 1 and v <= SAFETY.maxCellCount
  if not D.cellCountValid then v = 0 end
  F.cellCount = v
  return v
end
local function getPackVolt()
  if OPT.heliType == AIRCRAFT_FIXED_WING then G.readFixedWingBattery(); return F.packVolt end
  local v = F.packVolt
  if v ~= nil then return v end
  v = getSensorNumber("packVoltage")
  D.packVoltageValid = v ~= nil and v > 0
                       and v <= SAFETY.maxCellCount * SAFETY.maxCellSanityV
  if not D.packVoltageValid then v = 0 end
  F.packVolt = v
  return v
end
local function getCellVoltage()
  if OPT.heliType == AIRCRAFT_FIXED_WING then G.readFixedWingBattery(); return F.cellVoltage end
  local v = F.cellVoltage
  if v ~= nil then return v end
  if OPT.heliType == HELI_OMPHOBBY then
    local cells = getCellCount()
    local packVoltage = getPackVolt()
    v = cells > 0 and packVoltage > 0 and packVoltage / cells or nil
  else
    v = getSensorNumber("cellVoltage")
  end
  D.cellVoltageValid = v ~= nil and v > 0
                       and v <= SAFETY.maxCellSanityV
  if not D.cellVoltageValid then v = 0 end
  F.cellVoltage = v
  return v
end
local function getBatPct()
  if OPT.heliType == AIRCRAFT_FIXED_WING then D.batteryPercentValid = false; F.batPct = false; return false end
  local v = F.batPct
  if v ~= nil then return v end
  v = getSensorNumber("batteryPercent")
  D.batteryPercentValid = v ~= nil and v >= 0 and v <= 100
  if not D.batteryPercentValid then v = false end
  F.batPct = v
  return v
end
local function getCapa()
  local v = F.capa
  if v ~= nil then return v end
  v = getSensorNumber("capacity")
  D.capacityValid = v ~= nil and v >= 0 and v <= 100000
  if not D.capacityValid then v = 0 end
  F.capa = v
  return v
end
local function getCurr()
  local v = F.curr
  if v ~= nil then return v end
  v = getSensorNumber("current")
  local sane = v ~= nil and v >= -500 and v <= 1000
  if not sane then v = 0 end
  D.currentValid = sane
  F.curr = v
  return v
end
local function getTemp()
  local v = F.temp
  if v ~= nil then return v end
  v = getSensorNumber("escTemperature")
  local sane = v ~= nil and v >= -40 and v <= 250
  if not sane then v = 0 end
  D.tempValid = sane
  F.temp = v
  return v
end
local function getBec()
  local v = F.bec
  if v ~= nil then return v end
  v = getSensorNumber("becVoltage")
  local sane = v ~= nil and v > 0 and v <= 30
  D.becValid = sane
  if not D.becValid then v = 0 end
  F.bec = v
  return v
end
local function getRxBatt()
  local v = F.rxBatt
  if v ~= nil then return v end
  -- Nitro Rx pack voltage uses the same Vbec resolver as the BEC tile.
  v = getBec()
  F.rxBatt = v
  return v
end
local function getBattProfile()
  local v = F.battProfile
  if v ~= nil then return v end
  v = getSensorNumber("batteryProfile")
  local whole = v ~= nil and math.floor(v) or nil
  if whole == nil or v ~= whole
     or whole < 1 or whole > BATTERY_PROFILE_COUNT then
    v = nil
  else
    v = whole
  end

  -- BAT# can take a few telemetry cycles to reflect an RF Tool profile request,
  -- so retain the locally selected value briefly instead of flashing the prior
  -- telemetry value while MSP 176 is being delivered.
  if PROFILE_CONFIRMED.value then
    local age = frameNow() - (PROFILE_CONFIRMED.tick or 0)
    if v == PROFILE_CONFIRMED.value or age > 300 or age < 0 then
      PROFILE_CONFIRMED.value, PROFILE_CONFIRMED.tick = nil, nil
    else
      v = PROFILE_CONFIRMED.value
    end
  end
  F.battProfile = v
  return v
end
local function getHeadspeed()
  local v = F.rpm
  if v ~= nil then return v end
  v = getSensorNumber("headspeed")
  local sane = v ~= nil and v >= 0 and v <= 100000
  if not sane then v = 0 end
  D.rpmValid = sane
  F.rpm = v
  return v
end
local function getTailRpm()
  local v = F.trpm
  if v ~= nil then return v end
  v = getSensorNumber("tailHeadspeed")
  local sane = v ~= nil and v >= 0 and v <= 100000
  if not sane then v = 0 end
  D.tailRpmValid = sane
  F.trpm = v
  return v
end
local function getGovernorMode()
  local cached = F.govNumber
  if cached ~= nil then return cached ~= false and cached or nil end
  if OPT.heliType == HELI_OMPHOBBY then
    D.govValid = false
    D.govCurrentInvalid = false
    F.govNumber = false
    return nil
  end
  local raw, current = getSensorNumber("governorMode")
  local whole = raw ~= nil and math.floor(raw) or nil
  local valid = whole ~= nil and raw == whole and GOV_STATES[whole] ~= nil
  D.govValid = valid
  -- Missing/stale Gov may use the independent Hspd proof. A current but
  -- malformed or unknown enum is different: it must block that fallback.
  D.govCurrentInvalid = current == true and raw ~= nil and not valid
  F.govNumber = valid and whole or false
  return valid and whole or nil
end
local function getGovState()
  local v = F.gov
  if v ~= nil then return v end
  if OPT.heliType == HELI_OMPHOBBY then
    v = "--"
  else
    local g = getGovernorMode()
    v = g == nil and "--" or GOV_STATES[g]
  end
  F.gov = v
  return v
end
local function getTxVolt()
  local v = F.txVolt
  if v ~= nil then return v end
  -- Capture only the source value. get() also returns current/fresh/existence
  -- metadata, which must not spill into tonumber() as its optional base.
  local raw = get("tx-voltage")
  v = tonumber(raw) or 0
  if v > 100 then v = v / 1000 end
  if v < 0 or v > 20 then v = 0 end
  F.txVolt = v
  return v
end
-- TX battery display endpoints for a 2S pack. Keep these separate from the
-- model battery settings: the top-bar gauge represents the radio battery.
local TX_LIPO_EMPTY_V = 7.0   -- 3.50 V/cell
local TX_LIPO_FULL_V  = 8.2   -- Display full at 4.10 V/cell; allow headroom below 8.4 V.
local TX_LIION_EMPTY_V = 6.2  -- 3.10 V/cell
local TX_LIION_FULL_V  = 8.4  -- 4.20 V/cell

local function txPctFromVolts(volts, isLiIon)
  if not volts or volts <= 0 then return nil end
  local emptyV = isLiIon and TX_LIION_EMPTY_V or TX_LIPO_EMPTY_V
  local fullV = isLiIon and TX_LIION_FULL_V or TX_LIPO_FULL_V
  local pct = ((volts - emptyV) / (fullV - emptyV)) * 100
  if pct < 0 then pct = 0 end
  if pct > 100 then pct = 100 end
  return pct
end
local function signalPercent(raw)
  local v = tonumber(raw)
  if v == nil then return nil end
  local pct
  if v < 0 then
    pct = ((v + 120) / 80) * 100
  elseif v <= 100 then
    pct = v
  elseif v <= 255 then
    pct = (v / 255) * 100
  else
    pct = 100
  end
  if pct < 0 then pct = 0 end
  if pct > 100 then pct = 100 end
  return pct
end
local function getRqly()
  local v = F.rqly
  if v ~= nil then return v end
  A.linkSourceKnown = false
  v = resolveNamed("lq")
  if v == nil then
    local rssi
    if getRSSI then
      local ok, r = pcall(getRSSI)
      if ok then rssi = tonumber(r) end
    end
    if rssi ~= nil and rssi ~= 0 then A.linkSourceKnown = true end
    if rssi == nil or rssi == 0 then
      local raw, _, _, exists = get("RSSI")
      if exists then A.linkSourceKnown = true end
      if raw ~= nil then rssi = tonumber(raw) end
    end
    v = signalPercent(rssi)
  end
  v = tonumber(v) or 0
  if v < 0 or v > 100 then v = signalPercent(v) or 0 end
  if v > 0 then A.linkSourceSeen = true end
  F.rqly = v
  return v
end
local function percentFromCellVoltage(cellVolts, isLiHV)
  if not cellVolts or cellVolts <= 0 then return 0 end
  local minV = 3.3
  local maxV = isLiHV and 4.35 or 4.2
  local pct = (cellVolts - minV) / (maxV - minV) * 100
  if pct < 0 then pct = 0 end
  if pct > 100 then pct = 100 end
  return pct
end
-- Rotorflight publishes its FC-side charge estimate as Bat%. In Electric mode
-- that value is authoritative even when Vcel is not configured. A positive
-- Bat% is sufficient evidence by itself; a zero also needs live Vcel or Vbat
-- so an FC powered over USB without a flight pack is shown as NO DATA instead
-- of an empty battery. OMPHOBBY keeps its stricter RxBt + M1/M2 contract.
local function selectFlightBatteryPercent(heliType, sensorPercent, sensorValid,
                                          voltagePercent, hasCellVoltage,
                                          hasPackVoltage)
  local raw = tonumber(sensorPercent)
  if heliType == HELI_ELECTRIC then
    local fcPercentUsable = sensorValid and raw ~= nil
                            and raw >= 0 and raw <= 100
                            and (raw > 0 or hasCellVoltage or hasPackVoltage)
    if fcPercentUsable then return raw, true, "fc" end
  elseif heliType == HELI_OMPHOBBY then
    local ompPercentUsable = hasCellVoltage and sensorValid and raw ~= nil
                             and raw >= 0 and raw <= 100
    if ompPercentUsable then return raw, true, "telemetry" end
  elseif heliType == AIRCRAFT_FIXED_WING then
    if hasPackVoltage and hasCellVoltage and voltagePercent ~= nil then
      return voltagePercent, true, "voltage"
    end
    return 0, false, nil
  else
    return 0, false, nil
  end
  if voltagePercent ~= nil then return voltagePercent, true, "voltage" end
  return 0, false, nil
end
local function calculateAdjustedPercent(actual, reserve)
  if not actual or actual <= 0 then return 0 end
  reserve = reserve or 0
  if reserve >= 100 then return 0 end
  local usable = 100 - reserve
  local adj = ((actual - reserve) / usable) * 100
  if adj < 0 then adj = 0 end
  if adj > 100 then adj = 100 end
  return adj
end
function BATTERY_VOICE.play(path)
  if not playFile or not path then return false end
  local available = BATTERY_VOICE.available[path]
  if available == nil then
    local f = io.open(path, "r")
    available = f ~= nil
    BATTERY_VOICE.available[path] = available
    if f then pcall(io.close, f) end
  end
  if not available then return false end
  return pcall(playFile, path)
end
local function playBatteryRemainingAlert(level)
  local n = tonumber(level)
  if n == nil then return false end
  local customPath = BATTERY_VOICE.path .. tostring(math.floor(n)) .. "%.wav"
  if BATTERY_VOICE.play(customPath) then return true end
  if playNumber then
    return pcall(playNumber, n, SAFETY.batteryPercentUnit, 0)
  end
  return false
end
local function playBatteryHaptic()
  if not playHaptic then return end
  local modeNow = rawget(_G, "PLAY_NOW") or 0
  pcall(playHaptic, 15, 0, modeNow)
end
local function resetBatteryAlertState(scope)
  scope = scope or "all"
  if scope ~= "rx" then
    A.battAlertPrevPct       = nil
    A.battAlertPrevSource    = nil
    A.battVoicePlayed        = {}
    A.battZeroReached        = false
    A.ompStartupWarning      = false
    A.deadVoiceNextTick      = 0
    A.flightDeadVoiceLatched = false
    A.flightDeadVoiceAcknowledged = false
    A.flightDeadVoiceStartPosition = nil
    A.battAlert5HapticPlayed = false
    A.battAlert0HapticPlayed = false
    A.battAlertNextTick      = 0
    A.battHapticState        = 0
    A.battHapticBurstCount   = 0
    A.battHapticNextTick     = 0
    A.battHapticEndTick      = 0
    A.battConnectionZeroPending = false
    A.battConnectionZeroSince = nil
    A.battReplacementSince  = nil
    A.liHvHighSamples        = 0
    D.isLiHV                 = false
  end
  if scope ~= "flight" then
    A.rxLowSinceTick         = nil
    A.rxLowHapticNext        = 0
    A.rxDeadVoiceLatched     = false
    A.rxDeadVoiceAcknowledged= false
    A.rxDeadVoiceStartPosition = nil
    A.rxDeadVoiceNextTick    = 0
  end
  if scope == "all" then
    A.escTempAlertPlayed = false
    A.becAlertPlayed = false
    A.escTempHighSince = nil
    A.becLowSince = nil
  end
end
function BATTERY_VOICE.prime(percent, leaveZeroPending)
  local played = A.battVoicePlayed
  for _, level in ipairs(BATTERY_VOICE.levels) do
    -- Do not announce thresholds already passed when the widget starts or is
    -- reloaded in the middle of a flight. Zero is the safety exception: a
    -- widget that starts on a confirmed empty pack must still alert.
    if percent <= level and not (leaveZeroPending and level == 0) then
      played[level] = true
    end
  end
end
local function updateBatteryAlertState(percent, hasData, voiceEnabled, percentSource)
  if not hasData or not A.linkAvailable then
    -- A telemetry gap means a startup zero was not continuously observed.
    if A.battConnectionZeroPending then
      A.battConnectionZeroSince = nil
    end
    return
  end
  local p = tonumber(percent)
  if p == nil then return end
  if p < 0 then p = 0 end
  if p > 100 then p = 100 end
  local now = frameNow()
  local connectionZeroWaiting = false
  local connectionZeroConfirmed = false
  if A.battConnectionZeroPending then
    if p <= 0 then
      if A.battConnectionZeroSince == nil then
        A.battConnectionZeroSince = now
      end
      if now - A.battConnectionZeroSince
         >= SAFETY.batteryConnectionZeroConfirm then
        A.battConnectionZeroPending = false
        A.battConnectionZeroSince = nil
        connectionZeroConfirmed = true
      else
        connectionZeroWaiting = true
      end
    else
      -- Any positive reading proves the connection-time zero was transient.
      A.battConnectionZeroPending = false
      A.battConnectionZeroSince = nil
    end
  end
  local prev = tonumber(A.battAlertPrevPct)
  if prev == nil then
    local startsAtZero = p <= 0
    A.battAlertPrevPct = startsAtZero and 0.01 or p
    A.battAlertPrevSource = percentSource
    BATTERY_VOICE.prime(p, startsAtZero)
    return
  end
  local previousSource = A.battAlertPrevSource
  local sourceChanged = previousSource ~= nil and percentSource ~= nil
                        and previousSource ~= percentSource
  local replacementJump = false
  if not sourceChanged then
    if percentSource == "fc" and previousSource == "fc" then
      -- Rotorflight Smart Fuel is monotonic within a battery session. A
      -- sustained upward step therefore rearms alerts for the new FC session
      -- without any voltage/capacity-based pack classifier.
      replacementJump = (p - prev) >= 1
    else
      -- Voltage-derived/receiver percentages can rebound under reduced load,
      -- so retain the deliberately conservative legacy qualification.
      replacementJump = (p >= 95 and prev < 80)
                        or ((p - prev) >= 25 and p >= 60)
    end
  end
  if replacementJump then
    if A.battReplacementSince == nil then A.battReplacementSince = now end
    if (now - A.battReplacementSince) >= BATTERY_VOICE.replacementConfirm then
      resetBatteryAlertState("flight")
      A.battAlertPrevPct = p
      A.battAlertPrevSource = percentSource
      BATTERY_VOICE.prime(p)
    end
    return
  end
  A.battReplacementSince = nil
  local playedLevels = A.battVoicePlayed
  if voiceEnabled then
    if now >= (tonumber(A.battAlertNextTick) or 0) then
      local selectedLevel
      for i = #BATTERY_VOICE.levels, 1, -1 do
        local level = BATTERY_VOICE.levels[i]
        if not playedLevels[level] and p <= level then
          selectedLevel = level
          break
        end
      end
      if selectedLevel ~= nil then
        -- If telemetry skipped several thresholds, announce the current
        -- lowest one and retire the higher backlog. At 0%, this prevents old
        -- percentage clips from delaying the safety-critical dead warning.
        for _, level in ipairs(BATTERY_VOICE.levels) do
          if p <= level then playedLevels[level] = true end
        end
        playBatteryRemainingAlert(selectedLevel)
        A.battAlertNextTick = now + SAFETY.batteryAlertCooldown
        if selectedLevel == 0 then
          A.battZeroReached = true
          A.deadVoiceNextTick = now + BATTERY_VOICE.initialDelay
        end
      end
    end
  else
    -- Keep threshold state current while muted so enabling Battery Voice later
    -- does not announce a backlog of percentages already passed.
    for _, level in ipairs(BATTERY_VOICE.levels) do
      if p <= level then playedLevels[level] = true end
    end
  end
  if connectionZeroConfirmed and not A.battAlert0HapticPlayed then
    A.battHapticState      = 2
    A.battHapticNextTick   = now
    A.battHapticEndTick    = now + 500
    A.battAlert0HapticPlayed = true
  elseif not connectionZeroWaiting then
    if (not A.battAlert5HapticPlayed)
       and prev > SAFETY.batteryHapticThreshold
       and p <= SAFETY.batteryHapticThreshold then
      A.battHapticState      = 1
      A.battHapticBurstCount = 0
      A.battHapticNextTick   = now
      A.battAlert5HapticPlayed = true
    end
    if (not A.battAlert0HapticPlayed) and prev > 0 and p <= 0 then
      A.battHapticState      = 2
      A.battHapticNextTick   = now
      A.battHapticEndTick    = now + 500
      A.battAlert0HapticPlayed = true
    end
  end
  A.battAlertPrevPct = p
  A.battAlertPrevSource = percentSource
end
-- A connection-time pack check, independent of percentage reserve and voice
-- preferences. Only renewed, current RxBt evidence may finish confirmation.
-- Once settled healthy (or rotor motion is seen), voltage sag cannot reopen it.
function BATTERY_VOICE.checkOmpStartup(cellVoltage, headRpm)
  if OPT.heliType ~= HELI_OMPHOBBY then return false end
  if not A.linkAvailable then
    A.ompStartup = nil
    if A.ompStartupWarning then
      A.ompStartupWarning = false
      A.battZeroReached = false
      A.battHapticState = 0
    end
    return false
  end
  local startup = A.ompStartup
  if not startup then
    startup = { pending=true }
    A.ompStartup = startup
  end
  if not startup.pending then return false end
  local now = frameNow()
  -- A tool/page can suspend widget callbacks. Unobserved time cannot confirm
  -- a startup pack; collect a new window when service resumes.
  if startup.lastTick and (now < startup.lastTick or now - startup.lastTick > 100) then
    startup.since = nil
  end
  startup.lastTick = now
  if D.rpmValid and headRpm ~= nil
     and headRpm >= SAFETY.ompMotorRunningRpm then
    startup.pending = false
    return false
  end
  local _, current, fresh = get(OMPHOBBY_SENSOR.packVoltage)
  if not current or not D.cellVoltageValid or cellVoltage <= 0 then
    startup.since = nil
    return true
  end
  if not fresh then return true end
  local low = cellVoltage <= SAFETY.ompStartupCellVoltage
              or (D.hasBattData and D.adjustedPercent <= 0)
  if startup.since == nil or startup.low ~= low or now < startup.since then
    startup.since, startup.low = now, low
  end
  if now - startup.since < SAFETY.ompStartupConfirmTicks then return true end
  startup.pending = false
  -- Retire the startup percentage backlog without changing the gauge. The
  -- same low pack must not queue both this warning and an initial 0% clip.
  A.battConnectionZeroPending = false
  A.battConnectionZeroSince = nil
  A.battAlertPrevPct = D.adjustedPercent
  BATTERY_VOICE.prime(D.adjustedPercent)
  if low then
    startup.warningTick = now
    A.ompStartupWarning = true
    A.battZeroReached = true
    A.deadVoiceNextTick = now
    A.flightDeadVoiceLatched = false
    A.flightDeadVoiceAcknowledged = false
    A.flightDeadVoiceStartPosition = nil
    A.battHapticState = 2
    A.battHapticNextTick = now
    A.battHapticEndTick = now + 500
    if D.adjustedPercent <= 0 then A.battAlert0HapticPlayed = true end
  end
  return false
end
-- Keep the voltage readable between red pulses, including when the normal
-- session-minimum color is already red. Sound acknowledgement does not hide
-- this visual reminder; the existing startup-warning lifecycle clears it.
function BATTERY_VOICE.ompCellWarningColor()
  if OPT.heliType ~= HELI_OMPHOBBY or OPT.simTelemetry
     or not A.ompStartupWarning or not A.linkAvailable
     or not D.cellVoltageValid then return nil end
  local started = A.ompStartup and A.ompStartup.warningTick or frameNow()
  return (frameNow() - started) % 100 < 50 and C_RED or C_TEXT
end
function BATTERY_VOICE.updateDead(voiceEnabled)
  if not (voiceEnabled or A.ompStartupWarning) or not A.battZeroReached then return end
  -- Once the pilot has heard dead.wav, a later movement of the configured
  -- physical Motor Switch acknowledges only this repeating voice. Movement
  -- before the first successful playback cannot pre-acknowledge the warning;
  -- percentage/haptic pausing remains telemetry-validated separately.
  if A.flightDeadVoiceLatched then
    local startPosition = A.flightDeadVoiceStartPosition
    local currentPosition = A.motorSwitchPosition
    if startPosition == nil and currentPosition ~= nil then
      A.flightDeadVoiceStartPosition = currentPosition
      startPosition = currentPosition
    end
    if startPosition ~= nil and currentPosition ~= nil
       and currentPosition ~= startPosition then
      A.flightDeadVoiceAcknowledged = true
      A.deadVoiceNextTick = 0
    end
  end
  if A.flightDeadVoiceAcknowledged then return end
  if not A.linkAvailable then return end
  local now = frameNow()
  if now < (tonumber(A.deadVoiceNextTick) or 0) then return end
  local played = BATTERY_VOICE.play(BATTERY_VOICE.deadPath)
  -- A missing optional sound file must not make the startup warning silent.
  if not played and A.ompStartupWarning and playTone then
    played = pcall(playTone, 2000, 250, 0, rawget(_G, "PLAY_NOW") or 0)
  end
  if played and not A.flightDeadVoiceLatched then
    A.flightDeadVoiceLatched = true
    A.flightDeadVoiceStartPosition = A.motorSwitchPosition
  end
  A.deadVoiceNextTick = now + BATTERY_VOICE.repeatDelay
end
local function updateBatteryHapticTick()
  if (A.battHapticState or 0) == 0 then return end
  if not A.linkAvailable then return end
  local now = frameNow()
  if now < (A.battHapticNextTick or 0) then return end
  if A.battHapticState == 1 then
    playBatteryHaptic()
    A.battHapticBurstCount = (A.battHapticBurstCount or 0) + 1
    if A.battHapticBurstCount >= 2 then
      A.battHapticState = 0
    else
      A.battHapticNextTick = now + 100
    end
  elseif A.battHapticState == 2 then
    if now >= (A.battHapticEndTick or 0) then
      A.battHapticState = 0
    else
      playBatteryHaptic()
      A.battHapticNextTick = now + 18
    end
  end
end
local function updateEscBecAlerts(escT, escValid, becV, becValid)
  if not A.linkAvailable then
    A.escTempHighSince = nil
    A.becLowSince = nil
    return
  end
  local now = frameNow()
  if escValid then
    if escT > SAFETY.escTempThreshold then
      if not A.escTempAlertPlayed then
        if A.escTempHighSince == nil then A.escTempHighSince = now end
        if (now - A.escTempHighSince) >= SAFETY.alertConfirmTicks then
          playBatteryHaptic()
          A.escTempAlertPlayed = true
          A.escTempHighSince = nil
        end
      end
    elseif A.escTempAlertPlayed and escT < SAFETY.escTempRearm then
      A.escTempAlertPlayed = false
      A.escTempHighSince = nil
    elseif not A.escTempAlertPlayed then
      A.escTempHighSince = nil
    end
  else
    A.escTempHighSince = nil
  end
  if becValid and becV >= SAFETY.becAlertMinVoltage then
    if becV < SAFETY.becVoltThreshold then
      if not A.becAlertPlayed then
        if A.becLowSince == nil then A.becLowSince = now end
        if (now - A.becLowSince) >= SAFETY.alertConfirmTicks then
          playBatteryHaptic()
          A.becAlertPlayed = true
          A.becLowSince = nil
        end
      end
    elseif A.becAlertPlayed and becV > SAFETY.becVoltRearm then
      A.becAlertPlayed = false
      A.becLowSince = nil
    elseif not A.becAlertPlayed then
      A.becLowSince = nil
    end
  else
    A.becLowSince = nil
  end
end
-- Nitro Rx pack low-voltage alert: if rx voltage sits at or below RxPackMin for
-- SAFETY.rxLowArmTicks (2s) continuously, buzz aggressively and latch the repeating
-- dead-battery voice warning. Caller only invokes this in Nitro mode.
function BATTERY_VOICE.updateRxDead(voiceEnabled, rx)
  if not rx or rx < SAFETY.becAlertMinVoltage then return end
  if not A.rxDeadVoiceLatched or A.rxDeadVoiceAcknowledged then return end
  if not A.linkAvailable then return end
  local startPosition = A.rxDeadVoiceStartPosition
  local currentPosition = A.motorSwitchPosition
  if startPosition == nil and currentPosition ~= nil then
    A.rxDeadVoiceStartPosition = currentPosition
    startPosition = currentPosition
  end
  if startPosition ~= nil and currentPosition ~= nil
     and currentPosition ~= startPosition then
    A.rxDeadVoiceAcknowledged = true
    A.rxDeadVoiceNextTick = 0
    return
  end
  if not voiceEnabled then return end
  local now = frameNow()
  if now < (tonumber(A.rxDeadVoiceNextTick) or 0) then return end
  BATTERY_VOICE.play(BATTERY_VOICE.deadPath)
  A.rxDeadVoiceNextTick = now + BATTERY_VOICE.repeatDelay
end
local function updateRxPackAlert(rx)
  if not OPT.rxPackValid then
    A.rxLowSinceTick = nil
    A.rxLowHapticNext = 0
    A.rxDeadVoiceLatched = false
    A.rxDeadVoiceAcknowledged = false
    A.rxDeadVoiceStartPosition = nil
    A.rxDeadVoiceNextTick = 0
    return
  end
  if not A.linkAvailable then
    if not A.rxDeadVoiceLatched then A.rxLowSinceTick = nil end
    A.rxLowHapticNext = 0
    return
  end
  local rxMin = OPT.rxPackMin
  local low = rx and rx >= SAFETY.becAlertMinVoltage
              and rxMin and rxMin > 0 and rx <= rxMin
  if not low then
    A.rxLowSinceTick = nil
    A.rxLowHapticNext = 0
    -- Once the Motor Switch has acknowledged a latched warning, recovery above
    -- the minimum rearms it for a future sustained low-voltage event. An
    -- unacknowledged warning remains latched until the switch is moved.
    if not A.rxDeadVoiceLatched or A.rxDeadVoiceAcknowledged then
      A.rxDeadVoiceLatched = false
      A.rxDeadVoiceAcknowledged = false
      A.rxDeadVoiceStartPosition = nil
      A.rxDeadVoiceNextTick = 0
    end
    return
  end
  local now = frameNow()
  -- Only movement after the warning has actually latched can acknowledge it.
  -- Movement during the two-second qualification period is normal control
  -- activity and must not silence an alert that has not started yet.
  if A.rxDeadVoiceLatched and A.rxDeadVoiceStartPosition ~= nil
     and A.motorSwitchPosition ~= nil
     and A.motorSwitchPosition ~= A.rxDeadVoiceStartPosition then
    A.rxDeadVoiceAcknowledged = true
    A.rxDeadVoiceNextTick = 0
  end
  if A.rxLowSinceTick == nil then
    A.rxLowSinceTick  = now
    A.rxLowHapticNext = now + SAFETY.rxLowArmTicks -- first buzz only after 2s sustained
    A.rxDeadVoiceStartPosition = nil
    A.rxDeadVoiceAcknowledged = false
  else
    if (now - A.rxLowSinceTick) >= SAFETY.rxLowArmTicks
       and not A.rxDeadVoiceLatched then
      A.rxDeadVoiceLatched = true
      A.rxDeadVoiceStartPosition = A.motorSwitchPosition
      A.rxDeadVoiceAcknowledged = false
      A.rxDeadVoiceNextTick = now
    end
    if not A.rxDeadVoiceAcknowledged
       and now >= (A.rxLowHapticNext or 0) then
      playBatteryHaptic()
      A.rxLowHapticNext = now + SAFETY.rxLowHapticInterval
    end
  end
end
local updateMotorAlertGate
local function tick(nowT)
  nowT = nowT or frameNow()
  A.lastDataTick = nowT
  local rq = getRqly()
  local linkReported = rq and rq > 0 or false
  A.linkAvailable = false
  -- Read the whole physical Motor Switch as a raw source (-1024/0/+1024 for a
  -- three-position switch). There is deliberately no channel fallback: an
  -- invalid mapping must remain visible and can never suppress/acknowledge an
  -- alert.
  local rawMotorPosition
  if A.motorSourcePhysical then
    rawMotorPosition = getValSrc(SRC.motorSwitch)
  end
  rawMotorPosition = tonumber(rawMotorPosition)
  A.motorSourceReadable = A.motorSourcePhysical and rawMotorPosition ~= nil
  if not A.motorSourcePhysical then
    A.motorConfigError = "SELECT A PHYSICAL MOTOR SWITCH"
  elseif not A.motorSourceReadable then
    A.motorConfigError = "MOTOR SWITCH UNAVAILABLE"
  else
    A.motorConfigError = nil
  end
  if rawMotorPosition == nil then
    A.motorSwitchPosition = nil
  elseif rawMotorPosition > 0 then
    A.motorSwitchPosition = 1
  elseif rawMotorPosition < 0 then
    A.motorSwitchPosition = -1
  else
    A.motorSwitchPosition = 0
  end
  local volt  = getPackVolt()
  local cells = getCellCount()
  local pctSensor = getBatPct()
  local capa  = getCapa()
  getCurr()
  local escT  = getTemp()
  local becV  = getBec()
  local cellVoltage = getCellVoltage()
  local headRpm = getHeadspeed()
  local governorMode = getGovernorMode()
  local hasCellVoltage = D.cellVoltageValid and cellVoltage > 0
  local telemetryEvidence = hasCellVoltage or D.batteryPercentValid
                            or (OPT.heliType == AIRCRAFT_FIXED_WING and D.packVoltageValid)
                            or D.capacityValid or D.currentValid
                            or D.tempValid or D.becValid or D.rpmValid
                            or D.govValid
  -- A link source becomes authoritative after it has produced a live positive
  -- sample. Until then, current telemetry itself keeps safety alerts operating;
  -- this covers discovered-but-unpopulated link sensors without masking a real
  -- zero after the link source has proved itself.
  A.linkAvailable = linkReported
                    or (not A.linkSourceSeen and telemetryEvidence)
  if A.linkAvailable then
    if not A.battLinkWasAvailable then
      A.battConnectionZeroPending = true
      A.battConnectionZeroSince = nil
    end
    A.battLinkWasAvailable = true
  else
    A.battLinkWasAvailable = false
    A.battConnectionZeroPending = false
    A.battConnectionZeroSince = nil
  end
  D.voltage       = D.packVoltageValid and volt or 0
  D.cellsResolved = D.cellCountValid and cells or 0
  D.capacity      = capa or 0
  if OPT.heliType == AIRCRAFT_FIXED_WING then
    D.isLiHV, A.liHvHighSamples = false, 0
  elseif OPT.heliType == HELI_OMPHOBBY and OPT.ompPack ~= 1 then
    D.isLiHV = OPT.ompPack == 2
    A.liHvHighSamples = D.isLiHV and SAFETY.liHvConfirmSamples or 0
  elseif hasCellVoltage and cellVoltage > SAFETY.liHvDetectCellV then
    A.liHvHighSamples = math.min(SAFETY.liHvConfirmSamples, A.liHvHighSamples + 1)
    if A.liHvHighSamples >= SAFETY.liHvConfirmSamples then D.isLiHV = true end
  elseif not D.isLiHV then
    A.liHvHighSamples = 0
  end
  if hasCellVoltage then
    if D.minCellVoltage == nil or cellVoltage < D.minCellVoltage then
      D.minCellVoltage = cellVoltage
    end
  end
  local voltagePct = hasCellVoltage
                     and percentFromCellVoltage(cellVoltage, D.isLiHV) or nil
  local hasPackVoltage = D.packVoltageValid and volt > 0
  local pct, hasPct, pctSource = selectFlightBatteryPercent(
    OPT.heliType, pctSensor, D.batteryPercentValid, voltagePct,
    hasCellVoltage, hasPackVoltage)
  local hadPct = D.hasBattData
  D.hasBattData = hasPct
  D.adjustedPercent = calculateAdjustedPercent(pct, OPT.reservePct)
  if not hasPct then
    A.displayPercent = 0
    A.displayPercentInit = false
  elseif pctSource == "fc" then
    -- Smart Fuel already performs its own sag compensation and rate limiting.
    -- Preserve the FC estimate exactly instead of applying a second filter.
    A.displayPercent = D.adjustedPercent
    A.displayPercentInit = true
  elseif not hadPct or not A.displayPercentInit then
    A.displayPercent     = D.adjustedPercent
    A.displayPercentInit = true
  else
    A.displayPercent = A.displayPercent
                       + (D.adjustedPercent - A.displayPercent)
                         * SAFETY.displayPercentAlpha
  end
  -- A raw switch move is never enough to silence a warning. Rotorflight must
  -- corroborate it with Gov or Hspd; OMPHOBBY uses stopped RPM telemetry.
  updateMotorAlertGate(nowT, governorMode, headRpm)
  local ompStartupWaiting = BATTERY_VOICE.checkOmpStartup(cellVoltage, headRpm)
  -- Percentage voice/haptic alerts belong to the main flight pack shown by
  -- Electric and OMPHOBBY modes. Nitro displays an Rx-pack voltage bar, so it
  -- must never run or retain this electric flight-pack alert state machine.
  local voiceEnabled = OPT.battVoice
  if OPT.battBarMode == 0 then
    if not A.flightBatteryAlertsPaused and not ompStartupWaiting then
      updateBatteryAlertState(D.adjustedPercent, hasPct, voiceEnabled, pctSource)
      BATTERY_VOICE.updateDead(voiceEnabled)
      updateBatteryHapticTick()
    end
  elseif A.battAlertPrevPct ~= nil or A.battZeroReached
         or (A.battHapticState or 0) ~= 0 then
    resetBatteryAlertState("flight")
  end
  updateEscBecAlerts(escT, D.tempValid, becV, D.becValid)
  if OPT.battBarMode == 1 then
    local rx = getRxBatt()
    updateRxPackAlert(rx)
    BATTERY_VOICE.updateRxDead(voiceEnabled, rx)
    if D.becValid and rx and rx > 0 then
      D.rxVoltage     = rx
      D.rxCellVoltage = rx / 2
      if rx > 0 then
        if D.minRxVoltage == nil or rx < D.minRxVoltage then
          D.minRxVoltage = rx
        end
      end
      local rxMin = OPT.rxPackMin
      local rxMax = OPT.rxPackMax
      if OPT.rxPackValid and rxMax > rxMin then
        local p = (rx - rxMin) / (rxMax - rxMin) * 100
        if p < 0 then p = 0 end
        if p > 100 then p = 100 end
        D.rxPercent = p
      else
        D.rxPercent = 0
      end
    else
      D.rxVoltage = nil; D.rxCellVoltage = nil; D.rxPercent = 0
    end
  end
end
local function statRpmMax()  return S.rpmMax or 0 end
local function statCurrMax() return S.currMax or 0 end
local function statTempMax() return S.tempMax or 0 end
local function statBecMin()  return S.becMin end
local function statCellMin() return S.cellMin end
-- Timer 1 drives the KSE Counter, live clock and Electric/OMP recap duration.
-- Telemetry still qualifies flights. Returns the table or false on failure.
local function getTimer0()
  local t = F.timer0
  if t ~= nil then return t end
  local ok, tt = pcall(model.getTimer, 0)
  t = (ok and tt) or false
  F.timer0 = t
  return t
end
local function getTimer1Secs()
  local v = F.timerSecs
  if v ~= nil then return v end
  local t = getTimer0()
  v = (t and t.value) or 0
  F.timerSecs = v
  return v
end
local function getFlightCount()
  if OPT.flightCounter == FC.ROTORFLIGHT then return FC.count end
  return modelFlights
end
-- One on-disk store for both layouts. Version 1 name rows migrate lazily on
-- the next real count; version 2 adds stable identity and a complete-file check.
G.flightStore = { names={}, dirty=false, retryAt=nil, retryDelay=500 }
function G.flightStore.checksum(text)
  local value = 0
  for i=1,#text do value = (value + string.byte(text,i)) % 65521 end
  return value
end
function G.flightStore.encode(value)
  return (string.gsub(tostring(value),'[^%w_.%-]', function(c)
    return string.format('%%%02X', string.byte(c))
  end))
end
function G.flightStore.parse(text)
  if type(text) ~= 'string' or text == '' then return nil end
  local version = string.match(text,'# api_ver=(%d+)')
  if version and version ~= '1' and version ~= '2' then return nil end
  local v2 = version == '2'
  if v2 then
    local body, length, sum = string.match(text,'^(.*)# kse_complete=(%d+):(%d+)\n$')
    if not body or #body ~= tonumber(length)
       or G.flightStore.checksum(body) ~= tonumber(sum) then return nil end
    text = body
  end
  local counts, names, entries, header = {}, {}, 0, false
  for line in string.gmatch(text,'[^\r\n]+') do
    if line == 'model_name,flight_count' or line == 'model_name,flight_count,aircraft_id' then
      header = true
    elseif string.sub(line,1,1) ~= '#' and string.match(line,'%S') then
      local name, number, id = string.match(line,'^([^,]+),(%d+),([^,]+)$')
      if not name then name, number = string.match(line,'^([^,]+),(%d+)$') end
      local count = tonumber(number)
      if not name or not count or count < 0 or count > 2147483646
         or count ~= math.floor(count) then return nil end
      name = trim(name)
      local key = id and ('@'..id) or (':'..name)
      if name == '' or counts[key] ~= nil then return nil end
      entries = entries + 1
      if entries > FLIGHT_CACHE_MAX_ENTRIES then return nil end
      counts[key], names[key] = count, name
    end
  end
  if not header then return nil end
  return counts, names
end
local function getFlightCache()
  if OPT.flightCounter == FC.ROTORFLIGHT then return {} end
  if flightCache then return flightCache end
  local store = G.flightStore
  local anyFile = false
  for _,suffix in ipairs({'', '.tmp', '.bak'}) do
    local text, exists = readAll(FLIGHTS_PATH..suffix)
    anyFile = anyFile or exists
    local counts, names = store.parse(text)
    -- Only our checksummed complete files are eligible as pending saves.
    if counts and (suffix ~= '.tmp' or string.find(text,'# api_ver=2\n',1,true)) then
      flightCache, store.names = counts, names
      store.dirty = suffix ~= ''
      store.retryAt = store.dirty and frameNow() + 500 or nil
      A.flightSaveError = store.dirty
      return flightCache
    end
  end
  -- Never replace a malformed, truncated or oversized database with emptiness.
  store.blocked = anyFile
  A.flightSaveError = anyFile
  flightCache = {}
  return flightCache
end
local function saveFlightCache()
  if OPT.flightCounter ~= 1 or not flightCache then return false end
  local store = G.flightStore
  store.dirty = true
  local keys = {}
  for k in pairs(flightCache) do keys[#keys+1] = k end
  table.sort(keys)
  local out = { 'model_name,flight_count,aircraft_id\n# api_ver=2\n' }
  for _,k in ipairs(keys) do
    local name = store.names[k] or k
    name = string.gsub(name,'[,\r\n]', ' ')
    local id = string.sub(k,1,1) == '@' and (','..string.sub(k,2)) or ''
    out[#out+1] = string.format('%s,%d%s\n', name, flightCache[k], id)
  end
  local body = table.concat(out)
  local text = body..string.format('# kse_complete=%d:%d\n', #body, store.checksum(body))
  local ok = not store.blocked and #keys <= FLIGHT_CACHE_MAX_ENTRIES
             and #text <= READ_ALL_MAX_BYTES and writeAll(FLIGHTS_PATH,text)
  A.flightSaveError = not ok
  store.dirty = not ok
  store.retryAt = not ok and frameNow() + store.retryDelay or nil
  store.retryDelay = ok and 500 or math.min(3000,store.retryDelay * 2)
  return ok
end
local function modelKey(name)
  if type(name) ~= 'string' or name == '' then return '__default__' end
  local s = trim(name)
  if s == '' then return '__default__' end
  return (string.gsub(s,'[,\r\n]', ' '))
end
function G.flightStore.key()
  getModelName()
  local store = G.flightStore
  if F.modelNameSession then return '@rf:'..store.encode(F.modelNameSession.craftName) end
  if F.modelFilename then return '@model:'..store.encode(F.modelFilename) end
  return ':'..modelKey(getAircraftName())
end
function G.flightStore.count(key)
  local cache = getFlightCache()
  if cache[key] ~= nil then return cache[key] end
  -- An unclaimed legacy name is used until a real Timer 1 crossing migrates it.
  return cache[':'..modelKey(getAircraftName())] or 0
end
function G.flightStore.increment(key)
  local store, cache = G.flightStore, getFlightCache()
  local name = modelKey(getAircraftName())
  local legacy = ':'..name
  local count = store.count(key)
  if cache[key] == nil and key ~= legacy then
    cache[legacy], store.names[legacy] = nil, nil
  end
  cache[key] = math.min(2147483646, count + 1)
  store.names[key] = name
  modelFlights = cache[key]
  saveFlightCache()
end
function G.flightStore.retry()
  local store = G.flightStore
  if OPT.flightCounter ~= 1 or not store.dirty or store.blocked then return end
  local now = frameNow()
  if not store.retryAt or now >= store.retryAt or now < store.retryAt - 3000 then
    saveFlightCache()
  end
end
local function resetSessionStats()
  S.rpmMax  = 0
  S.currMax = 0
  S.tempMax = 0
  S.becMin  = nil
  S.cellMin = nil
  S.reviewedFlight = nil
  S.maximaHold, S.maximaDisconnected = nil, nil
end
local function resetSessionEvidence()
  for key in pairs(RESOLVED) do RESOLVED[key] = nil end
  A.linkAvailable = false
  A.linkSourceKnown = false
  A.linkSourceSeen = false
  A.battLinkWasAvailable = false
  A.ompStartup = nil
  A.battConnectionZeroPending = false
  A.battConnectionZeroSince = nil
  D.packVoltageValid = false
  D.cellCountValid = false
  D.cellVoltageValid = false
  D.batteryPercentValid = false
  D.capacityValid = false
  D.currentValid = false
  D.tempValid = false
  D.becValid = false
  D.rpmValid = false
  D.tailRpmValid = false
  D.govValid = false
  D.govCurrentInvalid = false
  D.hasBattData = false
  D.adjustedPercent = 0
  D.capacity = 0
  D.voltage = 0
  D.cellsResolved = 0
  D.isLiHV = false
  A.liHvHighSamples = 0
  A.displayPercent = 0
  A.displayPercentInit = false
  A.motorSwitchLastPosition = nil
  A.motorPausedPosition = nil
  A.motorGateCandidateFrom = nil
  A.motorGateCandidateTo = nil
  A.motorGateCandidateTick = nil
  A.govGateLastState = nil
  A.govGateRunningPosition = nil
  A.govGateStopTick = nil
  A.govGateStopSince = nil
  A.electricRpmGateRunningPosition = nil
  A.electricRpmGateZeroSince = nil
  A.ompGateRunningPosition = nil
  A.ompGateZeroSince = nil
  A.flightBatteryAlertsPaused = false
  A.batteryAlertPauseTick = nil
  A.motorPauseProof = nil
  D.minCellVoltage = nil
  D.minRxVoltage = nil
  resetBatteryAlertState()
end
local function loadModelFlights()
  if OPT.flightCounter == FC.ROTORFLIGHT then return end
  local key = G.flightStore.key()
  flightModel = key
  modelFlights = G.flightStore.count(key)
  timerThresholdArmed = nil
  resetSessionStats()
  resetSessionEvidence()
end

local function shiftFlightBatteryAlertTimers(delta)
  if not delta or delta <= 0 then return end
  if (A.battAlertNextTick or 0) > 0 then
    A.battAlertNextTick = A.battAlertNextTick + delta
  end
  if (A.deadVoiceNextTick or 0) > 0 then
    A.deadVoiceNextTick = A.deadVoiceNextTick + delta
  end
  if (A.battHapticNextTick or 0) > 0 then
    A.battHapticNextTick = A.battHapticNextTick + delta
  end
  if (A.battHapticEndTick or 0) > 0 then
    A.battHapticEndTick = A.battHapticEndTick + delta
  end
  if A.battConnectionZeroSince ~= nil then
    A.battConnectionZeroSince = A.battConnectionZeroSince + delta
  end
  if A.battReplacementSince ~= nil then
    A.battReplacementSince = A.battReplacementSince + delta
  end
end
local function setFlightBatteryAlertsPaused(paused, now)
  paused = paused == true
  if paused == A.flightBatteryAlertsPaused then return end
  now = tonumber(now) or frameNow()
  if paused then
    A.flightBatteryAlertsPaused = true
    A.batteryAlertPauseTick = now
  else
    local started = tonumber(A.batteryAlertPauseTick)
    A.flightBatteryAlertsPaused = false
    A.batteryAlertPauseTick = nil
    if started and now > started then
      shiftFlightBatteryAlertTimers(now - started)
    end
  end
end
local function clearMotorGateCandidate()
  A.motorGateCandidateFrom = nil
  A.motorGateCandidateTo = nil
  A.motorGateCandidateTick = nil
  A.electricRpmGateZeroSince = nil
  A.ompGateZeroSince = nil
end
local function clearMotorGateEvidence()
  clearMotorGateCandidate()
  A.govGateLastState = nil
  A.govGateRunningPosition = nil
  A.govGateStopTick = nil
  A.govGateStopSince = nil
  A.electricRpmGateRunningPosition = nil
  A.ompGateRunningPosition = nil
end
local function releaseMotorAlertPause(now)
  setFlightBatteryAlertsPaused(false, now)
  A.motorPausedPosition = nil
  A.motorPauseProof = nil
  clearMotorGateEvidence()
end
local function resetMotorAlertGate(now)
  -- Losing or changing any gate input must fail loud: immediately restore
  -- flight-pack alerts and discard all prior movement/state correlation.
  releaseMotorAlertPause(now)
  A.motorSwitchLastPosition = nil
end
local function gateTickIsRecent(tick, now, limit)
  return tick ~= nil and now >= tick and (now - tick) <= limit
end
local function captureMotorSwitchCandidate(fromPosition, toPosition, now)
  A.motorGateCandidateFrom = fromPosition
  A.motorGateCandidateTo = toPosition
  A.motorGateCandidateTick = now
  A.electricRpmGateZeroSince = nil
  A.ompGateZeroSince = nil
end
local function pauseFlightBatteryAlerts(position, now, proof)
  clearMotorGateEvidence()
  A.motorPausedPosition = position
  A.motorPauseProof = proof
  setFlightBatteryAlertsPaused(true, now)
end
local function updateRotorflightMotorGate(now, position, switchChanged,
                                           governorMode, headRpm)
  local govUsable = D.govValid and governorMode ~= nil
  local rpmUsable = D.rpmValid and headRpm ~= nil
  if not govUsable and not rpmUsable then
    clearMotorGateEvidence()
    return
  end

  -- Gov correlation is intentionally short, but the independent Hspd proof
  -- needs enough time for an autorotation or normal rotor coast-down.
  if A.motorGateCandidateTick ~= nil
     and not gateTickIsRecent(A.motorGateCandidateTick, now,
                              SAFETY.electricMotorStopWindowTicks) then
    clearMotorGateCandidate()
  end

  if govUsable then
    local previousGov = A.govGateLastState
    if GOV_RUNNING_STATE[governorMode] then
      A.govGateStopTick = nil
      A.govGateStopSince = nil
      -- A switch move may reach Lua just before Gov leaves ACTIVE. Keep the
      -- last position proven by an unchanged running sample until correlation
      -- either succeeds or expires.
      if not switchChanged and A.motorGateCandidateTick == nil then
        A.govGateRunningPosition = position
      end
    elseif GOV_STOP_STATE[governorMode] then
      if previousGov ~= nil and GOV_RUNNING_STATE[previousGov] then
        A.govGateStopTick = now
        A.govGateStopSince = now
      end
    elseif governorMode ~= 1 or A.govGateStopTick == nil then
      -- IDLE may follow a sampled AUTOROT/THR-OFF/OFF transition before its
      -- confirmation time elapses. Retain that explicit stop evidence only;
      -- IDLE by itself still cannot initiate a pause.
      A.govGateStopTick = nil
      A.govGateStopSince = nil
    end

    local switchRecent = gateTickIsRecent(
      A.motorGateCandidateTick, now, SAFETY.govMotorCorrelationTicks)
    local govRecent = gateTickIsRecent(
      A.govGateStopTick, now, SAFETY.govMotorCorrelationTicks)
    local stopConfirmed = A.govGateStopSince ~= nil
                          and now >= A.govGateStopSince
                          and (now - A.govGateStopSince)
                              >= SAFETY.govMotorStopConfirmTicks
    if GOV_PAUSE_HOLD_STATE[governorMode] and switchRecent and govRecent
       and stopConfirmed
       and A.motorGateCandidateFrom == A.govGateRunningPosition
       and A.motorGateCandidateTo == position then
      pauseFlightBatteryAlerts(position, now, "gov")
      return
    end
    A.govGateLastState = governorMode
  else
    -- Do not let stale Gov transition state leak into the Hspd fallback.
    A.govGateLastState = nil
    A.govGateRunningPosition = nil
    A.govGateStopTick = nil
    A.govGateStopSince = nil
  end

  if not rpmUsable then
    A.electricRpmGateRunningPosition = nil
    A.electricRpmGateZeroSince = nil
    return
  end

  local rotorRunning = headRpm >= SAFETY.electricMotorRunningRpm
  if rotorRunning then
    A.electricRpmGateZeroSince = nil
    if A.motorGateCandidateTick == nil then
      A.electricRpmGateRunningPosition = position
    end
    return
  end

  -- A known running/unsafe or current-invalid Gov value overrides a zero Hspd;
  -- this prevents a lost RPM signal from being mistaken for motor-off. Missing
  -- or stale Gov is allowed because Hspd is an independent current proof.
  local govAllowsRpmStop = not D.govCurrentInvalid
                           and (not govUsable
                                or GOV_PAUSE_HOLD_STATE[governorMode])
  local candidateValid = govAllowsRpmStop
                         and gateTickIsRecent(
                           A.motorGateCandidateTick, now,
                           SAFETY.electricMotorStopWindowTicks)
                         and A.electricRpmGateRunningPosition ~= nil
                         and A.motorGateCandidateFrom
                             == A.electricRpmGateRunningPosition
                         and A.motorGateCandidateTo == position
  if not candidateValid then
    A.electricRpmGateZeroSince = nil
    return
  end
  if A.electricRpmGateZeroSince == nil then
    A.electricRpmGateZeroSince = now
  end
  if now >= A.electricRpmGateZeroSince
     and (now - A.electricRpmGateZeroSince)
         >= SAFETY.electricMotorZeroConfirmTicks then
    pauseFlightBatteryAlerts(position, now, "rpm")
  end
end
local function updateOmpMotorGate(now, position, headRpm)
  if not D.rpmValid or headRpm == nil then
    clearMotorGateEvidence()
    return
  end

  if A.motorGateCandidateTick ~= nil
     and not gateTickIsRecent(A.motorGateCandidateTick, now,
                              SAFETY.ompMotorStopWindowTicks) then
    clearMotorGateCandidate()
  end

  local rotorRunning = headRpm >= SAFETY.ompMotorRunningRpm
  if rotorRunning then
    A.ompGateZeroSince = nil
    if A.motorGateCandidateTick ~= nil
       and (A.motorGateCandidateFrom ~= A.ompGateRunningPosition
            or A.motorGateCandidateTo ~= position) then
      clearMotorGateCandidate()
    end
    -- Running RPM telemetry can persist during rotor coast-down. Do not relabel the new
    -- switch position as running while a valid stop candidate is pending.
    if A.motorGateCandidateTick == nil then
      A.ompGateRunningPosition = position
    end
    return
  end

  local candidateValid = A.motorGateCandidateTick ~= nil
                         and A.ompGateRunningPosition ~= nil
                         and A.motorGateCandidateFrom
                             == A.ompGateRunningPosition
                         and A.motorGateCandidateTo == position
  if not candidateValid then
    A.ompGateZeroSince = nil
    return
  end
  if A.ompGateZeroSince == nil then A.ompGateZeroSince = now end
  if now >= A.ompGateZeroSince
     and (now - A.ompGateZeroSince) >= SAFETY.ompMotorZeroConfirmTicks then
    pauseFlightBatteryAlerts(position, now, "omp")
  end
end
updateMotorAlertGate = function(now, governorMode, headRpm)
  local position = A.motorSwitchPosition
  local switchUsable = A.motorSourcePhysical and A.motorSourceReadable
                       and position ~= nil
  if not switchUsable or not A.linkAvailable then
    resetMotorAlertGate(now)
    return
  end

  local previousPosition = A.motorSwitchLastPosition
  local switchChanged = previousPosition ~= nil
                        and previousPosition ~= position
  A.motorSwitchLastPosition = position

  -- Nitro's receiver-pack warning retains its independent post-latch switch
  -- acknowledgement. This gate only controls Electric/OMP flight-pack alerts.
  if OPT.battBarMode ~= 0 then
    releaseMotorAlertPause(now)
    return
  end

  if A.flightBatteryAlertsPaused then
    if switchChanged or position ~= A.motorPausedPosition then
      releaseMotorAlertPause(now)
      return
    end
    if OPT.heliType == HELI_ELECTRIC then
      if A.motorPauseProof == "rpm" then
        local govBlocksRpmHold = D.govCurrentInvalid
                                 or (D.govValid and governorMode ~= nil
                                     and not GOV_PAUSE_HOLD_STATE[governorMode])
        if govBlocksRpmHold or not D.rpmValid or headRpm == nil
           or headRpm >= SAFETY.electricMotorRunningRpm then
          releaseMotorAlertPause(now)
        end
      elseif not D.govValid or governorMode == nil
             or not GOV_PAUSE_HOLD_STATE[governorMode] then
        releaseMotorAlertPause(now)
      end
    elseif not D.rpmValid or headRpm == nil
           or headRpm >= SAFETY.ompMotorRunningRpm then
      releaseMotorAlertPause(now)
    end
    return
  end

  if switchChanged then
    local candidateFrom = previousPosition
    if OPT.heliType == HELI_ELECTRIC then
      candidateFrom = A.govGateRunningPosition
                      or A.electricRpmGateRunningPosition
                      or candidateFrom
    elseif OPT.heliType == HELI_OMPHOBBY
           and A.ompGateRunningPosition ~= nil then
      -- A three-position switch can cross its middle detent on a separate
      -- service tick. Keep the position proven by running telemetry as the
      -- origin so intermediate detents cannot erase a valid stop event.
      candidateFrom = A.ompGateRunningPosition
    end
    if candidateFrom ~= position then
      captureMotorSwitchCandidate(candidateFrom, position, now)
    else
      clearMotorGateCandidate()
    end
  end
  if OPT.heliType == HELI_ELECTRIC then
    updateRotorflightMotorGate(now, position, switchChanged, governorMode,
                               headRpm)
  elseif OPT.heliType == HELI_OMPHOBBY then
    updateOmpMotorGate(now, position, headRpm)
  else
    clearMotorGateEvidence()
  end
end
-- KSE Flight Debrief. RAM-only recording; no additional MSP requests or log files.
-- Qualification stays shared with KSE4; KSE Touch resets dashboard maxima when
-- showing a completed review, independently of the preserved flight snapshot.
G.debrief = {}
do
  local P = G.debrief
  P.stopTicks, P.disconnectTicks = 300, 200
  P.settleTicks, P.minRpm, P.stopRpm = 300, 500, 50
  P.electricRunTicks, P.electricStopTicks = 200, 200
  -- Rotorflight CRSF repeats unchanged ARM/Hspd roughly every 3.0-3.1s.
  -- Allow delivery/callback jitter between those packets, but still expire
  -- frozen evidence even while EdgeTX reports the last value as current.
  P.electricReviewFreshTicks = 400
  P.counterRpmMaxGapTicks = 400 -- bounded continuity between renewed RPM samples

  function P.reset()
    P.state = { page=1 }
  end
  P.reset()

  function P.identity()
    getModelName() -- also caches the model filename for same-name model changes
    return F.modelIdentity or F.modelName
  end

  function P.resetModel(identity)
    local previous = P.state
    local electric = previous.electric
    local completed = electric and electric.completed and electric.record
    local record = previous.pending or previous.retained or (previous.delivered and previous.record) or completed
    -- Keep review snapshots across same-file renames, including older RF Lua
    -- versions without the automatic-name marker. Unmarked renames still
    -- reset live counter/profile state; a different model file retires both.
    local retain = record and record.modelFilename ~= nil
                   and record.modelFilename == F.modelFilename
    P.reset()
    local s = P.state
    s.model = identity
    if retain then
      s.record, s.visible, s.delivered = previous.record, previous.visible, previous.delivered
      s.presented = previous.presented
      s.retained, s.retainedPrevious = previous.retained, previous.retainedPrevious
      s.pending = previous.pending
      s.pendingPrevious = previous.pending and (previous.pendingPrevious or not completed)
      s.pendingReviewOffline = previous.pendingReviewOffline
      s.switchId, s.switchActive = previous.switchId, previous.switchActive
      if completed then s.electric = electric; P.pauseElectric(s) end
      s.page, s.downSince, s.lastTick = previous.page, previous.downSince, previous.lastTick
      s.reviewRecord, s.reviewTimer = previous.reviewRecord, previous.reviewTimer
    end
    return retain
  end

  function P.fresh(key)
    return F[key .. "Fresh"] == true
  end

  function P.hide()
    local s = P.state
    s.visible, s.presented = false, true
    s.pendingReviewOffline = nil
    s.reviewRecord, s.reviewTimer = nil, nil
  end

  function P.snapshot(unconfirmed)
    local s = P.state
    local electric = OPT.heliType == HELI_ELECTRIC
    local source
    if electric then
      local e = s.electric
      source = e and e.record and (e.completed or (unconfirmed and e.record.qualified)) and e.record
    elseif OPT.heliType == HELI_OMPHOBBY then
      if not s.ompRecord or (s.ompRecord.rpmMax or 0) <= 0 then return end
      source = s.flight and s.flight.qualified and s.flight or s.ompRecord
    else
      source = s.flight and s.flight.qualified and s.flight
    end
    if not source then return end
    -- A review never aliases the live recorder or finalizes its session.
    local record = {}
    for key, value in pairs(source) do record[key] = value end
    local omp = OPT.heliType == HELI_OMPHOBBY and s.ompRecord
    if omp then
      record.seconds = omp.seconds
      if s.ompReviewFrozen then record.seconds = s.ompReviewSeconds end
      record.batteryPct = omp.batteryPct
      record.rpmMax, record.tempMax = omp.rpmMax, omp.tempMax
    else
      record.seconds = source.seconds or (unconfirmed and source.timerSeconds)
        or math.floor((source.ticks or 0) / 100 + 0.5)
    end
    record.modelName = source.modelName or getAircraftName()
    record.modelFilename = source.modelFilename or F.modelFilename
    record.counter = OPT.flightCounter
    record.totalStale = OPT.flightCounter == FC.ROTORFLIGHT and not record.fcConfirmed
    record.landingUnconfirmed = unconfirmed and electric and not s.electric.completed or nil
    return record
  end

  function P.show(record)
    local s = P.state
    P.resetMaxima(record)
    s.record = record
    if not record.landingUnconfirmed then s.retained = record end
    s.pendingReviewOffline = record.landingUnconfirmed and not P.connected() or nil
    s.visible, s.page, s.presented = true, 1, nil
    -- Reopening the same snapshot must establish a new timer-reset baseline.
    s.reviewRecord, s.reviewTimer = nil, nil
  end

  function P.connected()
    if A.linkAvailable then return true end
    if OPT.heliType == HELI_ELECTRIC and type(getRSSI) == "function" then
      local ok, rssi = pcall(getRSSI)
      rssi = tonumber(rssi)
      return ok and rssi ~= nil and rssi > 0 and rssi < math.huge
    end
    return false
  end

  function P.reviewStopValid()
    local rpm = getHeadspeed()
    if not D.rpmValid or rpm > P.stopRpm then return false end
    if OPT.heliType ~= HELI_ELECTRIC and not P.fresh("headspeed") then return false end
    if OPT.heliType == HELI_ELECTRIC then
      local arm, current = get("ARM")
      arm = tonumber(arm)
      local e = P.state.electric
      local proven = e and e.armFreshTick and e.rpmFreshTick
                     and math.min(e.armFreshTick, e.rpmFreshTick)
      return current and arm and arm >= 0 and arm <= 255
             and arm == math.floor(arm) and arm % 2 == 0
             and proven and frameNow() - proven <= P.electricReviewFreshTicks
    elseif OPT.heliType == HELI_NITRO then
      local gov = getGovernorMode()
      if D.govCurrentInvalid or (D.govValid and P.fresh("governorMode")
          and GOV_RUNNING_STATE[gov]) then return false end
      local arm, current, fresh = get("ARM")
      arm = tonumber(arm)
      if current and fresh and arm and math.floor(arm) % 2 == 1 then return false end
    end
    return true
  end

  function P.toggle()
    local s = P.state
    if s.visible then P.hide(); return end
    if OPT.simTelemetry then
      -- Preview the paused synthetic flight without entering any live recorder,
      -- qualification, timer-capture, counter or transport path.
      if s.simPaused and s.simFlight then
        local record = {}
        for key, value in pairs(s.simFlight) do record[key] = value end
        P.show(record)
      end
      return
    end
    local record = s.pending or s.retained
    if P.connected() then
      local now = frameNow()
      if not s.lastTick or now - s.lastTick > 100 or not P.reviewStopValid() then return end
      if OPT.heliType == HELI_ELECTRIC then
        local e = s.electric
        local proven = e and e.armFreshTick and e.rpmFreshTick
                       and math.min(e.armFreshTick, e.rpmFreshTick)
        if not proven or not e.stopSince or proven - e.stopSince < P.stopTicks then return end
      elseif not s.reviewStopSince or now - s.reviewStopSince < P.stopTicks then return end
      if not s.retainedPrevious and not s.pendingPrevious then
        if OPT.heliType == HELI_ELECTRIC then
          if not (s.electric and s.electric.completed and s.electric.record) then return end
        elseif OPT.heliType == HELI_OMPHOBBY then
          if not s.ompRecord or (s.ompRecord.rpmMax or 0) <= 0 then return end
        elseif not (s.flight and s.flight.qualified) then return end
        if s.ompRecord and not s.ompReviewFrozen then
          P.captureOmpTimer(s.ompRecord)
          s.ompReviewSeconds, s.ompReviewFrozen = s.ompRecord.seconds, true
        end
        record = P.snapshot()
      end
    end
    if record then P.show(record) end
  end

  function P.serviceSwitch()
    local s, id = P.state, OPT.debriefSwitch
    if s.switchId ~= id then s.switchId, s.switchActive = id, nil end
    if not id or id == 0 then
      s.switchActive = nil
      return
    end
    -- Use the same whole-switch SOURCE picker and value reader as MotorSw.
    -- Source IDs and switch-condition IDs belong to different namespaces.
    local value = getValSrc(id)
    if value == nil or value ~= value or math.abs(value) == math.huge then
      s.switchActive = nil
      return
    end
    local active = value > 0 -- +100%/down; middle and release only rearm the edge
    local previous = s.switchActive
    s.switchActive = active
    -- Only a real activation is actionable. A rejected request is consumed,
    -- never deferred until landing, and release cannot toggle a momentary switch.
    if previous == false and active then P.toggle() end
  end

  function P.extreme(record, key, value, valid, minimum)
    if not valid or value == nil or value ~= value then return end
    local old = record[key]
    if old == nil or (minimum and value < old) or (not minimum and value > old) then
      record[key] = value
    end
  end

  function P.sample(record, rpm)
    P.extreme(record, "rpmMin", rpm, true, true)
    P.extreme(record, "rpmMax", rpm, true)
    local tail = getTailRpm()
    P.extreme(record, "tailMax", tail, D.tailRpmValid and P.fresh("tailHeadspeed") and tail > 0)
    local amps, volts = getCurr(), getPackVolt()
    local ampsLive = D.currentValid and P.fresh("current")
    local voltsLive = D.packVoltageValid and P.fresh("packVoltage")
    P.extreme(record, "ampsMax", amps, ampsLive)
    P.extreme(record, "voltsMin", volts, voltsLive, true)
    -- Both readings must be valid in this in-flight sample. Multiplying
    -- independently recorded extrema would invent a power level never seen.
    if ampsLive and voltsLive and amps >= 0 then
      P.extreme(record, "wattsMax", amps * volts, true)
    end
    local cellFresh = OPT.heliType == HELI_OMPHOBBY and P.fresh("packVoltage") or P.fresh("cellVoltage")
    P.extreme(record, "cellMin", getCellVoltage(), D.cellVoltageValid and cellFresh, true)
    P.extreme(record, "tempMax", getTemp(), D.tempValid and P.fresh("escTemperature"))
    P.extreme(record, "becMin", getBec(), D.becValid and P.fresh("becVoltage"), true)
    P.extreme(record, "becMax", getBec(), D.becValid and P.fresh("becVoltage"))
    local capa = getCapa()
    if D.capacityValid and P.fresh("capacity") then
      -- Capa is cumulative: subtract the last stopped baseline, never add samples.
      -- A reset mid-flight makes the delta unknown instead of inventing consumption.
      if record.capaLast and capa < record.capaLast then record.capaReset = true end
      record.capaLast = capa
      if record.capaBase and not record.capaReset then
        record.mah = math.max(0, capa - record.capaBase)
      else
        record.mah = nil
      end
    end
    local pct = getBatPct()
    P.extreme(record, "remaining", pct, D.batteryPercentValid and P.fresh("batteryPercent"), true)
    record.batteryProfile = getBattProfile() or record.batteryProfile
  end

  function P.elapsedTimer()
    local timer = getTimer0()
    local value = type(timer) == "table" and tonumber(timer.value) or nil
    if not value or value ~= value or value == math.huge or value == -math.huge then return end
    local start = tonumber(timer.start) or 0
    if start ~= start or start == math.huge or start == -math.huge then return end
    -- Convert countdown timers to elapsed time, including time past zero.
    -- Keep the last valid reading if the timer becomes temporarily unavailable.
    return math.max(0, math.floor((start > 0 and start - value or value) + 0.5)), timer.mode
  end

  function P.captureOmpTimer(record)
    local seconds = P.elapsedTimer()
    if seconds ~= nil then record.seconds = seconds end
  end

  function P.captureElectricTimer(record)
    local seconds, mode = P.elapsedTimer()
    if mode == 0 or not seconds or seconds <= 0 then return end
    -- Keep the last elapsed time through a failed read or an early timer reset.
    -- This is display data only: renewed ARM/RPM still prove flight and landing.
    record.timerSeconds = math.max(record.timerSeconds or 0, seconds)
  end

  function P.observeOmp(s)
    getBatPct()
    local pctLive = D.batteryPercentValid and P.fresh("batteryPercent")
    local rpm = getHeadspeed()
    local rpmLive = D.rpmValid and P.fresh("headspeed")
    -- Battery telemetry may start recording on the bench, but only an observed
    -- positive RPM enables the review. RPM also starts a record when Bat% is
    -- absent; optional battery data must not block a short rotor run.
    local r = s.ompRecord
    if not r then
      if not pctLive and not (rpmLive and rpm > 0) then return end
      r = {telemetryOnly=true}; s.ompRecord = r
    end
    -- Keep the last valid dashboard percentage while connected. tick() clears
    -- the live display on link loss, so freeze this cached value at disconnect.
    -- Reuse its reserve adjustment, smoothing and whole-number rounding.
    if D.hasBattData then
      local displayed = A.displayPercentInit and A.displayPercent or D.adjustedPercent
      r.batteryPct = math.floor(math.max(0, math.min(100, displayed)))
    end
    s.ompTimerFrozen = false
    if not s.ompReviewFrozen then P.captureOmpTimer(r) end
    r.total = OPT.flightCounter == 1 and modelFlights or FC.count
    r.saveFailed = OPT.flightCounter == 1 and A.flightSaveError or nil
    local amps, volts = getCurr(), getPackVolt()
    local ampsLive = D.currentValid and P.fresh("current")
    local voltsLive = D.packVoltageValid and P.fresh("packVoltage")
    P.extreme(r, "rpmMax", rpm, rpmLive)
    P.extreme(r, "ampsMax", amps, ampsLive and amps >= 0)
    P.extreme(r, "voltsMin", volts, voltsLive, true)
    if ampsLive and voltsLive and amps >= 0 then P.extreme(r, "wattsMax", amps * volts, true) end
    local cell, temp, capa = getCellVoltage(), getTemp(), getCapa()
    P.extreme(r, "cellMin", cell, D.cellVoltageValid and voltsLive, true)
    P.extreme(r, "tempMax", temp, D.tempValid and P.fresh("escTemperature"))
    if D.capacityValid and P.fresh("capacity") then r.capaLast = capa end
  end

  function P.pauseElectric(s)
    local e = s.electric
    if e then
      e.runSince, e.stopSince, e.provenTick = nil, nil, nil
      e.armFreshTick, e.rpmFreshTick = nil, nil
    end
  end

  -- Electric reviews qualify independently of the KSE Counter. Require an
  -- observed disarmed/stopped baseline, then two seconds of current armed RPM
  -- confirmed by renewed samples from each sensor, independently.
  -- No timer, governor, power sensor, MSP request or counter write is involved.
  function P.observeElectric(s, now, rpm, rpmLive)
    local e = s.electric
    if not e then e = {}; s.electric = e end
    local arm, current, fresh = get("ARM")
    arm = tonumber(arm)
    local armLive = current and arm and arm >= 0 and arm <= 255
                    and arm == math.floor(arm)
    local rpmCurrent = D.rpmValid
    -- EdgeTX isFresh only covers roughly 320ms after receipt. ARM and Hspd
    -- packets need not coincide or arrive on every 100ms widget callback.
    -- Hold current values between packets, but advance proof only as far as
    -- BOTH sensors have supplied fresh evidence. One frozen value cannot
    -- finish a two-second run/stop, even before its sensor-lost timeout.
    if not armLive then e.armFreshTick = nil
    elseif fresh then e.armFreshTick = now end
    if not rpmCurrent then e.rpmFreshTick = nil
    elseif rpmLive then e.rpmFreshTick = now end
    local proven = e.armFreshTick and e.rpmFreshTick
                   and math.min(e.armFreshTick, e.rpmFreshTick)
    local armed = armLive and arm % 2 == 1
    local disarmed = armLive and arm % 2 == 0
    local stopped = rpmCurrent and rpm <= P.stopRpm

    -- Re-arming cancels the completed recap even before another spool-up.
    -- This does not reset Timer 1 or re-arm the independent KSE Counter.
    if armed and fresh and e.completed then
      e.record, e.completed = nil, nil
    elseif rpmLive and rpm > P.stopRpm then
      e.completed = nil -- fresh rotor motion invalidates earlier stop proof
    end
    local r = e.record
    if r then
      if not e.completed then
        P.captureElectricTimer(r)
        r.total = OPT.flightCounter == 1 and modelFlights or FC.count
        r.saveFailed = OPT.flightCounter == 1 and A.flightSaveError or nil
      elseif OPT.flightCounter == FC.ROTORFLIGHT and FC.count ~= nil
             and not FC.stale and (r.total == nil or FC.count >= r.total) then
        -- Accept a late FC count after landing, but keep the frozen total
        -- through a transport restart or a display-name/counter-cache reset.
        r.total = FC.count
      end
      if e.completed and OPT.flightCounter == FC.ROTORFLIGHT and not FC.stale then
        r.fcConfirmed = r.fcConfirmed or (r.fcBase ~= nil and FC.count ~= nil and FC.count > r.fcBase)
      end
    end

    if disarmed and stopped then
      e.runSince, e.provenTick = nil, nil
      e.stopSince = e.stopSince or now
      if not D.capacityValid then e.capaBase = nil
      elseif P.fresh("capacity") then e.capaBase = getCapa() end
      if not r and proven then
        -- A single current baseline is enough at startup; completion below
        -- still requires a continuous two-second disarmed/rotor-stop proof.
        e.ready = true
      elseif r and proven and proven - e.stopSince >= P.electricStopTicks then
        if e.reconnectNeedsStop or not r.qualified then
          -- Fresh stop proof after a long gap separates the next flight, but
          -- cannot retrospectively confirm how the interrupted flight ended.
          if e.reconnectNeedsStop and s.pending then s.pendingPrevious = true end
          e.record = nil
        elseif not e.completed then
          e.completed = true
          s.pending, s.pendingPrevious = nil, nil
          r.seconds = r.timerSeconds or math.floor(r.ticks / 100 + 0.5)
          r.modelName = getAircraftName()
          r.modelFilename = F.modelFilename
        end
        e.ready, e.reconnectNeedsStop = true, nil
      end
      return
    end
    if e.completed then return end -- cached activity cannot undo a proven landing
    e.stopSince = nil
    local running = e.ready and armed and rpmCurrent and rpm >= P.minRpm and proven
    if not running then
      e.runSince, e.provenTick = nil, nil
      return
    end
    e.reconnectNeedsStop = nil -- live armed rotor activity resumes the flight
    if not r and s.pendingPrevious then
      -- A new flight after an observed stopped baseline gets fresh maxima.
      -- Opening an unconfirmed review, or resuming airborne, never resets them.
      S.rpmMax, S.currMax, S.tempMax = 0, 0, 0
    end
    s.pending, s.pendingPrevious = nil, nil
    -- Electric's independent recorder retires the last recap even when the
    -- ordinary flight counter has not qualified or governor data is absent.
    s.retained, s.record, s.retainedPrevious = nil, nil, nil
    if not r then
      r = {ticks=0, capaBase=e.capaBase, fcBase=FC.count,
           total=OPT.flightCounter == 1 and modelFlights or FC.count}
      e.record = r
      P.captureElectricTimer(r)
    end
    e.runSince = e.runSince or now
    local previous = e.provenTick or e.runSince
    if proven > previous then
      r.ticks = r.ticks + proven - previous
      e.provenTick = proven
    end
    -- Extrema still require a freshly received rotor reading. The other
    -- statistics apply their own sensor freshness checks inside sample().
    if rpmLive then P.sample(r, rpm) end
    if proven - e.runSince >= P.electricRunTicks then r.qualified = true end
  end

  function P.tickFlight(now)
    if OPT.simTelemetry then return end
    local s = P.state
    local dt = s.lastTick and now - s.lastTick or 0
    if dt < 0 then P.reset(); return end
    s.lastTick = now
    -- Never infer elapsed flight/stop time across an unscheduled callback gap.
    if dt > 100 then
      dt = 0; s.stopSince, s.settleSince, s.lastRunning = nil, nil, false
      s.counterRpmTick = nil
      s.downSince, s.reviewStopSince = nil, nil
      P.pauseElectric(s)
    end
    local rpm = getHeadspeed()
    local rpmLive = D.rpmValid and P.fresh("headspeed")
    local connected = P.connected()
    if connected and s.pendingReviewOffline then
      P.hide() -- return to telemetry immediately, even before new ARM/RPM packets
    end
    if not connected then
      P.pauseElectric(s)
      s.counterRpmTick = nil
      s.reviewStopSince = nil
      if s.ompRecord and not s.ompTimerFrozen then
        if not s.ompReviewFrozen then P.captureOmpTimer(s.ompRecord) end
        s.ompTimerFrozen = true
      end
      s.downSince = s.downSince or now
      s.lastRunning, s.settleSince = false, nil
      if now - s.downSince >= P.disconnectTicks then
        local qualified = s.flight and s.flight.qualified
        local electric = OPT.heliType == HELI_ELECTRIC
        local review = electric and s.electric and s.electric.completed and s.electric.record
        local ready = review or (OPT.heliType == HELI_OMPHOBBY and s.ompRecord
          and (s.ompRecord.rpmMax or 0) > 0)
          or (OPT.heliType == HELI_NITRO and qualified and s.stopped)
        if ready and not s.delivered then
          P.show(P.snapshot())
          s.delivered, s.presented = true, nil
        elseif not s.flight or not s.flight.qualified then
          s.ready, s.flight, s.capaBase = false, nil, nil
        end
        if s.electric and (not s.electric.record or not s.electric.record.qualified) then
          s.electric = nil
        end
        if electric and not review and not s.pending then
          -- Keep one immutable, manual-only review of the last received data.
          -- Telemetry loss alone neither confirms landing nor opens a popup.
          s.pending = P.snapshot(true)
        end
        -- Electric needs disarm/stop proof; Nitro needs stop proof. OMP uses
        -- the receiver-session trigger once fresh Bat% has been observed.
      end
      s.stopSince = nil
      return
    end
    if s.delivered then
      local identity, retained = s.model, s.retained
      local switchId, switchActive = s.switchId, s.switchActive
      local electric = OPT.heliType == HELI_ELECTRIC and not s.presented
                       and s.electric and s.electric.completed and s.electric
      -- Reconnect returns to the dashboard. Keep the immutable recap for
      -- manual review, and preserve the existing unseen Electric retry.
      P.reset(); s = P.state; s.model, s.lastTick = identity, now
      s.retained, s.retainedPrevious = retained, retained ~= nil
      s.switchId, s.switchActive = switchId, switchActive
      if electric then s.electric = electric; P.pauseElectric(s) end
    elseif OPT.heliType == HELI_OMPHOBBY and s.downSince
           and now - s.downSince >= P.disconnectTicks then
      -- Reset bench-session evidence without losing the last manual review.
      local identity, retained = s.model, s.retained
      local switchId, switchActive = s.switchId, s.switchActive
      P.reset(); s = P.state; s.model, s.lastTick = identity, now
      s.retained, s.retainedPrevious = retained, retained ~= nil
      s.switchId, s.switchActive = switchId, switchActive
    elseif (s.downSince and now - s.downSince >= P.disconnectTicks)
        or (s.pending and not s.pendingPrevious) then
      if s.electric and s.electric.record and not s.electric.completed then
        s.electric.reconnectNeedsStop = true
      end
      if s.flight and s.flight.qualified and not s.stopped then
        -- If a long airborne loss returns already stopped, retire that record
        -- quietly after fresh stop proof. A subsequent battery records anew.
        s.reconnectNeedsStop = true
      end
    end
    s.downSince = nil
    if OPT.heliType == HELI_ELECTRIC then P.observeElectric(s, now, rpm, rpmLive) end
    if OPT.heliType == HELI_OMPHOBBY then P.observeOmp(s) end
    if s.flight and OPT.flightCounter == 1 then
      s.flight.total, s.flight.saveFailed = modelFlights, A.flightSaveError
    elseif s.flight and OPT.flightCounter == FC.ROTORFLIGHT and FC.count ~= nil then
      s.flight.total = FC.count
      if s.flight.qualified and s.stopped and not FC.stale then
        s.flight.fcConfirmed = s.flight.fcBase ~= nil and FC.count > s.flight.fcBase
      end
    end
    local gov = getGovernorMode()
    local govLive = D.govValid and P.fresh("governorMode")
    -- OMP's telemetry contract has RPM but no Rotorflight ARM sensor. A
    -- leftover or unrelated ARM=0 source must not veto an OMP flight.
    local arm, armCurrent, armFresh
    if OPT.heliType ~= HELI_OMPHOBBY then
      arm, armCurrent, armFresh = get("ARM")
      arm = tonumber(arm)
    end
    local disarmed = armCurrent and armFresh and arm and math.floor(arm) % 2 == 0
    if P.reviewStopValid() then
      s.reviewStopSince = s.reviewStopSince or now
    else
      s.reviewStopSince = nil
    end
    local armed = OPT.heliType ~= HELI_OMPHOBBY and armCurrent and armFresh
                  and arm and math.floor(arm) % 2 == 1
    if s.visible and ((rpmLive and rpm > P.stopRpm)
        or (OPT.heliType == HELI_NITRO and govLive and GOV_RUNNING_STATE[gov])
        or armed) then P.hide() end
    -- A current RPM value may outlive EdgeTX's short isFresh window between
    -- packets. Preserve recording continuity, but advance its clocks only on
    -- fresh evidence. Missing/expired readings must not backfill lost time.
    local previousRpmTick = s.counterRpmTick
    if not D.rpmValid or (previousRpmTick and now - previousRpmTick > P.counterRpmMaxGapTicks) then
      s.stopSince, s.settleSince, s.rpmAnchor, s.lastRunning = nil, nil, nil, false
      s.counterRpmTick, previousRpmTick = nil, nil
    end
    -- Observe independent blockers even when no fresh RPM packet is due.
    if govLive and GOV_RUNNING_STATE[gov] then s.stopSince = nil end
    if disarmed or D.govCurrentInvalid or (govLive and gov ~= 4 and gov ~= 9) then
      s.lastRunning, s.settleSince, s.rpmAnchor = false, nil, nil
    end
    if not rpmLive then return end
    s.counterRpmTick = now
    local rpmDt = previousRpmTick and now - previousRpmTick or 0
    local stopped = rpmLive and rpm <= P.stopRpm
                    and (not govLive or not GOV_RUNNING_STATE[gov])
    if stopped then
      s.stopSince = s.stopSince or now
      s.lastRunning, s.settleSince, s.rpmAnchor = false, nil, nil
      if now - s.stopSince >= P.stopTicks then
        s.ready, s.stopped = true, true
        if s.reconnectNeedsStop then s.flight, s.reconnectNeedsStop = nil, nil end
        if not s.flight or not s.flight.qualified then
          s.flight = nil -- separate brief bench runs cannot accumulate into a flight
          s.capaBase = D.capacityValid and P.fresh("capacity") and getCapa() or nil
        end
      end
      return
    end
    s.stopSince = nil
    if (rpmLive and rpm > P.stopRpm) or (govLive and GOV_RUNNING_STATE[gov]) then
      s.stopped = false
      s.reconnectNeedsStop = nil
    end
    local running = s.ready and rpmLive and rpm >= P.minRpm and not disarmed
                    and (not govLive or gov == 4 or gov == 9)
                    and not D.govCurrentInvalid
    if not running then
      s.lastRunning, s.settleSince, s.rpmAnchor = false, nil, nil
      return
    end
    -- A new running segment retires the previous review without splitting or
    -- restarting the existing powered telemetry session.
    s.retained, s.record, s.retainedPrevious = nil, nil, nil
    if s.ompReviewFrozen then
      s.ompReviewFrozen, s.ompReviewSeconds = nil, nil
      if s.ompRecord then P.captureOmpTimer(s.ompRecord) end
    end
    if not s.flight then
      s.flight = { ticks=0, capaBase=s.capaBase, fcBase=FC.count, total=getFlightCount(),
                   saveFailed=OPT.flightCounter == 1 and A.flightSaveError or nil }
    end
    local record = s.flight
    if s.lastRunning then record.ticks = record.ticks + rpmDt end
    s.lastRunning = true
    -- OMP flight proof is sustained renewed RPM above the running threshold.
    -- Normal RPM variation must not keep resetting an extra stability gate.
    if OPT.heliType ~= HELI_OMPHOBBY then
      if not s.rpmAnchor or math.abs(rpm - s.rpmAnchor) > s.rpmAnchor * 0.10 then
        s.rpmAnchor, s.settleSince = rpm, now
      end
      s.settleSince = s.settleSince or now
      if now - s.settleSince < P.settleTicks then return end
    end
    P.sample(record, rpm)
    -- Qualify the telemetry record independently of Timer 1 counting.
    local required = minFlightDur * 100
    if not record.qualified and record.ticks >= required then
      record.qualified = true
    end
  end

  function P.trackRqly()
    local s = P.state
    if s.delivered then return end
    local electric, omp = OPT.heliType == HELI_ELECTRIC, OPT.heliType == HELI_OMPHOBBY
    local record
    if electric then record = s.electric and s.electric.record
    elseif omp then record = s.ompRecord
    else record = s.flight end
    local tracker = s.rqly
    if tracker and tracker.record and tracker.record ~= record then
      tracker = nil -- re-arm, discarded run, or another flight record
    end
    if not tracker then tracker = {}; s.rqly = tracker end
    if record and tracker.record ~= record then
      tracker.record = record
      -- A completed unseen record may outlive its receiver/model-name state.
      P.extreme(tracker, "minimum", record.rqlyMin, record.rqlyMin ~= nil, true)
    end
    local rpm = getHeadspeed()
    if D.rpmValid and rpm == 0 then
      local completed = electric and s.electric and s.electric.completed
                        or (not electric and s.stopped)
      if record and completed and (record.qualified or tracker.started) then
        record.rqlyFrozen = true
      end
      if not record or (not omp and not record.qualified) then
        -- A stopped unqualified bench run cannot lower the next flight's min.
        if record then record.rqlyMin = nil end
        s.rqly = nil
        return
      end
    elseif D.rpmValid and rpm > 0 and not (record and record.rqlyFrozen) then
      tracker.started = true
      -- RQly has its own packet cadence. Current positive headspeed gates the
      -- window; only a fresh sample of this exact sensor can lower its minimum.
      local value, current, fresh = get("RQly")
      value = tonumber(value)
      local valid = current and fresh and value and value >= 0 and value <= 100
      if valid and value == 0 then
        -- Zero is meaningful while the receiver is live, but power-off zeros
        -- must not be combined with a cached positive rotor reading.
        local ok, heartbeat = false, nil
        if type(getRSSI) == "function" then ok, heartbeat = pcall(getRSSI) end
        heartbeat = tonumber(heartbeat)
        valid = ok and heartbeat and heartbeat > 0 and heartbeat < math.huge
      end
      P.extreme(tracker, "minimum", value, valid, true)
    end
    if record then
      record.rqlyMin = tracker.minimum
      -- OMP may deliver either the telemetry-only or counter-qualified record.
      if omp and s.flight then s.flight.rqlyMin = tracker.minimum end
    end
  end

  function P.tick(now)
    if OPT.simTelemetry then return end
    P.tickFlight(now)
    P.trackRqly()
  end

  function P.advanceSimulation(now)
    local identity = P.identity()
    local s = P.state
    if s.model ~= identity then P.reset(); s = P.state; s.model = identity end
    -- Advancing a private clock instead of wall time makes resume continue
    -- from the paused values, including after a background or layout rebuild.
    if s.simClock == nil then
      s.simClock, s.simPaused = now, false
    elseif not s.simPaused and s.simLastTick and now >= s.simLastTick then
      s.simClock = s.simClock + now - s.simLastTick
    end
    s.simLastTick, s.simMotorMoved = now, false
    if s.simMotorSource ~= SRC.motorSwitch then
      s.simMotorSource, s.simMotorPosition = SRC.motorSwitch, nil
    end
    local value = getValSrc(SRC.motorSwitch)
    if value == nil or value ~= value or math.abs(value) == math.huge then
      s.simMotorPosition = nil
    else
      local position = value > 0 and 1 or (value < 0 and -1 or 0)
      local previous = s.simMotorPosition
      s.simMotorPosition = position
      if previous ~= nil and previous ~= position then
        s.simMotorMoved, s.simPaused = true, not s.simPaused
        if not s.simPaused then
          if s.visible then P.hide() end
          s.record, s.retained = nil, nil
        end
      end
    end
    return s.simClock
  end

  function P.captureSimulation()
    local s = P.state
    local cycle = math.floor(s.simClock / 3600)
    if s.simCycle ~= cycle then s.simCycle, s.simFlight = cycle, nil end
    local r = s.simFlight
    if not r then
      r = {simulated=true, modelName=getModelName(), counter=FC.SIM_PREVIEW}
      s.simFlight = r
    end
    -- Only the synthetic cache populated by applySimulatedTelemetry is sampled.
    -- The real telemetry adapters, flight counter and SD log are never serviced.
    r.seconds, r.total = F.timerSecs, modelFlights
    P.extreme(r, "rpmMin", F.rpm, F.rpm and F.rpm > 0, true)
    P.extreme(r, "rpmMax", F.rpm, D.rpmValid)
    P.extreme(r, "rqlyMin", F.rqly, true, true)
    if OPT.heliType ~= HELI_OMPHOBBY then
      P.extreme(r, "tailMax", getTailRpm(), true)
      P.extreme(r, "becMin", F.bec, D.becValid, true)
      P.extreme(r, "becMax", F.bec, D.becValid)
    else
      r.batteryPct = math.floor(A.displayPercent)
    end
    if OPT.heliType ~= HELI_NITRO then
      P.extreme(r, "ampsMax", F.curr, D.currentValid)
      P.extreme(r, "wattsMax", F.curr * F.packVolt, D.currentValid and D.packVoltageValid)
      P.extreme(r, "voltsMin", F.packVolt, D.packVoltageValid, true)
      P.extreme(r, "cellMin", F.cellVoltage, D.cellVoltageValid, true)
      P.extreme(r, "tempMax", F.temp, D.tempValid)
      r.mah, r.batteryProfile = F.capa, F.battProfile
    end
  end

  function P.simulate(now)
    if not OPT.simTelemetry then return end
    local s = P.state
    local identity = P.identity()
    if s.model ~= identity then P.reset(); s = P.state; s.model = identity end
    -- A configured Debrief Switch owns manual preview controls. SF remains a
    -- fallback when none is configured, without also reacting to a motor flip.
    if OPT.debriefSwitch ~= 0 then s.sf = nil; return end
    local value = get("SF")
    value = tonumber(value)
    if not value then s.sf = nil; return end
    local position = value > 0 and 1 or (value < 0 and -1 or 0)
    local previous = s.sf
    s.sf = position
    if previous == nil or position == previous then return end
    if s.simMotorMoved then return end
    if s.simPaused then P.toggle(); return end
    -- Private small PRNG: no global randomseed changes and no live state mutations.
    s.seed = ((s.seed or now % 65521) * 251 + 13849) % 65521
    local function random(lo, hi)
      s.seed = (s.seed * 251 + 13849) % 65521
      return lo + math.floor(s.seed / 65521 * (hi - lo + 1))
    end
    local cells = OPT.heliType == HELI_OMPHOBBY and 3 or 12
    local cell = random(350, 382) / 100
    local bec = random(735, 780) / 100
    local record = {
      simulated=true, modelName=getModelName(), seconds=random(180, 480),
      total=random(25, 650), rpmMin=random(1650, 1900), rpmMax=random(2050, 2400),
      tailMax=random(8800, 11000), ampsMax=random(750, 1800) / 10,
      voltsMin=cell * cells, cellMin=cell, mah=random(1700, 3800),
      tempMax=random(58, 94), becMin=bec, becMax=bec + random(12, 35) / 100,
      rqlyMin=random(85, 99), remaining=random(18, 37), batteryProfile=random(1, 6),
    }
    if OPT.heliType == HELI_NITRO then
      record.ampsMax, record.voltsMin, record.cellMin, record.mah, record.remaining = nil, nil, nil, nil, nil
      record.tempMax, record.batteryProfile = nil, nil
    elseif OPT.heliType == HELI_OMPHOBBY then
      record.becMin, record.becMax, record.tailMax, record.batteryProfile = nil, nil, nil, nil
      record.rpmMin, record.rpmMax, record.mah = random(2800, 3100), random(3300, 3700), random(300, 700)
      record.batteryPct = record.remaining
    end
    if record.ampsMax and record.voltsMin then
      record.wattsMax = math.floor(record.ampsMax
        * (record.voltsMin + cells * random(0, 20) / 100) + 0.5)
    end
    s.record, s.visible, s.page = record, true, 1
  end
end

function G.debrief.resetMaxima(record)
  local s = G.debrief.state
  if not record or record.landingUnconfirmed or record.simulated
     or OPT.simTelemetry or s.retainedPrevious then return end
  -- Snapshot tables are copied on each manual review. Use the underlying
  -- recorder to reset once per flight, never when reopening an older recap.
  local source = OPT.heliType == HELI_ELECTRIC and s.electric and s.electric.record
                 or OPT.heliType == HELI_OMPHOBBY and s.ompRecord or s.flight
  if not source or S.reviewedFlight == source then return end
  S.reviewedFlight = source
  S.rpmMax, S.currMax, S.tempMax = 0, 0, 0
  -- A manual review can open with the old pack still connected. Keep its
  -- stopped/heat-soaked readings out until reconnect or fresh rotor motion.
  S.maximaHold, S.maximaDisconnected = true, not A.linkAvailable
end

local function tickFlightCount()
  local identity = G.debrief.identity()
  local thisModel = OPT.flightCounter == 1 and G.flightStore.key()
                    or modelKey(getAircraftName())
  if G.debrief.state.model ~= identity or flightModel ~= thisModel then
    local retained = G.debrief.resetModel(identity)
    local linkSourceSeen = A.linkSourceSeen
    G.debrief.modelChanged = true
    flightModel = thisModel
    if OPT.flightCounter == 1 then
      modelFlights = G.flightStore.count(thisModel)
    else
      FC.count, FC.stale = nil, false
      FC.status, FC.wanted = "WAITING", true
      FC.stableSince, FC.model = nil, nil
    end
    timerThresholdArmed = nil
    resetSessionStats()
    resetSessionEvidence()
    -- A display-name restore is not a new receiver session. Keep the proven
    -- link source authoritative so cached FC values cannot fake a reconnect.
    if retained then A.linkSourceSeen = linkSourceSeen end
  end
  -- Restore the original KSE counter contract: one count per Timer 1 crossing.
  -- Debrief qualification, RPM freshness and receiver state do not gate it.
  if OPT.flightCounter ~= 1 then return end
  local timer = getTimer0()
  local value = type(timer) == "table" and tonumber(timer.value) or nil
  if not value or value ~= value or math.abs(value) == math.huge then return end
  local start = tonumber(timer.start) or 0
  if start ~= start or math.abs(start) == math.huge then return end
  local secs = math.max(0, start > 0 and start - value or value)
  if timerThresholdArmed == nil then
    timerThresholdArmed = secs < minFlightDur
  end
  if secs < minFlightDur then
    timerThresholdArmed = true
  elseif timerThresholdArmed then
    timerThresholdArmed = false
    G.flightStore.increment(thisModel)
  end
end
local function updateStats()
  if not A.linkAvailable then
    if S.maximaHold then S.maximaDisconnected = true end
    return
  end
  local r = getHeadspeed()
  local rpmFresh = G.debrief.fresh("headspeed")
  if S.maximaHold and (S.maximaDisconnected
      or (D.rpmValid and rpmFresh and r > G.debrief.stopRpm)) then
    S.maximaHold, S.maximaDisconnected = nil, nil
  end
  if not S.maximaHold and D.rpmValid and rpmFresh and r > 0 then
    if r > S.rpmMax then S.rpmMax = r end
  end
  local c = getCurr()
  if not S.maximaHold and D.currentValid and G.debrief.fresh("current")
     and c > S.currMax then S.currMax = c end
  local t = getTemp()
  if not S.maximaHold and D.tempValid and G.debrief.fresh("escTemperature")
     and t > S.tempMax then S.tempMax = t end
  local b = getBec()
  if D.becValid and (S.becMin == nil or b < S.becMin) then S.becMin = b end
  local mc = getCellVoltage()
  if mc and mc > 0 and (S.cellMin == nil or mc < S.cellMin) then S.cellMin = mc end
end

local DATA_INTERVAL_TICKS = 10 -- 10 Hz; telemetry and UI do not need frame-rate polling
local function serviceTelemetry(trackStats)
  local now = frameNow()
  local last = A.lastDataTick
  if last and last >= 0 and now >= last and (now - last) < DATA_INTERVAL_TICKS then
    return false
  end
  tickFlightCount()
  G.flightStore.retry()
  tick(now)
  G.debrief.tick(now)
  if trackStats then updateStats() end
  return true
end

-- Simulation is a display-only 36-second loop. It bypasses tick(), so none of
-- the flight counter, audio, haptic, motor-gate, or safety-alert code can run.
-- The synthetic values live only in the same per-frame cache consumed by the
-- retained UI and are discarded before returning to live mode.
local SIM_INTERVAL_TICKS = 10
local function applySimulatedTelemetry(now)
  now = tonumber(now) or 0
  local phase = (now % 3600) / 3600
  local wave = (math.sin(phase * math.pi * 2) + 1) * 0.5
  local motorRunning = phase >= 0.08 and phase < 0.92
  local rpm = motorRunning and round(650 + wave * 1750) or 0
  local current = motorRunning and round(15 + wave * 235) or 0
  local temp = round(32 + phase * 68)
  local rawPercent = 96 - phase * 74
  local adjustedPercent = calculateAdjustedPercent(rawPercent, OPT.reservePct)
  local cells = OPT.heliType == HELI_OMPHOBBY and 3 or 12
  local cell = 4.18 - phase * 0.56
  local pack = cell * cells
  local bec = 7.65 + wave * 0.42
  local govMode
  if phase < 0.08 then
    govMode = 0
  elseif phase < 0.20 then
    govMode = 2
  elseif phase < 0.80 then
    govMode = 4
  elseif phase < 0.92 then
    govMode = 3
  else
    govMode = 7
  end

  A.linkAvailable = true
  A.linkSourceKnown = true
  A.linkSourceSeen = true
  A.displayPercent = adjustedPercent
  A.displayPercentInit = true

  D.isLiHV = false
  D.hasBattData = OPT.heliType ~= HELI_NITRO
  D.adjustedPercent = adjustedPercent
  D.capacity = round(180 + phase * 4100)
  D.voltage = pack
  D.cellsResolved = cells
  D.packVoltageValid = OPT.heliType ~= HELI_NITRO
  D.cellCountValid = OPT.heliType ~= HELI_NITRO
  D.cellVoltageValid = OPT.heliType ~= HELI_NITRO
  D.batteryPercentValid = OPT.heliType ~= HELI_NITRO
  D.capacityValid = OPT.heliType ~= HELI_NITRO
  D.currentValid = OPT.heliType ~= HELI_NITRO
  D.tempValid = OPT.heliType ~= HELI_NITRO
  D.becValid = OPT.heliType ~= HELI_OMPHOBBY
  D.rpmValid = true
  D.tailRpmValid = OPT.heliType ~= HELI_OMPHOBBY
  D.govValid = OPT.heliType ~= HELI_OMPHOBBY
  D.govCurrentInvalid = false
  D.minCellVoltage = cell - 0.05

  if OPT.heliType == HELI_NITRO then
    local rx = 8.25 - phase * 1.35
    local rxPercent = clamp((rx - OPT.rxPackMin)
                            / math.max(0.1, OPT.rxPackMax - OPT.rxPackMin)
                            * 100, 0, 100)
    D.rxVoltage = rx
    D.rxCellVoltage = rx / 2
    D.rxPercent = rxPercent
    D.minRxVoltage = rx - 0.12
    F.bec = rx
    F.cellVoltage = rx / 2
    F.packVolt = rx
  else
    D.rxVoltage = nil
    D.rxCellVoltage = nil
    D.rxPercent = 0
    D.minRxVoltage = nil
    F.bec = bec
    F.cellVoltage = cell
    F.packVolt = pack
  end

  F.rqly = round(88 + wave * 11)
  F.txVolt = 7.55 + wave * 0.65
  F.timerSecs = 182 + math.floor(phase * 815)
  F.cellCount = cells
  F.batPct = rawPercent
  F.capa = D.capacity
  F.curr = current
  F.temp = temp
  F.rpm = rpm
  F.trpm = round(rpm * 4.55)
  F.battProfile = G.companion.batteryProfile or 3
  if OPT.heliType == HELI_OMPHOBBY then
    F.govNumber = false
    F.gov = "--"
  else
    F.govNumber = govMode
    F.gov = GOV_STATES[govMode]
  end

  S.rpmMax = 2400
  S.currMax = 250
  S.tempMax = 100
  S.becMin = OPT.heliType ~= HELI_OMPHOBBY and 7.55 or nil
  S.cellMin = OPT.heliType == HELI_NITRO and nil or 3.57
end

local function serviceSimulation(widget)
  local now = frameNow()
  local last = widget.lastSimTick
  if last and last >= 0 and now >= last
     and (now - last) < SIM_INTERVAL_TICKS then
    return false
  end
  widget.lastSimTick = now
  applySimulatedTelemetry(G.debrief.advanceSimulation(now))
  G.debrief.captureSimulation()
  G.debrief.simulate(now)
  return true
end

local function fileExists(path)
  local f = io.open(path, "r")
  if not f then return false end
  pcall(io.close, f)
  return true
end

-- IMGR uses shared slots 11/12 for capability and refresh generation. It
-- invalidates changed files in the native image cache before publishing. Each
-- widget observes the generation independently; background only retires its
-- scene, and the next foreground pass rebuilds it without resetting flight data.
function G.pollImageRefresh(widget)
  if not lvgl or type(lvgl.invalidateImageCache) ~= "function"
     or type(getShmVar) ~= "function" or type(setShmVar) ~= "function" then return end
  local ok, tag, generation = pcall(function()
    return getShmVar(11), getShmVar(12)
  end)
  if not ok or type(generation) ~= "number" then return end
  if tag ~= 0x494D47 then pcall(setShmVar, 11, 0x494D47) end
  if widget.imageRefreshGeneration == generation then return end
  widget.imageRefreshGeneration = generation
  modelImageCache.key, modelImageCache.path = nil, nil
  widget.uiBuilt = false
end

local function resolveModelImagePath(name)
  -- Dashboard follows the current radio name, including its restored template
  -- after disconnect. Debriefs pass the flown aircraft name explicitly; their
  -- retained identity must not pin that image on the disconnected dashboard.
  -- Include the model file so equal names on different models cannot share a miss.
  name = name or getModelName()
  local info = getModelInfo()
  local key = tostring(info and (info.filename or info.id) or "") .. ":" .. name
  local now = frameNow()
  local connected = A.linkAvailable == true
  local same = modelImageCache.key == key and modelImageCache.aircraftType == OPT.heliType
  local reconnected = connected and modelImageCache.connected == false
  modelImageCache.connected = connected
  if same and (modelImageCache.found or (not reconnected
      and now >= modelImageCache.checkedAt and now < modelImageCache.retryAt)) then
    return modelImageCache.path
  end
  if not same or reconnected then modelImageCache.delay = 100 end
  -- A missing/transiently unavailable image gets a cheap, bounded backoff:
  -- 1, 2, 4, 8, then 15 seconds. Healthy images never reopen on ordinary frames.
  local used = getCurrentUsage and getCurrentUsage()
  if same and used and used >= 50 then return modelImageCache.path end
  local sanitized = sanitizeFsName(name)
  if not sanitized or sanitized == "" then sanitized = "MODEL" end

  -- Match StacyDashV4's proven radio path resolution: direct io.open() probes
  -- in a fixed order, with no directory enumeration or bitmap-field guessing.
  local candidates = {
    "/IMAGES/" .. sanitized .. ".png",
    "/IMAGES/" .. sanitized .. ".bmp",
    OPT.heliType == AIRCRAFT_FIXED_WING and "/WIDGETS/KSETouch/fixedwing.png"
      or "/WIDGETS/KSETouch/default.png",
  }
  if OPT.heliType ~= AIRCRAFT_FIXED_WING then
  candidates[#candidates + 1] = "/IMAGES/default.png"
  candidates[#candidates + 1] = "/IMAGES/defaultmodel.png"
  candidates[#candidates + 1] = "/WIDGETS/KSETouch/Rotorflight.png"
  end
  modelImageCache.path = nil
  modelImageCache.found = false
  for index, path in ipairs(candidates) do
    if fileExists(path) then
      modelImageCache.path, modelImageCache.found = path, index <= 2
      break
    end
  end
  modelImageCache.key, modelImageCache.checkedAt = key, now
  modelImageCache.aircraftType = OPT.heliType
  modelImageCache.retryAt = now + modelImageCache.delay
  modelImageCache.delay = math.min(modelImageCache.delay * 2, 1500)
  return modelImageCache.path
end

local function buildLayout(zone, fullScreen)
  local x, y, w, h = G.bounds(zone, fullScreen)
  G.configure(x, y, w, h)
  local layout = {
    x=x, y=y, w=w, h=h,
    pad=math.max(3, G.min(5)), gap=math.max(2, G.min(4)),
    signature=G.signature(x, y, w, h),
  }

  -- The large interactive surface is a touch home page. Normal widget zones
  -- and smaller radios retain the existing ring dashboard.
  if fullScreen and G.largeScreen then
    local sx, sy = w / 800, h / 480
    local function xx(v) return x + G.rounded(v * sx) end
    local function yy(v) return y + G.rounded(v * sy) end
    layout.touchHome = true
    layout.top = {x=x, y=y, w=w, h=G.rounded(54 * sy)}
    layout.modelX, layout.modelY = xx(8), yy(62)
    layout.modelW, layout.modelH = G.rounded(388 * sx), G.rounded(226 * sy)
    layout.modelFooterH = G.rounded(36 * sy)
    layout.modelImageX, layout.modelImageY = xx(14), yy(68)
    layout.modelImageW, layout.modelImageH = G.rounded(376 * sx), G.rounded(178 * sy)
    layout.rings, layout.tiles = {}, {}
    for i=1,4 do
      local col, row = (i-1)%2, math.floor((i-1)/2)
      layout.rings[i] = {x=xx(404 + col*198), y=yy(62 + row*117),
                        w=G.rounded(190*sx), h=G.rounded(109*sy)}
      layout.tiles[i] = {x=xx(8 + (i-1)*198), y=yy(296),
                        w=G.rounded(190*sx), h=G.rounded(96*sy)}
    end
    -- Keep metric identities intact while moving their cards. The top-right
    -- cluster is Gov/RPM, BEC/ESC; the bottom is Current/Cell/mAh/Battery.
    local cluster, bottom = layout.rings, layout.tiles
    layout.slots = {cluster[1], cluster[2], cluster[3], cluster[4], bottom[1], bottom[2], bottom[3], bottom[4]}
    layout.rings = {bottom[4], cluster[2], bottom[1], cluster[4]}
    layout.tiles = {cluster[1], cluster[3], bottom[2], bottom[3]}
    if OPT.heliType == AIRCRAFT_FIXED_WING then
      -- Airplanes use Current/Cell in the first pair and leave both slots
      -- beneath the image open. Keep metric identities and editable slots.
      layout.rings = {[1]=bottom[4], [3]=cluster[1], [4]=cluster[4]}
      layout.tiles = {[2]=cluster[3], [3]=cluster[2], [4]=bottom[3]}
    end
    layout.dock = {x=xx(8), y=yy(400), w=G.rounded(784*sx), h=G.rounded(72*sy)}
    return layout
  end

  layout.top = { x=x, y=y, w=w, h=math.max(28, G.y(34)) }
  layout.ringY = y + layout.top.h + layout.gap
  -- The short 480x272 target needs a fixed minimum for two discrete-font tile
  -- rows; taller screens scale the original 480x320 proportions normally.
  local compactBottomMin = G.compact and math.min(126, h - 118) or 0
  layout.bottomH = math.max(compactBottomMin, G.y(136),
                            math.floor(h * 0.425))
  layout.bottomY = y + h - layout.pad - layout.bottomH
  layout.ringH = math.max(88, layout.bottomY - layout.ringY - layout.gap)

  local right = x + w - layout.pad
  local contentW = w - layout.pad * 2
  local ringW = math.floor((contentW - layout.gap * 3) / 4)
  layout.rings = {}
  for i = 1, 4 do
    local cardX = x + layout.pad + (i - 1) * (ringW + layout.gap)
    layout.rings[i] = {
      x=cardX, y=layout.ringY,
      w=(i == 4) and (right - cardX) or ringW,
      h=layout.ringH,
    }
  end
  local firstRingW = layout.rings[1].w
  layout.ringRadius = math.max(math.max(24, G.min(28)),
      math.min(math.max(28, G.min(44)),
               math.floor(firstRingW / 2) - math.max(5, G.x(8)),
               math.floor((layout.ringH - math.max(26, G.y(30))) / 2)))
  layout.ringThickness = math.max(math.max(5, G.min(6)),
                                  math.floor(layout.ringRadius * 0.20))
  -- Match StacyDashV3's vertically balanced ring placement: the gauge sits
  -- midway between its title baseline and footer instead of being top-biased.
  layout.ringCenterY = layout.ringY + math.floor((layout.ringH + 2) / 2)

  layout.modelX = x + layout.pad
  layout.modelY = layout.bottomY
  -- With Tail RPM and Pack Voltage hidden, split the lower dashboard evenly:
  -- a double-width model panel and a compact 2x2 telemetry grid.
  layout.modelW = math.floor((contentW - layout.gap) / 2)
  layout.modelH = layout.bottomH
  layout.modelFooterH = math.max(22, G.y(24))
  local imageInset = math.max(3, G.min(4))
  layout.modelImageX = layout.modelX + imageInset
  layout.modelImageY = layout.modelY + imageInset
  layout.modelImageW = layout.modelW - imageInset * 2
  layout.modelImageH = layout.modelH - layout.modelFooterH - imageInset * 2

  local statsX = layout.modelX + layout.modelW + layout.gap
  local tileW = math.floor((right - statsX - layout.gap) / 2)
  local tileH = math.floor((layout.bottomH - layout.gap) / 2)
  layout.tiles = {}
  for i = 1, 4 do
    local col = (i - 1) % 2
    local row = math.floor((i - 1) / 2)
    local tileX = statsX + col * (tileW + layout.gap)
    layout.tiles[i] = {
      x=tileX,
      y=layout.bottomY + row * (tileH + layout.gap),
      w=(col == 1) and (right - tileX) or tileW,
      h=(row == 1) and (y + h - layout.pad
                         - (layout.bottomY + tileH + layout.gap)) or tileH,
    }
  end
  return layout
end

-- Retained LVGL UI -----------------------------------------------------------
local function rememberObject(wgt, object, properties)
  if not object then return nil end
  -- Each caller supplies a new, private properties table. Keep it as the last
  -- submitted state instead of allocating and copying it for every LVGL object.
  -- LVGL consumes these properties on creation; later changes still go through
  -- setObject so native setters run only when a value actually changes.
  local state = properties or {}
  if state.visible == nil then state.visible = true end
  wgt.objectState[object] = state
  return object
end

local function setObject(wgt, object, properties)
  if not object then return end
  local state = wgt.objectState[object]
  if not state then
    state = { visible=true }
    wgt.objectState[object] = state
  end
  local changed = false
  for key, value in pairs(properties) do
    if state[key] ~= value then
      state[key] = value
      changed = true
    end
  end
  if changed then object:set(properties) end
end

local function setVisible(wgt, object, visible)
  if not object then return end
  local state = wgt.objectState[object]
  if not state then
    state = { visible=true }
    wgt.objectState[object] = state
  end
  visible = not not visible
  if state.visible == visible then return end
  state.visible = visible
  if visible then object:show() else object:hide() end
end

local function newLabel(wgt, x, y, w, text, font, color, align)
  local properties = {
    x=x, y=y, w=w or 0, h=0, text=text or "",
    font=font or 0, color=color or C_TEXT, align=align or 0,
  }
  return rememberObject(wgt, lvgl.label(properties), properties)
end

local function setLabel(wgt, object, text, color, align)
  local properties = { text=tostring(text or "") }
  if color ~= nil then properties.color = color end
  if align ~= nil then properties.align = align end
  setObject(wgt, object, properties)
end

local function newRect(wgt, x, y, w, h, color, filled, rounded, thickness, opacity)
  local properties = {
    x=x, y=y, w=w, h=h, color=color,
    filled=not not filled, rounded=rounded or 0, thickness=thickness or 1,
    opacity=opacity,
  }
  return rememberObject(wgt, lvgl.rectangle(properties), properties)
end

local function newPanel(wgt, x, y, w, h, fill, border, rounded)
  return {
    fill=newRect(wgt, x, y, w, h, fill, true, rounded or 4, 1,
                 OPT.bgTransparent and TRANSPARENT_PANEL_OPACITY or nil),
    border=newRect(wgt, x, y, w, h, border, false, rounded or 4, 1),
  }
end

local function compactModelName(wgt, maxChars)
  local raw = getModelName()
  wgt.fitNames = wgt.fitNames or {}
  local cached = wgt.fitNames[maxChars]
  if cached and cached.raw == raw then return cached.text end
  local text = raw
  if #text > maxChars then text = string.sub(text, 1, maxChars - 2) .. ".." end
  wgt.fitNames[maxChars] = { raw=raw, text=text }
  return text
end

local function buildTopBar(wgt)
  local l, ui = wgt.layout, wgt.ui
  local t = l.top
  newRect(wgt, t.x, t.y, t.w, t.h, C_TOP, true, 0, 1,
          OPT.bgTransparent and TRANSPARENT_HEADER_OPACITY or nil)
  local lineInset = math.max(4, G.x(5))
  lvgl.hline({ x=t.x + lineInset, y=t.y + t.h - 1,
               w=t.w - lineInset * 2,
               h=1, color=C_BORDER })

  local txBodyW, txBodyH = math.max(11, G.x(13)), math.max(19, G.y(21))
  local txBodyX = t.x + t.w - l.pad - txBodyW
  local txBodyY = t.y + math.max(7, G.y(9))
  local centerY = G.rounded(t.y + t.h / 2)
  -- KSE4's signal geometry is based on an 800x480 reference. Convert those
  -- exact proportions into KSE Touch's 480x320 reference so both glyphs render at
  -- the same physical size and battery-relative position on every target.
  local sigX = txBodyX - G.x(8.4) - G.x(21.6)
  local timerW = math.max(90, G.x(100))
  local timerX = t.x + math.floor((t.w - timerW) / 2)
  local modelNameX = t.x + math.max(5, G.x(6))
  if wgt.layout.touchHome and wgt.appMode and not wgt.fullScreen then
    -- The native EdgeTX menu tab remains at the upper left until focus enters
    -- the widget. Keep the model name clear of that tab at boot.
    modelNameX = t.x + 72
  end
  local modelNameW = math.max(90, timerX - modelNameX - math.max(5, G.x(6)))
  wgt.nativeHomeNavigation = wgt.layout.touchHome and lvgl
    and type(lvgl.isAppHost)=="function" and lvgl.isAppHost()
  if wgt.nativeHomeNavigation then
    ui.modelSelectorBounds = {x=t.x,y=t.y,w=timerX-t.x-4,h=t.h-2}
  end

  -- On EdgeTX color displays BOLD is a font size of its own, not a style bit.
  -- Combining it with SMLSIZE/MIDSIZE selects an unintended oversized font on
  -- the radio even when a desktop mock happens to look acceptable.
  ui.modelName = newLabel(wgt, modelNameX, t.y + math.max(1, G.y(2)),
                          modelNameW, "", G.fontTop, C_TEXT)
  ui.timer = newLabel(wgt, timerX, t.y + math.max(1, G.y(2)),
                      timerW, "", G.fontTimer, C_TEXT, CENTERED)

  local profileSignalGap = math.max(8, G.x(10))
  local profileMinW = #"Profile 6 / Rate 6" * 9
  local profileX = math.min(timerX + timerW - math.max(20, G.x(28)),
                            sigX - profileSignalGap - profileMinW)
  local profileY = math.floor(centerY - 11)
  if G.screenW == 480 and G.screenH == 320
     and G.w == 480 and G.h == 320 then profileY = profileY + 2 end
  ui.profileStatus = newLabel(
    wgt, profileX, profileY,
    math.max(1, sigX - profileSignalGap - profileX), "",
    SMLSIZE, C_TEXT, RIGHT)

  -- Match KSE4's ascending four-bar link-quality glyph immediately to the
  -- left of the vertical transmitter-battery indicator.
  ui.signal = {}
  for i, referenceH in ipairs(G.signalHeights) do
    local barH = math.max(1, G.y(referenceH * 2 / 3))
    ui.signal[i] = newRect(wgt,
      sigX + (i - 1) * G.x(6),
      centerY + G.y(20 / 3) - barH,
      math.max(1, G.x(3.6)), barH, C_BORDER, true, 0, 0)
  end

  ui.txBody = newPanel(wgt, txBodyX, txBodyY, txBodyW, txBodyH,
                       C_PANEL_ALT, C_DIM, math.max(1, G.min(2)))
  local terminalW = math.max(4, G.x(5))
  newRect(wgt, txBodyX + math.floor((txBodyW - terminalW) / 2),
          txBodyY - math.max(2, G.y(3)), terminalW,
          math.max(2, G.y(2)), C_DIM, true, 1, 1)
  local txInset = math.max(2, G.min(2))
  ui.txFill = newRect(wgt, txBodyX + txInset,
                      txBodyY + txBodyH - txInset,
                      txBodyW - txInset * 2, 1, C_GREEN, true, 1, 1)
  ui.txBodyX, ui.txBodyY = txBodyX, txBodyY
  ui.txBodyW, ui.txBodyH = txBodyW, txBodyH
  ui.txInset = txInset
end

local RING_LABELS = { "BATTERY", "HEAD RPM", "CURRENT", "ESC TEMP" }
local RING_UNITS = { "%", "RPM", "AMPS", "\xC2\xB0C" }
local RING_STANDARD = {
  bottom=90, span=359, -- EdgeTX: 0 is 3 o'clock; 90 is 6 o'clock.
  rpmMin=500, rpmMax=2400,
  currentMin=0, currentMax=250,
  tempMin=32, tempMax=100,
}
local function buildRingCards(wgt)
  local l, ui = wgt.layout, wgt.ui
  ui.rings = {}
  if l.touchHome then
    for i=1,4 do
      local c = l.rings[i]
      ui.rings[i] = {}
      if c then
      newPanel(wgt, c.x, c.y, c.w, c.h, i==3 and C_PANEL_ALT or C_PANEL, C_BORDER, 6)
      local trackW = c.w - 20
      local battery = i == 1
      local trackH = battery and 24 or 3
      local trackY = c.y+c.h-(battery and 27 or 6)
      local label
      if not battery then
        label=newLabel(wgt,c.x+10,c.y+(i==3 and 1 or 3),c.w-20,RING_LABELS[i],G.fontSmall,C_DIM)
      end
      newRect(wgt, c.x+10, trackY, trackW, trackH, C_TRACK, true, 1, 1)
      local valueW = c.w-77
      if i~=3 then
        valueW = c.w-28-lcd.sizeText(RING_UNITS[i],G.fontSmall)
      end
      local valueY = battery and 25 or c.h-82
      local unitY = battery and 39 or c.h-66
      -- Give Current's shorter card clear space below its heading while
      -- retaining the MAX-to-bar gap used by RPM and ESC.
      if not battery and c.h < 109 then valueY, unitY = valueY+8, unitY+8 end
      ui.rings[i] = {
        accent=newRect(wgt,c.x+10,trackY,1,trackH,C_DIM,true,1,1),
        arcState={}, progressW=trackW,
        label=label,
        value=newLabel(wgt,c.x+10,c.y+valueY,valueW,"--",G.fontRingValue,C_TEXT,RIGHT),
        unit=newLabel(wgt,c.x+c.w-68,c.y+unitY,58,RING_UNITS[i],G.fontSmall,C_DIM,RIGHT),
        footer=newLabel(wgt,c.x+10,c.y+(battery and 1 or c.h-33),c.w-20,"",G.fontSmall,C_DIM,battery and 0 or RIGHT),
      }
      end
    end
    return
  end
  for i = 1, 4 do
    local card = l.rings[i]
    local panel = newPanel(wgt, card.x, card.y, card.w, card.h,
                           C_PANEL, C_BORDER, math.max(2, G.min(4)))
    local inset = math.max(2, G.x(2))
    local accent = newRect(wgt, card.x + inset, card.y + 1,
                           card.w - inset * 2, 1, C_DIM, true, 1, 1)
    -- Arcs are children of the card fill, so EdgeTX clips overdraw at the card
    -- boundary. Keep their geometry immutable: the radio can displace an arc
    -- when object:set() changes its angles. Dynamic property functions update
    -- only the rendered sweep/color while x, y, and radius remain untouched.
    local cx = math.floor(card.w / 2)
    local cy = l.ringCenterY - card.y
    local arcState = { endAngle=RING_STANDARD.bottom, color=C_DIM, opacity=0 }
    local primaryProperties = {
      x=cx, y=cy, radius=l.ringRadius,
      thickness=l.ringThickness,
      startAngle=RING_STANDARD.bottom,
      endAngle=function() return arcState.endAngle end,
      rounded=true,
      color=function() return arcState.color end,
      opacity=function() return arcState.opacity end,
      bgColor=C_TRACK, bgOpacity=255,
      bgStartAngle=0, bgEndAngle=360,
    }
    local primary = rememberObject(wgt, lvgl.arc(panel.fill, primaryProperties),
                                   primaryProperties)
    local ringLabel = i == 1 and OPT.simTelemetry
                      and "SIM \xC2\xB7 BATTERY" or RING_LABELS[i]
    local label = newLabel(wgt, card.x + inset,
                           card.y + math.max(1, G.y(2)),
                           card.w - inset * 2, ringLabel,
                           G.fontSmall, C_DIM, CENTERED)
    local valueOffset = G.largeScreen and math.max(17, G.y(13)) or 13
    local unitOffset = G.largeScreen and math.max(14, G.y(10)) or 12
    -- Keep value and unit locked together; lift both another 2 px so the
    -- complete text group sits optically centered inside the ring.
    local ringTextLift = G.largeScreen and 6 or 2
    local value = newLabel(wgt, card.x + inset,
                           l.ringCenterY - valueOffset - ringTextLift,
                           card.w - inset * 2, "--", G.fontRingValue,
                           C_TEXT, CENTERED)
    local unit = newLabel(wgt, card.x + inset,
                          l.ringCenterY + unitOffset - ringTextLift,
                          card.w - inset * 2, RING_UNITS[i],
                          G.fontSmall, C_DIM, CENTERED)
    local footer = newLabel(wgt, card.x + inset,
                            card.y + card.h - math.max(16, G.y(16)),
                            card.w - inset * 2, "", G.fontSmall,
                            C_DIM, CENTERED)
    ui.rings[i] = {
      accent=accent, primary=primary, arcState=arcState,
      label=label, value=value, unit=unit, footer=footer,
    }
  end
end

local TILE_LABELS = {
  "GOV MODE", "BEC OUTPUT", "CELL VOLT", "USED CAPACITY",
}

-- Display-only arm evidence. Never use the motor switch or RF Tool's cached
-- state as proof of disarm. ARM can repeat at ~3s intervals on custom CRSF;
-- use native receive age (also after a paused callback) for at most 4s,
-- and MSP status for 2s. Older firmware falls back to observed fresh samples.
G.armStatus = {}
function G.armStatus.sample(wgt)
  -- MSP replies are timestamped after the shared queue runs. A callback can
  -- cross a clock tick, so the cached frame-start time can predate a new reply
  -- and reject it for one frame. Compare receive times against the live clock.
  local now = (getTime and getTime()) or 0
  local identity = F.modelIdentity
  if wgt.armIdentity ~= identity then
    wgt.armIdentity = identity
    wgt.armSensorAt, wgt.armSensorState = nil, nil
    wgt.armingFlightModeFlags, wgt.armingStatusUpdatedAt = nil, nil
  end
  wgt.armDisplayState = nil
  if OPT.simTelemetry or OPT.heliType == HELI_OMPHOBBY then
    wgt.armSensorAt, wgt.armSensorState = nil, nil
    return
  end
  local ok, rssi = pcall(getRSSI)
  if not ok or type(rssi) ~= "number" or not (rssi > 0) then
    wgt.armSensorAt, wgt.armSensorState = nil, nil
    wgt.armingFlightModeFlags, wgt.armingStatusUpdatedAt = nil, nil
    return
  end
  local value, current, fresh, sampleAge, sourceId
  if type(getSourceValue) == "function" and type(getFieldInfoFn) == "function" then
    local found, info = pcall(getFieldInfoFn, "ARM")
    if found and type(info) == "table" and info.id ~= nil then
      local readOk
      sourceId = info.id
      readOk, value, current, fresh, sampleAge = pcall(getSourceValue, sourceId)
      if not readOk then value = nil end
    end
  end
  if wgt.armSourceId ~= sourceId then
    wgt.armSourceId = sourceId
    wgt.armSensorAt, wgt.armSensorState = nil, nil
  end
  local valid = current == true and type(value) == "number"
                and value == math.floor(value) and value >= 0 and value <= 255
  local sensorState
  if valid then
    local armed = value % 2 == 1
    if sampleAge ~= nil then
      -- Native age is a conservative receive-time bound. Never restart its
      -- clock on each redraw, or a frozen zero could look disarmed forever.
      if type(sampleAge) == "number" and sampleAge >= 0 and sampleAge < 400 then
        wgt.armSensorAt, wgt.armSensorState = now - sampleAge, armed
      else
        wgt.armSensorAt, wgt.armSensorState = nil, nil
      end
    elseif fresh == true then
      wgt.armSensorAt, wgt.armSensorState = now, armed
    end
    local age = wgt.armSensorAt and now - wgt.armSensorAt
    if age and age >= 0 and age < 400 and wgt.armSensorState == armed then
      sensorState = armed
    end
  else
    wgt.armSensorAt, wgt.armSensorState = nil, nil
  end
  local flags = wgt.armingFlightModeFlags
  local age = wgt.armingStatusUpdatedAt and now - wgt.armingStatusUpdatedAt
  local statusState
  if flags ~= nil and age and age >= 0 and age < 200 then
    statusState = flags % 2 == 1
  end
  -- In a brief disagreement keep the armed indication until that evidence
  -- expires or is replaced. Missing data is always unknown, never disarmed.
  if sensorState == true or statusState == true then wgt.armDisplayState = true
  elseif sensorState == false or statusState == false then wgt.armDisplayState = false end
end

function G.armStatus.text(wgt)
  if OPT.heliType == HELI_OMPHOBBY then return nil end
  if OPT.simTelemetry then return "Simulated" end
  local ok, rssi = pcall(getRSSI)
  if not ok or type(rssi) ~= "number" or not (rssi > 0) then return nil end
  if wgt.armDisplayState == true then return "Armed"
  elseif wgt.armDisplayState == false then return "Disarmed" end
  return "Arm unknown"
end

local function buildLowerDashboard(wgt)
  local l, ui = wgt.layout, wgt.ui
  newPanel(wgt, l.modelX, l.modelY, l.modelW, l.modelH,
           C_PANEL, C_BORDER, math.max(2, G.min(4)))
  if not OPT.bgTransparent then
    newRect(wgt, l.modelImageX, l.modelImageY, l.modelImageW,
            l.modelImageH,
            resolveModelImagePath()=="/WIDGETS/KSETouch/default.png"
              and lcd.RGB(22,27,34) or C_IMAGE_BG,
            true, math.max(2, G.min(3)), 1)
  end
  local imageProperties = {
    x=l.modelImageX, y=l.modelImageY, w=l.modelImageW, h=l.modelImageH,
    file=function() return resolveModelImagePath() or "" end,
    visible=function() return resolveModelImagePath() ~= nil end,
    fill=false,
  }
  ui.modelImage = rememberObject(wgt, lvgl.image(imageProperties), imageProperties)
  ui.noImage = newLabel(wgt, l.modelImageX, l.modelImageY
                        + math.floor(l.modelImageH / 2) - 8,
                        l.modelImageW, "NO IMAGE", G.fontSmall,
                        C_DIM, CENTERED)
  local imagePath = resolveModelImagePath()
  setVisible(wgt, ui.modelImage, imagePath ~= nil)
  setVisible(wgt, ui.noImage, imagePath == nil)
  local footerY = l.modelY + l.modelH - l.modelFooterH
  local footerInset = math.max(4, G.x(5))
  lvgl.hline({ x=l.modelX + footerInset, y=footerY,
               w=l.modelW - footerInset * 2,
               h=1, color=C_BORDER })
  ui.flightCount = newLabel(wgt, l.modelX + math.max(3, G.x(3)),
                            footerY + math.max(2, G.y(3)),
                            l.modelW - math.max(6, G.x(6)), "", G.fontSmall,
                            C_TEXT, 0)
  ui.armStatus = newLabel(wgt, l.modelX, footerY + math.max(2, G.y(3)),
                         1, "", G.fontSmall, C_DIM, 0)
  setVisible(wgt, ui.armStatus, false)

  ui.tiles = {}
  for i = 1, 4 do
    local tile = l.tiles[i]
    ui.tiles[i] = {}
    if tile then
    newPanel(wgt, tile.x, tile.y, tile.w, tile.h,
             C_PANEL_ALT, C_BORDER, math.max(2, G.min(4)))
    local accent
    if not l.touchHome then
      accent = newRect(wgt, tile.x + 1, tile.y + math.max(2, G.y(2)),
                       math.max(3, G.x(3)), tile.h - math.max(4, G.y(4)),
                       C_DIM, true, 1, 1)
    end
    local textX = tile.x + math.max(8, G.x(9))
    local textW = tile.w - math.max(15, G.x(16))
    local label = newLabel(wgt, textX, tile.y + math.max(2, G.y(4)),
                           textW, TILE_LABELS[i], G.fontSmall, C_DIM)
    local valueFont = i == 1 and G.fontGovernorValue or G.fontTileValue
    local valueY = tile.y + math.max(19, G.y(21))
    if l.touchHome then valueY = tile.y + 27 end
    local valueX, valueW = textX, textW
    local valueAlign = RIGHT
    local persistentValueAlign
    if i == 1 and G.compact then
      -- BOLD is a 20 px line on compact EdgeTX color targets. Center the
      -- governor value horizontally, then lower it 4 px from geometric center
      -- for optical balance inside the tile.
      valueX = tile.x + 4
      valueW = tile.w - 8
      valueY = tile.y + math.floor((tile.h - 20) / 2) + 4
      valueAlign = CENTERED
      persistentValueAlign = CENTERED
    end
    local value = newLabel(wgt, valueX, valueY,
                           valueW, "--", valueFont, C_TEXT, valueAlign)
    local footer = newLabel(wgt, textX,
                            tile.y + tile.h - math.max(16, G.y(17)),
                            textW, "", G.fontSmall, C_DIM, RIGHT)
    ui.tiles[i] = {
      accent=accent, label=label, value=value, footer=footer,
      valueAlign=persistentValueAlign,
    }
    if l.touchHome then
      setObject(wgt, label, {y=tile.y+2})
      setObject(wgt, footer, {y=tile.y+tile.h-24})
    end
    end
  end
  if G.personal then G.personal.buildExtras(wgt) end
end

local function buildProfileEntryPrompt(wgt)
  local l, ui = wgt.layout, wgt.ui
  local promptW = math.min(G.largeScreen and 360 or 250,
                           l.w - math.max(24, G.x(24)))
  local promptH = G.largeScreen and 64 or 56
  local titleOffset = G.largeScreen and 7 or 5
  local detailOffset = G.largeScreen and 39 or 34
  local x = l.x + math.floor((l.w - promptW) / 2)
  local y = l.y + math.floor((l.h - promptH) / 2)
  local compactW = promptW
  local compactH = promptH
  local compactX = l.x + math.floor((l.w - compactW) / 2)
  local compactY = l.y + math.floor((l.h - compactH) / 2)
  local prompt = {
    fill=newRect(wgt, x, y, promptW, promptH, C_PANEL_ALT, true,
                 math.max(3, G.min(6)), 1),
    border=newRect(wgt, x, y, promptW, promptH, C_BORDER, false,
                   math.max(3, G.min(6)), 2),
    accent=newRect(wgt, x + 2, y + 2, math.max(4, G.x(5)), promptH - 4,
                   C_GREEN, true, math.max(1, G.min(2)), 1),
    title=newLabel(wgt, x + 10, y + titleOffset,
                   promptW - 20, "", G.fontSmall, C_TEXT, CENTERED),
    detail=newLabel(wgt, x + 10, y + detailOffset,
                    promptW - 20, "", G.fontSmall, C_DIM, CENTERED),
    full={ x=x, y=y, w=promptW, h=promptH,
           titleX=x + 10, titleY=y + titleOffset, titleW=promptW - 20,
           detailX=x + 10, detailY=y + detailOffset, detailW=promptW - 20 },
    compact={ x=compactX, y=compactY, w=compactW, h=compactH,
              titleX=compactX + 10, titleY=compactY + titleOffset,
              titleW=compactW - 20,
              detailX=compactX + 10, detailY=compactY + detailOffset,
              detailW=compactW - 20 },
  }
  prompt.objects = {
    prompt.fill, prompt.border, prompt.accent, prompt.title, prompt.detail,
  }
  ui.profilePrompt = prompt
  for _, object in ipairs(prompt.objects) do setVisible(wgt, object, false) end
end


local function batteryColor(percent)
  local p = tonumber(percent) or 0
  if p >= 50 then return C_GREEN end
  if p >= 20 then return C_YELLOW end
  return C_RED
end

local function txBatteryColor(percent)
  local p = math.floor((tonumber(percent) or 0) + 0.5)
  if p >= 51 then return C_GREEN end
  if p >= 31 then return C_YELLOW end
  return C_RED
end

local function becValueColor(volts)
  local v = tonumber(volts)
  if not v then return C_DIM end
  if v < 4.8 then return C_RED end
  if v < 5.1 then return C_YELLOW end
  return C_TEXT
end

local function formatTimer(seconds)
  local value = math.abs(tonumber(seconds) or 0)
  local minutes = math.floor(value / 60)
  local secs = math.floor(value - minutes * 60)
  return string.format("%d:%02d", minutes, secs)
end

local function updateTopBar(wgt)
  local ui = wgt.ui
  local maxModelChars = G.largeScreen and 28 or 16
  if OPT.simTelemetry then maxModelChars = G.largeScreen and 22 or 10 end
  local modelName = compactModelName(wgt, maxModelChars)
  if OPT.simTelemetry then modelName = "SIM \xC2\xB7 " .. modelName end
  if wgt.layout.touchHome then
    local width = wgt.objectState[ui.modelName].w
    while #modelName > 3 and lcd.sizeText(modelName, G.fontTop) > width do
      modelName = string.sub(modelName, 1, #modelName-3) .. ".."
    end
  end
  setLabel(wgt, ui.modelName, modelName, C_TEXT)
  setLabel(wgt, ui.timer, formatTimer(getTimer1Secs()), C_TEXT)

  local rq = getRqly()
  local bars = rq >= 80 and 4 or rq >= 60 and 3
               or rq >= 40 and 2 or rq >= 20 and 1 or 0
  local signalColor = bars >= 3 and C_GREEN
                      or bars == 2 and C_YELLOW or C_RED
  for i, bar in ipairs(ui.signal or {}) do
    setObject(wgt, bar, { color=i <= bars and signalColor or C_BORDER })
  end

  local pidProfile = getSensorNumber("pidProfile")
  local rateProfile = getSensorNumber("rateProfile")
  pidProfile = tonumber(pidProfile)
  rateProfile = tonumber(rateProfile)
  if not pidProfile or pidProfile ~= math.floor(pidProfile)
     or pidProfile < 1 or pidProfile > 6 then
    pidProfile = nil
  end
  if not rateProfile or rateProfile ~= math.floor(rateProfile)
     or rateProfile < 1 or rateProfile > 6 then
    rateProfile = nil
  end
  if OPT.simTelemetry then
    pidProfile, rateProfile = 1, 1
  end
  local profilesReady = OPT.simTelemetry
                        or (A.linkAvailable
                            and pidProfile and rateProfile)
  setLabel(wgt, ui.profileStatus,
    profilesReady and string.format("Profile %d / Rate %d",
      pidProfile, rateProfile) or "", C_TEXT)

  local txPct = txPctFromVolts(getTxVolt(), txIsLiIon)
  if txPct then
    local innerH = ui.txBodyH - ui.txInset * 2
    local fillH = math.max(1, math.floor(innerH * clamp(txPct, 0, 100) / 100))
    setObject(wgt, ui.txFill, {
      y=ui.txBodyY + ui.txBodyH - ui.txInset - fillH,
      w=ui.txBodyW - ui.txInset * 2,
      h=fillH, color=txBatteryColor(txPct),
    })
    setVisible(wgt, ui.txFill, true)
  else
    setVisible(wgt, ui.txFill, false)
  end
end

local function updateRing(wgt, index, value, unit, footer, progress, color,
                          valid, footerColor, invalidMessage)
  local ring = wgt.ui.rings[index]
  if not ring or not ring.value then return end
  local p = valid and clamp(tonumber(progress) or 0, 0, 1) or 0
  local activeColor = valid and (color or C_DIM) or C_DIM
  local sweep = round(p * RING_STANDARD.span)
  setObject(wgt, ring.accent, { color=activeColor })
  if ring.progressW then
    setObject(wgt, ring.accent, {w=math.max(1, math.floor(ring.progressW*p))})
    setVisible(wgt, ring.accent, valid and p > 0)
  end
  -- EdgeTX evaluates these functions from the retained arc without a set()
  -- call, preventing telemetry changes from disturbing the arc geometry.
  ring.arcState.endAngle = (RING_STANDARD.bottom + sweep) % 360
  ring.arcState.color = activeColor
  ring.arcState.opacity = (valid and sweep > 0) and 255 or 0
  local missingText = invalidMessage
                      or (A.linkAvailable and "NO SENSOR" or "")
  setLabel(wgt, ring.value, valid and value or "--", valid and C_TEXT or C_DIM)
  setLabel(wgt, ring.unit, unit, C_DIM)
  setLabel(wgt, ring.footer, valid and footer or missingText,
           valid and (footerColor or C_DIM) or C_DIM)
end

local function batteryFooter()
  if OPT.heliType == AIRCRAFT_FIXED_WING then
    return D.hasBattData and string.format("%dS %.1fV", D.cellsResolved, D.voltage)
           or F.fwBatteryError or "NO BATTERY DATA"
  end
  if not OPT.simTelemetry and A.motorConfigError then
    return G.compact and "SET MOTOR SW" or "SET MOTOR SWITCH"
  end
  if OPT.heliType == HELI_NITRO then
    if not OPT.rxPackValid then return "INVALID RX RANGE" end
    return D.rxVoltage and string.format("RX %.2fV", D.rxVoltage) or "NO TELEMETRY"
  end
  if OPT.heliType == HELI_OMPHOBBY and getCellCount() == 0 then
    return "SET OMP BATTERY"
  end
  local parts = {}
  local profile = getBattProfile()
  if OPT.heliType == HELI_ELECTRIC and profile and profile > 0 then
    parts[#parts+1] = "P" .. tostring(math.floor(profile))
  end
  if D.cellCountValid then parts[#parts+1] = tostring(D.cellsResolved) .. "S" end
  if D.packVoltageValid then parts[#parts+1] = string.format("%.1fV", D.voltage) end
  return #parts > 0 and table.concat(parts, " ") or "SMART FUEL"
end

local function batteryInvalidMessage()
  if OPT.heliType == AIRCRAFT_FIXED_WING then return F.fwBatteryError or "NO BATTERY DATA" end
  if not OPT.simTelemetry and A.motorConfigError then
    return G.compact and "SET MOTOR SW" or "SET MOTOR SWITCH"
  end
  if OPT.heliType == HELI_NITRO and not OPT.rxPackValid then
    return "CHECK RX RANGE"
  end
  if OPT.heliType == HELI_OMPHOBBY and getCellCount() == 0 then
    return "SET OMP BATTERY"
  end
  return A.linkAvailable and "NO BATTERY DATA" or ""
end

local function updateRings(wgt)
  local batteryValid, batteryPct
  if OPT.heliType == HELI_NITRO then
    batteryValid = OPT.rxPackValid and D.rxVoltage ~= nil and D.rxVoltage > 0
    batteryPct = D.rxPercent or 0
  else
    batteryValid = D.hasBattData
    batteryPct = A.displayPercentInit and A.displayPercent or D.adjustedPercent
  end
  updateRing(wgt, 1, tostring(math.floor(batteryPct or 0)), "%",
    batteryFooter(), (batteryPct or 0) / 100,
    batteryColor(batteryPct), batteryValid, C_DIM,
    batteryInvalidMessage())

  local rpm = getHeadspeed()
  updateRing(wgt, 2, tostring(math.floor(rpm or 0)), "RPM",
    string.format("MAX %d", math.floor(statRpmMax())),
    ((rpm or 0) - RING_STANDARD.rpmMin)
      / (RING_STANDARD.rpmMax - RING_STANDARD.rpmMin),
    C_ACCENT, D.rpmValid, C_YELLOW)

  local curr = getCurr()
  local currentValid = OPT.heliType ~= HELI_NITRO and D.currentValid
  local currentProgress = ((curr or 0) - RING_STANDARD.currentMin)
                          / (RING_STANDARD.currentMax - RING_STANDARD.currentMin)
  updateRing(wgt, 3, tostring(math.ceil(curr or 0)), "AMPS",
    string.format("MAX %dA", math.ceil(statCurrMax())), currentProgress,
    wgt.layout.touchHome and C_GREEN or C_BLUE, currentValid, C_YELLOW,
    OPT.heliType == HELI_NITRO and "NOT USED" or nil)

  local temp = getTemp()
  local tempValid = OPT.heliType ~= HELI_NITRO and D.tempValid
  updateRing(wgt, 4, tostring(math.floor(temp or 0)), "\xC2\xB0C",
    string.format("MAX %d\xC2\xB0C", math.floor(statTempMax())),
    ((temp or 0) - RING_STANDARD.tempMin)
      / (RING_STANDARD.tempMax - RING_STANDARD.tempMin),
    C_ORANGE, tempValid, C_YELLOW,
    OPT.heliType == HELI_NITRO and "NOT USED" or nil)
end

local function updateTile(wgt, index, value, footer, accent, valid,
                          valueColor, footerColor, align)
  local tile = wgt.ui.tiles[index]
  if not tile or not tile.value then return end
  setObject(wgt, tile.accent, { color=valid and accent or C_DIM })
  setLabel(wgt, tile.value, valid and value or "--",
           valid and (valueColor or C_TEXT) or C_DIM,
           align or tile.valueAlign or (valid and RIGHT or CENTERED))
  setLabel(wgt, tile.footer, valid and footer or "", footerColor or C_DIM)
end

local function updateLowerDashboard(wgt, footerOnly)
  local ui = wgt.ui
  local imagePath = resolveModelImagePath()
  setVisible(wgt, ui.modelImage, imagePath ~= nil)
  setVisible(wgt, ui.noImage, imagePath == nil)
  local flightCount = getFlightCount()
  local flightText
  local flightColor = C_TEXT
  if G.companion.active then
    wgt.footerCountCache = nil
    flightText = "Companion preview"
  elseif OPT.heliType == AIRCRAFT_FIXED_WING and OPT.flightCounter == FC.ROTORFLIGHT then
    -- RF flight totals are unavailable in this mode. Keep the saved counter
    -- choice intact instead of displaying an endless RF connection status.
    wgt.footerCountCache = nil
    flightText = "Fixed Wing"
  elseif OPT.flightCounter == FC.ROTORFLIGHT then
    -- Display-only grace: never feed a retained count back into FC/debrief
    -- state. New models, RF sessions/providers and counter sources cannot
    -- inherit another context's cached display value.
    local identity = G.debrief.identity()
    local cache = wgt.footerCountCache
    if not cache or cache.identity ~= identity
       or cache.session ~= F.modelNameSession
       or cache.provider ~= wgt.profileRfProviderRef then
      cache = {identity=identity, session=F.modelNameSession,
               provider=wgt.profileRfProviderRef}
      wgt.footerCountCache = cache
    end
    if flightCount ~= nil then
      cache.count, cache.lostAt = flightCount, nil
    elseif cache.count ~= nil then
      cache.lostAt = cache.lostAt or frameNow()
    end
    -- Ordinary reads stay neutral. After a qualifying arm session, yellow
    -- marks the FC-owned total being confirmed through RF Tool, not a write
    -- issued by this widget. Failed/unavailable reads keep their warnings.
    local normalRead = FC.status == "STARTING" or FC.status == "WAITING"
                       or FC.status == "LOADING" or FC.status == "CONFIRMING"
                       or FC.status == "ARMED"
    if flightCount ~= nil then
      flightText = string.format("%d flights", flightCount)
      if FC.refreshQualified or (FC.stale and not normalRead) then
        flightColor = C_YELLOW
      end
    elseif cache.count ~= nil and cache.lostAt
       and frameNow() - cache.lostAt >= 0
       and frameNow() - cache.lostAt < 500
       and (normalRead or FC.status == "DISCONNECTED"
            or FC.status == "NO ARM SENSOR") then
      flightText = string.format("%d flights", cache.count)
      flightColor = C_DIM -- Last known value, awaiting a fresh FC reply.
    else
      flightText = FC.status or "WAITING"
      if not normalRead then flightColor = C_RED end
    end
  else
    wgt.footerCountCache = nil
    flightText = string.format("%d flights", flightCount or 0)
    if A.flightSaveError then flightText = flightText .. "  SAVE ERROR" end
    if A.flightSaveError then flightColor = C_RED end
  end
  if OPT.heliType ~= HELI_OMPHOBBY and wgt.profileConnectedForDisplay then
    flightText = flightText .. " - Connected"
  end
  local armText = G.armStatus.text(wgt)
  local prefix = flightText
  local centeredText = flightText
  if armText then
    -- Unknown evidence must not move the count/connection anchor either.
    -- Keep normal centering based on Disarmed; longer text can extend right.
    local liveArm = armText == "Armed" or armText == "Disarmed"
                    or armText == "Arm unknown"
    local reservedArm = liveArm and "Disarmed" or armText
    centeredText = flightText .. " - " .. reservedArm
    flightText = flightText .. " - " .. armText
  end
  local l = wgt.layout
  local footerW = l.modelW - math.max(6, G.x(6))
  -- EdgeTX returns width and height; only width belongs in the allocation.
  local measuredW = lcd.sizeText(centeredText, G.fontSmall)
  local textW = math.min(footerW, measuredW)
  local textX = l.modelX + math.floor((l.modelW - textW) / 2)
  local availableW = l.modelX + l.modelW - math.max(3, G.x(3)) - textX
  if armText == "Arm unknown" then
    local actualW = lcd.sizeText(flightText, G.fontSmall)
    if actualW > availableW then
      flightText = prefix .. " - Unknown"
      actualW = lcd.sizeText(flightText, G.fontSmall)
    end
    textW = math.min(availableW, math.max(textW, actualW))
  end
  setObject(wgt, ui.flightCount, {
    x=textX, w=textW,
  })
  -- Separate text colors without changing the count/connection anchor.
  local prefixText = armText and (prefix .. " - ") or flightText
  setLabel(wgt, ui.flightCount, prefixText, flightColor)
  local armVisible = false
  if armText then
    if flightText == prefix .. " - Unknown" then armText = "Unknown" end
    local prefixW = lcd.sizeText(prefixText, G.fontSmall)
    armVisible = prefixW < textW
    setObject(wgt, ui.armStatus, {x=textX + math.min(prefixW, textW - 1), w=math.max(1, textW - prefixW)})
    setLabel(wgt, ui.armStatus, armText,
      wgt.armDisplayState == true and C_GREEN or
      (wgt.armDisplayState == false and C_RED or C_DIM))
  end
  setVisible(wgt, ui.armStatus, armVisible)

  if footerOnly then return end
  local govState = getGovState()
  local govValid = OPT.heliType ~= HELI_OMPHOBBY and D.govValid
  updateTile(wgt, 1, govState == "AUTOROT" and "Auto" or govState, "",
    GOV_COLOR[govState] or GOV_FALLBACK, govValid,
    GOV_COLOR[govState] or GOV_FALLBACK)

  local bec = getBec()
  local becValid = OPT.heliType ~= HELI_OMPHOBBY and D.becValid
  local becFooter = statBecMin() and string.format("LOW %.1fV", statBecMin()) or ""
  setLabel(wgt, ui.tiles[2].label,
           OPT.heliType == HELI_NITRO and "BATT OUTPUT" or "BEC OUTPUT", C_DIM)
  updateTile(wgt, 2, string.format("%.1fV", bec or 0), becFooter,
    becValueColor(bec), becValid, becValueColor(bec))

  local cell, cellMin, cellValid
  if OPT.heliType == HELI_NITRO then
    cell = D.rxCellVoltage
    cellMin = D.minRxVoltage and D.minRxVoltage / 2 or nil
    cellValid = cell ~= nil and cell > 0
  else
    cell = getCellVoltage()
    cellMin = statCellMin()
    cellValid = D.cellVoltageValid
  end
  local cellColor = C_TEXT
  if OPT.heliType ~= HELI_NITRO and cellMin
     and cellMin <= SAFETY.cellRedThreshold then cellColor = C_RED end
  updateTile(wgt, 3, string.format("%.2fV", cell or 0),
    cellMin and string.format("LOW %.2fV", cellMin) or "",
    cellColor, cellValid, BATTERY_VOICE.ompCellWarningColor() or cellColor)

  updateTile(wgt, 4, tostring(math.floor(D.capacity or 0)), "mAh",
    C_ACCENT, D.capacityValid)
  if G.personal then G.personal.updateExtras(wgt) end
end

local function updateUiState(wgt)
  if not wgt.uiBuilt or wgt.debriefScene then return end
  updateTopBar(wgt)
  updateRings(wgt)
  updateLowerDashboard(wgt)
end

-- RotorFlight 2.3 battery-profile picker ------------------------------------
-- RF Tool owns the telemetry transport and publishes its connection state and
-- MSP queue for other EdgeTX widgets. KSE Touch deliberately uses that API as
-- its sole profile transport so it never competes for telemetry frames.
local batteryProfiles = (function()
local EVT_TOUCH_TAP = rawget(_G, "EVT_TOUCH_TAP") or _G.EVT_TOUCH_TAP
local MSP_BATTERY_CONFIG = 32
local MSP_BATTERY_STATE = 130
local MSP_BATTERY_PROFILE = 175
local MSP_SET_BATTERY_PROFILE = 176
local MSP_EEPROM_WRITE = 250
local ROTORFLIGHT_23_MSP_API = 12.09
local RF_TOOL_WIDGET_API = 1.00
local BATTERY_CAPACITY_MAX = 20000
local PROFILE_SELECTION_NOTICE = 100 -- EdgeTX ticks: maximum one second
local PROFILE_CONNECT_SETTLE = 40 -- UltiDash pattern: let RF Tool settle 0.4 s
local PROFILE_HOST_DISCOVERY = 20 -- let an enabled rf2bg function publish first
local PROFILE_READ_TIMEOUT = 800 -- MSP 175 is small; allow slower telemetry links 8 s
local PROFILE_SELECT_TIMEOUT = 2000 -- MSP 176 + 175 verification + EEPROM commit
local PROFILE_CAPACITY_TIMEOUT = 400 -- all six capacities, never wait over 4 seconds
local PROFILE_ACTIVE_CAPACITY_TIMEOUT = 300 -- MSP 130 is a small 12-byte reply
local PROFILE_SNAPSHOT_ACTIVE_TIMEOUT = 500 -- MSP 175 must answer within 5 seconds
local PROFILE_SNAPSHOT_CAPACITY_TIMEOUT = 1200 -- then allow MSP 32 up to 12 seconds
local PROFILE_FLIGHT_STATS_TIMEOUT = 200 -- one command-14 send, two-second reply window

local function profileNow()
  return (getTime and getTime()) or 0
end

local function profileRf2()
  local value = rawget(_G, "rf2") or _G.rf2
  return type(value) == "table" and value or nil
end

local function profileCoreMatchesModel(shared)
  local owner = shared and shared.rfToolModel
  if not owner then return true end -- compatibility with older external RF Tool
  local info = getModelInfo()
  if not info then return false end
  if owner.filename and owner.filename ~= "" then return owner.filename == info.filename end
  return owner.id ~= nil and owner.id == info.id
end

local function profileRetireStaleModel(wgt)
  local shared = profileRf2()
  if shared and not profileCoreMatchesModel(shared)
     and type(shared.retireModel) == "function" then
    shared.retireModel() -- drops unsent work; never writes/restores the old name
    wgt.profileRfToolHost, wgt.profileRfToolHostCore = nil, nil
    wgt.profileRfToolDiscoveryAt = nil
    return true
  end
end

local function profileRfToolInstanceLive()
  local shared = profileRf2()
  if not shared or not profileCoreMatchesModel(shared) then return nil end
  local seenAt = tonumber(shared.rfToolInstanceSeenAt)
  local clock = shared.clock
  if not seenAt or type(clock) ~= "function" then return nil end
  local ok, current = pcall(clock)
  current = ok and tonumber(current) or nil
  if not current or current - seenAt > 2 then return nil end
  return shared
end

local function profileRadioLinkLive()
  local reader = rawget(_G, "getRSSI") or _G.getRSSI
  if type(reader) ~= "function" then return false end
  local ok, value = pcall(reader)
  return ok and tonumber(value) ~= nil and tonumber(value) > 0
end

local function profileStandaloneRf2bgCore(shared)
  shared = shared or profileRf2()
  if type(shared) ~= "table" then return false end
  local api = tonumber(shared.apiVersion)
  return api and api >= ROTORFLIGHT_23_MSP_API
         and type(shared.useApi) == "function"
         and type(shared.mspQueue) == "table"
         and type(shared.mspQueue.add) == "function"
         and shared.rfToolApiVersion == nil
         and shared.registerWidget == nil
         and shared.widget == nil
         and shared.rfToolInstanceSeenAt == nil
end

local function profileRfToolProvider()
  local shared = profileRf2()
  if not shared or not profileCoreMatchesModel(shared) then return nil end

  -- RF Tool 2.3 releases before the consumer registration API still publish
  -- the active widget, MSP API version, and queue. Treat that connected core
  -- as a valid provider, but do not accept standalone rf2bg: its custom CRSF
  -- decoder can consume MSP response frames before this queue polls them.
  local toolApi = tonumber(shared.rfToolApiVersion)
  local hasConsumerApi = toolApi and toolApi >= RF_TOOL_WIDGET_API
                         and type(shared.registerWidget) == "function"
  local mspApi = tonumber(shared.apiVersion)
  local hasQueue = type(shared.mspQueue) == "table"
                   and type(shared.mspQueue.add) == "function"
  local hasRfToolCore = hasQueue
                        and (type(shared.widget) == "table"
                             or (mspApi and mspApi >= ROTORFLIGHT_23_MSP_API
                                 and profileRfToolInstanceLive() == shared))
  if not hasConsumerApi and not hasRfToolCore then return nil end
  return shared
end

local function profileSharedQueue()
  local shared = profileRfToolProvider()
  local mspApi = shared and tonumber(shared.apiVersion) or nil
  if not shared or not mspApi or mspApi < ROTORFLIGHT_23_MSP_API
     or type(shared.mspQueue) ~= "table"
     or type(shared.mspQueue.add) ~= "function" then return nil end
  return shared.mspQueue
end

local function profileQueueSupportsOwnership(queue)
  return type(queue) == "table"
    and type(queue.withOwner) == "function"
    and type(queue.cancelOwner) == "function"
    and type(queue.reject) == "function"
end

local function profileQueueSupportsWrites(queue)
  return profileQueueSupportsOwnership(queue)
    and type(queue.checkWriteSafety) == "function"
    and type(queue.prepareWrite) == "function"
    and type(queue.protectProfileSelection) == "function"
end

local function profileRfApi(name)
  local shared = profileRfToolProvider()
  if not shared or type(shared.useApi) ~= "function" then return nil end
  local ok, api = pcall(shared.useApi, name)
  return ok and type(api) == "table" and api or nil
end

local function profileTransport()
  return profileSharedQueue() and "shared" or nil
end

local function profileStartEmbeddedRfTool(wgt)
  -- A currently serviced external RF Tool owns the one permitted RF2 global
  -- instance, even if it predates the optional consumer-registration API.
  if profileRfToolInstanceLive() or profileRfToolProvider()
     or wgt.profileRfToolHost then return end
  if profileStandaloneRf2bgCore() then
    wgt.profileRfToolHostError = "DISABLE rf2bg SPECIAL FUNCTION"
    return
  end
  local now = profileNow()
  -- EdgeTX may run model special functions just after constructing widgets.
  -- Give rf2bg one scheduler beat to publish its RF2 core before deciding that
  -- KSE Touch must create the hidden RF Tool host.
  if not wgt.profileRfToolDiscoveryAt then
    wgt.profileRfToolDiscoveryAt = now + PROFILE_HOST_DISCOVERY
    return
  end
  if now < wgt.profileRfToolDiscoveryAt then return end
  if wgt.profileRfToolHostNextTick
     and now < wgt.profileRfToolHostNextTick then return end

  local loader = rawget(_G, "loadScript") or _G.loadScript
  if type(loader) ~= "function" then
    wgt.profileRfToolHostError = "INSTALL RF TOOL 2.3"
    wgt.profileRfToolHostNextTick = now + 500
    return
  end

  local ok, factory = pcall(loader, "/WIDGETS/RfTool/app.lua")
  if not ok or type(factory) ~= "function" then
    wgt.profileRfToolHostError = "INSTALL RF TOOL 2.3"
    wgt.profileRfToolHostNextTick = now + 500
    return
  end

  local hostZone = { x=0, y=0, w=1, h=1 }
  local hostOptions = {
    Source=0,
    Color=C_TEXT,
    ["Hide Model"]=1,
    ["Hide State"]=1,
    ["Hide Telemetry"]=1,
    sourceName="",
    sourceUnit="",
  }
  local hostOk, host = pcall(factory, hostZone, hostOptions)
  if not hostOk or type(host) ~= "table"
     or type(host.background) ~= "function" then
    wgt.profileRfToolHostError = "RF TOOL HOST FAILED"
    wgt.profileRfToolHostNextTick = now + 500
    return
  end

  wgt.profileRfToolHost = host
  wgt.profileRfToolHostCore = profileRf2()
  wgt.profileRfToolHostError = nil
  wgt.profileRfToolHostNextTick = nil
end

local function profileServiceEmbeddedRfTool(wgt)
  profileStartEmbeddedRfTool(wgt)
  local shared = profileRf2()
  -- When RF Tool is installed as a tile on another EdgeTX screen, its widget
  -- object and queue remain published but that screen may stop receiving
  -- refresh/background time while KSE Touch is full screen. Reuse and service that
  -- exact host here; otherwise requests can be queued successfully yet never
  -- transmitted. This also lets the RF Tool tile be removed entirely because
  -- profileStartEmbeddedRfTool() supplies the same host when none exists.
  local host = wgt.profileRfToolHost
               or (shared and type(shared.widget) == "table"
                   and shared.widget or nil)
  if host == wgt.profileRfToolHost and wgt.profileRfToolHostCore
     and shared ~= wgt.profileRfToolHostCore then
    -- A later-starting rf2bg special function replaced the global published by
    -- our hidden host. Drop the stale closure and consume the new shared core.
    wgt.profileRfToolHost = nil
    wgt.profileRfToolHostCore = nil
    host = shared and type(shared.widget) == "table" and shared.widget or nil
  end

  local function serviceQueue(core, currentHost)
    local state = currentHost and currentHost.state or wgt.profileRfState
    local hostReady = state == "connected" or state == "armed"
                      or state == "disarmed"
    local coreReady = not currentHost and profileRadioLinkLive()
    local queue = core and core.mspQueue or nil
    local api = core and tonumber(core.apiVersion) or nil
    if not (hostReady or coreReady)
       or not api or api < ROTORFLIGHT_23_MSP_API
       or type(queue) ~= "table"
       or type(queue.processQueue) ~= "function" then return false end
    local queueOk = pcall(queue.processQueue, queue)
    if not queueOk then
      wgt.profileRfToolHostError = "RF TOOL QUEUE ERROR"
      wgt.profileQueueFault = true
    elseif wgt.profileRfToolHostError == "RF TOOL QUEUE ERROR" then
      wgt.profileRfToolHostError = nil
      wgt.profileQueueFault = nil
    end
    return true
  end

  -- rf2bg's CRSF custom-telemetry decoder pops every waiting CRSF frame and
  -- discards non-custom frames. While one of KSE Touch's MSP messages is in flight,
  -- poll the MSP queue first and skip that decoder for the entire pass. This is
  -- essential for the slower MSP 32 response; otherwise MSP 175 often works
  -- while the later battery-config reply is consumed before mspQueue sees it.
  local priorityPass = wgt.profileOperation ~= nil
                       or (OPT.heliType ~= HELI_OMPHOBBY
                           and wgt.armingStatusPending == true)
  local priorityServiced = priorityPass and serviceQueue(shared, host) or false

  -- calledFromRefresh=true prevents RF Tool from drawing its own UI. Run its
  -- normal background services only when they cannot steal an in-flight MSP
  -- reply, or when the host is not ready enough for the priority pump.
  if host and type(host.background) == "function" and not priorityServiced then
    local ok = pcall(host.background, host, true)
    if not ok then
      wgt.profileRfToolHostError = "RF TOOL HOST ERROR"
      return
    end
  end

  if not priorityServiced then
    local used = getCurrentUsage and getCurrentUsage()
    if used and used >= 60 then return end
    shared = profileRf2()
    serviceQueue(shared, host)
  end
end

local function profileRfToolStatus(wgt)
  if wgt.profileRfToolHostError then return wgt.profileRfToolHostError end
  local shared = profileRfToolProvider()
  if not shared then return "STARTING RF TOOL 2.3" end
  local state = wgt.profileRfState
  if state == "compiling" or state == "loading"
     or state == "unknown protocol" or state == "ready"
     or state == "initializing" then
    return "RF TOOL: " .. string.upper(state)
  end
  local mspApi = tonumber(shared.apiVersion)
  if mspApi and mspApi < ROTORFLIGHT_23_MSP_API then
    return "ROTORFLIGHT 2.3 FC REQUIRED"
  end
  if not profileSharedQueue() then return "WAITING FOR RF TOOL API" end
  if state == "disconnected" then return "RF TOOL: DISCONNECTED" end
  return "WAITING FOR RF TOOL CONNECTION"
end

local function profileSetFlightCounterStatus(wgt, eligible, connected)
  if not wgt then return end
  local showConnected = eligible and connected or false
  if wgt.profileConnectedForDisplay == showConnected then return end
  wgt.profileConnectedForDisplay = showConnected
  if wgt.uiBuilt then updateLowerDashboard(wgt) end
end

local function profileSetMessage(wgt, text, color)
  wgt.profileMessage = text
  wgt.profileMessageColor = color or C_DIM
end

local function profileSetNotice(wgt, title, detail, color, duration, compact)
  wgt.profileNoticeTitle = title
  wgt.profileNoticeDetail = detail
  wgt.profileNoticeColor = color or C_DIM
  wgt.profileNoticeCompact = compact == true
  wgt.profileNoticeUntil = profileNow() + (duration or 300)
end

local function profileRefreshSelectionNotice(wgt, title, detail, color)
  local now = profileNow()
  if not wgt.profileNoticeCompact or not wgt.profileNoticeUntil
     or now >= wgt.profileNoticeUntil then return end
  wgt.profileNoticeTitle = title
  wgt.profileNoticeDetail = detail
  wgt.profileNoticeColor = color or C_DIM
end

local function profileSetEntryPrompt(wgt, visible, title, detail, color, compact)
  local prompt = wgt.ui and wgt.ui.profilePrompt
  if not prompt then return end
  if visible then
    local geometry = compact and prompt.compact or prompt.full
    setObject(wgt, prompt.fill, {
      x=geometry.x, y=geometry.y, w=geometry.w, h=geometry.h,
    })
    setObject(wgt, prompt.border, {
      x=geometry.x, y=geometry.y, w=geometry.w, h=geometry.h,
    })
    setObject(wgt, prompt.accent, {
      x=geometry.x + 2, y=geometry.y + 2, h=geometry.h - 4,
      color=color or C_GREEN,
    })
    setObject(wgt, prompt.title, {
      x=geometry.titleX, y=geometry.titleY, w=geometry.titleW,
    })
    setObject(wgt, prompt.detail, {
      x=geometry.detailX, y=geometry.detailY, w=geometry.detailW,
    })
    setLabel(wgt, prompt.title, title or "BATTERY PROFILE READY", C_TEXT)
    setLabel(wgt, prompt.detail, detail or "SELECT A BATTERY PROFILE", C_DIM)
  end
  for _, object in ipairs(prompt.objects) do setVisible(wgt, object, visible) end
  if visible and compact then setVisible(wgt, prompt.accent, false) end
end

local function profileOperationOwnsMessage(operation, message)
  if not operation or not message then return false end
  if operation.owner and message._rf2Owner == operation.owner then return true end
  for _, ownMessage in ipairs(operation.messages or {}) do
    if ownMessage == message then return true end
  end
  return false
end

local function profileCancelOperationQueue(operation)
  local queue = operation and operation.queue or nil
  if operation and operation.owner then
    local ok = pcall(queue.cancelOwner, queue, operation.owner)
    if not ok then return false end
    -- RF2 cancelOwner removes unsent requests but retains the active one.
    -- Retire our own active request through the queue's existing reject path
    -- so it cannot retry after cancellation. Other owners remain queued.
    -- A replaced provider owns the transport now: never drain its frames by
    -- rejecting a request on the retired queue.
    local current = queue.currentMessage
    if queue == profileSharedQueue() and current
       and profileOperationOwnsMessage(operation, current) then
      return pcall(queue.reject, queue, current, "KSE Touch request cancelled")
    end
    return true
  end
  if not queue or type(queue.clear) ~= "function" then return false end
  if queue.currentMessage
     and not profileOperationOwnsMessage(operation, queue.currentMessage) then
    return false
  end
  for _, message in pairs(queue.messageQueue or {}) do
    if message and not profileOperationOwnsMessage(operation, message) then
      return false
    end
  end
  local ok = pcall(queue.clear, queue)
  return ok
end

local function profileQueueOwned(operation, callback)
  local queue = operation.queue
  if not profileQueueSupportsOwnership(queue) then return pcall(callback) end
  if not operation.owner or operation.owner.cancelled then
    local owner = {timeout=20}
    operation.owner = owner
    owner.onError = function(reason, command)
      operation.error = reason
      -- The queue reports safety-probe failures to the same owner as the
      -- write. Forward those failures to the operation's existing UI handler.
      local handler
      for _, message in ipairs(operation.messages) do
        handler = handler or message.errorHandler
        if message.command == command and message.errorHandler then
          handler = message.errorHandler
          break
        end
      end
      if handler then handler() end
    end
  end
  return pcall(queue.withOwner, queue, operation.owner, callback)
end

local function profileOperationFailed(wgt, text, token)
  local operation = wgt.profileOperation
  if token and (not operation or operation.token ~= token) then return end
  local kind = operation and operation.kind or nil
  if kind == "select" then wgt.profileSelectionInterrupted = true end
  wgt.profileOperation = nil
  wgt.profileBusy = false
  wgt.profilePending = nil
  if kind == "read" then
    wgt.profileInitialReadFinished = true
    wgt.profileInitialReadValid = false
  end
  if kind == "capacity" then wgt.profileCapacityReadFinished = true end
  if kind == "snapshot" then
    wgt.profileInitialReadFinished = true
    wgt.profileCapacityReadFinished = true
    if wgt.profileInitialReadValid and wgt.profileActive then
      profileSetMessage(wgt, "MSP 32 mAh NOT RECEIVED", C_YELLOW)
    else
      profileSetMessage(wgt, text or "PROFILE DATA UNAVAILABLE", C_DIM)
    end
    return
  end
  if kind == "activeCapacity" then
    -- This read is a best-effort enhancement after an already queued profile
    -- selection. Never turn its absence into a profile-selection error.
    profileSetMessage(wgt,
      "PROFILE " .. tostring(operation and operation.target or "")
        .. " SELECTED", C_DIM)
    return
  end
  if kind == "capacity" then
    -- Capacity is optional display data. A slow or unsupported MSP 32 reply
    -- must not turn a usable profile picker into a modal error.
    profileSetMessage(wgt, text or "CAPACITY DATA UNAVAILABLE", C_DIM)
    return
  end
  if kind == "read" then
    -- The six choices can still be used when the active marker is unknown.
    profileSetMessage(wgt, text or "ACTIVE PROFILE UNAVAILABLE", C_YELLOW)
    return
  end
  profileSetMessage(wgt, text or "PROFILE COMMAND FAILED", C_RED)
  profileSetNotice(wgt, "BATTERY PROFILE ERROR",
                   text or "PROFILE COMMAND FAILED", C_RED, 500)
end

local function profileReadbackReceived(wgt, zeroBased, token)
  local operation = wgt.profileOperation
  if not operation or operation.token ~= token then return end
  local index = tonumber(zeroBased)
  if not index or index ~= math.floor(index)
     or index < 0 or index >= BATTERY_PROFILE_COUNT then
    profileOperationFailed(wgt, "INVALID PROFILE REPLY", token)
    return
  end

  local displayProfile = index + 1
  wgt.profileOperation = nil
  wgt.profileBusy = false
  wgt.profilePending = nil
  wgt.profileActive = displayProfile
  wgt.profileInitialReadFinished = true
  wgt.profileInitialReadValid = true
  profileSetMessage(wgt,
    "CURRENT PROFILE " .. tostring(displayProfile), C_DIM)
end

local function profileSelectionVerified(wgt, zeroBased, token)
  local operation = wgt.profileOperation
  if not operation or operation.token ~= token
     or operation.kind ~= "select" then return end

  local index = tonumber(zeroBased)
  if not index or index ~= math.floor(index)
     or index < 0 or index >= BATTERY_PROFILE_COUNT then
    profileCancelOperationQueue(operation)
    profileOperationFailed(wgt, "INVALID PROFILE REPLY", token)
    return
  end

  local displayProfile = index + 1
  wgt.profileActive = displayProfile
  F.battProfile = displayProfile
  if displayProfile ~= operation.target then
    profileCancelOperationQueue(operation)
    profileOperationFailed(wgt,
      "FC REMAINS ON PROFILE " .. tostring(displayProfile), token)
    return
  end

  operation.verified = true
  operation.stage = "save"
  operation.stageStartedAt = profileNow()
  profileSetMessage(wgt,
    "SAVING PROFILE " .. tostring(displayProfile) .. " TO FC...", C_YELLOW)
end

local function profileSelectionSaved(wgt, displayProfile, token)
  local operation = wgt.profileOperation
  if not operation or operation.token ~= token
     or operation.kind ~= "select" or not operation.verified
     or operation.target ~= displayProfile then return end
  wgt.profileOperation = nil
  wgt.profileBusy = false
  wgt.profilePending = nil
  wgt.profileActive = displayProfile
  PROFILE_CONFIRMED.value = displayProfile
  PROFILE_CONFIRMED.tick = profileNow()
  F.battProfile = displayProfile
  -- MSP 130 is much smaller than the six-profile MSP 32 response. Queue its
  -- read after selection verification and the EEPROM commit have drained,
  -- never before or by switching profiles behind the user's back.
  wgt.profileActiveCapacityRequested = displayProfile
  profileSetMessage(wgt,
    "PROFILE " .. tostring(displayProfile) .. " SAVED TO FC", C_GREEN)
  local capacity = wgt.profileCapacities
                   and wgt.profileCapacities[displayProfile] or nil
  local capacityText = capacity == nil and "PERSISTS AFTER FC REBOOT"
                       or (capacity > 0 and (tostring(capacity) .. " mAh")
                           or "CAPACITY NOT SET")
  profileSetNotice(wgt,
    "PROFILE " .. tostring(displayProfile) .. " SAVED",
    capacityText, C_GREEN, PROFILE_SELECTION_NOTICE, true)
end

local function profileReadByte(buf, index)
  local value = type(buf) == "table" and tonumber(buf[index]) or nil
  if not value or value ~= math.floor(value) or value < 0 or value > 255 then
    return nil
  end
  return value
end

local function profileReadU16(buf, index)
  local low = profileReadByte(buf, index)
  local high = profileReadByte(buf, index + 1)
  if low == nil or high == nil then return nil end
  return low + high * 256
end

local function profileActiveCapacityReceived(wgt, buf, token)
  local operation = wgt.profileOperation
  if not operation or operation.token ~= token
     or operation.kind ~= "activeCapacity" then return end

  -- RF 2.3 MSP_BATTERY_STATE: state, cells, configured capacity (U16),
  -- used capacity, voltage, current, remaining %, active profile.
  local capacity = profileReadU16(buf, 3)
  local replyProfile = profileReadByte(buf, 12)
  local displayProfile = replyProfile and (replyProfile + 1)
                         or tonumber(operation.target)
  if not capacity or capacity > BATTERY_CAPACITY_MAX
     or not displayProfile or displayProfile < 1
     or displayProfile > BATTERY_PROFILE_COUNT then
    profileOperationFailed(wgt, "ACTIVE CAPACITY NOT RECEIVED", token)
    return
  end

  wgt.profileOperation = nil
  wgt.profileBusy = false
  wgt.profilePending = nil
  wgt.profileActive = displayProfile
  wgt.profileCapacities = wgt.profileCapacities or {}
  wgt.profileCapacities[displayProfile] = capacity
  wgt.profileCapacitiesReady = true
  wgt.profileCapacitiesComplete = false
  local capacityText = capacity > 0 and (tostring(capacity) .. " mAh")
                       or "CAPACITY NOT SET"
  profileSetMessage(wgt,
    "PROFILE " .. tostring(displayProfile) .. ": " .. capacityText, C_GREEN)
  profileRefreshSelectionNotice(wgt,
    "PROFILE " .. tostring(displayProfile) .. " SELECTED",
    capacityText, C_GREEN)
end

local function profileFinishCapacities(wgt, capacities, allProfiles, token)
  local operation = wgt.profileOperation
  if not operation or operation.token ~= token
     or operation.kind ~= "capacity" then return end

  wgt.profileOperation = nil
  wgt.profileBusy = false
  wgt.profilePending = nil
  wgt.profileCapacities = capacities
  wgt.profileCapacitiesReady = true
  wgt.profileCapacitiesComplete = allProfiles
  wgt.profileCapacityReadFinished = true
  profileSetMessage(wgt, "BATTERY PROFILE DATA READY", C_DIM)
end

local function profileDecodeCapacityConfig(wgt, config)
  -- This is RF Tool's supported public callback shape. Rotorflight 2.3 returns
  -- a zero-based table: batteryCapacity[0] through batteryCapacity[5].
  local source = type(config) == "table" and config.batteryCapacity or nil
  local capacities = {}
  local allProfiles = type(source) == "table"
  for i = 1, BATTERY_PROFILE_COUNT do
    local entry = allProfiles and source[i - 1] or nil
    local capacity = type(entry) == "table" and tonumber(entry.value)
                     or tonumber(entry)
    if not capacity or capacity ~= math.floor(capacity)
       or capacity < 0 or capacity > BATTERY_CAPACITY_MAX then
      allProfiles = false
      break
    end
    capacities[i] = capacity
  end

  if not allProfiles then
    capacities = {}
    local activeCapacity = type(source) == "table"
                           and tonumber(source.value) or nil
    local activeProfile = tonumber(wgt.profileActive)
    if activeCapacity == nil or activeCapacity ~= math.floor(activeCapacity)
       or activeCapacity < 0 or activeCapacity > BATTERY_CAPACITY_MAX then
      return nil, false
    end
    if activeProfile and activeProfile >= 1
       and activeProfile <= BATTERY_PROFILE_COUNT then
      capacities[activeProfile] = activeCapacity
    end
  end

  return capacities, allProfiles
end

local function profileCapacityConfigReceived(wgt, config, token)
  local operation = wgt.profileOperation
  if not operation or operation.token ~= token
     or operation.kind ~= "capacity" then return end

  local capacities, allProfiles = profileDecodeCapacityConfig(wgt, config)
  if not capacities then
    profileOperationFailed(wgt, "CAPACITY DATA NOT RECEIVED", token)
    return
  end

  profileFinishCapacities(wgt, capacities, allProfiles, token)
end

local function profileDecodeCapacityRaw(wgt, buf)
  -- RF 2.3 appends six little-endian capacities at bytes 16-27. Some radios
  -- have a mixed RF Tool/FC install that returns only the 15-byte legacy body;
  -- byte 1-2 is still the active profile capacity and is useful instead of
  -- incorrectly declaring all capacity data unavailable.
  local capacities = {}
  local allProfiles = true
  for i = 1, BATTERY_PROFILE_COUNT do
    local capacity = profileReadU16(buf, 16 + (i - 1) * 2)
    if capacity == nil or capacity > BATTERY_CAPACITY_MAX then
      allProfiles = false
      break
    end
    capacities[i] = capacity
  end

  if not allProfiles then
    capacities = {}
    local activeCapacity = profileReadU16(buf, 1)
    local activeProfile = tonumber(wgt.profileActive)
    if activeCapacity == nil or activeCapacity > BATTERY_CAPACITY_MAX then
      return nil, false
    end
    if activeProfile and activeProfile >= 1
       and activeProfile <= BATTERY_PROFILE_COUNT then
      capacities[activeProfile] = activeCapacity
    end
  end

  return capacities, allProfiles
end

local function profileCapacityRawReceived(wgt, buf, token)
  local operation = wgt.profileOperation
  if not operation or operation.token ~= token
     or operation.kind ~= "capacity" then return end

  local capacities, allProfiles = profileDecodeCapacityRaw(wgt, buf)
  if not capacities then
    profileOperationFailed(wgt, "PROFILE CAPACITIES UNAVAILABLE", token)
    return
  end

  profileFinishCapacities(wgt, capacities, allProfiles, token)
end

local function profileQueueIdle(queue)
  if type(queue.isProcessed) ~= "function" then return true end
  local ok, idle = pcall(queue.isProcessed, queue)
  return ok and idle == true
end

local function profileQueueMessageSet(queue)
  local messages = {}
  if type(queue) ~= "table" then return messages end
  if queue.currentMessage then messages[queue.currentMessage] = true end
  for _, message in pairs(queue.messageQueue or {}) do
    if message then messages[message] = true end
  end
  return messages
end

local function profileCallApiAndCollect(queue, operation, callback)
  -- Do not replace mspQueue.add(), even briefly. RF Tool owns this shared
  -- object and real EdgeTX builds may retain/bind that method differently
  -- from the host harness. The API call is synchronous, so record the queue
  -- before and after it and retain only the newly appended message objects.
  local before = profileQueueMessageSet(queue)
  local ok = profileQueueOwned(operation, callback)
  local added = 0
  local after = profileQueueMessageSet(queue)
  for message in pairs(after) do
    if not before[message] then
      operation.messages[#operation.messages + 1] = message
      added = added + 1
    end
  end
  -- Older/private queue implementations do not expose messageQueue. The API
  -- call itself is still authoritative there; it began from an idle queue.
  return ok, added > 0 or type(queue.messageQueue) ~= "table"
end

local function profileInstallErrorHandler(messages, failed)
  for _, message in ipairs(messages or {}) do
    if type(message) == "table" then message.errorHandler = failed end
  end
end

-- RotorFlight arming blockers ----------------------------------------------
-- Status is read-only MSP 101. The ARM_SWITCH flag is intentionally omitted
-- from the banner because it is the normal state while the pilot has the arm
-- switch off; every other active flag is a real reason the FC will not arm.
local ARMING_DISABLE_NAMES = {
  [0]="NO GYRO", [1]="FAILSAFE", [2]="RX FAILSAFE",
  [3]="RX RECOVERY", [4]="FAILSAFE MODE", [5]="GOVERNOR",
  [6]="RPM SIGNAL", [7]="THROTTLE", [8]="ANGLE",
  [9]="BOOT GRACE", [10]="PREARM", [11]="CPU LOAD",
  [12]="CALIBRATING", [13]="CLI", [14]="CMS MENU", [15]="BST",
  [16]="MSP", [17]="PARALYZE", [18]="GPS", [19]="RESCUE",
  [20]="RPM FILTER", [21]="REBOOT REQUIRED", [22]="DSHOT",
  [23]="ACC CAL", [24]="MOTOR PROTOCOL",
}
local ARMING_STATUS_INTERVAL = 100
local ARMING_STATUS_TIMEOUT = 200
local ARMING_STATUS_STALE = 500
local ARMING_DISABLED_CALIBRATING = 4096
local ARMING_DISABLED_ARM_SWITCH = 67108864

local function armingBannerText(flags)
  local value = tonumber(flags)
  if not value then return nil end
  -- During gyro_cal_on_first_arm, RotorFlight remains disarmed and reports
  -- CALIBRATING but intentionally omits ARM_SWITCH so that arm request can
  -- continue once calibration finishes. A real calibration block during an
  -- arm attempt also carries ARM_SWITCH. Use that FC distinction instead of
  -- showing a permanent false blocker while the arm switch is off.
  if bit32.band(value, ARMING_DISABLED_CALIBRATING) ~= 0
     and bit32.band(value, ARMING_DISABLED_ARM_SWITCH) == 0 then
    value = value - ARMING_DISABLED_CALIBRATING
  end
  local reasons = {}
  for index = 0, 24 do
    if bit32.band(value, bit32.lshift(1, index)) ~= 0 then
      reasons[#reasons + 1] = ARMING_DISABLE_NAMES[index]
    end
  end
  if #reasons == 0 then return nil end
  local shown = math.min(2, #reasons)
  local text = reasons[1]
  if shown == 2 then text = text .. ", " .. reasons[2] end
  if #reasons > shown then
    text = text .. " +" .. tostring(#reasons - shown)
  end
  return "ARMING BLOCKED: " .. text
end

local function profileShowArmingBanner(wgt)
  local banner = wgt and wgt.ui and wgt.ui.armingBanner or nil
  if not banner then return end
  local visible = type(wgt.armingBlockerText) == "string"
                  and wgt.armingBlockerText ~= ""
  if visible then
    setLabel(wgt, banner.label, wgt.armingBlockerText, C_TEXT, CENTERED)
  end
  for _, object in ipairs(banner.objects) do
    setVisible(wgt, object, visible)
  end
end

local function profileFailArmingStatus(wgt, token)
  local operation = wgt and wgt.armingStatusOperation or nil
  if not operation or operation.token ~= token then return end
  profileCancelOperationQueue(operation)
  wgt.armingStatusOperation = nil
  wgt.armingStatusPending = false
  wgt.armingStatusNextAt = profileNow() + ARMING_STATUS_INTERVAL * 2
end

local function profileFinishArmingStatus(wgt, status, token)
  local operation = wgt and wgt.armingStatusOperation or nil
  if not operation or operation.token ~= token then return end
  wgt.armingStatusOperation = nil
  wgt.armingStatusPending = false
  if OPT.heliType == HELI_OMPHOBBY then
    wgt.armingStatusNextAt = nil
    wgt.armingDisableFlags = nil
    wgt.armingBlockerText = nil
    wgt.armingStatusUpdatedAt = nil
    return
  end
  wgt.armingStatusNextAt = profileNow() + ARMING_STATUS_INTERVAL
  local flags = type(status) == "table" and status.flightModeFlags or nil
  -- readU32 returns a signed integer on the radio's 32-bit Lua build.
  -- Preserve its low ARM bit even when another flight-mode bit sets bit 31.
  wgt.armingFlightModeFlags = type(flags) == "number"
    and flags == math.floor(flags) and flags >= -2147483648 and flags < 4294967296
    and flags or nil
  wgt.armingDisableFlags = type(status) == "table"
                           and tonumber(status.armingDisableFlags) or nil
  wgt.armingBlockerText = armingBannerText(wgt.armingDisableFlags)
  wgt.armingStatusUpdatedAt = profileNow()
end

local function profileBeginArmingStatus(wgt)
  if OPT.heliType == HELI_OMPHOBBY then return false end
  if wgt.armingStatusPending or wgt.profileBusy then return false end
  local queue = profileSharedQueue()
  if not queue or not profileQueueIdle(queue) then return false end
  local api = profileRfApi("mspStatus")
  if not api or type(api.getStatus) ~= "function" then return false end

  wgt.armingStatusToken = (wgt.armingStatusToken or 0) + 1
  local token = wgt.armingStatusToken
  local operation = {
    token=token, kind="armingStatus", startedAt=profileNow(),
    queue=queue, messages={},
  }
  wgt.armingStatusOperation = operation
  wgt.armingStatusPending = true
  local ok, added = profileCallApiAndCollect(queue, operation, function()
    api.getStatus(function(_, status)
      profileFinishArmingStatus(wgt, status, token)
    end, wgt)
  end)
  local decorated = false
  if ok and added then
    for _, message in ipairs(operation.messages) do
      if type(message) == "table" and message.command == 101 then
        decorated = true
        message.retryDelay = 86400
        message.errorHandler = function()
          profileFailArmingStatus(wgt, token)
        end
      end
    end
  end
  if not ok or not added or not decorated then
    profileFailArmingStatus(wgt, token)
    return false
  end
  return true
end

local function profileServiceArmingStatus(wgt, connected, now, allowUi)
  if OPT.heliType == HELI_OMPHOBBY or not connected then
    if wgt.armingStatusOperation then
      profileCancelOperationQueue(wgt.armingStatusOperation)
    end
    wgt.armingStatusOperation = nil
    wgt.armingStatusPending = false
    wgt.armingStatusNextAt = nil
    wgt.armingDisableFlags = nil
    wgt.armingBlockerText = nil
    wgt.armingStatusUpdatedAt = nil
    if allowUi then profileShowArmingBanner(wgt) end
    return
  end
  local operation = wgt.armingStatusOperation
  if operation and now - operation.startedAt >= ARMING_STATUS_TIMEOUT then
    profileFailArmingStatus(wgt, operation.token)
  end
  if wgt.armingStatusUpdatedAt
     and now - wgt.armingStatusUpdatedAt >= ARMING_STATUS_STALE then
    wgt.armingStatusUpdatedAt = nil
    wgt.armingDisableFlags = nil
    wgt.armingBlockerText = nil
  end
  if allowUi then profileShowArmingBanner(wgt) end
  local flightStatsDue = OPT.flightCounter == FC.ROTORFLIGHT
                         and FC.wanted and not FC.pending
                         and FC.stableSince ~= nil
                         and now - FC.stableSince >= FC.disarmStableTicks
  if not wgt.armingStatusPending
     and now >= (wgt.armingStatusNextAt or now)
     and not wgt.profileBusy and not flightStatsDue then
    profileBeginArmingStatus(wgt)
  end
end

local function profileYieldArmingStatusToFlightStats(wgt, now)
  local operation = wgt and wgt.armingStatusOperation or nil
  if not operation then return true end
  -- Cancel only when RF Tool's queue contains this KSE Touch read and nothing from
  -- another consumer. profileCancelOperationQueue enforces that ownership.
  if not profileCancelOperationQueue(operation) then return false end
  wgt.armingStatusOperation = nil
  wgt.armingStatusPending = false
  wgt.armingStatusNextAt = now + ARMING_STATUS_INTERVAL
  return true
end

-- RotorFlight persistent flight counter ------------------------------------
-- Command 14 is read-only. It is queued only through RF Tool's public API and
-- only after the battery-profile queue is idle. Each queue message remains a
-- single send; after a real arm/disarm event, the widget may issue a bounded
-- series of fresh reads while RotorFlight commits its persistent flight total.
local function profileFlightCounterSelected()
  return OPT.flightCounter == FC.ROTORFLIGHT
end

local function profileClearFlightStatsRefresh()
  FC.refreshBase = nil
  FC.refreshAttempts = 0
  FC.refreshQualified = false
end

local function profileRequestFlightStatsRefresh(now, afterFlight, qualified)
  FC.wanted = true
  FC.stableSince = now
  if afterFlight and FC.count ~= nil then
    FC.refreshBase = FC.count
    FC.refreshAttempts = 0
    FC.stale = true
    FC.refreshQualified = qualified == true
  end
end

local function profileFinishFlightStats(wgt, stats, token)
  local operation = wgt and wgt.profileOperation or nil
  if not operation or operation.kind ~= "flightStats"
     or operation.token ~= token then return end
  wgt.profileOperation = nil
  wgt.profileBusy = false
  wgt.profilePending = nil
  FC.pending = false
  if not profileFlightCounterSelected()
     or operation.model ~= flightModel then return end
  if type(stats) ~= "table" or type(stats.statsEnabled) ~= "table"
     or tonumber(stats.statsEnabled.value) ~= 1 then
    FC.count, FC.stale, FC.status = nil, false, "STATS OFF"
    FC.minArmedSeconds = nil
    profileClearFlightStatsRefresh()
    return
  end
  local count = type(stats.stats_total_flights) == "table"
                and tonumber(stats.stats_total_flights.value) or nil
  if not count or count < 0 or count ~= math.floor(count) then
    FC.count, FC.stale, FC.status = nil, false, "BAD REPLY"
    FC.minArmedSeconds = nil
    profileClearFlightStatsRefresh()
    return
  end
  -- This is the FC's qualification setting, independent of KSE's Timer 1
  -- minimum. Missing/invalid settings cannot justify a progress indication.
  local minimum = type(stats.stats_min_armed_time_s) == "table"
                  and tonumber(stats.stats_min_armed_time_s.value) or nil
  FC.minArmedSeconds = minimum and minimum >= 0 and minimum <= 127
                       and minimum == math.floor(minimum) and minimum or nil
  -- RotorFlight can acknowledge command 14 just before its persistent flight
  -- count becomes visible. Do not manufacture a +1; ask for a fresh command-14
  -- reply until the FC reports a changed total or this bounded window expires.
  if operation.refreshBase ~= nil
     and count == operation.refreshBase
     and operation.refreshAttempt < FC.confirmMaxReads then
    FC.stale, FC.status = true, "CONFIRMING"
    FC.wanted = true
    FC.stableSince = profileNow()
    return
  end
  FC.count, FC.stale, FC.status = count, false, "AVAILABLE"
  profileClearFlightStatsRefresh()
end

local function profileFailFlightStats(wgt, token, status)
  local operation = wgt and wgt.profileOperation or nil
  if not operation or operation.kind ~= "flightStats"
     or (token and operation.token ~= token) then return end
  profileCancelOperationQueue(operation)
  wgt.profileOperation = nil
  wgt.profileBusy = false
  wgt.profilePending = nil
  FC.pending = false
  FC.stale = FC.count ~= nil
  FC.status = status or "NO REPLY"
  local retryable = status == "NO REPLY" or status == "QUEUE ERROR"
                    or status == "REQUEST ERROR"
  if retryable and profileFlightCounterSelected()
     and operation.model == flightModel
     and operation.refreshBase ~= nil
     and operation.refreshAttempt < FC.confirmMaxReads then
    FC.wanted = true
    FC.stableSince = profileNow()
    FC.status = "RETRYING"
  else
    FC.refreshQualified = false
  end
end

local function profileBeginFlightStats(wgt)
  if wgt.profileBusy then return false end
  local queue = profileSharedQueue()
  if not queue or not profileQueueIdle(queue) then return false end
  local api = profileRfApi("mspFlightStats")
  if not api or type(api.read) ~= "function" then
    FC.status = "NO API"
    return false
  end

  wgt.profileOperationToken = (wgt.profileOperationToken or 0) + 1
  local token = wgt.profileOperationToken
  local refreshAttempt = 0
  if FC.refreshBase ~= nil then
    FC.refreshAttempts = FC.refreshAttempts + 1
    refreshAttempt = FC.refreshAttempts
  end
  local operation = {
    token=token, kind="flightStats", startedAt=profileNow(),
    queue=queue, messages={}, model=flightModel,
    refreshBase=FC.refreshBase, refreshAttempt=refreshAttempt,
  }
  wgt.profileOperation = operation
  wgt.profileBusy = true
  FC.pending, FC.wanted, FC.status = true, false, "LOADING"

  local apiOk, messageAdded = profileCallApiAndCollect(
    queue, operation,
    function()
      api.read(function(_, stats)
        profileFinishFlightStats(wgt, stats, token)
      end, wgt)
    end)
  local decorated = false
  if apiOk and messageAdded then
    for _, message in ipairs(operation.messages) do
      if type(message) == "table" and message.command == 14 then
        decorated = true
        -- RF Tool's official queue retries forever by default. This very long
        -- per-message delay permits the first send but prevents any retry;
        -- profileCheckOperationTimeout releases it after two seconds.
        message.retryDelay = 86400
        message.errorHandler = function()
          profileFailFlightStats(wgt, token, "NO REPLY")
        end
      end
    end
  end
  if not apiOk or not messageAdded or not decorated then
    profileFailFlightStats(wgt, token, "REQUEST ERROR")
    return false
  end
  return true
end

local function profileBeginOperation(wgt, kind, target)
  if wgt.profileBusy then return false end
  local queue = profileSharedQueue()
  if not queue then
    profileSetMessage(wgt, "RF TOOL 2.3 REQUIRED", C_RED)
    return false
  end
  if kind == "select" and not profileQueueSupportsWrites(queue) then
    profileSetMessage(wgt, "RF TOOL SAFETY UPDATE REQUIRED", C_RED)
    return false
  end
  if not profileQueueIdle(queue) then
    profileSetMessage(wgt, "WAITING FOR RF TOOL QUEUE...", C_YELLOW)
    return false
  end

  wgt.profileOperationToken = (wgt.profileOperationToken or 0) + 1
  local token = wgt.profileOperationToken
  local operation = {
    token=token,
    kind=kind,
    target=target,
    startedAt=profileNow(),
    queue=queue,
    messages={},
    stage=kind == "select" and "set" or nil,
  }
  wgt.profileOperation = operation
  wgt.profileBusy = true
  wgt.profilePending = kind == "select" and target or nil
  profileSetMessage(wgt,
    kind == "select" and ("SETTING PROFILE " .. tostring(target) .. "...")
      or (kind == "capacity" and "READING PROFILE CAPACITIES..."
          or (kind == "activeCapacity"
              and ("READING PROFILE " .. tostring(target) .. " mAh...")
                              or "CHECKING CONTROLLER...")),
    C_YELLOW)
  local function failed()
    profileCancelOperationQueue(operation)
    local message = kind == "capacity" and "CAPACITY READ TIMED OUT"
                    or (kind == "activeCapacity"
                        and "ACTIVE CAPACITY NOT RECEIVED"
                    or (kind == "select"
                        and (operation.stage == "save"
                             and "PROFILE ACTIVE BUT SAVE FAILED"
                             or "PROFILE CHANGE NOT CONFIRMED")
                        or "PROFILE REQUEST TIMED OUT"))
    profileOperationFailed(wgt, message, token)
  end
  local function verifiedConfig(_, config)
    local value = type(config) == "table"
                  and type(config.batteryProfile) == "table"
                  and config.batteryProfile.value or nil
    profileReadbackReceived(wgt, value, token)
  end
  local function verifiedRaw(_, buf)
    profileReadbackReceived(wgt, type(buf) == "table" and buf[1] or nil,
      token)
  end
  local function capacitiesConfig(_, config)
    profileCapacityConfigReceived(wgt, config, token)
  end
  local function capacitiesRaw(_, buf)
    profileCapacityRawReceived(wgt, buf, token)
  end
  local function activeCapacityRaw(_, buf)
    profileActiveCapacityReceived(wgt, buf, token)
  end

  if kind == "activeCapacity" then
    local message = {
      command=MSP_BATTERY_STATE,
      processReply=activeCapacityRaw,
      errorHandler=failed,
    }
    operation.messages[#operation.messages + 1] = message
    local ok = profileQueueOwned(operation, function() queue:add(message) end)
    if not ok then failed() end
    return ok
  end

  if kind == "select" then
    wgt.profileSelectionInterrupted = false
    -- Changing the active battery profile is only a mutable runtime update in
    -- RotorFlight. Keep the entire transaction on RF Tool's one shared queue:
    -- set MSP 176, prove the FC accepted it with MSP 175, then persist it with
    -- the same MSP 250 EEPROM command used by RF Tool's Save action. Success
    -- is reported only after the EEPROM command replies.
    local setMessage = {
      command=MSP_SET_BATTERY_PROFILE,
      payload={ target - 1 },
      processReply=function()
        local current = wgt.profileOperation
        if not current or current.token ~= token then return end
        current.stage = "verify"
        current.stageStartedAt = profileNow()
        profileSetMessage(wgt,
          "VERIFYING PROFILE " .. tostring(target) .. "...", C_YELLOW)
      end,
      errorHandler=failed,
    }
    local verifyMessage = {
      command=MSP_BATTERY_PROFILE,
      processReply=function(_, buf)
        profileSelectionVerified(wgt,
          type(buf) == "table" and buf[1] or nil, token)
      end,
      errorHandler=failed,
    }
    local saveMessage = {
      command=MSP_EEPROM_WRITE,
      processReply=function()
        profileSelectionSaved(wgt, target, token)
      end,
      errorHandler=failed,
    }
    operation.messages[#operation.messages + 1] = setMessage
    operation.messages[#operation.messages + 1] = verifyMessage
    operation.messages[#operation.messages + 1] = saveMessage
    local ok = profileQueueOwned(operation, function()
      queue:add(setMessage)
      queue:add(verifyMessage)
      queue:add(saveMessage)
    end)
    if not ok then failed() end
    return ok
  end

  -- Follow UltiDash's integration path first: ask RF Tool to build and parse
  -- the messages through its public RF2 API modules. Record newly queued
  -- messages without replacing any method on RF Tool's shared queue.
  local api
  local apiCall
  if kind == "capacity" then
    api = profileRfApi("mspBatteryConfig")
    if api and type(api.read) == "function" then
      apiCall = function() api.read(capacitiesConfig, wgt) end
    end
  else
    api = profileRfApi("mspBatteryProfile")
    if api and type(api.read) == "function" then
      apiCall = function() api.read(verifiedConfig, wgt) end
    end
  end
  if apiCall then
    local apiOk, messageAdded =
      profileCallApiAndCollect(queue, operation, apiCall)
    if apiOk and messageAdded then
      profileInstallErrorHandler(operation.messages, failed)
      -- Leave RF Tool's processReply intact. Its public callback supplies
      -- the parsed config object and is the same integration used by its
      -- own Battery page and by UltiDash.
      return true
    end
    profileCancelOperationQueue(operation)
    operation.messages = {}
  end

  -- Compatibility fallback for an older RF Tool core without rf2.useApi().
  if kind == "capacity" then
    local message = {
      command=MSP_BATTERY_CONFIG,
      processReply=capacitiesRaw,
      errorHandler=failed,
    }
    operation.messages[#operation.messages + 1] = message
    local ok = profileQueueOwned(operation, function() queue:add(message) end)
    if not ok then failed() end
    return ok
  end
  local readMessage = {
    command=MSP_BATTERY_PROFILE,
    processReply=verifiedRaw,
    errorHandler=failed,
  }
  operation.messages[#operation.messages + 1] = readMessage
  local ok = profileQueueOwned(operation, function() queue:add(readMessage) end)
  if not ok then failed() end
  return ok
end

local function profileFinishSnapshotIfReady(wgt, token)
  local operation = wgt.profileOperation
  if not operation or operation.token ~= token
     or operation.kind ~= "snapshot"
     or not operation.activeDone or not operation.capacityDone then return end

  wgt.profileOperation = nil
  wgt.profileBusy = false
  wgt.profilePending = nil
  wgt.profileInitialReadFinished = true
  wgt.profileCapacityReadFinished = true
  if wgt.profileCapacitiesReady then
    local summary = {}
    for i = 1, BATTERY_PROFILE_COUNT do
      local capacity = wgt.profileCapacities
                       and tonumber(wgt.profileCapacities[i]) or nil
      summary[i] = capacity and tostring(math.floor(capacity)) or "-"
    end
    profileSetMessage(wgt, "mAh  " .. table.concat(summary, " / "), C_DIM)
  elseif wgt.profileInitialReadValid and wgt.profileActive then
    local length = tonumber(wgt.profileCapacityReplyLength)
    profileSetMessage(wgt,
      length and ("MSP 32: " .. tostring(length) .. " BYTES, NO mAh")
        or "MSP 32 mAh NOT RECEIVED",
      C_YELLOW)
  else
    profileSetMessage(wgt, "PROFILE DATA UNAVAILABLE", C_DIM)
  end
end

local function profileSnapshotActiveReceived(wgt, zeroBased, token)
  local operation = wgt.profileOperation
  if not operation or operation.token ~= token
     or operation.kind ~= "snapshot" then return end

  local index = tonumber(zeroBased)
  if index and index == math.floor(index)
     and index >= 0 and index < BATTERY_PROFILE_COUNT then
    wgt.profileActive = index + 1
    wgt.profileInitialReadValid = true
    F.battProfile = index + 1
  else
    wgt.profileInitialReadValid = false
  end
  operation.activeDone = true
  operation.capacityStartedAt = profileNow()
  if wgt.profileInitialReadValid and wgt.profileActive then
    profileSetMessage(wgt,
      "PROFILE " .. tostring(wgt.profileActive) .. " ACTIVE - READING mAh...",
      C_YELLOW)
  end
  profileFinishSnapshotIfReady(wgt, token)
end

local function profileSnapshotCapacitiesReceived(wgt, value, token, raw)
  local operation = wgt.profileOperation
  if not operation or operation.token ~= token
     or operation.kind ~= "snapshot" then return end

  local capacities, allProfiles
  if raw then
    wgt.profileCapacityReplyLength = type(value) == "table" and #value or 0
    capacities, allProfiles = profileDecodeCapacityRaw(wgt, value)
  else
    capacities, allProfiles = profileDecodeCapacityConfig(wgt, value)
  end
  if capacities then
    wgt.profileCapacities = capacities
    wgt.profileCapacitiesReady = true
    wgt.profileCapacitiesComplete = allProfiles
  else
    wgt.profileCapacities = nil
    wgt.profileCapacitiesReady = false
    wgt.profileCapacitiesComplete = false
  end
  operation.capacityDone = true
  profileFinishSnapshotIfReady(wgt, token)
end

local function profileBeginSnapshot(wgt)
  if wgt.profileBusy then return false end
  local queue = profileSharedQueue()
  if not queue then
    profileSetMessage(wgt, "RF TOOL 2.3 REQUIRED", C_RED)
    return false
  end
  if not profileQueueIdle(queue) then
    profileSetMessage(wgt, "WAITING FOR RF TOOL QUEUE...", C_YELLOW)
    return false
  end

  wgt.profileOperationToken = (wgt.profileOperationToken or 0) + 1
  local token = wgt.profileOperationToken
  local operation = {
    token=token,
    kind="snapshot",
    startedAt=profileNow(),
    queue=queue,
    messages={},
    activeDone=false,
    capacityDone=false,
  }
  wgt.profileOperation = operation
  wgt.profileBusy = true
  wgt.profileInitialReadRequested = true
  wgt.profileCapacityReadRequested = true
  profileSetMessage(wgt, "READING BATTERY PROFILE DATA...", C_YELLOW)

  local function failed()
    profileCancelOperationQueue(operation)
    profileOperationFailed(wgt, "PROFILE DATA NOT RECEIVED", token)
  end
  local function activeRaw(_, buf)
    profileSnapshotActiveReceived(wgt,
      type(buf) == "table" and buf[1] or nil, token)
  end
  local function capacitiesRaw(_, buf)
    profileSnapshotCapacitiesReceived(wgt, buf, token, true)
  end
  local function activeConfig(_, config)
    local value = type(config) == "table"
                  and type(config.batteryProfile) == "table"
                  and config.batteryProfile.value or nil
    profileSnapshotActiveReceived(wgt, value, token)
  end
  local function capacitiesConfig(_, config)
    profileSnapshotCapacitiesReceived(wgt, config, token, false)
  end

  -- Follow the supported RF Tool 2.3 path used by its own Battery page and by
  -- UltiDash: let mspBatteryProfile and mspBatteryConfig construct and parse
  -- MSP 175/32. The latter exposes batteryCapacity[0]..[5] on MSP API 12.09.
  local activeApi = profileRfApi("mspBatteryProfile")
  local capacityApi = profileRfApi("mspBatteryConfig")
  if activeApi and type(activeApi.read) == "function"
     and capacityApi and type(capacityApi.read) == "function" then
    local activeOk, activeAdded = profileCallApiAndCollect(
      queue, operation, function() activeApi.read(activeConfig, wgt) end)
    local capacityOk, capacityAdded = false, false
    if activeOk and activeAdded then
      capacityOk, capacityAdded = profileCallApiAndCollect(
        queue, operation, function() capacityApi.read(capacitiesConfig, wgt) end)
    end
    if activeOk and activeAdded and capacityOk and capacityAdded then
      local capacityWrapped = false
      for _, message in ipairs(operation.messages) do
        if message.command == MSP_BATTERY_CONFIG then
          -- RF Tool's 12.09 decoder assumes the full 27-byte response and its
          -- queue deliberately pcall-swallows decoder errors. Capture the raw
          -- body first so a short/variant FC reply is still observable and its
          -- active capacity can be recovered from bytes 1-2.
          message.processReply = capacitiesRaw
          -- Give the larger response breathing room before RF Tool retries it.
          message.retryDelay = 4
          capacityWrapped = true
        end
      end
      if capacityWrapped then
        profileInstallErrorHandler(operation.messages, failed)
        return true
      end
      -- Private queue implementations may hide their queued message objects.
      -- In that case retain RF Tool's parsed callback instead of duplicating
      -- the request merely for diagnostics.
      profileInstallErrorHandler(operation.messages, failed)
      return true
    end
    profileCancelOperationQueue(operation)
    operation.messages = {}
  end

  -- Compatibility fallback for an older/private RF Tool without both public
  -- API modules. The raw decoders accept the RF 2.3 27-byte body and the
  -- 15-byte legacy body.
  local activeMessage = {
    command=MSP_BATTERY_PROFILE,
    processReply=activeRaw,
  }
  local capacityMessage = {
    command=MSP_BATTERY_CONFIG,
    processReply=capacitiesRaw,
    -- A slow telemetry ratio may need longer than RF Tool's default 0.8 s
    -- before the larger response is complete. Avoid restarting it mid-reply.
    retryDelay=4,
  }
  operation.messages[#operation.messages + 1] = activeMessage
  operation.messages[#operation.messages + 1] = capacityMessage
  profileInstallErrorHandler(operation.messages, failed)
  local ok = profileQueueOwned(operation, function()
    queue:add(activeMessage)
    queue:add(capacityMessage)
  end)
  if not ok then failed() end
  return ok
end

local function profileCheckOperationTimeout(wgt, now)
  local operation = wgt.profileOperation
  if not operation then return end
  local timeout
  local timeoutStartedAt = operation.startedAt
  if operation.kind == "snapshot" then
    if operation.activeDone then
      timeout = PROFILE_SNAPSHOT_CAPACITY_TIMEOUT
      timeoutStartedAt = operation.capacityStartedAt or operation.startedAt
    else
      timeout = PROFILE_SNAPSHOT_ACTIVE_TIMEOUT
    end
  elseif operation.kind == "capacity" then
    timeout = PROFILE_CAPACITY_TIMEOUT
  elseif operation.kind == "activeCapacity" then
    timeout = PROFILE_ACTIVE_CAPACITY_TIMEOUT
  elseif operation.kind == "select" then
    timeout = PROFILE_SELECT_TIMEOUT
    timeoutStartedAt = operation.stageStartedAt or operation.startedAt
  elseif operation.kind == "flightStats" then
    timeout = PROFILE_FLIGHT_STATS_TIMEOUT
  else
    timeout = PROFILE_READ_TIMEOUT
  end
  local timedOut = now - timeoutStartedAt >= timeout
  if not timedOut and not wgt.profileQueueFault then return end
  if operation.kind == "flightStats" then
    profileFailFlightStats(wgt, operation.token,
      wgt.profileQueueFault and "QUEUE ERROR" or "NO REPLY")
    wgt.profileQueueFault = nil
    return
  end
  profileCancelOperationQueue(operation)
  local message
  if wgt.profileQueueFault then
    message = "RF TOOL QUEUE ERROR"
  elseif operation.kind == "capacity" then
    message = "CAPACITY READ TIMED OUT"
  elseif operation.kind == "snapshot" then
    message = "PROFILE DATA NOT RECEIVED"
  elseif operation.kind == "activeCapacity" then
    message = "ACTIVE CAPACITY NOT RECEIVED"
  elseif operation.kind == "select" then
    message = operation.stage == "save"
              and "PROFILE ACTIVE BUT SAVE TIMED OUT"
              or "PROFILE CHANGE NOT CONFIRMED"
  else
    message = "PROFILE REQUEST TIMED OUT"
  end
  wgt.profileQueueFault = nil
  profileOperationFailed(wgt, message, operation.token)
end

local function profileCapacityInProgress(wgt)
  local operation = wgt and wgt.profileOperation or nil
  return wgt and wgt.profileBusy and operation
         and (operation.kind == "capacity"
              or operation.kind == "activeCapacity")
end

local function profilePickerBusy(wgt)
  if not wgt.profileBusy then return false end
  local operation = wgt.profileOperation
  -- Read-only flight statistics must not flash the picker into its disabled
  -- style. A tap closes the modal and queues a choice; the service loop waits
  -- for this bounded read, then rechecks connection/arming before any write.
  return not profileCapacityInProgress(wgt)
         and not (operation and operation.kind == "flightStats")
end

local function profileStopCapacityRead(wgt)
  if not profileCapacityInProgress(wgt) then return true end
  local operation = wgt.profileOperation
  if not profileCancelOperationQueue(operation) then return false end
  wgt.profileOperation = nil
  wgt.profileBusy = false
  wgt.profilePending = nil
  if operation.kind == "capacity" then
    wgt.profileCapacityReadFinished = true
  end
  profileSetMessage(wgt, "CAPACITY READ SKIPPED", C_DIM)
  return true
end

local function profileSwitchUnsafe(wgt)
  if wgt and wgt.profileRfState == "armed" then
    return true, "DISARM TO CHANGE PROFILE"
  end
  local armRaw, armCurrent = get("ARM")
  local arm = tonumber(armRaw)
  -- Explicit unsafe telemetry blocks the change, but missing ARM, governor,
  -- or headspeed telemetry does not create a permanent lock.
  if armCurrent == true and arm ~= nil and math.floor(arm) % 2 == 1 then
    return true, "DISARM TO CHANGE PROFILE"
  end
  local governorMode = getGovernorMode()
  if governorMode ~= nil and GOV_RUNNING_STATE[governorMode] then
    return true, "STOP GOVERNOR TO CHANGE PROFILE"
  end
  local headspeed = getHeadspeed()
  if D.rpmValid and headspeed >= 1 then
    return true, "STOP ROTOR TO CHANGE PROFILE"
  end
  return false, nil
end

local function profileWriteBlocked(wgt)
  -- Companion selection is consumed locally by the preview service below;
  -- it never enters the live profile-write path or the RF transport queue.
  if G.companion.active then return false end
  if not profileRadioLinkLive() then return true, "CONNECTION LOST" end
  local unsafe, reason = profileSwitchUnsafe(wgt)
  if unsafe then return unsafe, reason end
  if not profileQueueSupportsWrites(profileSharedQueue()) then
    return true, "RF TOOL SAFETY UPDATE REQUIRED"
  end
  return false, nil
end

local closeBatteryProfileMenu
local showBatteryProfileMenu

local function profileCapacityText(wgt, profileIndex)
  if not wgt.profileCapacitiesReady then
    if wgt.profileCapacityReadRequested
       and not wgt.profileCapacityReadFinished then return "READING..." end
    return ""
  end
  local capacity = wgt.profileCapacities
                   and tonumber(wgt.profileCapacities[profileIndex]) or nil
  if capacity == nil then return "" end
  if capacity <= 0 then return "NOT SET" end
  return tostring(math.floor(capacity)) .. " mAh"
end

local function profileButtonText(wgt, profileIndex, multiline)
  local capacity = profileCapacityText(wgt, profileIndex)
  local text = "P" .. tostring(profileIndex)
  local active = wgt.profileActive == profileIndex
  if multiline and capacity ~= "" then
    if active then text = text .. "  ACTIVE" end
    text = text .. "\n" .. capacity
  else
    if capacity ~= "" then text = text .. "  " .. capacity end
    if active then text = text .. "  ACTIVE" end
  end
  return text
end

local function showNativeBatteryProfileMenu(wgt)
  if not lvgl or type(lvgl.menu) ~= "function" then return false end
  local generation = wgt.profileConnectionGeneration or 0
  local title = "BATTERY PROFILES"
  if wgt.profileActive then
    title = title .. " - P" .. tostring(wgt.profileActive) .. " ACTIVE"
  end
  local unsafe, unsafeMessage = profileWriteBlocked(wgt)
  local profileIndexes = {}
  local values = {}
  for i = 1, BATTERY_PROFILE_COUNT do
    local capacity = wgt.profileCapacities
                     and tonumber(wgt.profileCapacities[i]) or nil
    if capacity and capacity > 0 then
      profileIndexes[#profileIndexes + 1] = i
      values[#values + 1] = profileButtonText(wgt, i, false)
    end
  end
  if #profileIndexes == 0 then
    values[#values + 1] = "NO CONFIGURED PROFILES"
  end
  local safetyIndex
  if unsafe then
    safetyIndex = #values + 1
    values[safetyIndex] = "LOCKED: " .. tostring(unsafeMessage)
  end
  local closeText = "CLOSE"
  if not wgt.profileActive and not wgt.profileCapacitiesReady then
    closeText = "CLOSE - NO MSP 175/32"
  elseif not wgt.profileActive then
    closeText = "CLOSE - NO MSP 175 ACTIVE"
  elseif not wgt.profileCapacitiesReady then
    local length = tonumber(wgt.profileCapacityReplyLength)
    closeText = length and ("CLOSE - MSP 32 " .. tostring(length) .. "B NO mAh")
                or "CLOSE - NO MSP 32 mAh"
  elseif not wgt.profileCapacitiesComplete then
    local length = tonumber(wgt.profileCapacityReplyLength)
    closeText = length and ("CLOSE - MSP 32 " .. tostring(length)
                            .. "B ACTIVE ONLY")
                or "CLOSE - ACTIVE mAh ONLY"
  end
  values[#values + 1] = closeText

  local ok = pcall(lvgl.menu, {
    title=title,
    values=values,
    get=function()
      for valueIndex, profileIndex in ipairs(profileIndexes) do
        if wgt.profileActive == profileIndex then return valueIndex end
      end
      return 0
    end,
    set=function(selected)
      if generation ~= (wgt.profileConnectionGeneration or 0) then return end
      local valueIndex = tonumber(selected)
      wgt.profileAutoShown = true
      if safetyIndex and valueIndex == safetyIndex then
        profileSetNotice(wgt, "PROFILE CHANGE LOCKED",
                         unsafeMessage, C_RED, 500)
        return
      end
      local profileIndex = valueIndex and profileIndexes[valueIndex] or nil
      if not profileIndex then return end
      if wgt.profileActive == profileIndex then
        profileSetEntryPrompt(wgt, false)
        return -- The native menu has already closed; no write or notice.
      end
      local currentState = wgt.profileRfState
      local currentlyReady = G.companion.active or (profileTransport(wgt) ~= nil
                             and (currentState == "connected"
                                  or currentState == "armed"
                                  or currentState == "disarmed"))
      local blockingOperation = profilePickerBusy(wgt)
      if not currentlyReady or blockingOperation then
        profileSetNotice(wgt, "BATTERY PROFILE ERROR",
                         profileRfToolStatus(wgt), C_RED, 500)
        return
      end
      local blocked, blockedMessage = profileWriteBlocked(wgt)
      if blocked then
        profileSetMessage(wgt, blockedMessage, C_RED)
        profileSetNotice(wgt, "PROFILE CHANGE LOCKED",
                         blockedMessage, C_RED, 500)
        return
      end
      -- Leave the native popup callback before touching the RF Tool queue.
      -- The service loop rechecks transport and safety, then starts the write.
      wgt.profileSelectionRequested = profileIndex
      profileSetMessage(wgt,
        "SETTING PROFILE " .. tostring(profileIndex) .. "...", C_YELLOW)
    end,
  })
  if not ok then
    profileSetNotice(wgt, "BATTERY PROFILE ERROR",
                     "NATIVE MENU FAILED", C_RED, 500)
  end
  return ok
end

closeBatteryProfileMenu = function(wgt)
  local dialog = wgt and wgt.profileDialog or nil
  if wgt then wgt.profileDialog = nil end
  if dialog and type(dialog.close) == "function" then
    pcall(dialog.close, dialog)
  end
end

showBatteryProfileMenu = function(wgt)
  if wgt.profileDialog then return true end
  if not lvgl or type(lvgl.dialog) ~= "function" then
    return showNativeBatteryProfileMenu(wgt)
  end

  local generation = wgt.profileConnectionGeneration or 0
  local profileIndexes = {}
  for i = 1, BATTERY_PROFILE_COUNT do
    local capacity = wgt.profileCapacities
                     and tonumber(wgt.profileCapacities[i]) or nil
    if capacity and capacity > 0 then
      profileIndexes[#profileIndexes + 1] = i
    end
  end
  -- Match the native Tools/Favorites menu. Size only when opening: no extra
  -- recurring layout work, and no changes to selection/transport ownership.
  local rgb = lcd.RGB
  local rowColor = rgb(40,40,44)
  local textColor, muted = rgb(240,239,237), rgb(170,169,167)
  local accent, activeText = rgb(214,211,205), rgb(22,22,22)
  if OPT.themeLinked then
    rowColor, textColor, muted = C_PANEL, C_TEXT, C_DIM
    accent, activeText = C_ACCENT, C_PANEL
  end
  local dialogW = math.min(340, G.w - 24)
  local pad = math.max(4, G.rounded(G.h / 60))
  local gap = math.max(3, G.rounded(G.h / 80))
  local rowH = math.max(28, G.rounded(G.h / 10))
  local headerH = G.rounded(G.h / 12) + pad
  local rowsH = #profileIndexes * (rowH + gap)
  local footerY = pad + rowsH
  local dialogH = headerH + footerY + rowH + pad
  local closeW = math.min(108, math.floor((dialogW - pad * 2) / 2))
  local dialogOk, dialog = pcall(lvgl.dialog, {
    title="Battery profiles",
    menuStyle=true,
    w=dialogW,
    h=dialogH,
    close=function()
      wgt.profileDialog = nil
      -- EdgeTX 2.12 retains the closed dialog's LVGL wrapper in this widget.
      -- Rebuild on the next refresh so lvgl.clear() retires it before native
      -- callRefs can inspect the deleted modal. Never clear inside the button
      -- callback that is still executing.
      wgt.uiBuilt = false
    end,
  })
  -- EdgeTX returns LVGL userdata; desktop fixtures may return a table.
  -- Rejecting userdata after creation leaves an empty native modal behind
  -- the fallback menu, because its handle is never retained or closed.
  if not dialogOk or (type(dialog) ~= "userdata" and type(dialog) ~= "table") then
    return showNativeBatteryProfileMenu(wgt)
  end
  wgt.profileDialog = dialog
  if type(dialog.build) ~= "function" then
    closeBatteryProfileMenu(wgt)
    return showNativeBatteryProfileMenu(wgt)
  end

  local children = {}
  for buttonIndex, profileIndex in ipairs(profileIndexes) do
    children[#children + 1] = {
      type="button",
      x=pad, y=pad + (buttonIndex - 1) * (rowH + gap),
      w=dialogW - pad * 2, h=rowH,
      font=0, menuStyle=true,
      cornerRadius=gap,
      color=function()
        if wgt.profileActive == profileIndex then return accent end
        if wgt.profilePending == profileIndex then return C_YELLOW end
        return rowColor
      end,
      textColor=function()
        if wgt.profileActive == profileIndex or wgt.profilePending == profileIndex then
          return activeText
        end
        return textColor
      end,
      -- The modal cannot service/update itself. Freeze the completed snapshot
      -- into a plain string before build so EdgeTX does not retain a
      -- stale function result containing only "P1".."P6".
      text=profileButtonText(wgt, profileIndex, false),
      active=function()
        if generation ~= (wgt.profileConnectionGeneration or 0) then return false end
        if wgt.profileActive == profileIndex then return true end
        local unsafe = profileWriteBlocked(wgt)
        return (G.companion.active or profileTransport(wgt) ~= nil) and not unsafe
               and not profilePickerBusy(wgt)
      end,
      press=function()
        if generation ~= (wgt.profileConnectionGeneration or 0) then return end
        if wgt.profileActive == profileIndex then
          wgt.profileAutoShown = true
          profileSetEntryPrompt(wgt, false)
          closeBatteryProfileMenu(wgt)
          return
        end
        if profilePickerBusy(wgt) then return end
        local blocked, blockedMessage = profileWriteBlocked(wgt)
        if blocked then
          profileSetNotice(wgt, "PROFILE CHANGE LOCKED",
                           blockedMessage, C_RED, 500)
          return
        end
        -- Defer RF traffic until after EdgeTX has closed this callback/dialog.
        wgt.profileSelectionRequested = profileIndex
        wgt.profileAutoShown = true
        profileSetMessage(wgt,
          "SETTING PROFILE " .. tostring(profileIndex) .. "...", C_YELLOW)
        closeBatteryProfileMenu(wgt)
      end,
    }
  end

  children[#children + 1] = {
    type="label", x=pad, y=footerY, w=dialogW - pad * 3 - closeW, h=rowH,
    font=SMLSIZE, color=function()
      local unsafe = profileWriteBlocked(wgt)
      return unsafe and C_RED or muted
    end,
    align=VCENTERED,
    text=(function()
      local unsafe, unsafeMessage = profileWriteBlocked(wgt)
      if unsafe then return unsafeMessage end
      if #profileIndexes == 0 then return "NO CONFIGURED PROFILES" end
      return wgt.profileMessage or "SELECT A PROFILE"
    end)(),
  }
  children[#children + 1] = {
    type="button", x=dialogW - pad - closeW, y=footerY, w=closeW, h=rowH,
    text="Close", color=rowColor, textColor=textColor, menuStyle=true,
    font=0, cornerRadius=gap,
    press=function()
      if generation ~= (wgt.profileConnectionGeneration or 0) then return end
      wgt.profileAutoShown = true
      closeBatteryProfileMenu(wgt)
    end,
  }

  local buildOk = pcall(dialog.build, dialog, children)
  if not buildOk then
    closeBatteryProfileMenu(wgt)
    return showNativeBatteryProfileMenu(wgt)
  end
  return true
end

local function profileRegisterWithRfTool(wgt)
  local shared = profileRfToolProvider()
  if wgt.profileRfProviderRef ~= shared then
    local old = wgt.profileRfProviderRef
    if old and type(old.unregisterWidget) == "function" then old.unregisterWidget(wgt) end
    wgt.profileRfProviderRef = shared
    wgt.profileRfToolRegistered = false
    wgt.profileProviderChanged = true
  end
  if not shared then return end
  local toolApi = tonumber(shared.rfToolApiVersion)
  local canRegister = toolApi and toolApi >= RF_TOOL_WIDGET_API
                      and type(shared.registerWidget) == "function"
  if canRegister and not wgt.profileRfToolRegistered then
    wgt.onStateChanged = function(widget, newState)
      widget.profileRfState = newState
      if widget.touchRfHost and newState == "disconnected" then
        widget.profileRfSessionLost = true
      end
    end
    local ok = pcall(shared.registerWidget, wgt)
    wgt.profileRfToolRegistered = ok
  end
  -- registerWidget() does not replay the current state. Synchronize it on
  -- every service pass so a widget registered before RF Tool finished loading
  -- cannot remain permanently unaware of an already-connected controller.
  if shared.widget and shared.widget.state then
    wgt.profileRfState = shared.widget.state
  elseif not canRegister and tonumber(shared.apiVersion)
         and tonumber(shared.apiVersion) >= ROTORFLIGHT_23_MSP_API
         and (profileRfToolInstanceLive() == shared
              or profileRadioLinkLive()) then
    -- apiVersion is populated only after RF Tool has received a two-way MSP
    -- reply. Older RF Tool cores and rf2bg do not publish a widget object;
    -- require a current radio link before accepting their initialized core.
    wgt.profileRfState = "connected"
  end
end

local function profileControllerConnected(wgt)
  local state = wgt.profileRfState
  return profileRadioLinkLive() and profileSharedQueue() ~= nil
         and (state == "connected" or state == "armed" or state == "disarmed")
end

local function profileOnlyConfigured(wgt)
  -- Automatic selection is allowed only after a complete MSP 32 snapshot.
  -- A shorter reply may contain just the active profile's capacity and must
  -- never be mistaken for proof that the other five profiles are unused.
  if not wgt.profileCapacitiesReady
     or not wgt.profileCapacitiesComplete
     or type(wgt.profileCapacities) ~= "table" then return nil end

  local onlyProfile
  for i = 1, BATTERY_PROFILE_COUNT do
    local capacity = tonumber(wgt.profileCapacities[i])
    if not capacity or capacity ~= math.floor(capacity)
       or capacity < 0 or capacity > BATTERY_CAPACITY_MAX then return nil end
    if capacity > 0 then
      if onlyProfile then return nil end
      onlyProfile = i
    end
  end
  return onlyProfile
end

local function profileResetConnection(wgt)
  wgt.profileRfSessionLost = nil
  wgt.profileRefreshQuiet = nil
  FC.minArmedSeconds, FC.armedSince, FC.refreshQualified = nil, nil, false
  -- Cancel before dropping references, including writes and the queue's
  -- injected status/RPM probes. Tokens also retire callbacks on older cores.
  if wgt.profileOperation then
    profileCancelOperationQueue(wgt.profileOperation)
  end
  if wgt.armingStatusOperation then
    profileCancelOperationQueue(wgt.armingStatusOperation)
  end
  if wgt.profileOperation
     and wgt.profileOperation.kind == "flightStats" then
    profileFailFlightStats(wgt, wgt.profileOperation.token, "DISCONNECTED")
  end
  wgt.profileOperationToken = (wgt.profileOperationToken or 0) + 1
  wgt.armingStatusToken = (wgt.armingStatusToken or 0) + 1
  wgt.profileConnectionGeneration = (wgt.profileConnectionGeneration or 0) + 1
  closeBatteryProfileMenu(wgt)
  profileSetEntryPrompt(wgt, false)
  wgt.profileWasConnected = false
  wgt.profileConnectedForDisplay = false
  wgt.profileAutoShown = false
  wgt.profileSingleConfigured = nil
  wgt.profileInitialReadRequested = false
  wgt.profileInitialReadFinished = false
  wgt.profileInitialReadValid = false
  wgt.profileCapacityReadRequested = false
  wgt.profileCapacityReadFinished = false
  wgt.profileCapacitiesReady = false
  wgt.profileCapacitiesComplete = false
  wgt.profileCapacities = nil
  wgt.profileCapacityReplyLength = nil
  wgt.profileSelectionRequested = nil
  wgt.profileSelectionInterrupted = nil
  wgt.profileActiveCapacityRequested = nil
  wgt.profileCapacityRefreshRequested = nil
  wgt.profileConnectReadyAt = nil
  wgt.profileMenuRetryAt = nil
  wgt.profileDisconnectedSince = nil
  wgt.profileBusy = false
  wgt.profilePending = nil
  wgt.profileOperation = nil
  wgt.profileMessage = nil
  wgt.profileNoticeTitle = nil
  wgt.profileNoticeDetail = nil
  wgt.profileNoticeColor = nil
  wgt.profileNoticeCompact = nil
  wgt.profileNoticeUntil = nil
  wgt.profileActive = nil
  wgt.profileUnsafe = nil
  wgt.profileUnsafeMessage = nil
  wgt.profileTransportReady = nil
  wgt.profileRfStatusKey = nil
  wgt.profileQueueFault = nil
  wgt.armingStatusOperation = nil
  wgt.armingStatusPending = false
  wgt.armingStatusNextAt = nil
  wgt.armingDisableFlags = nil
  wgt.armingBlockerText = nil
  wgt.armingStatusUpdatedAt = nil
  PROFILE_CONFIRMED.value, PROFILE_CONFIRMED.tick = nil, nil
end

local function profilePauseForRf(wgt)
  -- Navigation releases only our queued work. It is not a new battery session.
  if wgt.profileOperation then
    profileCancelOperationQueue(wgt.profileOperation)
    if wgt.profileOperation.kind == "flightStats" then
      profileFailFlightStats(wgt, wgt.profileOperation.token, "REFRESHING")
      FC.wanted = true
    end
  end
  if wgt.armingStatusOperation then profileCancelOperationQueue(wgt.armingStatusOperation) end
  wgt.profileOperationToken = (wgt.profileOperationToken or 0) + 1
  wgt.armingStatusToken = (wgt.armingStatusToken or 0) + 1
  wgt.profileConnectionGeneration = (wgt.profileConnectionGeneration or 0) + 1
  closeBatteryProfileMenu(wgt)
  profileSetEntryPrompt(wgt, false)
  wgt.profileOperation, wgt.armingStatusOperation = nil, nil
  wgt.profileBusy, wgt.armingStatusPending = false, false
  wgt.profilePending, wgt.profileSelectionRequested = nil, nil
  wgt.profileActiveCapacityRequested, wgt.armingStatusNextAt = nil, nil
  -- Read the active profile/capacities again on return, without reopening a
  -- prompt the user already handled. This also picks up RF Battery-page edits.
  wgt.profileCapacityRefreshRequested = true
  wgt.profileRefreshQuiet = true
end

local function profileObserveRfSession(wgt)
  if not wgt.profileWasConnected then return end
  if profileControllerConnected(wgt) then
    wgt.profileDisconnectedSince = nil
  else
    local now = profileNow()
    wgt.profileDisconnectedSince = wgt.profileDisconnectedSince or now
    if wgt.profileRfState == "disconnected" or now - wgt.profileDisconnectedSince >= 500 then
      wgt.profileRfSessionLost = true
    end
  end
end

local function profileFlightCounterArmState(wgt)
  if wgt.profileRfState == "armed" then return true end
  if wgt.profileRfState == "disarmed" then return false end
  local value, current, _, known = get("ARM")
  value = tonumber(value)
  if current ~= true or known ~= true or value == nil then return nil end
  return math.floor(value) % 2 == 1
end

local function profileFlightCounterSourceChanged(wgt)
  if wgt and wgt.profileOperation
     and wgt.profileOperation.kind == "flightStats" then
    profileFailFlightStats(wgt, wgt.profileOperation.token, "SOURCE CHANGED")
  end
  FC.count, FC.stale, FC.pending = nil, false, false
  FC.stableSince, FC.state, FC.armState = nil, nil, nil
  FC.flightSeenArmed = false
  FC.minArmedSeconds, FC.armedSince = nil, nil
  profileClearFlightStatsRefresh()
  FC.model = flightModel
  if profileFlightCounterSelected() then
    FC.status, FC.wanted = "STARTING", true
  else
    FC.status, FC.wanted = "STACYDASH", false
  end
end

local function profileServiceFlightCounter(wgt, connected, now)
  if not profileFlightCounterSelected() then return end
  if FC.model ~= flightModel then
    if wgt.profileOperation
       and wgt.profileOperation.kind == "flightStats" then
      profileFailFlightStats(wgt, wgt.profileOperation.token, "MODEL CHANGED")
    end
    FC.count, FC.stale, FC.pending = nil, false, false
    FC.status, FC.wanted = "WAITING", true
    FC.stableSince, FC.model = nil, flightModel
    FC.flightSeenArmed = false
    FC.minArmedSeconds, FC.armedSince = nil, nil
    profileClearFlightStatsRefresh()
  end

  local state = wgt.profileRfState
  if not connected then
    if wgt.profileOperation
       and wgt.profileOperation.kind == "flightStats" then
      profileFailFlightStats(wgt, wgt.profileOperation.token, "DISCONNECTED")
    end
    FC.state, FC.armState, FC.stableSince = state, nil, nil
    FC.count, FC.stale, FC.pending = nil, false, false
    FC.flightSeenArmed = false
    FC.minArmedSeconds, FC.armedSince = nil, nil
    profileClearFlightStatsRefresh()
    FC.wanted = true
    FC.status = state == "disconnected" and "DISCONNECTED" or "STARTING"
    return
  end

  local armed = profileFlightCounterArmState(wgt)
  local qualifiedDisarm = false
  if armed == true then
    FC.armedSince = FC.armedSince or now
  else
    qualifiedDisarm = armed == false and FC.armedSince ~= nil
      and FC.minArmedSeconds ~= nil
      and now - FC.armedSince >= FC.minArmedSeconds * 100
    -- Unknown state and disconnects must not bridge separate arm sessions.
    FC.armedSince = nil
  end

  if state ~= FC.state then
    local previous = FC.state
    FC.state = state
    if state == "armed" then
      FC.wanted, FC.stableSince = false, nil
      FC.flightSeenArmed = true
      profileClearFlightStatsRefresh()
    elseif state == "disarmed" or state == "connected" then
      if previous == nil or previous == "armed"
         or previous == "disconnected" then
        local afterFlight = FC.flightSeenArmed
        FC.flightSeenArmed = false
        profileRequestFlightStatsRefresh(now, afterFlight, qualifiedDisarm)
      end
    end
  end

  if armed ~= FC.armState then
    local previous = FC.armState
    FC.armState = armed
    if armed == true then
      FC.wanted, FC.stableSince = false, nil
      FC.flightSeenArmed = true
      profileClearFlightStatsRefresh()
      if wgt.profileOperation
         and wgt.profileOperation.kind == "flightStats" then
        profileFailFlightStats(wgt, wgt.profileOperation.token, "ARMED")
      end
    elseif armed == false and previous ~= false then
      local afterFlight = FC.flightSeenArmed
      FC.flightSeenArmed = false
      profileRequestFlightStatsRefresh(now, afterFlight, qualifiedDisarm)
    end
  end

  if armed == nil then
    FC.stableSince = nil
    if not FC.pending then FC.status = "NO ARM SENSOR" end
    return
  elseif armed then
    FC.stableSince = nil
    if FC.count == nil and not FC.pending then FC.status = "ARMED" end
    return
  end

  FC.stableSince = FC.stableSince or now
  if FC.wanted and not FC.pending then
    FC.status = "WAITING"
    if now - FC.stableSince >= FC.disarmStableTicks then
      if profileYieldArmingStatusToFlightStats(wgt, now) then
        profileBeginFlightStats(wgt)
      end
    end
  end
end

local function profilePointInBatteryCard(wgt, touchState)
  if type(touchState) ~= "table" then return false end
  local x, y = tonumber(touchState.x), tonumber(touchState.y)
  local card = wgt.layout and wgt.layout.rings and wgt.layout.rings[1]
  return x and y and card
         and x >= card.x and x < card.x + card.w
         and y >= card.y and y < card.y + card.h
end

local function profileModeAccess()
  -- Native Inputs/Curves replace RF Setup for fixed-wing models. Do not start
  -- an MSP session, even if the saved flight-counter choice is RotorFlight.
  if OPT.heliType == AIRCRAFT_FIXED_WING then return false, false, false, false end
  local live = not OPT.simTelemetry
  -- Nitro has no RotorFlight battery profiles. It still keeps RF Tool alive
  -- for read-only arming diagnostics and, when selected, MSP 14 flight stats.
  local profiles = live and OPT.heliType == HELI_ELECTRIC
  local arming = live and OPT.heliType ~= HELI_OMPHOBBY
  local flightStats = live and OPT.flightCounter == FC.ROTORFLIGHT
  return profiles, arming, flightStats, arming or flightStats
end

local function serviceBatteryProfileFeature(wgt, allowUi, event, touchState)
  if not wgt then return end
  if profileRetireStaleModel(wgt) then
    profileResetConnection(wgt)
    return -- retirement and new-core initialization get separate CPU budgets
  end
  if wgt.profileRfSessionLost then profileResetConnection(wgt) end
  if G.companion.active and OPT.heliType ~= AIRCRAFT_FIXED_WING then
    -- Keep the real RF2 offline UI ready, independently of the synthetic
    -- dashboard. Do not enter live profile reads/writes, ARM polling or stats.
    profileServiceEmbeddedRfTool(wgt)
    local info = model.getInfo()
    local identity = info and (info.filename or info.name)
    if G.companion.model ~= identity then
      G.companion.model, G.companion.batteryProfile = identity, 3
      wgt.profileSelectionRequested = nil
    end
    if wgt.profileSelectionRequested then
      G.companion.batteryProfile = wgt.profileSelectionRequested
      wgt.profileSelectionRequested = nil
      G.touch.notice(wgt, "Preview battery P" .. tostring(G.companion.batteryProfile))
    end
    wgt.profileActive = G.companion.batteryProfile or 3
    wgt.profileCapacities = {1800, 2200, 3300, 4000, 5000, 6000}
    wgt.profileCapacitiesReady, wgt.profileCapacitiesComplete = true, true
    wgt.profileCapacityRefreshRequested = nil
    wgt.profileMessage = "COMPANION PREVIEW - SAMPLE BATTERIES"
    return
  end
  local profileEligible, armingEligible, counterEligible, rfToolNeeded =
    profileModeAccess()
  if rfToolNeeded then
    -- Retire old work BEFORE either RF Tool or KSE Touch pumps the shared queue.
    -- Preserve the existing short-loss display grace, but never resume an
    -- interrupted profile write automatically when the receiver returns.
    profileRegisterWithRfTool(wgt)
    local queue = profileSharedQueue()
    if wgt.profileProviderChanged
       or (wgt.profileOperation and wgt.profileOperation.queue ~= queue)
       or (wgt.armingStatusOperation and wgt.armingStatusOperation.queue ~= queue) then
      wgt.profileProviderChanged = false
      profileResetConnection(wgt)
    end
    local connected = profileControllerConnected(wgt)
    local operation = wgt.profileOperation
    if operation and operation.kind == "select" then
      local blocked, reason = profileWriteBlocked(wgt)
      if not connected then blocked, reason = true, "CONNECTION LOST - SELECT AGAIN" end
      if blocked then
        profileCancelOperationQueue(operation)
        profileOperationFailed(wgt, reason, operation.token)
      end
    end
    if not connected then
      wgt.profileSelectionRequested = nil
      if wgt.profileDialog then closeBatteryProfileMenu(wgt) end
    end
    profileCheckOperationTimeout(wgt, profileNow())
    profileServiceEmbeddedRfTool(wgt)
    local used = getCurrentUsage and getCurrentUsage()
    if used and used >= 60 then return end
    profileRegisterWithRfTool(wgt)
  end
  if wgt.profileProviderChanged then
    wgt.profileProviderChanged = false
    profileResetConnection(wgt)
  end

  local now = profileNow()
  local providerReady = rfToolNeeded and profileRfToolProvider() ~= nil
  local transportReady = profileEligible and profileTransport(wgt) ~= nil
  local statusKey = tostring(providerReady) .. ":"
                    .. tostring(wgt.profileRfState) .. ":"
                    .. tostring(transportReady)
  if wgt.profileRfStatusKey ~= statusKey then
    wgt.profileRfStatusKey = statusKey
  end

  local linkObserved = profileEligible and A.linkAvailable
  local connected = rfToolNeeded and profileControllerConnected(wgt)
  if allowUi then
    profileSetFlightCounterStatus(wgt, rfToolNeeded, connected)
  end
  if profileEligible and connected then
    wgt.profileDisconnectedSince = nil
    if not wgt.profileWasConnected then
      wgt.profileWasConnected = true
      wgt.profileAutoShown = false
      -- Match UltiDash's controller snapshot: queue the active profile
      -- (MSP 175) and all six configured capacities (MSP 32) together after
      -- the short connection-settle window. The popup opens only after both
      -- callbacks, or after one strict bounded fallback.
      wgt.profileInitialReadRequested = false
      wgt.profileInitialReadFinished = false
      wgt.profileInitialReadValid = false
      wgt.profileCapacityReadRequested = false
      wgt.profileCapacityReadFinished = false
      wgt.profileCapacitiesReady = false
      wgt.profileCapacitiesComplete = false
      wgt.profileCapacities = nil
      wgt.profileCapacityReplyLength = nil
      wgt.profileSelectionRequested = nil
      wgt.profileActiveCapacityRequested = nil
      wgt.profileCapacityRefreshRequested = nil
      wgt.profileConnectReadyAt = now + PROFILE_CONNECT_SETTLE
      wgt.profileMenuRetryAt = nil
      profileSetMessage(wgt, "SELECT A BATTERY PROFILE", C_DIM)
    end

    if wgt.profileCapacityRefreshRequested and not wgt.profileBusy then
      wgt.profileCapacityRefreshRequested = nil
      wgt.profileInitialReadRequested = false
      wgt.profileInitialReadFinished = false
      wgt.profileCapacityReadRequested = false
      wgt.profileCapacityReadFinished = false
      wgt.profileCapacitiesReady = false
      wgt.profileCapacitiesComplete = false
      wgt.profileCapacities = nil
      wgt.profileCapacityReplyLength = nil
      wgt.profileNoticeUntil = nil
      wgt.profileConnectReadyAt = now
      profileSetMessage(wgt, "READING PROFILE CAPACITIES...", C_YELLOW)
    end

    local telemetryProfile = getBattProfile()
    if telemetryProfile and telemetryProfile ~= wgt.profileActive
       and not wgt.profileBusy then
      wgt.profileActive = telemetryProfile
      wgt.profileInitialReadValid = true
      profileSetMessage(wgt,
        "CURRENT PROFILE " .. tostring(telemetryProfile), C_DIM)
    end

    transportReady = profileTransport(wgt) ~= nil
    profileCheckOperationTimeout(wgt, now)
    local unsafe, unsafeMessage = profileSwitchUnsafe(wgt)
    local connectionSettled = now >= (wgt.profileConnectReadyAt or now)
    if wgt.profileUnsafe ~= unsafe
       or wgt.profileUnsafeMessage ~= unsafeMessage
       or wgt.profileTransportReady ~= transportReady then
      wgt.profileUnsafe = unsafe
      wgt.profileUnsafeMessage = unsafeMessage
      wgt.profileTransportReady = transportReady
    end
    if transportReady and connectionSettled and not unsafe
       and not wgt.profileInitialReadRequested
       and not wgt.profileCapacityReadRequested and not wgt.profileBusy then
      profileBeginSnapshot(wgt)
    end

    -- lvgl.dialog is modal: on affected EdgeTX builds it suspends this widget's
    -- refresh/background service. Keep it closed until the hidden RF Tool host
    -- has finished MSP 32, otherwise the dialog itself freezes the queue that
    -- must deliver the capacities. A bounded failure still marks this ready.
    local snapshotReady = wgt.profileInitialReadFinished
                          and wgt.profileCapacityReadFinished
    local onlyProfile = snapshotReady and profileOnlyConfigured(wgt) or nil
    if onlyProfile then
      -- A capacity of zero means that profile is not configured. When exactly
      -- one of the six profiles is configured, use it without asking the user
      -- to choose. The normal armed-state gate still protects the MSP 176
      -- write, so a required change waits quietly until the model is disarmed.
      wgt.profileAutoShown = true
      wgt.profileSingleConfigured = onlyProfile
      if wgt.profileActive ~= onlyProfile and not wgt.profileSelectionInterrupted
         and not profileWriteBlocked(wgt)
         and not wgt.profileBusy and not wgt.profileSelectionRequested then
        wgt.profileSelectionRequested = onlyProfile
        profileSetMessage(wgt,
          "USING ONLY PROFILE " .. tostring(onlyProfile) .. "...", C_YELLOW)
      elseif wgt.profileActive == onlyProfile then
        local capacity = wgt.profileCapacities[onlyProfile]
        profileSetMessage(wgt,
          "PROFILE " .. tostring(onlyProfile) .. ": "
            .. tostring(capacity) .. " mAh", C_GREEN)
      end
    else
      wgt.profileSingleConfigured = nil
    end
    local requestedProfile = wgt.profileSelectionRequested
    local selectionQueuedThisPass = false
    if requestedProfile and profileCapacityInProgress(wgt) then
      -- A user choice takes priority over optional display data. Cancel only
      -- when the RF Tool queue contains KSE Touch's own capacity message.
      profileStopCapacityRead(wgt)
    end
    if requestedProfile and not wgt.profileBusy then
      wgt.profileSelectionRequested = nil
      transportReady = profileTransport(wgt) ~= nil
      local blocked, blockedMessage = profileWriteBlocked(wgt)
      if not transportReady then
        profileSetMessage(wgt, profileRfToolStatus(wgt), C_RED)
        profileSetNotice(wgt, "BATTERY PROFILE ERROR",
                         profileRfToolStatus(wgt), C_RED, 500)
      elseif blocked then
        profileSetMessage(wgt, blockedMessage, C_RED)
        profileSetNotice(wgt, "PROFILE CHANGE LOCKED",
                         blockedMessage, C_RED, 500)
      else
        if not profileBeginOperation(wgt, "select", requestedProfile) then
          wgt.profileSelectionRequested = requestedProfile
        else
          selectionQueuedThisPass = true
        end
      end
    end
    local activeCapacityProfile = wgt.profileActiveCapacityRequested
    if activeCapacityProfile and not selectionQueuedThisPass
       and not wgt.profileBusy and not unsafe then
      if profileBeginOperation(wgt, "activeCapacity",
                               activeCapacityProfile) then
        wgt.profileActiveCapacityRequested = nil
      end
    end
    local wasAutoShown = wgt.profileAutoShown
    if allowUi then
      local blockingRead = profilePickerBusy(wgt)
      local quietRead = wgt.profileRefreshQuiet and wgt.profileOperation
                        and wgt.profileOperation.kind ~= "select"
      if blockingRead and not quietRead then
        profileSetEntryPrompt(wgt, true, "BATTERY PROFILES",
                              wgt.profileMessage or "READING CONTROLLER...",
                              C_YELLOW)
      elseif wgt.profileNoticeUntil and now < wgt.profileNoticeUntil then
        profileSetEntryPrompt(wgt, true,
                              wgt.profileNoticeTitle,
                              wgt.profileNoticeDetail,
                              wgt.profileNoticeColor,
                              wgt.profileNoticeCompact)
      elseif snapshotReady and not wgt.profileAutoShown
             and (not wgt.profileMenuRetryAt
                  or now >= wgt.profileMenuRetryAt) then
        profileSetEntryPrompt(wgt, false)
        local opened = showBatteryProfileMenu(wgt) == true
        wgt.profileAutoShown = opened
        if not opened then wgt.profileMenuRetryAt = now + 500 end
      elseif not snapshotReady and not wgt.profileAutoShown and not wgt.profileRefreshQuiet then
        profileSetEntryPrompt(wgt, true,
          unsafe and "BATTERY PROFILE LOCKED" or "READING BATTERY PROFILES",
          wgt.profileMessage or "WAITING FOR RF TOOL...",
          unsafe and C_RED or C_YELLOW)
      else
        profileSetEntryPrompt(wgt, false)
      end
    end

    -- Touch events are available in EdgeTX's interactive widget/App surface;
    -- tapping the battery card reopens the KSE Touch dialog after it was dismissed.
    if wasAutoShown and snapshotReady
       and not profilePickerBusy(wgt)
       and EVT_TOUCH_TAP
       and event == EVT_TOUCH_TAP
       and profilePointInBatteryCard(wgt, touchState) then
      wgt.profileAutoShown = true
      showBatteryProfileMenu(wgt)
    end
  else
    if wgt.profileWasConnected then
      if not wgt.profileDisconnectedSince then
        wgt.profileDisconnectedSince = now
      end
      local explicit = wgt.profileRfToolRegistered
                       and wgt.profileRfState == "disconnected"
      if explicit or now - wgt.profileDisconnectedSince >= 500 then
        profileResetConnection(wgt)
      end
    end

    -- Connection/setup status is display-only. All profile traffic still
    -- belongs to RF Tool's shared MSP queue.
    if allowUi then profileSetEntryPrompt(wgt, false) end
    if not linkObserved and not wgt.profileWasConnected then
      wgt.profileAutoShown = false
    end
  end
  -- Flight statistics are model-wide and also apply to OMPHOBBY models; only
  -- the battery-profile picker is restricted by its own eligibility rules.
  local controllerConnected = connected == true
  profileServiceFlightCounter(wgt,
    counterEligible and controllerConnected, now)
  local armingConnected = armingEligible and controllerConnected
  profileServiceArmingStatus(wgt, armingConnected, now, allowUi)
  G.armStatus.sample(wgt)
end

return {
  service=serviceBatteryProfileFeature,
  reset=profileResetConnection,
  pauseForRf=profilePauseForRf,
  observeRfSession=profileObserveRfSession,
  flightSourceChanged=profileFlightCounterSourceChanged,
  open=function(wgt)
    if G.companion.active and OPT.heliType == HELI_ELECTRIC then
      return showBatteryProfileMenu(wgt)
    end
    if OPT.simTelemetry or OPT.heliType ~= HELI_ELECTRIC then return false end
    if not wgt.profileCapacitiesReady or not profileRadioLinkLive()
       or profilePickerBusy(wgt) then return false end
    wgt.profileAutoShown = true
    return showBatteryProfileMenu(wgt)
  end,
}
end)()

-- Touch callbacks only request actions. Scene changes happen on the next
-- refresh, after EdgeTX has finished dispatching the pressed LVGL control.
G.touch = {}
function G.touch.modelGuard(wgt)
  local guard = lvgl and lvgl.isModelSelectLocked
  -- The native guard watches all incoming telemetry while modals suspend Lua.
  -- Do not silently fall back to an unguarded picker on older firmware.
  local ok, locked, reason, seconds
  if type(guard)=="function" then
    ok, locked, reason, seconds = pcall(guard)
  end
  wgt.modelSwitchLocked = not ok or locked~=false
  local label = "Model"
  if wgt.modelSwitchLocked then
    if not ok or type(locked)~="boolean" then label="Model locked\nGuard unavailable"
    elseif reason=="telemetry" then label="Model locked\nTelemetry active"
    elseif reason=="quiet" and type(seconds)=="number" and seconds>=1 and seconds<=5 then
      label="Model locked\nWait "..seconds.." s"
    else label="Model locked" end
  end
  wgt.modelSwitchLabel = label
  return wgt.modelSwitchLocked
end

function G.touch.notice(wgt, message)
  wgt.touchNotice, wgt.touchNoticeUntil = message, frameNow()+350
end

function G.touch.closeRf(wgt)
  if lvgl and type(lvgl.cancelAppNumber)=="function" then lvgl.cancelAppNumber() end
  local host = wgt.touchRfHost
  local core = wgt.touchRfCore
  local info = model.getInfo()
  if core and core == _G.rf2 and not wgt.profileRfSessionLost
     and info and (info.filename or info.name) == wgt.touchRfModel then
    -- Saving RF settings may reinitialize its name metadata while the same
    -- controller stays connected. Preserve the already-handled battery prompt.
    wgt.profileNameSession = core.modelNameSession
  end
  if host and type(host.closeEmbeddedUi) == "function" then
    pcall(host.closeEmbeddedUi, host, wgt)
  end
  wgt.touchRfHost, wgt.touchRfCore, wgt.touchRfModel = nil, nil, nil
  local restored = wgt.nativeHomeRetained and lvgl.appScene("home")
  wgt.nativeHomeRetained = nil
  if not restored then wgt.uiBuilt = false end
  return restored
end

function G.touch.build(wgt)
  if not wgt.layout.touchHome then return end
  local d = wgt.layout.dock
  local modelSelect = lvgl and type(lvgl.openModelSelect)=="function"
  local names = {"RotorFlight", "Battery", "Tools", modelSelect and "Model" or "Radio"}
  local actions = {"rf", "battery", "tools", modelSelect and "model" or "radio"}
  if OPT.heliType == AIRCRAFT_FIXED_WING then
    names[1], names[2], actions[1], actions[2] = "Inputs", "Curves", "inputs", "curves"
  end
  local count = wgt.nativeHomeNavigation and 3 or 4
  local info = model.getInfo()
  local identity = info and (info.filename or info.name)
  local gap = 8
  local width = math.floor((d.w-gap*(count-1))/count)
  wgt.ui.actions = {}
  -- One shared surface distinguishes navigation from telemetry cards. Button
  -- bounds and native label centering share exactly the same vertical center.
  -- Static dock objects add no Lua getter callbacks or idle allocations.
  wgt.ui.dockSurface = newRect(wgt,d.x,d.y,d.w,d.h,C_TOP,true,12,1,
    OPT.bgTransparent and TRANSPARENT_HEADER_OPACITY or 255)
  wgt.ui.dockBorder = newRect(wgt,d.x,d.y,d.w,d.h,C_BORDER,false,12,1,160)
  local dividerH = math.floor(d.h*0.39)
  for i=1,count-1 do
    newRect(wgt,d.x+i*(width+gap)-gap/2,d.y+math.floor((d.h-dividerH)/2),
      1,dividerH,C_BORDER,true,0,1,110)
  end
  wgt.touchGeneration = (wgt.touchGeneration or 0)+1
  local generation = wgt.touchGeneration
  if wgt.nativeHomeNavigation and wgt.fullScreen then
    local b = wgt.ui.modelSelectorBounds
    local p = {x=b.x,y=b.y,w=b.w,h=b.h,text="",flat=true,cornerRadius=5,
      accentColor=C_ACCENT,press=function()
        local current=model.getInfo()
        if wgt.fullScreen and generation==wgt.touchGeneration
           and current and (current.filename or current.name)==identity then
          -- Keep the title usable for a lock explanation; dispatch rechecks
          -- live telemetry and the native picker applies its own guard too.
          wgt.touchRequested,wgt.touchRequestedModel="model",identity
        end
      end}
    wgt.ui.modelSelector=rememberObject(wgt,lvgl.button(p),p)
  end
  for i=1,count do
    local action = actions[i]
    local p = {x=d.x+(i-1)*(width+gap),y=d.y,w=width,h=d.h,
      text=names[i],font=BOLD_FONT,cornerRadius=10,flat=true,accentColor=C_ACCENT,
      color=C_PANEL_ALT,
      textColor=C_TEXT,
      press=function()
        local current = model.getInfo()
        if wgt.fullScreen and generation==wgt.touchGeneration
           and current and (current.filename or current.name)==identity then
          if action=="model" and G.touch.modelGuard(wgt) then return end
          wgt.touchRequested, wgt.touchRequestedModel = action, identity
        end
      end}
    if action=="model" then
      p.active=function() return not wgt.modelSwitchLocked end
      p.text=function() return wgt.modelSwitchLabel or "Model" end
      p.textColor=function() return wgt.modelSwitchLocked and C_DIM or C_TEXT end
    end
    if wgt.fullScreen then
      wgt.ui.actions[i] = rememberObject(wgt,lvgl.button(p),p)
    else
      -- EdgeTX omits interactive LVGL objects before App mode has focus.
      -- Keep the same dashboard appearance; the long press is handled by
      -- EdgeTX, which then recreates these as real buttons.
      local text = type(p.text)=="function" and p.text() or p.text
      local color = type(p.textColor)=="function" and p.textColor() or p.textColor
      local _, textH = lcd.sizeText(text,p.font)
      newLabel(wgt,p.x,p.y+math.floor((p.h-textH)/2),p.w,text,p.font,color,CENTERED)
    end
  end
  local nx, ny, nw = wgt.layout.x+30, wgt.layout.y+200, wgt.layout.w-60
  wgt.ui.touchNoticePanel = newRect(wgt,nx,ny,nw,46,C_PANEL_ALT,true,6,1)
  wgt.ui.touchNotice = newLabel(wgt,nx+10,ny+10,nw-20,"",G.fontSmall,C_YELLOW,CENTERED)
  setVisible(wgt,wgt.ui.touchNoticePanel,false)
  setVisible(wgt,wgt.ui.touchNotice,false)
end

function G.touch.action(wgt)
  local action, identity = wgt.touchRequested, wgt.touchRequestedModel
  local setupRoute
  wgt.touchRequested, wgt.touchRequestedModel = nil, nil
  local info = model.getInfo()
  if identity and (not info or (info.filename or info.name)~=identity) then return end
  if not wgt.fullScreen then return end
  if lvgl and type(lvgl.takeToolsAction)=="function" then
    -- Native popup has closed. Build the debrief only from the next refresh,
    -- never from an LVGL press callback; the dashboard remains full screen.
    local selected = lvgl.takeToolsAction()
    if selected=="lastFlight" then action = "review"
    elseif selected=="dashboardLayout" then action = "layout" end
  end
  if lvgl and type(lvgl.takeAppRoute)=="function" then
    local route=lvgl.takeAppRoute()
    if route=="dashboardLayout" then action="layout"
    elseif route=="home" or route=="rates" or route=="profile_pids" or route=="profile_governor" or route=="settings" then
      action,setupRoute="rf",route
    end
  end
  if not action or not wgt.layout.touchHome or G.debrief.state.visible then return end
  if action=="model" then
    if G.touch.modelGuard(wgt) then
      G.touch.notice(wgt,string.gsub(wgt.modelSwitchLabel or "Model locked","\n",": "))
    elseif wgt.profileOperation and wgt.profileOperation.kind=="select" then
      G.touch.notice(wgt,"Finish battery selection before changing models")
    elseif lvgl and type(lvgl.openModelSelect)=="function" then
      -- Keep profile/session state while the native Favorites popup is open.
      -- A real model change tears down this widget through EdgeTX's lifecycle.
      local ok, accepted = pcall(lvgl.openModelSelect,true)
      if not (ok and accepted) then
        G.touch.notice(wgt,"Model selection unavailable; try again from the dashboard")
      end
    else
      G.touch.notice(wgt,"Model selection needs KSE firmware")
    end
  elseif action=="radio" then
    if lvgl and type(lvgl.exitFullScreen)=="function" then lvgl.exitFullScreen() end
  elseif action=="inputs" or action=="curves" then
    if OPT.heliType ~= AIRCRAFT_FIXED_WING then return end
    local ok, accepted = false, false
    if lvgl and type(lvgl.openModelPage)=="function" then
      ok, accepted = pcall(lvgl.openModelPage, action)
    end
    if not (ok and accepted) then
      G.touch.notice(wgt,"Native model page unavailable; updated KSE firmware required")
    end
  elseif action=="battery" then
    if not batteryProfiles.open(wgt) then
      G.touch.notice(wgt,OPT.heliType~=HELI_ELECTRIC and "Battery profiles are for RotorFlight electrics"
        or OPT.simTelemetry and "Battery picker needs live telemetry"
        or "Waiting for battery profiles")
    end
  elseif action=="layout" then
    -- A newly created home may enter settings before its first preference read.
    -- Finish that bounded initialization before opening its layout draft.
    if lvgl and type(lvgl.isAppHost)=="function" and lvgl.isAppHost()
       and (not wgt.personalLoaded or wgt.personalKey~=(info and info.filename) or wgt.personalType~=OPT.heliType)
       and info and info.filename and not wgt.profileDialog and not wgt.profileBusy then
      wgt.homeLayoutPending=info.filename;lvgl.registerApp(0);return
    end
    local allowed, reason = G.personal.guard(wgt,true)
    if allowed and not wgt.profileDialog and not wgt.profileBusy then
      if lvgl and type(lvgl.registerApp)=="function" then lvgl.registerApp(0) end
      wgt.layoutEditorRequested = true
    else G.touch.notice(wgt,not allowed and (reason or "Layout locked: dashboard is not ready")
      or wgt.profileDialog and "Layout locked: close the battery window first"
      or "Layout locked: waiting for battery operation") end
  elseif action=="tools" then
    if wgt.profileOperation and wgt.profileOperation.kind=="select" then
      G.touch.notice(wgt,"Finish battery selection before opening Tools")
    elseif lvgl and type(lvgl.openTools)=="function" then
      if type(lvgl.appProtocol)=="function" and type(lvgl.registerApp)=="function" and lvgl.appProtocol()==1 then
        lvgl.registerApp(1)
      end
      local ok, accepted = pcall(lvgl.openTools,true)
      if not (ok and accepted) then G.touch.notice(wgt,"Tools unavailable; try again from the dashboard") end
    else
      G.touch.notice(wgt,"Tools needs updated KSE firmware")
    end
  elseif action=="review" then
    -- Make the sample review accessible by touch without configuring a switch.
    if G.companion.active then G.debrief.state.simPaused = true end
    G.debrief.toggle()
    if not G.debrief.state.visible then
      G.touch.notice(wgt,"No flight review available yet")
    end
  elseif action=="rf" then
    local core = _G.rf2
    local host = wgt.profileRfToolHost or (core and core.widget)
    if OPT.simTelemetry and not G.companion.active then
      G.touch.notice(wgt,"Exit telemetry demo to open RF Lua")
    elseif G.companion.active and core and not core.offlineSimulator then
      G.touch.notice(wgt,"Enable the RF2 Companion offline preview")
    elseif wgt.profileOperation and wgt.profileOperation.kind=="select" then
      G.touch.notice(wgt,"Finish battery selection before opening RF Lua")
    elseif setupRoute and (not host or type(host.getSetupProtocol)~="function" or host.getSetupProtocol()~=1) then
      G.touch.notice(wgt,"RF Setup files need the matching Full update")
    elseif not host or type(host.openEmbeddedUi)~="function" then
      G.touch.notice(wgt,"Install the KSEDev RF Tool companion")
    else
      -- Cancel only KSE's owned operations before handing over the queue.
      batteryProfiles.pauseForRf(wgt)
      local ok, opened = pcall(host.openEmbeddedUi,host,wgt,setupRoute)
      if ok and opened then
        -- The native hub belongs to the dashboard, not to a live edit/save.
        -- Re-register on the next Tools visit; never queue a route behind RF.
        if lvgl and type(lvgl.registerApp)=="function" then lvgl.registerApp(0) end
        wgt.touchRfHost, wgt.touchRfCore = host, core
        local info = model.getInfo()
        wgt.touchRfModel = info and (info.filename or info.name)
        wgt.nativeHomeRetained = lvgl and type(lvgl.appScene)=="function" and lvgl.appScene("rf")
        if not wgt.nativeHomeRetained then wgt.uiBuilt = false end
      else
        G.touch.notice(wgt,"RF Lua is starting; try again shortly")
      end
    end
  end
end

function G.touch.runRf(wgt, event, touchState)
  local host = wgt.touchRfHost
  if not host then return false end
  local info = model.getInfo()
  local identity = info and (info.filename or info.name)
  local homeRequested = lvgl and type(lvgl.takeAppRoute)=="function" and lvgl.takeAppRoute()=="dashboard"
  if homeRequested and _G.rf2==wgt.touchRfCore and type(_G.rf2.requestDashboardExit)=="function" then
    _G.rf2.requestDashboardExit() -- same unsaved/save/override guards as the button
  end
  if event==nil or _G.rf2~=wgt.touchRfCore or identity~=wgt.touchRfModel then
    G.touch.closeRf(wgt)
    return false
  end
  local ok, result = pcall(host.runEmbeddedUi,host,wgt,event,touchState)
  batteryProfiles.observeRfSession(wgt)
  if not ok or result==2 then
    local restored = G.touch.closeRf(wgt)
    wgt.touchRfReturning = true
    if restored then
      if not ok then G.touch.notice(wgt,"RF Lua error; reopen to retry") end
      return true -- home is already visible; telemetry updates next refresh
    end
    if not ok then G.touch.notice(wgt,"RF Lua error; reopen to retry") end
    -- Ordinary exits are cheap enough to replace the RF page with the whole
    -- dashboard in this refresh. Reserve at least 80% of the budget for that
    -- build and skip profile service on the return pass below.
    local used = getCurrentUsage and getCurrentUsage()
    if used and used <= 20 then return false end
    -- An expensive cleanup/error (or firmware without budget reporting) still
    -- needs a fresh pass. Retire the unloaded RF callbacks, but never expose
    -- an empty scene to EdgeTX while the dashboard waits for its next refresh.
    if lvgl then
      lvgl.clear()
      local l = wgt.layout
      lvgl.rectangle({x=l.x,y=l.y,w=l.w,h=l.h,color=C_BG,filled=true})
      lvgl.label({x=l.x+20,y=l.y+math.floor(l.h/2)-16,w=l.w-40,
        text="Returning to dashboard...",font=G.fontSmall,color=C_TEXT,align=CENTERED})
    end
    return true
  end
  return true
end

-- Retained Flight Debrief scene. Return to the dashboard on a Timer 1
-- nonzero -> zero transition, including in normal widget/background mode.
do
  local P = G.debrief
  function P.format(value, pattern)
    return value == nil and "--" or string.format(pattern or "%.0f", value)
  end
  function P.dismiss(widget, resetTimer)
    if resetTimer and not OPT.simTelemetry and model and type(model.resetTimer) == "function" then
      -- Reset the live clock, not the frozen flight record. Native reset also
      -- clears the fractional tick and switch-latch state for the next flight.
      local ok = pcall(model.resetTimer, 0)
      F.timer0, F.timerSecs = nil, nil
      if ok then
        local timer = getTimer0()
        -- A configured countdown resets to its start value. Dismissal means
        -- zero here; keep the user's start, mode and switch settings intact.
        if timer and timer.value ~= 0 and type(model.setTimer) == "function" then
          pcall(model.setTimer, 0, {value=0})
        end
        F.timer0, F.timerSecs = nil, nil
      end
    end
    P.hide()
    P.rebuild(widget)
  end
  function P.watchTimer()
    local s = P.state
    if not s.visible or not s.record
       or (OPT.heliType == HELI_ELECTRIC and s.delivered and not s.presented) then
      -- RF pilot configuration may reset a timer during reinitialization.
      -- A recap not yet presented cannot be dismissed by that timer change.
      s.reviewRecord, s.reviewTimer = nil, nil
      return
    end
    -- Read the actual Timer 1 table, not the simulated dashboard clock or a
    -- helper that substitutes zero for a failed timer read. Reuse frame cache.
    local timer = getTimer0()
    local value = type(timer) == "table" and tonumber(timer.value) or nil
    if value and (value ~= value or value == math.huge or value == -math.huge) then value = nil end
    if s.reviewRecord ~= s.record then
      -- A timer already at zero when the recap opens is not a reset event.
      s.reviewRecord, s.reviewTimer = s.record, value
    elseif value ~= nil then
      if value == 0 and s.reviewTimer ~= nil and s.reviewTimer ~= 0 then
        s.visible = false -- foreground rebuilds later; background never draws
      end
      s.reviewTimer = value
    end
  end
  function P.build(widget)
    local s, record = P.state, P.state.record
    widget.debriefScene = s.visible and record or nil
    widget.debriefClose, widget.debriefNext = nil, nil
    widget.debriefCloseRequested, widget.debriefCloseToken = nil, nil
    if not s.visible or not record then return false end
    local omp = OPT.heliType == HELI_OMPHOBBY
    local nitro = OPT.heliType == HELI_NITRO
    local snapshot = record.telemetryOnly == true
    local switchHint = OPT.debriefSwitch ~= 0
    if widget.profileDialog and type(widget.profileDialog.close) == "function" then
      pcall(widget.profileDialog.close, widget.profileDialog)
      widget.profileDialog = nil
    end
    local large = G.w >= 700 and G.h >= 420
    local x, y, w, h = G.originX, G.originY, G.w, G.h
    local gap = large and 14 or 8
    local margin = large and 18 or 10
    local panel, border = C_PANEL, C_BORDER
    local radius = 10
    local small = SMLSIZE
    local tableFont = _G.BOLD or small
    local valueFont = MIDSIZE
    local function rect(rx, ry, rw, rh, color, rounded, opacity)
      return lvgl.rectangle({x=rx, y=ry, w=rw, h=rh, filled=1,
        color=color, rounded=rounded or 0, thickness=0, opacity=opacity, inputTransparent=true})
    end
    local function card(cx, cy, cw, ch)
      rect(cx, cy, cw, ch, panel, radius,
        OPT.bgTransparent and TRANSPARENT_PANEL_OPACITY or nil)
      if OPT.themeName == "light" or OPT.bgTransparent then
        lvgl.rectangle({x=cx, y=cy, w=cw, h=ch, filled=false,
          color=border, rounded=radius, thickness=1, inputTransparent=true})
      end
    end
    local function label(lx, ly, lw, text, font, color, align)
      -- Keep every name/value inside its allocation with native font measurements.
      text = tostring(text)
      if type(lcd.sizeText) == "function" then
        local clipped = text
        while #clipped > 0 and lcd.sizeText(clipped, font) > lw do
          clipped = string.sub(clipped, 1, -2)
        end
        if clipped ~= text then
          while #clipped > 0 and lcd.sizeText(clipped .. "...", font) > lw do
            clipped = string.sub(clipped, 1, -2)
          end
          text = clipped .. "..."
        end
      end
      return lvgl.label({x=lx, y=ly, w=lw, h=0, text=text, font=font,
        color=OPT.bgTransparent and C_TEXT or color, align=align or 0})
    end
    if OPT.bgTransparent then
      -- Compact fallback text has no cards; give that view one readable veil.
      if w < 430 or h < 260 then
        rect(x, y, w, h, C_TOP, 0, TRANSPARENT_HEADER_OPACITY)
      end
    elseif not OPT.hasBackground then
      rect(x, y, w, h, C_BG)
    end
    if w < 430 or h < 260 then
      -- Small zones use the same timer dismissal, without interactive controls.
      if h >= 24 then label(x + margin, y + 5, w - margin * 2,
        record.landingUnconfirmed and "Landing unconfirmed"
          or record.simulated and "KSE DEBRIEF / SIM" or "KSE FLIGHT DEBRIEF", small, C_ACCENT) end
      if h >= 68 then
        label(x + margin, y + 28, w - margin * 2, switchHint and "Debrief switch or" or "Reset Timer to go", small, C_ACCENT)
        label(x + margin, y + 46, w - margin * 2, switchHint and "reset Timer to return" or "back to dashboard", small, C_ACCENT)
      end
      if h >= 94 then label(x + margin, y + 72, w - margin * 2,
        record.modelName, small, C_TEXT) end
      if h >= 120 then label(x + margin, y + 98, w - margin * 2,
        "Flight: " .. P.format(record.seconds) .. " sec", small, C_TEXT) end
      return true
    end
    local badge = record.landingUnconfirmed and "Landing unconfirmed"
      or record.simulated and "SIMULATED"
      or (snapshot and "TELEM ONLY")
      or (record.saveFailed and "COUNT ERROR"
      or (record.totalStale and "COUNT STALE" or nil))
    -- Use the same outer padding on every edge of the debrief.
    local contentInset = margin
    local heroY = y + contentInset
    local heroH = large and 126 or 96
    local imageW = large and 224 or 132
    card(x + margin, heroY, w - margin * 2, heroH)
    rect(x + margin + imageW, heroY + 12, 1, heroH - 24, border)
    local path = resolveModelImagePath(record.modelName)
    if path == "/WIDGETS/KSETouch/default.png" and not OPT.bgTransparent then
      -- The bundled white line drawing needs contrast even in a light palette.
      rect(x + margin + 4, heroY + 4, imageW - 8, heroH - 8, lcd.RGB(22, 27, 34), radius)
    end
    if path then
      lvgl.image({x=x + margin + 5, y=heroY + 6, w=imageW - 10,
        h=heroH-12, file=path, fill=false})
    end
    local infoX = x + margin + imageW + gap
    local infoW = w - margin - (infoX - x) - gap
    local closeSize, closeGap = large and 36 or 32, 8
    local closeInset = large and 12 or 8
    local closeX, closeY = x + w - margin - closeInset - closeSize, heroY + closeInset
    local badgeW = badge and (large and 164 or 92) or 0
    if record.landingUnconfirmed then
      badgeW = math.min(infoW - closeSize - closeGap, type(lcd.sizeText) == "function"
        and math.ceil(lcd.sizeText(badge, small)) + 2 or (large and 232 or 174))
    end
    label(infoX, heroY + (large and 8 or 6), infoW - badgeW - closeSize - closeGap - gap,
      record.modelName, tableFont, C_TEXT)
    if badge then
      label(closeX - closeGap - badgeW, heroY + (large and 12 or 8), badgeW,
        badge, small, C_YELLOW, RIGHT)
    end
    -- Queue dismissal for refresh, after LVGL has finished the click callback.
    -- The token rejects callbacks belonging to an older/closed recap scene.
    local closeToken = {}
    widget.debriefCloseToken = closeToken
    -- Solid circle beneath a borderless native button; decoration passes touch through.
    rect(closeX, closeY, closeSize, closeSize, C_RED, closeSize/2)
    widget.debriefClose = lvgl.button({x=closeX,y=closeY,w=closeSize,h=closeSize,
      text="X",font=small,textColor=lcd.RGB(0,0,0),color=C_RED,flat=true,cornerRadius=closeSize/2,
      accentColor=C_RED,press=function()
        if s.visible and s.presented and widget.debriefScene == record
           and widget.debriefCloseToken == closeToken then
          widget.debriefCloseRequested = record
        end
      end})
    local statY = heroY + (large and 40 or 32)
    local colW = math.floor(infoW / (nitro and 2 or 3))
    local seconds = record.seconds
    local duration = seconds and string.format("%02d:%02d", math.floor(seconds / 60), seconds % 60) or "--"
    local total = P.format(record.total) .. (record.totalStale and "*" or "")
    local values = nitro and {duration, total}
      or {duration, total, P.format(snapshot and record.capaLast or record.mah)}
    local captions = nitro and {"FLIGHT TIME", "TOTAL FLIGHTS"}
      or {"FLIGHT TIME", "TOTAL FLIGHTS", snapshot and "REPORTED mAh" or "USED mAh"}
    for i=1,#values do
      local font = DBLSIZE
      if type(lcd.sizeText) == "function" and lcd.sizeText(values[i], font) > colW - 4 then
        font = valueFont
        if lcd.sizeText(values[i], font) > colW - 4 then font = small end
      end
      label(infoX + (i-1)*colW, statY, colW - 4, values[i], font, C_ACCENT)
      label(infoX + (i-1)*colW, heroY + (large and 99 or 74), colW - 4,
        captions[i], small, C_DIM)
    end
    local cardsY = heroY + heroH + gap
    local cardsBottom = y + h - contentInset
    local cardW = math.floor((w - margin * 2 - gap) / 2)
    local cardH = large and math.floor((cardsBottom - cardsY - gap) * 0.61)
                            or (cardsBottom - cardsY)
    local f = P.format
    if nitro then
      -- Nitro uses the full lower area for rotor and receiver-pack data.
      -- Compact screens retain max RPM and min voltage, with a RQly footer.
      local height = cardsBottom - cardsY
      local rotorX, receiverX = x + margin, x + margin + cardW + gap
      card(rotorX, cardsY, cardW, height)
      card(receiverX, cardsY, cardW, height)
      label(rotorX + 12, cardsY + 6, cardW - 24, "ROTOR", tableFont, C_ACCENT)
      label(receiverX + 12, cardsY + 6, cardW - 24, "RECEIVER PACK", tableFont, C_ACCENT)
      if large then
        local rows = {{"Main RPM max", f(record.rpmMax)},
          {"Main RPM min", f(record.rpmMin)}, {"Tail RPM max", f(record.tailMax)}}
        local rowH = (height - 44) / #rows
        for i,row in ipairs(rows) do
          local ry = cardsY + 44 + (i-1) * rowH
          label(rotorX + 12, ry + math.floor((rowH - 29) / 2), cardW - 186,
            row[1], tableFont, C_DIM)
          label(rotorX + cardW - 162, ry + math.floor((rowH - 57) / 2), 150,
            row[2], DBLSIZE, C_TEXT, RIGHT)
        end
        local font = _G.XXLSIZE or DBLSIZE
        local lineH = _G.XXLSIZE and 114 or 57
        local voltage = f(record.becMin, "%.2f V")
        if type(lcd.sizeText) == "function" and lcd.sizeText(voltage, font) > cardW - 24 then
          font, lineH = DBLSIZE, 57
        end
        local valueY = cardsY + 44 + math.floor((height - 108 - lineH - 29) / 2)
        label(receiverX + 12, valueY, cardW - 24, voltage, font, C_TEXT, CENTER)
        label(receiverX + 12, valueY + lineH + 6, cardW - 24, "MINIMUM VOLTAGE",
          small, C_DIM, CENTER)
        label(receiverX + 12, cardsBottom - 47, cardW - 132,
          "MIN RQLY", tableFont, C_DIM)
        label(receiverX + cardW - 112, cardsBottom - 54, 100,
          f(record.rqlyMin, "%.0f%%"), valueFont, C_TEXT, RIGHT)
      else
        local useXL = height >= 165 and _G.XXLSIZE ~= nil
        local font, lineH = useXL and _G.XXLSIZE or DBLSIZE, useXL and 83 or 41
        local columns = {{rotorX, f(record.rpmMax), "MAX MAIN RPM"},
          {receiverX, f(record.becMin, "%.2f V"), "MINIMUM VOLTAGE"}}
        for _,column in ipairs(columns) do
          local numberFont, numberH = font, lineH
          if type(lcd.sizeText) == "function" and lcd.sizeText(column[2], font) > cardW - 24 then
            numberFont, numberH = DBLSIZE, 41
          end
          local footerH = column[1] == receiverX and 28 or 0
          local valueY = cardsY + 32 + math.floor((height - 32 - footerH - numberH - 21) / 2)
          label(column[1] + 12, valueY, cardW - 24, column[2], numberFont, C_TEXT, CENTER)
          label(column[1] + 12, valueY + numberH + 4, cardW - 24, column[3], small, C_DIM, CENTER)
        end
        label(receiverX + 12, cardsBottom - 25, cardW - 110,
          "MIN RQLY", tableFont, C_DIM)
        label(receiverX + cardW - 88, cardsBottom - 25, 76,
          f(record.rqlyMin, "%.0f%%"), tableFont, C_TEXT, RIGHT)
      end
      return true
    end
    local temp = record.tempMax
    local powerRows = {
      {"Peak amps", f(record.ampsMax, "%.1f A")},
      {"Peak watts", f(record.wattsMax, "%.0f W")},
      {omp and "Low batt V" or (large and "Pack minimum" or "Pack min"), f(record.voltsMin, "%.2f V")},
      {omp and "Low cell V" or (large and "Cell minimum" or "Cell min"), f(record.cellMin, "%.2f V")},
    }
    if not large then
      -- Four compact tiles keep RQly on the same page as all prior readings.
      -- The shorter 480x272 screen uses table-size values to fit each row.
      local miniH = math.floor((cardH - gap * 3) / 4)
      local miniFont, miniLineH = valueFont, 31
      if miniH < 35 then miniFont, miniLineH = tableFont, 21 end
      local summaries = {
        {omp and "Max RPM" or "MAX RPM", f(record.rpmMax)},
        {omp and "Battery %" or (OPT.heliType == HELI_NITRO and "MIN RX" or "MIN BEC"),
          omp and f(record.batteryPct, "%.0f%%") or f(record.becMin, "%.2f V")},
        {omp and "Peak ESC Temp" or "MAX ESC", f(temp, "%.0f C")},
        {"MIN RQLY", f(record.rqlyMin, "%.0f%%")},
      }
      for i,row in ipairs(summaries) do
        local cx, cy = x + margin, cardsY + (i-1) * (miniH + gap)
        card(cx, cy, cardW, miniH)
        label(cx + 12, cy + math.floor((miniH - 21) / 2), cardW - (omp and 110 or 140),
          row[1], tableFont, C_ACCENT)
        label(cx + cardW - (omp and 94 or 122), cy + math.floor((miniH - miniLineH) / 2), omp and 82 or 110,
          row[2], miniFont, C_TEXT, RIGHT)
      end
      local cx = x + margin + cardW + gap
      card(cx, cardsY, cardW, cardH)
      label(cx + 10, cardsY + 6, cardW - 20, "POWER", tableFont, C_ACCENT)
      local rowH = (cardH - 32) / 4
      local powerFont = rowH >= 31 and valueFont or tableFont
      local powerLineH = rowH >= 31 and 31 or 21
      for i,row in ipairs(powerRows) do
        local ry = cardsY + 32 + (i-1) * rowH
        label(cx + 10, ry + math.floor((rowH - 21) / 2), cardW - 132,
          row[1], tableFont, C_DIM)
        label(cx + cardW - 116, ry + math.floor((rowH - powerLineH) / 2), 106,
          row[2], powerFont, C_TEXT, RIGHT)
      end
      return true
    end
    local rotorRows = omp and {{"Max RPM", f(record.rpmMax)}}
      or {{"Main RPM min", f(record.rpmMin)}, {"Main RPM max", f(record.rpmMax)}}
    if not omp then rotorRows[#rotorRows + 1] = {"Tail RPM max", f(record.tailMax)} end
    local groups = {
      {"ROTOR", rotorRows},
      {"POWER", powerRows},
      {omp and "BATTERY" or (OPT.heliType == HELI_NITRO and "RECEIVER PACK" or "BEC"), {
        {omp and "Battery %" or "Voltage min",
          omp and f(record.batteryPct, "%.0f%%") or f(record.becMin, "%.2f V")}}},
      {"SYSTEM", {{omp and "Peak ESC Temp" or "ESC temp max", f(temp, "%.0f C")},
        {"MIN RQLY", f(record.rqlyMin, "%.0f%%")}}},
    }
    for i=1,4 do
      local index = i - 1
      local cx = x + margin + (index % 2) * (cardW + gap)
      local cy = cardsY + math.floor(index / 2) * (cardH + gap)
      local groupH = i <= 2 and cardH or cardsBottom - cy
      card(cx, cy, cardW, groupH)
      label(cx + 10, cy + 5, cardW - 20, groups[i][1], tableFont, C_ACCENT)
      local rowH = (groupH - 38) / #groups[i][2]
      for j,row in ipairs(groups[i][2]) do
        local ry = cy + 38 + (j-1) * rowH + math.floor((rowH - 29) / 2)
        local valueW = 140
        label(cx + 10, ry, cardW - valueW - 22, row[1], tableFont, C_DIM)
        label(cx + cardW - valueW - 10, ry, valueW, row[2], tableFont, C_TEXT, RIGHT)
      end
    end
    return true
  end
  function P.syncProfiles(widget)
    -- A new RF initialization still needs a battery snapshot/prompt, even
    -- if this widget missed the disconnected frame or the craft name matches.
    -- refresh/background clear F every callback, but telemetry is throttled
    -- to 10 Hz. Populate the name cache even when that telemetry tick skips.
    getModelName()
    local session = F.modelNameSession
    local newSession = session and widget.profileNameSession ~= session
    widget.profileNameSession = session
    if P.modelChanged or newSession then
      P.modelChanged = false
      batteryProfiles.reset(widget)
      batteryProfiles.flightSourceChanged(widget)
    end
  end
  function P.serviceProfiles(widget, allowUi, event, touchState)
    P.syncProfiles(widget)
    batteryProfiles.service(widget, allowUi and not P.state.visible, event, touchState)
  end
  function P.ui(widget, event)
    local s = P.state
    if s.visible and event ~= nil then
      if event == _G.EVT_VIRTUAL_EXIT or event == _G.EVT_EXIT_BREAK then
        P.dismiss(widget)
      end
    end
    if widget.debriefScene ~= (s.visible and s.record or nil) then P.rebuild(widget) end
    if s.visible and widget.debriefScene == s.record and not s.presented then
      -- Only foreground refresh, after current telemetry has been serviced,
      -- proves the recap was presented. Building a scene alone does not.
      s.presented = true
      P.watchTimer()
    end
  end
end

-- Local dashboard personalization; modules and disk reads occur only on context
-- changes or explicit editing. Idle dashboard getters remain allocation-free.
G.personal = {}
do
 local P=G.personal
 local ringIds={battery=1,rpm=2,current=3,temp=4}
 local tileIds={gov=1,bec=2,cell=3,capacity=4}
 local extraNames={tail="TAIL RPM",pack="PACK VOLTAGE",link="LINK QUALITY",timer="TIMER 1"}
 function P.defaults()
  -- Match buildLayout for every aircraft type. The editor must not replace
  -- visible tiles merely because this model has never saved a custom layout.
  if OPT.heliType==AIRCRAFT_FIXED_WING then
   return {"current","cell","bec","temp","empty","empty","capacity","battery"}
  end
  return {"gov","rpm","bec","temp","current","cell","capacity","battery"}
 end
 function P.supported(id)
  return OPT.heliType~=HELI_OMPHOBBY or (id~="gov" and id~="bec" and id~="tail")
 end
 -- Layout preferences never write flight-controller settings. Telemetry and
 -- RPM are intentionally not permissions here: airplanes may have neither.
 -- Retain model/scene identity checks so deferred callbacks cannot save a
 -- previous model's draft after navigation or a model change.
 function P.guard(wgt,force)
  if not wgt.fullScreen or not wgt.layout.touchHome then return false end
  getModelName()
  local key=F.modelFilename
  if not key or key~=wgt.personalKey or OPT.heliType~=wgt.personalType then return false end
  if force then
   local ok,info=pcall(model.getInfo)
   if not ok or not info or info.filename~=key then return false end
  end
  return true
 end
 function P.close(wgt,returnSettings)
  wgt.homeLayoutPending=nil
  wgt.homeSettingsRequested=returnSettings and lvgl and type(lvgl.isAppHost)=="function" and lvgl.isAppHost() or nil
  if wgt.layoutEditor then wgt.layoutEditor.retire();wgt.layoutEditor=nil;wgt.uiBuilt=false;wgt.personalRebuild=true end
  wgt.layoutEditorRequested=nil
 end
 function P.map(wgt)
  local l=wgt.layout
  if not l.touchHome then return end
  local values=wgt.personalValues
  if not values then return end
  l.rings,l.tiles={},{}
  for i=1,8 do
   local id=values[i];local r,t=ringIds[id],tileIds[id]
   if r then l.rings[r]=l.slots[i] elseif t then l.tiles[t]=l.slots[i]end
  end
 end
 function P.buildExtras(wgt)
  wgt.ui.personalExtras={}
  wgt.ui.radioTiles={}
  wgt.radioPaintCursor=1;wgt.deferRadioPaint=true
  if not wgt.layout.touchHome or not wgt.personalValues then return end
  for i=1,8 do
   local id=wgt.personalValues[i]
   if not ringIds[id] and not tileIds[id]
      and not (id=="empty" and OPT.heliType==AIRCRAFT_FIXED_WING)then
    local c=wgt.layout.slots[i]
    newPanel(wgt,c.x,c.y,c.w,c.h,C_PANEL_ALT,C_BORDER,6)
    if P.store and string.sub(id,1,1)=='@'then
     local binding=P.store.binding(id)
     local title=P.telemetry and P.telemetry.title(id,binding) or (binding.title~='' and binding.title or binding.name)
     local u={token=id,card=c}
     u.title=newLabel(wgt,c.x+10,c.y+3,c.w-20,title,G.fontSmall,C_DIM)
     u.value=newLabel(wgt,c.x+10,c.y+31,c.w-20,"--",G.fontTileValue,C_TEXT,RIGHT)
     u.unit=newLabel(wgt,c.x+10,c.y+c.h-29,c.w-20,"",G.fontSmall,C_DIM,RIGHT)
     u.track=newRect(wgt,c.x+10,c.y+c.h-5,c.w-20,3,C_TRACK,true,1,1)
     u.bar=newRect(wgt,c.x+10,c.y+c.h-5,1,3,C_GREEN,true,1,1)
     setVisible(wgt,u.track,false);setVisible(wgt,u.bar,false)
     wgt.ui.radioTiles[#wgt.ui.radioTiles+1]=u
    elseif id~="empty" then
     newLabel(wgt,c.x+10,c.y+3,c.w-20,extraNames[id],G.fontSmall,C_DIM)
     wgt.ui.personalExtras[id]=newLabel(wgt,c.x+10,c.y+31,c.w-20,"--",G.fontTileValue,C_TEXT,RIGHT)
    end
   end
  end
 end
 function P.updateExtras(wgt)
  for id,label in pairs(wgt.ui.personalExtras or {})do
   local value,valid
   if id=="tail" then value=tostring(math.floor(getTailRpm()));valid=D.tailRpmValid
   elseif id=="pack" then value=string.format("%.1fV",getPackVolt() or 0);valid=D.packVoltageValid
   elseif id=="link" then value=tostring(math.floor(getRqly())).."%";valid=A.linkAvailable
   elseif id=="timer" then value=formatTimer(getTimer1Secs());valid=true end
   setLabel(wgt,label,valid and value or "--",valid and C_TEXT or C_DIM)
  end
  if wgt.deferRadioPaint then wgt.deferRadioPaint=nil;return end
  local tiles=wgt.ui.radioTiles or {}
  for _=1,math.min(2,#tiles)do
   local index=wgt.radioPaintCursor or 1
   local u=tiles[index];wgt.radioPaintCursor=index%#tiles+1
   local text,unit,progress,valid='--','',nil,false
   if P.telemetry then text,unit,progress,valid=P.telemetry.read(u.token)end
   local combined=text..(unit~='' and ' '..unit or '')
   -- Short cards have one value row; taller cards have a separate unit row.
   local short=u.card.h<110
   local display=short and combined or text
   local font=G.fontTileValue
   if lcd.sizeText(display,font)>u.card.w-20 then font=G.fontSmall end
   if lcd.sizeText(display,font)>u.card.w-20 then
    local n=math.max(1,math.floor((u.card.w-30)/10));display=string.sub(display,1,n)..'…'
   end
   setObject(wgt,u.value,{text=display,font=font,color=valid and C_TEXT or C_DIM})
   setLabel(wgt,u.unit,short and '' or unit,C_DIM)
   setVisible(wgt,u.track,progress~=nil);setVisible(wgt,u.bar,progress~=nil and progress>0)
   if progress then setObject(wgt,u.bar,{w=math.max(1,math.floor((u.card.w-20)*progress)),color=C_GREEN})end
  end
 end
 function P.service(wgt,event)
  if not wgt.fullScreen or not wgt.layout.touchHome or G.debrief.state.visible then P.close(wgt);return false end
  getModelName()
  local key=F.modelFilename
  if wgt.personalKey~=key or wgt.personalType~=OPT.heliType then
   local hadLayout=wgt.personalValues~=nil
   local requested=wgt.homeLayoutPending
   P.close(wgt);wgt.homeLayoutPending=requested==key and requested or nil
   wgt.personalKey=key;wgt.personalType=OPT.heliType
   wgt.personalValues=nil;wgt.personalLoaded=nil;P.telemetry=nil;P.telemetryUnavailable=nil;wgt.personalRadio=nil
   if hadLayout then
    wgt.layout=buildLayout(wgt.zone,wgt.fullScreen or wgt.appMode);wgt.uiBuilt=false;wgt.personalRebuild=true
   end
  end
  if not P.store then
   if P.unavailable then return false end
   local chunk=loadScript and loadScript('/SCRIPTS/RF2/F/modelPreferences.lua')
   if chunk then P.store=chunk()else P.unavailable=true end
   return true
  end
  if not wgt.personalLoaded then
   local values,revision,err=P.store.load(key,'layout'..OPT.heliType)
   wgt.personalValues,wgt.personalRevision,wgt.personalError=values,revision,err
   wgt.personalRadio=values and string.find(table.concat(values),"@",1,true)~=nil
   wgt.personalLoaded=true
   if values then wgt.uiBuilt=false;wgt.personalRebuild=true end
   return true
  end
  if wgt.homeLayoutPending then
   local requested=wgt.homeLayoutPending;wgt.homeLayoutPending=nil
   if requested==key then wgt.layoutEditorRequested=true end
  end
  local generic=wgt.personalRadio
  if (generic or wgt.layoutEditorRequested or wgt.layoutEditor) and not P.telemetry and not P.telemetryUnavailable then
   local chunk=loadScript('/WIDGETS/KSETouch/telemetryTiles.lua')
   if chunk then P.telemetry=chunk()(P.store)else P.telemetryUnavailable=true end
   return true
  end
  if P.telemetry and P.telemetry.needsScan and frameNow()-(P.telemetry.scannedAt or 0)>=500 then
   P.telemetry.restart();P.telemetry.scannedAt=frameNow()
  end
  if P.telemetry and not P.telemetry.complete then P.telemetry.step()end
  if wgt.layoutEditor then
   local editor=wgt.layoutEditor
   if (event==_G.EVT_VIRTUAL_EXIT or event==_G.EVT_EXIT_BREAK) and not editor.back()then
    P.close(wgt,true)
   elseif not editor.tick()then P.close(wgt,editor.returnSettings)end
   return true
  end
  if wgt.layoutEditorRequested then
   wgt.layoutEditorRequested=nil
   local allowed,reason=P.guard(wgt,true)
   if not allowed or wgt.profileDialog or wgt.profileBusy then
    G.touch.notice(wgt,reason or 'Layout locked: finish the battery operation first');return false
   end
   if wgt.personalError then G.touch.notice(wgt,wgt.personalError);return false end
   local chunk=loadScript('/WIDGETS/KSETouch/layoutEditor.lua')
   if not chunk then G.touch.notice(wgt,'Dashboard editor unavailable');return false end
   local kind='layout'..OPT.heliType
   local editor=chunk()
   wgt.layoutEditor=editor({integrated=lvgl and type(lvgl.isAppHost)=="function" and lvgl.isAppHost(),small=G.fontSmall,bold=BOLD_FONT,large=G.fontTileValue,
    colors={bg=C_BG,panel=C_PANEL_ALT,text=C_TEXT,dim=C_DIM,accent=C_ACCENT,accentText=C_BG,warning=C_ORANGE},
    guard=function()return P.guard(wgt,true)end,defaults=P.defaults,supported=P.supported,
    telemetry=P.telemetry,store=P.store,
    prepare=function(values,revision)
     if not P.guard(wgt,true)then return nil,'Dashboard model changed; reopen layout' end
     local commit,reason=P.store.prepare(key,kind,values,revision,function()return P.guard(wgt,true)end)
     if not commit then return nil,reason end
     return function()
      local ok,result=commit()
      if ok and P.guard(wgt,true)then
       wgt.personalValues=values;wgt.personalRevision=result
       wgt.personalRadio=string.find(table.concat(values),"@",1,true)~=nil
      end
      return ok,result
     end
    end},wgt.personalValues or P.defaults(),wgt.personalRevision)
   return true
  end
  return false
 end
end

local function buildUi(wgt)
  if G.debrief.state.visible and wgt.profileDialog
     and type(wgt.profileDialog.close) == "function" then
    pcall(wgt.profileDialog.close, wgt.profileDialog)
    wgt.profileDialog = nil
  end
  if not lvgl then wgt.uiBuilt = false; return end
  lvgl.clear()
  wgt.profileDialog = nil
  wgt.ui = {}
  wgt.objectState = {}
  if G.debrief.build(wgt) then
    wgt.uiBuilt = true
    return
  end
  if not OPT.bgTransparent and not OPT.hasBackground then
    newRect(wgt, wgt.layout.x, wgt.layout.y, wgt.layout.w,
            wgt.layout.h, C_BG, true, 0, 1)
  end
  G.personal.map(wgt)
  buildTopBar(wgt)
  buildRingCards(wgt)
  buildLowerDashboard(wgt)
  if OPT.heliType ~= HELI_OMPHOBBY then
    local bannerY = wgt.layout.top.y + wgt.layout.top.h
    local bannerH = math.max(20, G.y(22))
    local bannerInset = math.max(5, G.x(5))
    local armingBanner = {
      fill=newRect(wgt, wgt.layout.x + bannerInset, bannerY,
                   wgt.layout.w - bannerInset * 2, bannerH, C_RED, true,
                   math.max(2, G.min(3)), 1),
      border=newRect(wgt, wgt.layout.x + bannerInset, bannerY,
                     wgt.layout.w - bannerInset * 2, bannerH,
                     C_YELLOW, false, math.max(2, G.min(3)), 1),
      label=newLabel(wgt, wgt.layout.x + bannerInset * 2,
                     bannerY + math.max(3, G.y(4)),
                     wgt.layout.w - bannerInset * 4, "", G.fontSmall,
                     C_TEXT, CENTERED),
    }
    armingBanner.objects = {
      armingBanner.fill, armingBanner.border, armingBanner.label,
    }
    wgt.ui.armingBanner = armingBanner
    for _, object in ipairs(armingBanner.objects) do
      setVisible(wgt, object, false)
    end
  end
  buildProfileEntryPrompt(wgt)
  G.touch.build(wgt)
  if OPT.simTelemetry then applySimulatedTelemetry(G.debrief.state.simClock or frameNow()) end
  wgt.uiBuilt = true
  updateUiState(wgt)
end

G.debrief.rebuild = buildUi

local function ensureLayout(wgt, fullScreen, appMode)
  local presentation = fullScreen or appMode
  local x, y, w, h = G.bounds(wgt.zone, presentation)
  local signature = G.signature(x, y, w, h)
  if wgt.layoutSignature == signature and wgt.fullScreen == fullScreen and wgt.appMode == appMode then return false end
  wgt.fullScreen = fullScreen
  wgt.appMode = appMode
  wgt.layout = buildLayout(wgt.zone, presentation)
  wgt.layoutSignature = signature
  buildUi(wgt)
  return true
end

local function refresh(widget, event, touchState)
  if not widget then return end
  G.pollImageRefresh(widget)
  clearFrameCache()
  G.touch.modelGuard(widget)
  if lvgl and type(lvgl.takeAppHome)=="function" and lvgl.takeAppHome() then
    if widget.touchRfHost then
      widget.homeExitRequested=true
    else
      widget.touchRequested,widget.touchRequestedModel=nil,nil
      widget.homeSettingsRequested=nil
      G.personal.close(widget) -- retires pending layout saves and discovery
      widget.profileAutoShown=true
      local dialog=widget.profileDialog
      widget.profileDialog=nil
      if dialog and type(dialog.close)=="function" then pcall(dialog.close,dialog) end
      if G.debrief.state.visible then G.debrief.hide();widget.uiBuilt=false end
    end
  end
  -- Consume a completed tap before servicing dashboard/profile actions. The
  -- debrief has no buttons: its native widget receives taps across the scene.
  -- Rebuild only from refresh (after release), never inside an LVGL callback.
  local review = G.debrief.state
  local closeRequested = widget.debriefCloseRequested
  widget.debriefCloseRequested = nil
  if ((EVT_TOUCH_TAP and event == EVT_TOUCH_TAP) or (closeRequested and closeRequested == review.record))
     and review.visible and review.presented
     and widget.debriefScene == review.record then
    widget.touchRequested, widget.touchRequestedModel = nil, nil
    G.debrief.dismiss(widget, true)
    if G.companion.active then review.simPaused = false end
    return
  end
  if widget.homeExitRequested then
    if not widget.touchRfHost or _G.rf2~=widget.touchRfCore then widget.homeExitRequested=nil
    elseif type(_G.rf2.requestDashboardExit)=="function" and
        (type(_G.rf2.canExitToDashboard)~="function" or _G.rf2.canExitToDashboard()) then
      widget.homeExitRequested=nil
      _G.rf2.requestDashboardExit() -- finish saves first; retain unsaved/override guards
    end
  end
  local serviced
  if OPT.simTelemetry then
    serviced = serviceSimulation(widget)
  else
    serviced = serviceTelemetry(true)
  end
  if G.touch.runRf(widget,event,touchState) then return end
  -- Full owns navigation. Local editors/popups finish before new routes may
  -- open; legacy App mode keeps its existing registration behavior.
  if lvgl and type(lvgl.isAppHost)=="function" and lvgl.isAppHost() then
    lvgl.registerApp(not widget.homeLayoutPending and not widget.layoutEditor and not widget.layoutEditorRequested
      and not widget.profileBusy and not widget.profileDialog and not G.debrief.state.visible and 1 or 0)
  end
  if not widget.layoutEditor and not widget.profileBusy and not G.debrief.state.visible then
    local linked=G.appearanceLinked()
    local version=(linked or OPT.themeName=="radio") and type(getRadioThemeVersion)=="function" and getRadioThemeVersion() or OPT.themeRevision
    if linked~=OPT.themeLinked or version~=OPT.themeRevision then
      G.applyAppearance(widget.options)
      widget.uiBuilt=false;widget.personalRebuild=true
    end
  end
  local returningFromRf = widget.touchRfReturning
  widget.touchRfReturning = nil
  local rebuilt = ensureLayout(widget, event ~= nil, lvgl and type(lvgl.isAppMode)=="function" and lvgl.isAppMode() or false)
  if not widget.uiBuilt then buildUi(widget); rebuilt = true end
  if rebuilt and widget.personalRebuild then
    widget.personalRebuild=nil
    G.debrief.ui(widget,event)
    return -- The rebuilt dashboard already consumed this frame's telemetry.
  end
  if widget.homeSettingsRequested and not widget.layoutEditor and widget.uiBuilt then
    widget.homeSettingsRequested=nil
    if type(lvgl.openHomeSettings)=="function" then lvgl.openHomeSettings() end
    return
  end
  -- Reconnect/profile reads can be expensive too. Finish the first dashboard
  -- frame before resuming them, rather than spending its budget twice.
  if returningFromRf or rebuilt then
    G.debrief.syncProfiles(widget) -- Retire old session callbacks before yielding.
    G.debrief.serviceSwitch()
    G.debrief.watchTimer()
    G.debrief.ui(widget, event)
    return
  end
  if widget.layoutEditor or widget.layoutEditorRequested then
    if G.personal.service(widget,event) then return end
  end
  G.debrief.serviceSwitch()
  G.debrief.watchTimer()
  G.debrief.serviceProfiles(widget, true, event, touchState)
  -- Connection initialization can persist the model-name recovery setting.
  -- Finish that pass before doing more profile/display work. If it retired a
  -- dialog, remove stale native callbacks now and rebuild on the next refresh.
  local used = getCurrentUsage and getCurrentUsage()
  if used and used >= 60 then
    if not widget.uiBuilt then lvgl.clear() end
    return
  end
  G.touch.action(widget)
  if widget.touchRfHost then return end
  -- Profile service can close a dialog on disconnect or session changes.
  -- Retire its native wrapper and redraw the current connection state before
  -- returning to EdgeTX's reference callbacks.
  if not widget.uiBuilt then buildUi(widget); rebuilt = true end
  -- Telemetry service can retire the recap on a model change or reconnect.
  -- Build the new scene before accessing dashboard-only objects/geometry.
  G.debrief.ui(widget, event)
  if serviced and not G.debrief.state.visible then
    -- buildUi already applied the sampled telemetry. Profile service may have
    -- updated flight/arming status afterward; only that panel needs another pass.
    if rebuilt then updateLowerDashboard(widget,true) else updateUiState(widget) end
  end
  if widget.ui.touchNotice then
    local visible = widget.touchNoticeUntil and frameNow()<widget.touchNoticeUntil
    setLabel(widget,widget.ui.touchNotice,widget.touchNotice or "",C_YELLOW)
    setVisible(widget,widget.ui.touchNotice,not not visible)
    setVisible(widget,widget.ui.touchNoticePanel,not not visible)
  end
  -- Load preferences after a completed, inexpensive dashboard frame. Critical
  -- debrief/profile/switch servicing keeps its established first-frame order.
  local prefsUsage=getCurrentUsage and getCurrentUsage()
  if not rebuilt and (not prefsUsage or prefsUsage<60) then
    G.personal.service(widget,event)
  end
end

local function background(widget)
  if not widget then return end
  G.pollImageRefresh(widget)
  clearFrameCache()
  G.touch.modelGuard(widget)
  if widget.touchRfHost and lvgl and type(lvgl.appNumberActive)=="function" and lvgl.appNumberActive() then
    local host=widget.touchRfHost
    local ok,serviced=pcall(host.serviceEmbeddedEditor,host,widget)
    if ok and serviced then return end
    if type(lvgl.cancelAppNumber)=="function" then lvgl.cancelAppNumber() end
  end
  if widget.touchRfHost then G.touch.closeRf(widget) end
  widget.touchRequested = nil
  G.personal.close(widget)
  if OPT.simTelemetry then
    serviceSimulation(widget)
  else
    serviceTelemetry(true)
  end
  G.debrief.serviceSwitch()
  G.debrief.watchTimer()
  G.debrief.serviceProfiles(widget, false, nil, nil)
end

local function create(zone, options)
  clearFrameCache()
  applyOptions(options)
  G.debrief.reset()
  if OPT.flightCounter ~= FC.ROTORFLIGHT then
    loadModelFlights()
  else
    flightModel = modelKey(getAircraftName())
    modelFlights = 0
    timerThresholdArmed = nil
    resetSessionStats()
    resetSessionEvidence()
  end
  local widget = {
    zone=zone,
    options=options or {},
    layout=buildLayout(zone, false),
    uiBuilt=false,
    lastSimTick=-1,
    profileWasConnected=false,
    profileConnectedForDisplay=false,
    profileAutoShown=false,
    profileBusy=false,
  }
  widget.layoutSignature = widget.layout.signature
  batteryProfiles.flightSourceChanged(widget)
  return widget
end

local function update(widget, options)
  G.personal.close(widget)
  widget.personalKey = nil
  if widget.touchRfHost then G.touch.closeRf(widget) end
  widget.touchRequested = nil
  widget.options = options or {}
  local previousOmpPack = OPT.ompPack
  local previousFwSource, previousFwCells = OPT.fwVoltageSource, OPT.fwCells
  local previousHeliType = OPT.heliType
  local previousReserve = OPT.reservePct
  local previousRxMin = OPT.rxPackMin
  local previousRxMax = OPT.rxPackMax
  local previousRxValid = OPT.rxPackValid
  local previousMotorSource = SRC.motorSwitch
  local previousSim = OPT.simTelemetry
  local previousFlightCounter = OPT.flightCounter
  applyOptions(options)
  local heliChanged = previousHeliType ~= OPT.heliType or previousOmpPack ~= OPT.ompPack
  local reserveChanged = previousReserve ~= OPT.reservePct
  local fwBatteryChanged = previousFwSource ~= OPT.fwVoltageSource or previousFwCells ~= OPT.fwCells
  local rxSettingsChanged = previousRxMin ~= OPT.rxPackMin
                            or previousRxMax ~= OPT.rxPackMax
                            or previousRxValid ~= OPT.rxPackValid
  local motorChanged = previousMotorSource ~= SRC.motorSwitch
  local simChanged = previousSim ~= OPT.simTelemetry
  local flightCounterChanged = previousFlightCounter ~= OPT.flightCounter
  if heliChanged or simChanged or flightCounterChanged then G.debrief.reset() end
  if heliChanged or simChanged then
    resetSessionStats()
    resetSessionEvidence()
  else
    if reserveChanged or fwBatteryChanged then
      resetBatteryAlertState("flight")
      A.displayPercent = 0
      A.displayPercentInit = false
    end
    if fwBatteryChanged then S.cellMin, D.minCellVoltage = nil, nil end
    if rxSettingsChanged then resetBatteryAlertState("rx") end
  end
  if motorChanged then
    resetMotorAlertGate(frameNow())
    if A.flightDeadVoiceLatched and not A.flightDeadVoiceAcknowledged then
      A.flightDeadVoiceStartPosition = nil
    end
    if A.rxDeadVoiceLatched and not A.rxDeadVoiceAcknowledged then
      A.rxDeadVoiceStartPosition = nil
    end
  end
  if heliChanged or reserveChanged or fwBatteryChanged or simChanged then D.hasBattData = false end
  if heliChanged or rxSettingsChanged or simChanged then
    D.rxVoltage, D.rxCellVoltage, D.rxPercent = nil, nil, 0
  end
  if simChanged then
    timerThresholdArmed = nil
    widget.lastSimTick = -1
  end
  if flightCounterChanged then
    if OPT.flightCounter ~= FC.ROTORFLIGHT then
      loadModelFlights()
    else
      flightModel = modelKey(getAircraftName())
      timerThresholdArmed = nil
    end
    batteryProfiles.flightSourceChanged(widget)
  end
  if heliChanged or simChanged then batteryProfiles.reset(widget) end
  A.lastDataTick = -1
  clearFrameCache()
  widget.fullScreen = false
  widget.layout = buildLayout(widget.zone, false)
  widget.layoutSignature = widget.layout.signature
  buildUi(widget)
end

local options = {
  { "Theme",     CHOICE, 1, {
      "Dark",
      "Light",
      "Arctic Blue",
      "Orange",
      "Red",
      "Blue",
      "Pink",
      "Purple",
      "Graphite",
      "Sunset",
      "Synthwave",
      "Voltage",
      "Titanium Ember",
      "Transparent",
      "Obsidian",
      "Copper",
      "Amethyst",
      "Follow radio theme",
    } },
  { "TxBatt",    CHOICE, 1, { "LiPo", "Li-Ion" } },
  { "MinFlight", VALUE, TOPBAR_MIN_DUR_DEFAULT, -30, 120 },
  { "HeliType",  CHOICE, 1, { "Electric", "Nitro", "OMPHOBBY", "Fixed Wing" } },
  { "BattRsv",   VALUE, 20, 0, 50 },
  { "BattVoice", BOOL, 0 },
  { "RxPackMin", STRING, "6.60" },
  { "RxPackMax", STRING, "8.40" },
  { "MotorSw",   SOURCE, (function()
      local info = type(getFieldInfo) == "function" and getFieldInfo("SG") or nil
      return type(info) == "table" and info.id or 0
    end)() },
  { "CountSrc",  CHOICE, 2,
    { "KSE Counter", "RotorFlight", "Simulate Telemetry" } },
  { "DebriefSw", SOURCE, 0 },
  { "OmpPack", CHOICE, 1, { "Auto (model name)", "M1 / 2S LiHV", "M2 / 3S LiPo" } },
  -- Append only: existing saved widget option positions remain unchanged.
  { "FwVolt", SOURCE, 0 },
  { "FwCells", CHOICE, 1, { "From sensor", "1S", "2S", "3S", "4S", "5S", "6S", "7S", "8S", "9S", "10S", "11S", "12S", "13S", "14S", "15S", "16S" } },
}

local OPTION_LABELS = {
  FwVolt = "Battery voltage",
  FwCells = "Battery cells",
  OmpPack = "OMP Battery",
  DebriefSw = "Debrief Switch",
  TxBatt="TX Battery",
  MinFlight="KSE Counter Min (sec)",
  HeliType="Aircraft Type",
  BattRsv="Battery Reserve %",
  BattVoice="Battery Voice",
  RxPackMin="Rx Pack Minimum",
  RxPackMax="Rx Pack Maximum",
  MotorSw="Motor Switch",
  CountSrc="Flight Counter",
}

local function translate(name, language)
  return OPTION_LABELS[name] or name
end

return {
  name="KSE Touch",
  options=options,
  create=create,
  update=update,
  background=background,
  refresh=refresh,
  translate=translate,
  useLvgl=true,
}
