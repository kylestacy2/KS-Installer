-- Read-only EdgeTX telemetry adapter. Catalog work is bounded to four slots
-- per tick; only selected sources are sampled on the dashboard. No MSP or IO.
return function(store)
 local T={entries={},byKey={},cursor=0,complete=false,bindings={},revision=0}
 local pendingEntries,pendingByKey={},{}
 local max=tonumber(MAX_SENSORS)or 75
 T.maximum=math.min(128,math.max(0,math.floor(max)))
 local units={[0]='',[1]='V',[2]='A',[3]='mA',[4]='kt',[5]='m/s',[6]='ft/s',[7]='km/h',[8]='mph',
  [9]='m',[10]='ft',[11]='°C',[12]='°F',[13]='%',[14]='mAh',[15]='W',[16]='mW',[17]='dB',
  [18]='RPM',[19]='g',[20]='°',[21]='rad',[22]='mL',[23]='fl oz',[24]='mL/min',[25]='Hz',
  [26]='ms',[27]='µs',[28]='km',[29]='dBm',[35]='h',[36]='min',[37]='s'}
 local CELLS,DATETIME,GPS,BITS,TEXT=UNIT_CELLS or 38,UNIT_DATETIME or 39,UNIT_GPS or 40,UNIT_BITFIELD or 41,UNIT_TEXT or 42
 local function finite(v)return type(v)=='number' and v==v and v>-math.huge and v<math.huge end
 local function clean(s,limit)
  if type(s)~='string'then return ''end
  return string.sub(string.gsub(s,'[%z\1-\31\127]',' '),1,limit or 48)
 end
 local function metadata(slot)
  if not model or type(model.getSensor)~='function'then return end
  local ok,sensor=pcall(model.getSensor,slot)
  if not ok then return end
  local valid,key=pcall(store.sensorKey,sensor)
  if valid and key then return sensor,key end
 end
 function T.unitName(unit)return units[unit]or(unit==TEXT and 'Text' or unit==GPS and 'GPS' or unit==CELLS and 'Cells' or unit==DATETIME and 'Date/time' or unit==BITS and 'Bits' or 'Unit '..tostring(unit))end
 function T.restart()
  pendingEntries={};pendingByKey={};T.cursor=0;T.complete=false;T.bindings={};T.needsScan=nil;T.bindingCount=0;T.error=nil
 end
 function T.step()
  if T.complete then return false end
  if not model or type(model.getSensor)~='function'then T.complete=true;T.error='Telemetry catalog unavailable';return true end
  local batch
  if model and type(model.getSensors)=='function' and T.cursor<T.maximum then
   local ok,result=pcall(model.getSensors,T.cursor,math.min(4,T.maximum-T.cursor))
   if ok and type(result)=='table' then batch=result end
  end
  for batchIndex=1,4 do
   if T.cursor>=T.maximum then break end
   local slot=T.cursor;T.cursor=slot+1
   local sensor,key
   if batch then
    sensor=batch[batchIndex]
    local ok,result=pcall(store.sensorKey,sensor);if ok then key=result end
   else sensor,key=metadata(slot) end
   if key then
    local entry={key=key,slot=slot,name=clean(sensor.name,4),unit=sensor.unit,prec=sensor.prec}
    entry.sort=string.lower(entry.name)
    if sensor and type(sensor.source)=='number' then entry.source=sensor.source
    else
     local info=getFieldInfo and getFieldInfo('telem'..(slot+1))
     entry.source=info and type(info.id)=='number' and info.id or nil
    end
    pendingEntries[#pendingEntries+1]=entry
    if pendingByKey[key]~=nil then pendingByKey[key]=false else pendingByKey[key]=entry end
   end
  end
  if T.cursor>=T.maximum then
   table.sort(pendingEntries,function(a,b)if a.sort==b.sort then return a.slot<b.slot end;return a.sort<b.sort end)
   T.entries,T.byKey=pendingEntries,pendingByKey
   T.complete=true;T.revision=T.revision+1
  end
  return true
 end
 function T.views(unit)
  if unit==GPS then return {{1,'Latitude'},{2,'Longitude'},{3,'Pilot latitude'},{4,'Pilot longitude'}}end
  if unit==DATETIME then return {{1,'Date'},{2,'Time'}}end
  if unit==CELLS then
   local views={{1,'Lowest cell'},{2,'Highest cell'},{3,'Pack total'},{4,'Cell count'}}
   for i=1,18 do views[#views+1]={16+i,'Cell '..i}end
   return views
  end
  if unit==TEXT or unit==BITS then return {{0,unit==TEXT and 'Text' or 'Bitfield'}}end
  return {{0,'Current value'},{1,'Radio minimum'},{2,'Radio maximum'}}
 end
 function T.defaultView(unit)return (unit==GPS or unit==DATETIME or unit==CELLS)and 1 or 0 end
 function T.title(token,binding)
  local b=binding or store.binding(token);if not b then return 'Sensor'end
  if b.title~=''then return clean(b.title,8)end
  local suffix=''
  for _,view in ipairs(T.views(b.unit))do if view[1]==b.view and b.view>0 then
   if b.unit==GPS then suffix=({' lat',' lon',' P.lat',' P.lon'})[b.view]
   elseif b.unit==DATETIME then suffix=b.view==1 and ' date'or' time'
   elseif b.unit==CELLS then suffix=({[1]=' min',[2]=' max',[3]=' total',[4]=' count'})[b.view]or' C'..(b.view-16)
   else suffix=b.view==1 and ' min'or' max'end
   break
  end end
  return clean(b.name,4)..suffix
 end
 function T.read(token)
  local b=T.bindings[token]
  if not b then
   b=store.binding(token);if not b then return '--','',nil,false end
   T.bindingCount=(T.bindingCount or 0)+1
   if T.bindingCount>16 then T.bindings={};T.bindingCount=1 end
   T.bindings[token]=b
  end
  if not T.complete then return '--','',nil,false end
  local entry=T.byKey[b.key]
  if not entry or not entry.source then T.needsScan=true;return '--','',nil,false end
  local _,key=metadata(entry.slot)
  if key~=b.key then T.needsScan=true;return '--','',nil,false end
  local special=b.unit==CELLS or b.unit==GPS or b.unit==DATETIME or b.unit==TEXT or b.unit==BITS
  local source=entry.source+(not special and (b.view==1 or b.view==2)and b.view or 0)
  local ok,v,current=pcall(getSourceValue,source)
  if not ok or current~=true or v==nil then return '--','',nil,false end
  local unit,prec=b.unit,b.prec
  if unit==TEXT then if type(v)~='string'then return '--','',nil,false end;return clean(v,48),'',nil,true end
  if unit==GPS then
   if type(v)~='table'then return '--','',nil,false end
   v=v[({[1]='lat',[2]='lon',[3]='pilot-lat',[4]='pilot-lon'})[b.view]or'']
   unit,prec=20,5
  elseif unit==DATETIME then
   if type(v)~='table'then return '--','',nil,false end
   local a,c,d=v.year,v.mon,v.day
   if b.view==2 then a,c,d=v.hour,v.min,v.sec end
   if not finite(a)or not finite(c)or not finite(d)then return '--','',nil,false end
   if a%1>0 or c%1>0 or d%1>0 then return '--','',nil,false end
   if b.view==2 then
    if a<0 or a>23 or c<0 or c>59 or d<0 or d>60 then return '--','',nil,false end
   elseif a<0 or a>9999 or c<1 or c>12 or d<1 or d>31 then return '--','',nil,false end
   if b.view==2 then return string.format('%02d:%02d:%02d',a,c,d),'',nil,true end
   return string.format('%04d-%02d-%02d',a,c,d),'',nil,true
  elseif unit==CELLS then
   if type(v)~='table' or #v==0 or #v>18 then return '--','',nil,false end
   local result=b.view==1 and math.huge or b.view==2 and -math.huge or 0
   for i=1,#v do
    if not finite(v[i])or v[i]<=0 then return '--','',nil,false end
    if b.view==1 then result=math.min(result,v[i])elseif b.view==2 then result=math.max(result,v[i])else result=result+v[i]end
   end
   if b.view==4 then result=#v;unit,prec=0,0
   else if b.view>16 then result=v[b.view-16]end;unit,prec=1,2 end
   v=result
  elseif unit==BITS then
   if not finite(v)or v<-2147483648 or v>=2147483648 or v%1>0 then return '--','',nil,false end
   return string.format('0x%08X',math.floor(v)),'',nil,true
  end
  if not finite(v)then return '--','',nil,false end
  if b.override~=255 then unit=b.override end
  local text
  if math.abs(v)>=1000000 then text=string.format('%.3g',v)else text=string.format('%.'..prec..'f',v)end
  local progress=unit==13 and math.max(0,math.min(100,v))/100 or nil
  return text,units[unit]or'',progress,true
 end
 return T
end
